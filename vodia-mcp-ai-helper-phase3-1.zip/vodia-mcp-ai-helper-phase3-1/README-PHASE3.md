# Vodia MCP Phase 3 — AI Helper / Workflow Layer

This patch adds a high-level workflow layer without removing the existing low-level MCP tools.

New tools:
- `pbx_ai_get_workflow_catalog`
- `pbx_ai_prepare_workflow`

The helper follows a common operational pattern:

`DISCOVER → RECOMMEND → CHOICES → PLAN → APPROVAL → APPLY → VERIFY → REPORT`

The workflow catalog covers:
- Amazon Chime
- SIP trunks
- extensions/users
- phone provisioning
- DIDs
- dial plans
- queues/ACD
- IVR
- voicemail
- call/SIP/audio troubleshooting
- registration troubleshooting
- CDR/reporting
- system health
- backup/upgrade/maintenance
- DNS/certificates

For Amazon Chime, `pbx_ai_prepare_workflow` performs live read-only discovery:
- region recommendation/validation
- existing Voice Connector lookup
- phone-number inventory
- recommended setup choices

No new write permission is introduced by Phase 3. Existing guarded plan/apply tools remain authoritative.

Example client prompt:

`Prepare an AI workflow to set up Amazon Chime for tenant vodiatech.audiomercy.com in the United States. Show me the recommended choices and make no changes.`

The AI should present the returned choices to the user instead of forcing the user to know individual AWS/Vodia tool names.

#!/usr/bin/env bash
set -Eeuo pipefail

APP_DIR="/opt/vodia-mcp"
BACKUP="/var/backups/vodia-mcp-ai-helper-phase3-1-$(date +%Y%m%d-%H%M%S)"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

[[ ${EUID} -eq 0 ]] || { echo "Run: sudo bash apply-ai-helper-phase3-1.sh"; exit 1; }
[[ -f "$APP_DIR/index.js" ]] || { echo "Missing $APP_DIR/index.js"; exit 1; }
[[ -f "$APP_DIR/aws-chime.js" ]] || { echo "Phase 2B/3 must be installed first."; exit 1; }

echo "[1/5] Backup..."
mkdir -p "$BACKUP"
cp -a "$APP_DIR/index.js" "$BACKUP/index.js"
cp -a "$APP_DIR/aws-chime.js" "$BACKUP/aws-chime.js"
[[ -f "$APP_DIR/workflow-helper.js" ]] && cp -a "$APP_DIR/workflow-helper.js" "$BACKUP/workflow-helper.js"

echo "[2/5] Install Phase 3.1..."
install -m 0644 "$HERE/index.js" "$APP_DIR/index.js"
install -m 0644 "$HERE/aws-chime.js" "$APP_DIR/aws-chime.js"
install -m 0644 "$HERE/workflow-helper.js" "$APP_DIR/workflow-helper.js"

echo "[3/5] Syntax checks..."
node --check "$APP_DIR/index.js"
node --check "$APP_DIR/aws-chime.js"
node --check "$APP_DIR/workflow-helper.js"

echo "[4/5] Restart..."
systemctl restart vodia-mcp
systemctl is-active --quiet vodia-mcp

echo "[5/5] Complete. Backup: $BACKUP"
echo
echo "Phase 3.1 changes:"
echo "  - Amazon Chime phone-number maxResults capped at 99"
echo "  - AI workflow returns BLOCKED/READY status"
echo "  - Blocked workflows must not present partial write plans as ready for approval"

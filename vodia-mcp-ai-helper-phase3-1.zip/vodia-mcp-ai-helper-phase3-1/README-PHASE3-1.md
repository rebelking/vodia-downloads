# Vodia MCP Phase 3.1 — AI Helper reliability patch

Fixes two issues found during a live Amazon Chime workflow test.

## 1. AWS phone-number pagination limit
All internal Chime phone-number inventory/order discovery now caps `MaxResults` at 99.

## 2. Workflow dependency gating
`pbx_ai_prepare_workflow` now returns:
- `workflowStatus`
- `blockers`
- `canPlanWrites`
- `canApplyWrites`
- `applyGate`

If prerequisites fail, the workflow is marked `BLOCKED`. The AI should resolve blockers before creating or presenting partial AWS/Vodia write plans as ready for approval.

The workflow pattern remains:

`DISCOVER → RECOMMEND → CHOICES → PLAN → APPROVAL → APPLY → VERIFY → REPORT`

## Test
Ask:

`Prepare Amazon Chime setup for tenant vodiatech.audiomercy.com in the United States. Show blockers and choices. Do not make changes.`

Then verify phone-number inventory/search no longer fails on `maxResults=100`.

import http from "node:http";
import { spawn } from "node:child_process";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StreamableHTTPClientTransport } from "@modelcontextprotocol/sdk/client/streamableHttp.js";

let pcapEnabled = false;
let createdAccount = null;
let trunkConfig = { id: "4", name: "Original trunk", proxy: "sip:old.example.com", reg_password: "must-redact" };
let dialPlans = [{ name: "Default", value: "1", inuse: true }];
let nextDialPlanId = 2;
let activeCallReads = 0;
let activeCalls = [
  { id: "live-call-1", from: "2010", to: "2009", state: "holding", now: 100 },
  { id: "live-call-2", from: "2011", to: "2009", state: "connected", now: 100 },
];
const callActions = [];
function testPcap() {
  const sip = Buffer.from("INVITE sip:2037@remote.example.com SIP/2.0\r\nCall-ID: call-1\r\nCSeq: 1 INVITE\r\nAuthorization: Digest hidden\r\nContent-Length: 0\r\n\r\n", "latin1");
  const globalHeader = Buffer.alloc(24);
  globalHeader.writeUInt32LE(0xa1b2c3d4, 0);
  globalHeader.writeUInt16LE(2, 4);
  globalHeader.writeUInt16LE(4, 6);
  globalHeader.writeUInt32LE(65535, 16);
  globalHeader.writeUInt32LE(1, 20);
  const record = Buffer.alloc(16);
  record.writeUInt32LE(1_786_200_000, 0);
  record.writeUInt32LE(sip.length, 8);
  record.writeUInt32LE(sip.length, 12);
  return Buffer.concat([globalHeader, record, sip]);
}

const mockPbx = http.createServer((request, response) => {
  response.setHeader("content-type", "application/json");
  const decodedUrl = decodeURIComponent(request.url);
  if (request.url === "/rest/system/status") {
    return response.end(JSON.stringify({ status: "ok", password: "must-redact" }));
  }
  if (request.url === "/rest/system/domains") {
    return response.end(JSON.stringify([{ name: "remote.example.com" }]));
  }
  if (request.url === "/rest/domain/remote.example.com/user_settings/2037" && request.method === "GET") {
    return response.end(JSON.stringify({ extension: "2037", pcap: pcapEnabled ? "true" : "" }));
  }
  if (request.url === "/rest/domain/remote.example.com/user_settings/2037" && request.method === "POST") {
    let body = "";
    request.on("data", (chunk) => { body += chunk; });
    return request.on("end", () => {
      pcapEnabled = JSON.parse(body).pcap === "true";
      response.end(JSON.stringify({ ok: true }));
    });
  }
  if (request.url === "/rest/domain/remote.example.com/addacc" && request.method === "POST") {
    let body = "";
    request.on("data", (chunk) => { body += chunk; });
    return request.on("end", () => {
      createdAccount = JSON.parse(body);
      response.end(JSON.stringify({ ok: true }));
    });
  }
  if (request.url === "/rest/domain/remote.example.com/edit_trunk/4" && request.method === "GET") {
    return response.end(JSON.stringify(trunkConfig));
  }
  if (request.url === "/rest/domain/remote.example.com/edit_trunk/4" && request.method === "POST") {
    let body = "";
    request.on("data", (chunk) => { body += chunk; });
    return request.on("end", () => {
      trunkConfig = { ...trunkConfig, ...JSON.parse(body) };
      response.end(JSON.stringify({ ok: true }));
    });
  }
  if (request.url === "/rest/domain/remote.example.com/domain_trunks" && request.method === "GET") {
    return response.end(JSON.stringify([trunkConfig]));
  }
  if (request.url === "/rest/domain/remote.example.com/dialplans" && request.method === "GET") {
    return response.end(JSON.stringify(dialPlans));
  }
  if (request.url === "/rest/domain/remote.example.com/dialplans" && request.method === "POST") {
    let body = "";
    request.on("data", (chunk) => { body += chunk; });
    return request.on("end", () => {
      const input = JSON.parse(body);
      const created = { name: input.name, value: String(nextDialPlanId++), inuse: false };
      dialPlans.push(created);
      response.end(JSON.stringify(Number(created.value)));
    });
  }
  if (decodedUrl === "/rest/user/2009@remote.example.com/calls" && request.method === "GET") {
    activeCallReads += 1;
    return response.end(JSON.stringify(activeCalls.map((call) => ({ ...call, now: call.now + activeCallReads }))));
  }
  if (decodedUrl === "/rest/user/2009@remote.example.com/calls" && request.method === "POST") {
    let body = "";
    request.on("data", (chunk) => { body += chunk; });
    return request.on("end", () => {
      const input = JSON.parse(body);
      callActions.push(input);
      const terminalId = input.hangup || input.reject;
      if (terminalId) activeCalls = activeCalls.filter((call) => call.id !== terminalId);
      response.end(JSON.stringify({ ok: true }));
    });
  }
  if (request.url === "/rest/domain/remote.example.com/cdr?id=call-1") {
    return response.end(JSON.stringify([{ id: "call-1", pcap: true }]));
  }
  if (request.url === "/rest/system/pcap?id=call-1") {
    response.setHeader("content-type", "application/vnd.tcpdump.pcap");
    return response.end(testPcap());
  }
  response.statusCode = 404;
  response.end(JSON.stringify({ error: request.url }));
});

await new Promise((resolve) => mockPbx.listen(0, "127.0.0.1", resolve));
const pbxPort = mockPbx.address().port;
const httpPort = 32000 + Math.floor(Math.random() * 1000);
const child = spawn(process.execPath, ["http.js"], {
  cwd: process.cwd(),
  env: {
    ...process.env,
    VODIA_URL: `http://127.0.0.1:${pbxPort}`,
    VODIA_USER: "mcp-api",
    VODIA_PASS: "test-pass",
    MCP_BEARER_TOKEN: "test-mcp-token",
    MCP_ADMIN_BEARER_TOKEN: "test-admin-mcp-token",
    MCP_ADMIN_ACTOR: "selftest-admin",
    VODIA_ADMIN_PROFILE: "full",
    VODIA_ENABLE_DESTRUCTIVE: "false",
    VODIA_ENABLE_CRITICAL_WRITES: "false",
    ADMIN_TOKEN: "test-admin-token",
    PORT: String(httpPort),
  },
  stdio: ["ignore", "pipe", "pipe"],
});

let startupLog = "";
child.stdout.on("data", (chunk) => { startupLog += chunk.toString(); });
child.stderr.on("data", (chunk) => { startupLog += chunk.toString(); });

for (let attempt = 0; attempt < 60; attempt += 1) {
  if (startupLog.includes("HTTP server listening")) break;
  if (child.exitCode !== null) throw new Error(`HTTP server exited early: ${startupLog}`);
  await new Promise((resolve) => setTimeout(resolve, 50));
}

const baseUrl = `http://127.0.0.1:${httpPort}`;
const unauthorized = await fetch(`${baseUrl}/api/status`);
const dashboard = await fetch(`${baseUrl}/admin/`);
const adminStatus = await fetch(`${baseUrl}/api/status`, {
  headers: { Authorization: "Bearer test-admin-token" },
}).then((response) => response.json());
const health = await fetch(`${baseUrl}/health`).then((response) => response.json());
const downloadedPcap = await fetch(`${baseUrl}/api/pcap/call-1?domain=remote.example.com`, {
  headers: { Authorization: "Bearer test-admin-token" },
});
const downloadedPcapBytes = Buffer.from(await downloadedPcap.arrayBuffer());

const transport = new StreamableHTTPClientTransport(new URL(`${baseUrl}/mcp`), {
  requestInit: { headers: { Authorization: "Bearer test-mcp-token" } },
});
const client = new Client({ name: "vodia-http-selftest", version: "1.0.0" });
const adminTransport = new StreamableHTTPClientTransport(new URL(`${baseUrl}/mcp-admin`), {
  requestInit: { headers: { Authorization: "Bearer test-admin-mcp-token" } },
});
const adminClient = new Client({ name: "vodia-http-admin-selftest", version: "1.0.0" });

try {
  await client.connect(transport);
  await adminClient.connect(adminTransport);
  const tools = await client.listTools();
  const adminTools = await adminClient.listTools();
  const adminInfo = await adminClient.callTool({ name: "get_connector_info", arguments: {} });
  const domains = await client.callTool({ name: "list_domains", arguments: {} });
  const createPlan = await adminClient.callTool({ name: "plan_create_account", arguments: { domain: "remote.example.com", type: "extensions", accounts: "2040", reason: "full-admin self-test" } });
  const wrongConfirmation = await adminClient.callTool({ name: "apply_vodia_change", arguments: { change_id: createPlan.structuredContent?.data?.changeId, confirmation: "DELETE" } });
  const createApply = await adminClient.callTool({ name: "apply_vodia_change", arguments: { change_id: createPlan.structuredContent?.data?.changeId, confirmation: "APPLY" } });
  const trunkPlan = await adminClient.callTool({ name: "plan_update_sip_trunk", arguments: { domain: "remote.example.com", trunk_id: "4", changes: { name: "Renamed trunk" }, reason: "trunk update self-test" } });
  const trunkApply = await adminClient.callTool({ name: "apply_vodia_change", arguments: { change_id: trunkPlan.structuredContent?.data?.changeId, confirmation: "APPLY" } });
  const dialPlan = await adminClient.callTool({ name: "plan_create_dial_plan", arguments: { domain: "remote.example.com", name: "Emergency", reason: "dial-plan creation self-test" } });
  const dialPlanApply = await adminClient.callTool({ name: "apply_vodia_change", arguments: { change_id: dialPlan.structuredContent?.data?.changeId, confirmation: "APPLY" } });
  const hangupPlan = await adminClient.callTool({ name: "plan_hangup_call", arguments: { account: "2009@remote.example.com", call_id: "live-call-1", reason: "live-call hangup self-test" } });
  const hangupWrongConfirmation = await adminClient.callTool({ name: "apply_vodia_change", arguments: { change_id: hangupPlan.structuredContent?.data?.changeId, confirmation: "APPLY" } });
  const hangupApply = await adminClient.callTool({ name: "apply_vodia_change", arguments: { change_id: hangupPlan.structuredContent?.data?.changeId, confirmation: "HANGUP live-call-1" } });
  const disappearedCallPlan = await adminClient.callTool({ name: "plan_hold_call", arguments: { account: "2009@remote.example.com", call_id: "live-call-2", reason: "disappearing-call self-test" } });
  activeCalls = activeCalls.filter((call) => call.id !== "live-call-2");
  const disappearedCallApply = await adminClient.callTool({ name: "apply_vodia_change", arguments: { change_id: disappearedCallPlan.structuredContent?.data?.changeId, confirmation: "HOLD live-call-2" } });
  const deleteBlocked = await adminClient.callTool({ name: "plan_delete_sip_trunk", arguments: { domain: "remote.example.com", trunk_id: "4", reason: "destructive policy self-test" } });
  const criticalBlocked = await adminClient.callTool({ name: "plan_vodia_change", arguments: { operation_id: "post_rest_system_config", body: { web_port: "443" }, reason: "critical policy self-test" } });
  const plan = await adminClient.callTool({ name: "plan_extension_pcap", arguments: { domain: "remote.example.com", extension: "2037", enabled: true, reason: "self-test" } });
  const apply = await adminClient.callTool({ name: "apply_vodia_change", arguments: { change_id: plan.structuredContent?.data?.changeId, confirmation: "APPLY" } });
  const replay = await adminClient.callTool({ name: "apply_vodia_change", arguments: { change_id: plan.structuredContent?.data?.changeId, confirmation: "APPLY" } });
  const stalePlan = await adminClient.callTool({ name: "plan_extension_pcap", arguments: { domain: "remote.example.com", extension: "2037", enabled: false, reason: "stale-state self-test" } });
  await fetch(`http://127.0.0.1:${pbxPort}/rest/domain/remote.example.com/user_settings/2037`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ pcap: "" }) });
  const staleApply = await adminClient.callTool({ name: "apply_vodia_change", arguments: { change_id: stalePlan.structuredContent?.data?.changeId, confirmation: "APPLY" } });
  const trace = await adminClient.callTool({ name: "get_call_sip_trace", arguments: { domain: "remote.example.com", call_id: "call-1", include_raw_messages: true } });
  const result = {
    unauthorizedAdminBlocked: unauthorized.status === 401,
    dashboardServed: dashboard.ok && (await dashboard.text()).includes("Vodia MCP Control Center"),
    adminPbxTestWorked: adminStatus.ok === true && adminStatus.pbx?.password === "[REDACTED]",
    streamableHttpConnected: tools.tools.length >= 15,
    bearerProtectedToolWorked: domains.structuredContent?.data?.[0]?.name === "remote.example.com",
    adminToolsSeparated: !tools.tools.some((tool) => tool.name === "apply_vodia_change") && adminTools.tools.some((tool) => tool.name === "apply_vodia_change"),
    fullAdminProfileReported: adminInfo.structuredContent?.data?.admin?.adminProfile === "full" && adminInfo.structuredContent?.data?.admin?.elevatedWritesAllowed === true,
    connectorVersionReported: health.version === "0.9.0" && adminInfo.structuredContent?.data?.connectorVersion === "0.9.0",
    fullAdminPlannersPresent: ["plan_create_account", "plan_update_account", "plan_update_sip_trunk", "plan_set_sip_trunk_enabled", "plan_create_dial_plan", "plan_update_dial_plan", "plan_update_tenant_settings", "plan_delete_account", "plan_delete_sip_trunk"].every((name) => adminTools.tools.some((tool) => tool.name === name)),
    liveCallPlannersPresent: ["plan_hangup_call", "plan_reject_call", "plan_transfer_call", "plan_hold_call", "plan_resume_call", "plan_answer_call"].every((name) => adminTools.tools.some((tool) => tool.name === name)),
    exactConfirmationEnforced: wrongConfirmation.isError === true && !createApply.isError,
    accountCreationApplied: createdAccount?.type === "extensions" && createdAccount?.account_ext === "2040",
    elevatedTrunkUpdateApplied: !trunkApply.isError && trunkConfig.name === "Renamed trunk",
    dialPlanCreationApplied: !dialPlanApply.isError && dialPlans.some((item) => item.name === "Emergency"),
    volatileCallPlanApplied: hangupWrongConfirmation.isError === true && !hangupApply.isError && callActions.some((action) => action.hangup === "live-call-1"),
    disappearedCallBlocked: disappearedCallApply.isError === true && JSON.stringify(disappearedCallApply).includes("no longer exists"),
    secretsRedactedFromTrunkPlan: !JSON.stringify(trunkPlan).includes("must-redact"),
    destructiveWriteBlockedByDefault: deleteBlocked.isError === true,
    criticalWriteBlockedByDefault: criticalBlocked.isError === true,
    plannedWriteApplied: !apply.isError,
    writePlanSingleUse: replay.isError === true,
    stalePlanBlocked: staleApply.isError === true && JSON.stringify(staleApply).includes("PBX state changed"),
    pcapTraceParsedAndRedacted: trace.structuredContent?.data?.summary?.messageCount === 1 && !JSON.stringify(trace.structuredContent).includes("Digest hidden"),
    pcapDownloadProtectedAndWorked: downloadedPcap.ok && downloadedPcap.headers.get("content-type")?.includes("application/vnd.tcpdump.pcap") && downloadedPcapBytes.length > 24,
  };
  console.log(JSON.stringify(result, null, 2));
  if (!result.plannedWriteApplied) console.error(JSON.stringify({ plan, apply, pcapEnabled, startupLog }, null, 2));
  if (Object.values(result).some((value) => value !== true)) process.exitCode = 1;
} finally {
  await client.close().catch(() => {});
  await adminClient.close().catch(() => {});
  child.kill("SIGTERM");
  await new Promise((resolve) => child.once("exit", resolve));
  await new Promise((resolve) => mockPbx.close(resolve));
}

export const CONNECTOR_VERSION = "0.9.0";


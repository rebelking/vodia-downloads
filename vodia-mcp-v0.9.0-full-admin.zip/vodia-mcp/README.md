# Vodia PBX MCP 0.9.0 full-admin release

Vodia MCP 0.9 provides a read-only support endpoint and a separate,
policy-controlled full-administrator endpoint for Vodia PBX 70.x. The API
catalog is generated from the official Vodia REST API 70.3 schema.

## Included

- Read-only MCP endpoint: `/mcp`
- Full-administrator MCP endpoint: `/mcp-admin`
- 299 documented operations: 200 GET, 63 POST, 3 PUT and 33 DELETE
- Typed planners for account creation/update/deletion, SIP-trunk update,
  enable/disable and deletion, dial-plan creation/update/deletion, and tenant settings
- Live-call hangup, reject, blind-transfer, hold, resume and answer planners
- Call-ID-aware live-state validation that ignores volatile call timestamps
- Generic plan/apply access to allowed operations in the generated catalog
- All-tenant inventory and cross-tenant extension search
- CDR, log, registration, statistics, audit and dropped-call diagnostics
- Tenant-validated PCAP retrieval with redacted SIP-dialog parsing and a
  protected binary-download endpoint
- Expiring, immutable, single-use write plans and persistent JSONL auditing

## Administration model

`VODIA_ADMIN_PROFILE` controls the write surface:

| Profile | Access |
|---|---|
| `diagnostic` | Dedicated diagnostic wrappers only |
| `operator` | Standard configuration writes |
| `full` | Standard and elevated administration writes |

The installer selects `full`. Ordinary create, update, rename, enable/disable,
and settings operations are therefore available. Permanent deletion and
critical system-level writes remain independent break-glass capabilities:

| Operation tier | Extra switch | Exact apply confirmation |
|---|---|---|
| Standard/elevated | None with `full` profile | `APPLY` |
| Destructive DELETE | `VODIA_ENABLE_DESTRUCTIVE=true` | `DELETE` |
| Critical system write | `VODIA_ENABLE_CRITICAL_WRITES=true` | `APPLY-CRITICAL` |
| Critical DELETE | Both switches | `DELETE-CRITICAL` |

Every write requires two MCP calls. `plan_vodia_change` or a typed planner
validates the request and returns an expiring change ID, request hash and exact
confirmation. `apply_vodia_change` accepts only that unchanged plan and exact
confirmation. Plans expire after five minutes by default and can be used once.
Live-call plans expire after one minute and require an action-specific phrase,
such as `HANGUP <call-id>`.

## SIP trunk boundary

The Vodia API 70.3 schema documents listing, reading, renaming/updating,
enabling/disabling and deleting existing SIP trunks. It does not document a
create-SIP-trunk REST operation. This connector intentionally does not invent
an unsupported endpoint. Use the PBX web interface to create a trunk, then use
MCP to manage it, or regenerate the catalog when Vodia publishes a creation
operation.

## Requirements

- Ubuntu or Debian connector server
- Node.js 18 or newer
- Vodia PBX 70.x and a dedicated system-administrator API account
- HTTPS DNS name for the connector; TCP 80 and 443 open to Caddy
- Codex on macOS, Windows, or Linux

Port 3100 listens only on localhost and must not be exposed publicly.

## Install

See [TESTING-GUIDE.md](TESTING-GUIDE.md) for installation, macOS Keychain and
Codex setup, acceptance tests, break-glass controls, and rollback.

The installer stores the generated endpoint tokens in the root-only file:

```text
/root/vodia-mcp-credentials.txt
```

## Codex endpoints

| Endpoint | Purpose | Local token variable |
|---|---|---|
| `/mcp` | Strictly read-only support | `VODIA_MCP_TOKEN` |
| `/mcp-admin` | Planned administrator changes | `VODIA_MCP_ADMIN_TOKEN` |
| `/health` | Non-sensitive health check | None |
| `/admin/` | Connector dashboard | Dashboard administrator token |
| `/api/pcap/{call-id}?domain=...` | Protected binary PCAP download | Dashboard administrator token |

Keep `default_tools_approval_mode = "writes"` on the administrator endpoint.

## High-value tools

- Read/support: `list_domains`, `list_accounts`, `list_extensions`,
  `find_extension_across_tenants`, `list_registrations`,
  `get_extension_registration_history`, `get_tenant_cdrs`,
  `troubleshoot_dropped_call`, `get_call_sip_trace`
- Typed administration: `plan_create_account`, `plan_update_account`,
  `plan_update_sip_trunk`, `plan_set_sip_trunk_enabled`,
  `plan_create_dial_plan`, `plan_update_dial_plan`, `plan_delete_dial_plan`,
  `plan_update_tenant_settings`,
  `plan_delete_account`, `plan_delete_sip_trunk`
- Live calls: `plan_hangup_call`, `plan_reject_call`, `plan_transfer_call`,
  `plan_hold_call`, `plan_resume_call`, `plan_answer_call`
- Catalog administration: `find_api_capabilities`, `plan_vodia_change`,
  `apply_vodia_change`

Raw arbitrary URLs are never accepted. Operations must exist in the generated
catalog, pass tenant validation and policy checks, and satisfy request limits.

## Security boundary

The two MCP endpoints use different bearer tokens. The administrator token maps
to `MCP_ADMIN_ACTOR` for auditing; this release does not yet implement per-human
OAuth 2.1 identity. Use a dedicated PBX API account, protect the administrator
token, retain human approval for writes, and rotate tokens after a test.

Secrets are recursively redacted from plans, results and audit records. SIP
authentication headers are also redacted. `VODIA_ALLOWED_DOMAINS` can restrict
the connector to named tenants; leave it blank only for intended system-wide
administration.

## Environment variables

| Variable | Purpose |
|---|---|
| `VODIA_URL` | HTTPS PBX base URL |
| `VODIA_USER` / `VODIA_PASS` | Dedicated PBX API account |
| `VODIA_ALLOWED_DOMAINS` | Optional comma-separated tenant allowlist |
| `MCP_BEARER_TOKEN` | Read endpoint token |
| `MCP_ADMIN_BEARER_TOKEN` | Administrator endpoint token |
| `MCP_ADMIN_ACTOR` | Administrator audit identity |
| `VODIA_ADMIN_PROFILE` | `diagnostic`, `operator`, or `full` |
| `VODIA_ENABLE_DESTRUCTIVE` | Permit DELETE operations; default `false` |
| `VODIA_ENABLE_CRITICAL_WRITES` | Permit critical system writes; default `false` |
| `VODIA_ALLOWED_WRITE_OPERATIONS` | Optional comma-separated operation-ID allowlist |
| `VODIA_BLOCKED_WRITE_OPERATIONS` | Optional comma-separated operation-ID denylist |
| `VODIA_MAX_WRITE_BODY_BYTES` | Maximum serialized write body; default 262144 |
| `VODIA_CHANGE_PLAN_TTL_MS` | Plan lifetime; default 300000 |
| `VODIA_PCAP_LIMIT_BYTES` | Maximum PCAP download; default 20000000 |
| `VODIA_AUDIT_LOG` | Persistent JSONL audit path |

## Download a retained PCAP

Use the dashboard administrator token, not either MCP bearer token:

```bash
curl -fsS \
  -H "Authorization: Bearer $ADMIN_TOKEN" \
  -o call.pcap \
  "https://YOUR-MCP-DOMAIN/api/pcap/CALL-ID?domain=TENANT-DOMAIN"
```

The connector first verifies that the call ID belongs to the requested tenant,
enforces `VODIA_PCAP_LIMIT_BYTES`, disables caching and audits the download.

## Local verification

```bash
npm ci
npm run check
npm test
npm audit --omit=dev --audit-level=high
```

Regenerate the catalog after reviewing a new Vodia API schema:

```bash
npm run generate:catalog
```

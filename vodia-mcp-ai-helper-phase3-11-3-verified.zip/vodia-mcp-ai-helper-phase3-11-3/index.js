#!/usr/bin/env node
import * as path from "node:path";
import * as fs from "node:fs";
import { spawnSync } from "node:child_process";

/**
 * Vodia PBX MCP Server — policy-controlled full-admin v0.9
 *
 * Exposes the official Vodia v70 OpenAPI GET surface through:
 *   1. Focused, high-value PBX tools for routine support work.
 *   2. A searchable read capability catalog.
 *   3. A universal GET reader restricted to that generated allowlist.
 *
 * The read endpoint registers no write tools. The separate administrator
 * endpoint adds policy-controlled plan/apply tools backed by the REST catalog.
 */

import { appendFileSync, readFileSync, existsSync, realpathSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { pathToFileURL } from "node:url";
import { fileURLToPath } from "node:url";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";
import { getAdminRuntimeInfo, registerAdminTools, registerLearningApprovalTools } from "./admin.js";
import { CONNECTOR_VERSION } from "./version.js";
import {
  getAwsChimeConfig,
  getAwsChimeVoiceConnector,
  listAwsChimeVoiceConnectors,
  testAwsChimeConnection,
  getAwsChimeTermination,
  getAwsChimeOrigination,
  listAwsChimeTerminationCredentials,
  getAwsChimeTerminationHealth,
  listAwsChimeAvailableRegions,
  recommendAwsChimeRegion,
  planAwsChimeCreateVoiceConnector,
  searchAwsChimeAvailablePhoneNumbers,
  listAwsChimePhoneNumbers,
  getAwsChimePhoneNumber,
  listAwsChimePhoneNumberOrders,
  getAwsChimePhoneNumberOrder,
  planAwsChimeOrderPhoneNumber,
  planAwsChimeAssignPhoneNumber,
  applyAwsChimeChange,

  planAwsChimeSetTerminationCredentials,
  planAwsChimeUpdateTermination,
  planAwsChimeUpdateOrigination,} from "./aws-chime.js";
import { getAiWorkflowCatalog, prepareAiWorkflow, getGuidedWorkflowDefinition, buildGuidedInputState } from "./workflow-helper.js";

const projectRoot = dirname(fileURLToPath(import.meta.url));
export const catalog = JSON.parse(
  readFileSync(resolve(projectRoot, "generated/read-catalog.json"), "utf8")
);

const PBX_URL = (process.env.VODIA_URL || "").replace(/\/+$/, "");
const PBX_USER = process.env.VODIA_USER || "";
const PBX_PASS = process.env.VODIA_PASS || "";
const AUDIT_LOG_PATH = String(process.env.VODIA_AUDIT_LOG || "").trim();
const ALLOWED_DOMAINS = new Set(
  String(process.env.VODIA_ALLOWED_DOMAINS || "")
    .split(",")
    .map((domain) => domain.trim().toLowerCase())
    .filter(Boolean)
);
const REQUEST_TIMEOUT_MS = readPositiveInteger("VODIA_TIMEOUT_MS", 30_000, 1_000, 120_000);
const RESPONSE_LIMIT_BYTES = readPositiveInteger(
  "VODIA_RESPONSE_LIMIT_BYTES",
  2_000_000,
  10_000,
  10_000_000
);

if (/^true$/i.test(process.env.VODIA_INSECURE || "")) {
  process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
  console.error("[vodia-mcp] WARNING: TLS certificate verification is disabled (lab use only).");
}

if (!PBX_URL || !PBX_USER || !PBX_PASS) {
  console.error("[vodia-mcp] VODIA_URL, VODIA_USER and VODIA_PASS are required.");
  process.exit(1);
}

const operationsById = new Map(
  catalog.operations.map((operation) => [operation.operationId, operation])
);

export function resolveCatalogOperationId(path, { method = "GET", requiredQueryParams = [] } = {}) {
  const matches = catalog.operations.filter((operation) =>
    operation.path === path &&
    operation.method === method &&
    operation.callable !== false &&
    requiredQueryParams.every((name) =>
      operation.parameters.some((parameter) => parameter.in === "query" && parameter.name === name)
    )
  );
  if (matches.length !== 1) {
    throw new Error(`Expected exactly one callable ${method} catalog operation for ${path}; found ${matches.length}.`);
  }
  return matches[0].operationId;
}

const SYSTEM_STATS_OPERATION_ID = resolveCatalogOperationId("/rest/system/stats", { requiredQueryParams: ["type"] });
const TENANT_STATS_OPERATION_ID = resolveCatalogOperationId("/rest/domain/{domain}/stats", { requiredQueryParams: ["type"] });
const TRUNK_STATS_OPERATION_ID = resolveCatalogOperationId("/rest/domain/{domain}/trunk-stats", { requiredQueryParams: ["type"] });

const parameterValueSchema = z.union([z.string(), z.number(), z.boolean()]);
const parameterMapSchema = z.record(z.string(), parameterValueSchema);
const toolOutputSchema = {
  data: z.any(),
  meta: z.record(z.string(), z.any()),
};

const SENSITIVE_KEY = /(?:^|_)(?:pass(?:word|phrase)?|secret|token|credential|authorization|auth|session|cookie|pin|private_key|api_key|access_key|client_secret|oauth|jwt|csrf)(?:$|_)/i;
const TENANT_SAFE_SYSTEM_READS = new Set([
  "get_rest_system_status",
  "get_rest_system_stats_5",
  "get_rest_system_license",
  "get_rest_system_swupdate",
  "get_rest_system_domains",
]);

function isSensitiveKey(key) {
  const normalized = String(key)
    .replace(/([a-z0-9])([A-Z])/g, "$1_$2")
    .replace(/[^a-z0-9]+/gi, "_");
  return SENSITIVE_KEY.test(normalized);
}

function readPositiveInteger(name, fallback, minimum, maximum) {
  const raw = Number(process.env[name] || fallback);
  if (!Number.isInteger(raw) || raw < minimum || raw > maximum) {
    console.error(
      `[vodia-mcp] ${name} must be an integer from ${minimum} through ${maximum}.`
    );
    process.exit(1);
  }
  return raw;
}

export function redactSensitive(value, depth = 0, context = {}) {
  if (depth > 30) return "[MAX_DEPTH]";
  if (typeof value === "string") {
    if (/-----BEGIN (?:RSA |EC |OPENSSH |ENCRYPTED )?PRIVATE KEY-----|\b(?:Basic|Bearer|Digest)\s+[A-Za-z0-9+/=_:.-]{8,}/i.test(value)) {
      return "[REDACTED]";
    }
    if (/^(?:[0-9a-f]{2}[:-]){5}[0-9a-f]{2}$/i.test(value.trim())) return "[REDACTED_MAC]";
    const ip = value.trim().match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
    if (ip) {
      const [, a, b] = ip.map(Number);
      if (a === 10 || a === 127 || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 169 && b === 254)) {
        return "[REDACTED_PRIVATE_IP]";
      }
    }
    return value;
  }
  if (Array.isArray(value)) return value.map((item) => redactSensitive(item, depth + 1, context));
  if (!value || typeof value !== "object") return value;

  const output = {};
  for (const [key, item] of Object.entries(value)) {
    const normalized = String(key)
      .replace(/([a-z0-9])([A-Z])/g, "$1_$2")
      .replace(/[^a-z0-9]+/gi, "_")
      .toLowerCase();
    const operationSensitive =
      /^(?:mac|macs|mac_address|mac_addresses|license_key|licensekey)$/.test(normalized) ||
      (context.operationId === "get_rest_system_license" && /^(?:key|serial|license_key)$/.test(normalized));
    output[key] = isSensitiveKey(key) || operationSensitive
      ? "[REDACTED]"
      : redactSensitive(item, depth + 1, context);
  }
  return output;
}

export function audit(tool, details = {}) {
  const cleanDetails = redactSensitive(details);
  const eventMode = /apply|change_applied|restore/i.test(tool) ? "write" : /plan/i.test(tool) ? "plan" : "read";
  const event = {
    timestamp: new Date().toISOString(),
    mode: eventMode,
    tool,
    details: cleanDetails,
  };
  recentActivity.unshift(event);
  recentActivity.splice(100);
  console.error(
    `[vodia-mcp][${new Date().toISOString()}][${eventMode}] ${tool} ${JSON.stringify(cleanDetails)}`
  );
  if (AUDIT_LOG_PATH) {
    try {
      appendFileSync(AUDIT_LOG_PATH, `${JSON.stringify(event)}\n`, {
        encoding: "utf8",
        mode: 0o600,
      });
    } catch (error) {
      console.error(`[vodia-mcp] audit log write failed: ${error.message || error}`);
    }
  }
}



const THREE_CX_IMPORT_DIR = String(process.env.VODIA_3CX_IMPORT_DIR || "/var/lib/vodia-mcp/imports").trim();
const tenantCreatePlans = new Map();
const TENANT_CREATE_PLAN_TTL_MS = 5 * 60 * 1000;

function normalizeTenantName(value) {
  const tenant = String(value || "").trim().toLowerCase();
  if (!tenant) throw new Error("tenant is required.");
  if (tenant.length > 253) throw new Error("tenant is too long.");
  if (!/^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(tenant)) {
    throw new Error("tenant must be a valid DNS hostname.");
  }
  if (/^(example|test|your|real)[.-]/.test(tenant) || tenant.includes("your-tenant") || tenant.includes("example.com")) {
    throw new Error("placeholder/example tenant names are not allowed.");
  }
  return tenant;
}

function extractVisibleTenantNames(payload) {
  const values = Array.isArray(payload)
    ? payload
    : payload && typeof payload === "object"
      ? Object.values(payload)
      : [];
  return values
    .map((item) => String(item?.name ?? item?.domain ?? "").trim().toLowerCase())
    .filter(Boolean);
}

async function vodiaSystemJson({ method = "GET", path, body } = {}) {
  const authorization = Buffer.from(`${PBX_USER}:${PBX_PASS}`, "utf8").toString("base64");
  const response = await fetch(`${PBX_URL}${path}`, {
    method,
    headers: {
      Accept: "application/json, text/plain;q=0.9",
      "Content-Type": "application/json",
      Authorization: `Basic ${authorization}`,
      "User-Agent": `vodia-mcp-ai-helper/${CONNECTOR_VERSION}`,
    },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
    signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
  });
  const raw = await readLimitedBody(response);
  const text = raw.toString("utf8").trim();
  if (!response.ok) {
    throw new Error(`Vodia API ${method} ${path} returned HTTP ${response.status}: ${text.slice(0, 500)}`);
  }
  if (!text) return { status: response.status, data: null };
  try { return { status: response.status, data: JSON.parse(text) }; }
  catch { return { status: response.status, data: text }; }
}

async function planCreateTenant({ actor, tenant, reason } = {}) {
  const normalized = normalizeTenantName(tenant);
  const before = await vodiaSystemJson({ path: "/rest/system/domains" });
  const visible = extractVisibleTenantNames(before.data);
  if (visible.includes(normalized)) {
    throw new Error(`Tenant '${normalized}' already exists.`);
  }

  const changeId = `tenant-${globalThis.crypto?.randomUUID?.() || Date.now()}`;
  const expiresAt = new Date(Date.now() + TENANT_CREATE_PLAN_TTL_MS);
  const requiredConfirmation = `CREATE VODIA TENANT ${normalized}`;
  tenantCreatePlans.set(changeId, {
    changeId,
    actor: String(actor || "unknown"),
    tenant: normalized,
    reason: String(reason || "3CX migration tenant creation"),
    expiresAt,
    used: false,
    requiredConfirmation,
    preimageTenantNames: visible.slice().sort(),
  });

  return {
    changeId,
    operation: "CreateVodiaTenant",
    tenant: normalized,
    reason: String(reason || "3CX migration tenant creation"),
    expiresAt: expiresAt.toISOString(),
    requiredConfirmation,
    changesPbx: false,
    preflight: { tenantExists: false, visibleTenantCount: visible.length },
  };
}

async function applyCreateTenant({ actor, changeId, confirmation } = {}) {
  const id = String(changeId || "").trim();
  const plan = tenantCreatePlans.get(id);
  if (!plan) throw new Error("Tenant creation plan was not found, expired, or was already used.");
  if (plan.used) throw new Error("Tenant creation plan was already used.");
  if (Date.now() > plan.expiresAt.getTime()) {
    tenantCreatePlans.delete(id);
    throw new Error("Tenant creation plan expired. Prepare it again.");
  }
  if (String(actor || "unknown") !== plan.actor) {
    throw new Error("Tenant creation plan belongs to a different administrator identity.");
  }
  if (String(confirmation || "") !== plan.requiredConfirmation) {
    throw new Error("Confirmation does not exactly match requiredConfirmation.");
  }

  // Re-check immediately before write.
  const before = await vodiaSystemJson({ path: "/rest/system/domains" });
  const visible = extractVisibleTenantNames(before.data);
  if (visible.includes(plan.tenant)) {
    tenantCreatePlans.delete(id);
    throw new Error(`Tenant '${plan.tenant}' now exists; refusing duplicate creation.`);
  }

  plan.used = true;
  await vodiaSystemJson({
    method: "POST",
    path: "/rest/system/domains",
    body: [plan.tenant],
  });

  // Independently verify via the list endpoint.
  const after = await vodiaSystemJson({ path: "/rest/system/domains" });
  const afterNames = extractVisibleTenantNames(after.data);
  const verified = afterNames.includes(plan.tenant);
  tenantCreatePlans.delete(id);

  if (!verified) {
    throw new Error(`Vodia accepted tenant creation but '${plan.tenant}' was not present in GET /rest/system/domains afterward.`);
  }

  return {
    changeId: id,
    operation: "CreateVodiaTenant",
    tenant: plan.tenant,
    verified: true,
    verification: "GET /rest/system/domains contains the new tenant",
  };
}

function safeImportBasename(value) {
  const name = String(value || "").trim();
  if (!name) throw new Error("filename is required.");
  if (name !== PathLikeBasename(name) || !/^[A-Za-z0-9._-]+\.json$/i.test(name)) {
    throw new Error("filename must be a simple .json filename with no path components.");
  }
  return name;
}

function PathLikeBasename(value) {
  return String(value).replace(/^.*[\\/]/, "");
}

function load3cxNormalizedImport(filename) {
  const safeName = safeImportBasename(filename);
  const root = realpathSync(THREE_CX_IMPORT_DIR);
  const candidate = `${root}/${safeName}`;
  if (!existsSync(candidate)) throw new Error(`3CX normalized import file '${safeName}' was not found.`);
  const real = realpathSync(candidate);
  if (!real.startsWith(root + "/")) throw new Error("Import file escaped the configured import directory.");
  const raw = readFileSync(real, "utf8");
  const data = JSON.parse(raw);
  return { filename: safeName, data };
}

function arr(value) {
  return Array.isArray(value) ? value : [];
}

const THREE_CX_CONFIG_KEYS = [
  "extensions",
  "users",
  "phones",
  "ring_groups",
  "queues",
  "ivrs",
  "trunks",
  "gateways",
  "outbound_rules",
  "groups",
  "park_orbits",
  "fax_extensions",
  "conference_extensions",
];

function score3cxConfigObject(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return -1;
  let score = 0;
  for (const key of THREE_CX_CONFIG_KEYS) {
    if (Array.isArray(value[key])) score += 1;
  }
  return score;
}

function find3cxConfigObject(data) {
  // Known historical analyzer shapes first.
  const directCandidates = [
    data?.configuration,
    data?.config,
    data?.migration,
    data?.migration_data,
    data?.normalized,
    data?.normalized_data,
    data?.pbx,
    data?.pbx_config,
    data?.data,
    data,
  ].filter((v) => v && typeof v === "object" && !Array.isArray(v));

  let best = null;
  let bestScore = -1;
  let bestPath = "$";

  for (const candidate of directCandidates) {
    const score = score3cxConfigObject(candidate);
    if (score > bestScore) {
      best = candidate;
      bestScore = score;
    }
  }

  // Be schema-tolerant: recursively inspect nested objects and select the object
  // with the greatest number of migration collection keys. This prevents a
  // harmless wrapper-name change in analyze-3cx-backup.py from yielding zeros.
  const seen = new Set();
  const queue = [{ value: data, path: "$", depth: 0 }];
  while (queue.length) {
    const current = queue.shift();
    const value = current?.value;
    if (!value || typeof value !== "object" || seen.has(value)) continue;
    seen.add(value);

    if (!Array.isArray(value)) {
      const score = score3cxConfigObject(value);
      if (score > bestScore) {
        best = value;
        bestScore = score;
        bestPath = current.path;
      }
    }

    if (current.depth >= 5) continue;
    if (Array.isArray(value)) continue;

    for (const [key, child] of Object.entries(value)) {
      if (child && typeof child === "object" && !Array.isArray(child)) {
        queue.push({
          value: child,
          path: `${current.path}.${key}`,
          depth: current.depth + 1,
        });
      }
    }
  }

  if (!best || bestScore < 1) {
    throw new Error(
      "Normalized 3CX JSON was parsed, but no migration configuration object was found. " +
      "Expected at least one array such as extensions, phones, ring_groups, queues, ivrs, trunks, gateways, outbound_rules, groups, park_orbits, fax_extensions, or conference_extensions."
    );
  }

  return { config: best, path: bestPath, matchedCollections: bestScore };
}

function migrationInventory(data) {
  const located = find3cxConfigObject(data);
  const config = located.config;

  const extensionSource =
    arr(config.extensions).length > 0 ? arr(config.extensions) : arr(config.users);
  const extensions = extensionSource;
  const extensionSourceKey =
    arr(config.extensions).length > 0 ? "extensions" :
    arr(config.users).length > 0 ? "users" : null;
  const phones = arr(config.phones);
  const ringGroups = arr(config.ring_groups);
  const queues = arr(config.queues);
  const ivrs = arr(config.ivrs);
  const trunks = arr(config.trunks);
  const gateways = arr(config.gateways);
  const outboundRules = arr(config.outbound_rules);
  const groups = arr(config.groups);
  const parkOrbits = arr(config.park_orbits);
  const faxExtensions = arr(config.fax_extensions);
  const conferenceExtensions = arr(config.conference_extensions);
  const missingEmail = extensions
    .filter((e) => !String(e?.email || "").trim())
    .map((e) => String(e?.extension || "").trim())
    .filter(Boolean);
  const usersWithPhones = extensions.filter((e) => arr(e?.phones).length > 0).length;

  return {
    sourceShape: {
      configPath: located.path,
      matchedCollections: located.matchedCollections,
      availableKeys: Object.keys(config).sort(),
      extensionSourceKey,
    },
    extensions,
    phones,
    ringGroups,
    queues,
    ivrs,
    trunks,
    gateways,
    outboundRules,
    groups,
    parkOrbits,
    faxExtensions,
    conferenceExtensions,
    counts: {
      extensions: extensions.length,
      emails: extensions.length - missingEmail.length,
      missingEmail: missingEmail.length,
      usersWithPhones,
      phones: phones.length,
      ringGroups: ringGroups.length,
      queues: queues.length,
      ivrs: ivrs.length,
      trunks: trunks.length,
      gateways: gateways.length,
      outboundRules: outboundRules.length,
      groups: groups.length,
      parkOrbits: parkOrbits.length,
      faxExtensions: faxExtensions.length,
      conferenceExtensions: conferenceExtensions.length,
    },
    missingEmail,
  };
}


const THREE_CX_INVENTORY_CATEGORIES = new Set([
  "users",
  "extensions",
  "phones",
  "ring_groups",
  "queues",
  "ivrs",
  "trunks",
  "gateways",
  "outbound_rules",
  "groups",
  "park_orbits",
  "fax_extensions",
  "conference_extensions",
]);

function get3cxInventoryCategory(data, category) {
  const located = find3cxConfigObject(data);
  const config = located.config;
  const requested = String(category || "").trim();

  if (!THREE_CX_INVENTORY_CATEGORIES.has(requested)) {
    throw new Error(`Unsupported inventory category '${requested}'.`);
  }

  let sourceKey = requested;
  let items;

  if (requested === "extensions") {
    if (arr(config.extensions).length > 0) {
      sourceKey = "extensions";
      items = arr(config.extensions);
    } else {
      sourceKey = "users";
      items = arr(config.users);
    }
  } else if (requested === "users") {
    if (arr(config.users).length > 0) {
      sourceKey = "users";
      items = arr(config.users);
    } else {
      sourceKey = "extensions";
      items = arr(config.extensions);
    }
  } else {
    items = arr(config[requested]);
  }

  return {
    sourceShape: {
      configPath: located.path,
      matchedCollections: located.matchedCollections,
      sourceKey,
    },
    items,
  };
}

function sanitize3cxInventoryItem(category, item) {
  if (item === null || item === undefined) return item;
  if (typeof item !== "object") return item;

  // Defense in depth: the analyzer already removes secrets, but never surface
  // fields whose names look credential-bearing if a future analyzer adds them.
  const secretPattern = /(password|passwd|secret|credential|auth[_-]?id|auth[_-]?pass|pin|certificate|private[_-]?key)/i;

  const walk = (value, depth = 0) => {
    if (depth > 6) return "[TRUNCATED_DEPTH]";
    if (Array.isArray(value)) return value.map((v) => walk(v, depth + 1));
    if (!value || typeof value !== "object") return value;

    const out = {};
    for (const [key, val] of Object.entries(value)) {
      if (secretPattern.test(key)) {
        out[key] = "[REDACTED]";
      } else {
        out[key] = walk(val, depth + 1);
      }
    }
    return out;
  };

  return walk(item);
}

function build3cxMigrationAssessment(data, { targetTenant, emailPolicy, trunkStrategy } = {}) {
  const inv = migrationInventory(data);
  const blockers = [];
  const questions = [];
  const warnings = [];

  if (!targetTenant) {
    questions.push({
      field: "target_tenant",
      question: "What Vodia tenant/domain should receive this 3CX migration?",
      required: true,
    });
  }

  if (inv.missingEmail.length && !emailPolicy) {
    questions.push({
      field: "email_policy",
      question: `There are ${inv.missingEmail.length} extensions without email. How should they be handled?`,
      choices: ["create_without_email", "skip_missing_email", "provide_emails_before_import"],
      affectedExtensions: inv.missingEmail,
      required: true,
    });
  }

  if ((inv.trunks.length || inv.gateways.length) && !trunkStrategy) {
    questions.push({
      field: "trunk_strategy",
      question: "How should discovered 3CX trunks/gateways be handled?",
      choices: ["map_to_existing_vodia_trunk", "create_or_configure_manually", "skip_trunks_for_first_pass"],
      required: true,
    });
  }

  if (inv.ivrs.length) {
    warnings.push("IVRs require translation/validation against Vodia auto-attendant behavior before write planning.");
  }
  if (inv.outboundRules.length) {
    warnings.push("3CX outbound rules must be translated into Vodia dial-plan rules and checked for ordering/pattern overlap.");
  }
  if (inv.trunks.length || inv.gateways.length) {
    warnings.push("Carrier credentials are intentionally absent from normalized 3CX output; trunk authentication cannot be migrated automatically.");
  }

  const mapping = {
    extensions: { target: "Vodia extensions/users", automation: "HIGH", sourceCount: inv.counts.extensions },
    phones: { target: "Vodia MAC/provisioning assignments", automation: "HIGH_WITH_MODEL_REVIEW", sourceCount: inv.counts.phones },
    ring_groups: { target: "Vodia hunt/ring groups", automation: "HIGH", sourceCount: inv.counts.ringGroups },
    queues: { target: "Vodia ACD queues", automation: "HIGH_WITH_QUEUE_POLICY_REVIEW", sourceCount: inv.counts.queues },
    ivrs: { target: "Vodia auto attendants", automation: "REVIEW_REQUIRED", sourceCount: inv.counts.ivrs },
    trunks_gateways: { target: "Vodia SIP trunks", automation: "MANUAL_CREDENTIAL_REVIEW", sourceCount: inv.counts.trunks + inv.counts.gateways },
    outbound_rules: { target: "Vodia dial plans", automation: "TRANSLATION_REQUIRED", sourceCount: inv.counts.outboundRules },
    groups: { target: "Vodia groups/address/provisioning policy as appropriate", automation: "REVIEW_REQUIRED", sourceCount: inv.counts.groups },
    park_orbits: { target: "Vodia park-orbit configuration", automation: "REVIEW_REQUIRED", sourceCount: inv.counts.parkOrbits },
    fax: { target: "Vodia fax account/routing", automation: "REVIEW_REQUIRED", sourceCount: inv.counts.faxExtensions },
    conferences: { target: "Vodia conference account/settings", automation: "REVIEW_REQUIRED", sourceCount: inv.counts.conferenceExtensions },
  };

  const downstreamAccountDependents =
    inv.counts.phones +
    inv.counts.ringGroups +
    inv.counts.queues +
    inv.counts.ivrs +
    inv.counts.outboundRules +
    inv.counts.parkOrbits +
    inv.counts.faxExtensions +
    inv.counts.conferenceExtensions;

  if (inv.counts.extensions === 0 && downstreamAccountDependents > 0) {
    blockers.push({
      type: "missing_extension_root_objects",
      reason:
        `Migration contains ${downstreamAccountDependents} account-dependent objects but zero parsed extensions/users. ` +
        "Refusing READY status because phones and call-flow objects must not be planned before their underlying accounts."
    });
  }

  const recognizedTotal =
    inv.counts.extensions +
    inv.counts.phones +
    inv.counts.ringGroups +
    inv.counts.queues +
    inv.counts.ivrs +
    inv.counts.trunks +
    inv.counts.gateways +
    inv.counts.outboundRules +
    inv.counts.groups +
    inv.counts.parkOrbits +
    inv.counts.faxExtensions +
    inv.counts.conferenceExtensions;

  if (recognizedTotal === 0) {
    blockers.push({
      type: "empty_or_unrecognized_source",
      reason:
        "The normalized file contains a recognized migration section but all supported migration collections are empty. " +
        "Confirm the analyzer output before continuing."
    });
  }

  const requiredQuestions = questions.filter((q) => q.required);
  return {
    status: blockers.length ? "BLOCKED" : requiredQuestions.length ? "NEEDS_INPUT" : "READY_FOR_MIGRATION_PLAN",
    sourceShape: inv.sourceShape,
    counts: inv.counts,
    missingEmailExtensions: inv.missingEmail,
    mapping,
    warnings,
    blockers,
    questions,
    suppliedDecisions: {
      targetTenant: targetTenant || null,
      emailPolicy: emailPolicy || null,
      trunkStrategy: trunkStrategy || null,
    },
    nextSafeStep: requiredQuestions.length
      ? "Answer the essential migration questions. Do not create PBX objects yet."
      : "Prepare guarded Vodia object plans in dependency order. Do not apply until the full migration plan is reviewed.",
  };
}


const recentActivity = [];

export function getRecentActivity(limit = 25) {
  return recentActivity.slice(0, Math.max(1, Math.min(Number(limit) || 25, 100)));
}

function success(data, meta, message) {
  const structuredContent = { data, meta };
  return {
    structuredContent,
    content: [
      { type: "text", text: message },
      { type: "text", text: JSON.stringify(structuredContent, null, 2) },
    ],
  };
}

export function failure(error, mode = "read") {
  return {
    content: [{ type: "text", text: `Vodia ${mode} failed: ${error.message || error}` }],
    isError: true,
  };
}

async function readLimitedBody(response) {
  const declaredLength = Number(response.headers.get("content-length") || 0);
  if (declaredLength > RESPONSE_LIMIT_BYTES) {
    throw new Error(
      `Response is ${declaredLength} bytes; limit is ${RESPONSE_LIMIT_BYTES} bytes. Narrow the query.`
    );
  }

  if (!response.body) return "";
  const reader = response.body.getReader();
  const chunks = [];
  let total = 0;

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    total += value.byteLength;
    if (total > RESPONSE_LIMIT_BYTES) {
      await reader.cancel();
      throw new Error(
        `Response exceeded ${RESPONSE_LIMIT_BYTES} bytes. Narrow the query or page size.`
      );
    }
    chunks.push(value);
  }

  const joined = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) {
    joined.set(chunk, offset);
    offset += chunk.byteLength;
  }
  return Buffer.from(joined);
}

function buildRequest(operation, pathParams = {}, queryParams = {}) {
  if (!operation) throw new Error("Unknown Vodia read operation.");
  if (operation.method !== "GET") throw new Error("Only GET operations are available.");
  if (!operation.callable) {
    throw new Error(
      `Operation '${operation.operationId}' is blocked: ${operation.blockedReason}`
    );
  }
  if (
    ALLOWED_DOMAINS.size &&
    operation.path.startsWith("/rest/system/") &&
    !TENANT_SAFE_SYSTEM_READS.has(operation.operationId) &&
    operation.path !== "/rest/system/domains/{domain}"
  ) {
    throw new Error(
      `Operation '${operation.operationId}' is unavailable when tenant restrictions are enabled.`
    );
  }

  const requiredPathParameters = [...operation.path.matchAll(/\{([^}]+)\}/g)].map(
    (match) => match[1]
  );
  const suppliedPathParameters = Object.keys(pathParams);
  const unknownPathParameters = suppliedPathParameters.filter(
    (name) => !requiredPathParameters.includes(name)
  );
  if (unknownPathParameters.length) {
    throw new Error(`Unknown path parameter(s): ${unknownPathParameters.join(", ")}`);
  }

  let path = operation.path;
  for (const name of requiredPathParameters) {
    const value = pathParams[name];
    if (value === undefined || value === null || String(value).trim() === "") {
      throw new Error(`Missing required path parameter '${name}'.`);
    }
    enforceTenantValue(name, value);
    path = path.replace(`{${name}}`, encodeURIComponent(String(value)));
  }

  const allowedQueryParameters = new Set(
    operation.parameters
      .filter((parameter) => parameter.in === "query")
      .map((parameter) => parameter.name)
  );
  const unknownQueryParameters = Object.keys(queryParams).filter(
    (name) => !allowedQueryParameters.has(name)
  );
  if (unknownQueryParameters.length) {
    throw new Error(
      `Unsupported query parameter(s) for ${operation.operationId}: ${unknownQueryParameters.join(", ")}`
    );
  }

  const url = new URL(`${PBX_URL}${path}`);
  for (const [name, value] of Object.entries(queryParams)) {
    if (value !== undefined && value !== null && String(value) !== "") {
      enforceTenantValue(name, value);
      url.searchParams.set(name, String(value));
    }
  }

  return { url, path };
}

function enforceTenantValue(name, value) {
  if (!ALLOWED_DOMAINS.size) return;
  const parameter = String(name).toLowerCase();
  let domain = "";
  if (parameter === "domain") domain = String(value).trim().toLowerCase();
  if (parameter === "account" || parameter.endsWith("_account")) {
    const account = String(value).trim();
    const separator = account.lastIndexOf("@");
    if (separator < 1) {
      throw new Error(`'${name}' must use account@domain form when tenant restrictions are enabled.`);
    }
    domain = account.slice(separator + 1).toLowerCase();
  }
  if (domain && !ALLOWED_DOMAINS.has(domain)) {
    throw new Error(`Tenant '${domain}' is outside VODIA_ALLOWED_DOMAINS.`);
  }
}

export async function callOperationRaw(operationId, { pathParams = {}, queryParams = {} } = {}) {
  const operation = operationsById.get(operationId);
  const { url, path } = buildRequest(operation, pathParams, queryParams);
  const authorization = Buffer.from(`${PBX_USER}:${PBX_PASS}`, "utf8").toString("base64");

  const response = await fetch(url, {
    method: "GET",
    headers: {
      Accept: "application/json, text/plain;q=0.9",
      Authorization: `Basic ${authorization}`,
      "User-Agent": `vodia-mcp-readonly/${CONNECTOR_VERSION}`,
    },
    signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
  });

  const body = await readLimitedBody(response);
  const contentType = response.headers.get("content-type") || "application/octet-stream";
  if (!response.ok) {
    const diagnostic = /^text\//i.test(contentType) || /json/i.test(contentType)
      ? body.toString("utf8").slice(0, 400)
      : `[${contentType}; ${body.length} bytes]`;
    throw new Error(`Vodia API GET ${path} returned HTTP ${response.status}: ${diagnostic}`);
  }

  let data;
  if (/json/i.test(contentType)) {
    const text = body.toString("utf8");
    try {
      data = text ? JSON.parse(text) : {};
    } catch {
      throw new Error(`Vodia returned invalid JSON for ${operationId}.`);
    }
  } else if (/^text\//i.test(contentType)) {
    data = { contentType, data: body.toString("utf8") };
  } else {
    data = { contentType, encoding: "base64", data: body.toString("base64") };
  }

  if (operationId === "get_rest_system_domains" && ALLOWED_DOMAINS.size) {
    data = [...ALLOWED_DOMAINS].map((domain) => ({ domain }));
  }

  return {
    data,
    meta: {
      operationId,
      method: "GET",
      path: operation.path,
      summary: operation.summary,
      vodiaApiVersion: catalog.vodiaApiVersion,
    },
  };
}

export async function callOperation(operationId, args = {}) {
  const result = await callOperationRaw(operationId, args);
  const redactedData = redactSensitive(result.data, 0, { operationId });
  return {
    data: redactedData,
    meta: {
      ...result.meta,
      redactionApplied: JSON.stringify(redactedData) !== JSON.stringify(result.data),
    },
  };
}

export function createVodiaServer({ accessMode = "read", actor = "bearer-user", identity = null, toolResultLimitBytes = RESPONSE_LIMIT_BYTES } = {}) {
const adminMode = accessMode === "admin";
const approvalMode = accessMode === "approver";
const auditIdentity = identity ? {
  actor,
  user_id: identity.user_id,
  user: identity.email || identity.display_name || identity.user_id,
  role: identity.role,
  client_id: identity.client_id,
  client: identity.client,
  scopes: identity.scopes,
  auth_type: identity.auth_type,
} : { actor };
const scopedAudit = (tool, details = {}) => audit(
  tool,
  tool === "vodia_change_applied"
    ? { user: auditIdentity.user || actor, ...details }
    : { ...auditIdentity, ...details }
);
const scopedSuccess = (data, meta, message) => {
  const result = success(data, meta, message);
  const bytes = Buffer.byteLength(JSON.stringify(result.structuredContent), "utf8");
  if (bytes <= toolResultLimitBytes) return result;
  return success(
    {
      truncated: true,
      originalBytes: bytes,
      limitBytes: toolResultLimitBytes,
      guidance: "The result is too large for this MCP client. Narrow the query or use an operation's pagination parameters.",
    },
    { ...meta, truncated: true, originalBytes: bytes, limitBytes: toolResultLimitBytes },
    `Vodia returned ${bytes} bytes, exceeding this client's ${toolResultLimitBytes}-byte tool-result limit. Narrow or paginate the request.`
  );
};
const server = new McpServer(
  { name: approvalMode ? "vodia-pbx-learning-approver" : adminMode ? "vodia-pbx-admin" : "vodia-pbx-readonly", version: CONNECTOR_VERSION },
  {
    instructions: (approvalMode
      ? "This separate endpoint reviews and approves supervised MCP learning proposals. Approval never executes a PBX request. Inspect all evidence and the redacted request template before using the exact approval confirmation. "
      : adminMode
      ? "This is the policy-controlled system-administrator endpoint. Use get_account_live_calls or list_tenant_live_calls before any live-call action. Use find_api_capabilities plus read_vodia_api, read_vodia_binary, or plan_vodia_change for the complete documented API surface. Every action or write must be planned, reviewed, and separately applied with the exact confirmation shown in the plan. "
      : "This connector endpoint is strictly read-only. ") +
      "Use focused status and analytics tools first. " +
      "Use find_read_capabilities before read_vodia_resource for less common Vodia data. " +
      "Never claim that a read changed PBX configuration. Sensitive fields are redacted.",
  }
);

function registerPbXReadTool(name, definition, operationId, mapArguments, transformData = (data) => data) {
  server.registerTool(
    name,
    {
      title: definition.title,
      description: definition.description,
      inputSchema: definition.inputSchema,
      outputSchema: toolOutputSchema,
      annotations: {
        readOnlyHint: true,
        destructiveHint: false,
        openWorldHint: false,
      },
    },
    async (args) => {
      scopedAudit(name, args);
      try {
        const result = await callOperation(operationId, mapArguments(args || {}));
        return scopedSuccess(
          transformData(result.data),
          result.meta,
          `${definition.title} completed using read-only Vodia data.`
        );
      } catch (error) {
        return failure(error);
      }
    }
  );
}

registerPbXReadTool(
  "get_system_status",
  {
    title: "Get PBX system status",
    description: "Check Vodia PBX health, version and current system status.",
    inputSchema: {},
  },
  "get_rest_system_status",
  () => ({})
);

registerPbXReadTool(
  "get_system_license",
  {
    title: "Get PBX license status",
    description: "Read Vodia license status and licensed capacity without exposing license secrets.",
    inputSchema: {},
  },
  "get_rest_system_license",
  () => ({})
);

registerPbXReadTool(
  "get_system_stats",
  {
    title: "Get PBX performance statistics",
    description: "Read system performance, registration, call, or quality statistics.",
    inputSchema: { type: z.string().min(1).optional() },
  },
  SYSTEM_STATS_OPERATION_ID,
  ({ type }) => ({ queryParams: type ? { type } : {} })
);

registerPbXReadTool(
  "get_system_audit_log",
  {
    title: "Get PBX administrator change log",
    description: "Read paginated system administrator changes. Unavailable in tenant-restricted mode.",
    inputSchema: {
      page: z.number().int().min(1).default(1),
      size: z.number().int().min(1).max(500).default(100),
      search: z.string().optional(),
    },
  },
  "get_rest_system_changes",
  ({ page, size, search }) => ({
    queryParams: { page, size, ...(search ? { search } : {}) },
  })
);

registerPbXReadTool(
  "list_domains",
  {
    title: "List Vodia tenants",
    description: "List all tenant domains visible to the configured PBX API account.",
    inputSchema: {},
  },
  "get_rest_system_domains",
  () => ({})
);

registerPbXReadTool(
  "list_extensions",
  {
    title: "List tenant extensions",
    description: "List extension accounts in a Vodia tenant or retrieve one extension by account number.",
    inputSchema: {
      domain: z.string().min(1),
      account: z.string().min(1).optional(),
    },
  },
  "get_rest_domain_domain_extensions_3",
  ({ domain, account }) => ({
    pathParams: { domain },
    queryParams: account ? { account } : {},
  })
);

registerPbXReadTool(
  "list_accounts",
  {
    title: "List tenant accounts",
    description: "List all account types visible in a tenant, including extensions and routing accounts.",
    inputSchema: { domain: z.string().min(1) },
  },
  "get_rest_domain_domain_users",
  ({ domain }) => ({ pathParams: { domain } })
);

function normalizeParkOrbits(data) {
  const rows = Array.isArray(data)
    ? data
    : Array.isArray(data?.orbits)
      ? data.orbits
      : Array.isArray(data?.data)
        ? data.data
        : [];
  return rows.map((row) => {
    const calls = Array.isArray(row?.calls) ? row.calls : [];
    const number = String(row?.name ?? row?.number ?? row?.orbit ?? "").trim();
    return {
      number,
      name: String(row?.display ?? row?.description ?? `Park ${number}`).trim(),
      occupied: calls.length > 0,
      calls,
    };
  });
}

registerPbXReadTool(
  "list_park_orbits",
  {
    title: "List tenant park orbits",
    description: "List configured Vodia park-orbit accounts and show whether each orbit currently contains parked calls.",
    inputSchema: {
      domain: z.string().min(1),
      page: z.number().int().min(1).default(1),
      size: z.number().int().min(1).max(500).default(100),
    },
  },
  "get_rest_domain_domain_orbits_1",
  ({ domain, page, size }) => ({
    pathParams: { domain },
    queryParams: { page, size },
  }),
  normalizeParkOrbits
);

registerPbXReadTool(
  "get_live_park_status",
  {
    title: "Get user-visible park orbit status",
    description: "List the park orbits visible to one Vodia user and include the current parked-call occupancy for each orbit.",
    inputSchema: {
      account: z.string().min(3).describe("User account in extension@tenant-domain form"),
    },
  },
  "get_rest_user_account_orbits",
  ({ account }) => ({ pathParams: { account } }),
  normalizeParkOrbits
);

for (const [name, title, description, operationId] of [
  ["list_queues", "List tenant call queues", "List call queues configured in a Vodia tenant.", "get_rest_domain_domain_acds_1"],
  ["list_ring_groups", "List tenant ring groups", "List ring groups configured in a Vodia tenant.", "get_rest_domain_domain_hunts"],
  ["list_auto_attendants", "List tenant auto attendants", "List auto attendants configured in a Vodia tenant.", "get_rest_domain_domain_attendants"],
  ["list_conferences", "List tenant conferences", "List conference rooms configured in a Vodia tenant.", "get_rest_domain_domain_conferences"],
  ["list_service_flags", "List tenant service flags", "List service flags and their current state.", "get_rest_domain_domain_srvflags"],
  ["get_live_extension_status", "Get live extension status", "Get live status for all extensions in a Vodia tenant.", "get_rest_domain_domain_status_extensions"],
  ["get_live_ring_group_status", "Get live ring group status", "Get live ring-group state for a Vodia tenant.", "get_rest_domain_domain_status_hunts"],
  ["get_live_conference_status", "Get live conference status", "Get live conference-room state for a Vodia tenant.", "get_rest_domain_domain_status_conferences"],
]) {
  registerPbXReadTool(
    name,
    { title, description, inputSchema: { domain: z.string().min(1) } },
    operationId,
    ({ domain }) => ({ pathParams: { domain } })
  );
}

registerPbXReadTool(
  "list_registrations",
  {
    title: "List SIP and push registrations",
    description: "Show registered phones, apps and push registrations for a Vodia tenant.",
    inputSchema: { domain: z.string().min(1) },
  },
  "get_rest_domain_domain_registrations",
  ({ domain }) => ({ pathParams: { domain } })
);

registerPbXReadTool(
  "list_trunks",
  {
    title: "List tenant trunks",
    description: "List SIP trunks configured for a Vodia tenant.",
    inputSchema: { domain: z.string().min(1) },
  },
  "get_rest_domain_domain_domain_trunks",
  ({ domain }) => ({ pathParams: { domain } })
);

registerPbXReadTool(
  "list_dialplans",
  {
    title: "List tenant dial plans",
    description: "List dial plans configured for a Vodia tenant.",
    inputSchema: { domain: z.string().min(1) },
  },
  "get_rest_domain_domain_dialplans",
  ({ domain }) => ({ pathParams: { domain } })
);

registerPbXReadTool(
  "get_tenant_cdrs",
  {
    title: "Get tenant CDRs",
    description: "Get a paginated set of tenant call detail records for troubleshooting or charting.",
    inputSchema: {
      domain: z.string().min(1),
      page: z.number().int().min(1).default(1),
      size: z.number().int().min(1).max(500).default(100),
    },
  },
  "get_rest_domain_domain_cdrs_1",
  ({ domain, page, size }) => ({
    pathParams: { domain },
    queryParams: { page, size },
  })
);

registerPbXReadTool(
  "get_specific_cdr",
  {
    title: "Get one tenant CDR",
    description: "Read one call detail record by call ID for tenant-scoped troubleshooting.",
    inputSchema: { domain: z.string().min(1), call_id: z.string().min(1).max(256) },
  },
  "get_rest_domain_domain_cdr",
  ({ domain, call_id }) => ({ pathParams: { domain }, queryParams: { id: call_id } })
);

registerPbXReadTool(
  "get_tenant_log",
  {
    title: "Get tenant PBX log entries",
    description: "Read domain-scoped PBX log entries for call routing, registration, and integration troubleshooting.",
    inputSchema: { domain: z.string().min(1) },
  },
  "get_rest_domain_domain_log",
  ({ domain }) => ({ pathParams: { domain } })
);

registerPbXReadTool(
  "get_extension_syslog",
  {
    title: "Get extension syslog",
    description: "Read PBX syslog messages associated with one extension account.",
    inputSchema: { account: z.string().min(3).describe("Extension in extension@tenant-domain form") },
  },
  "get_rest_user_account_syslog",
  ({ account }) => ({ pathParams: { account } })
);

registerPbXReadTool(
  "get_extension_settings",
  {
    title: "Get extension account settings",
    description: "Read the complete redacted account settings for one extension in a tenant.",
    inputSchema: { domain: z.string().min(1), extension: z.string().min(1) },
  },
  "get_rest_domain_domain_user_settings_ext",
  ({ domain, extension }) => ({ pathParams: { domain, ext: extension } })
);

registerPbXReadTool(
  "get_tenant_audit_log",
  {
    title: "Get tenant administrator change log",
    description: "Read paginated administrator changes for one allowed tenant.",
    inputSchema: {
      domain: z.string().min(1),
      page: z.number().int().min(1).default(1),
      size: z.number().int().min(1).max(500).default(100),
    },
  },
  "get_rest_domain_domain_changes",
  ({ domain, page, size }) => ({
    pathParams: { domain },
    queryParams: { page, size },
  })
);

registerPbXReadTool(
  "get_extension_call_history",
  {
    title: "Get extension call history",
    description: "Read call history for an extension account.",
    inputSchema: {
      account: z.string().min(3).describe("Extension in extension@tenant-domain form"),
    },
  },
  "get_rest_user_account_history",
  ({ account }) => ({ pathParams: { account } })
);

registerPbXReadTool(
  "get_account_live_calls",
  {
    title: "Get active calls for one account",
    description: "Return individual active call legs, call IDs, parties, states and durations for one Vodia account.",
    inputSchema: {
      account: z.string().min(3).describe("Account in extension@tenant-domain form"),
    },
  },
  "get_rest_user_account_calls",
  ({ account }) => ({ pathParams: { account } })
);

function partyAccount(value) {
  const text = String(value ?? "").trim();
  const at = text.match(/(?:^|[<\s"'])([A-Za-z0-9*#_.-]+)@[^>\s]+/);
  if (at) return at[1];
  const simple = text.match(/^([A-Za-z0-9*#_.-]+)$/);
  return simple ? simple[1] : null;
}

function deriveLiveCallDirection(call, tenantExtensions) {
  const caller = partyAccount(call?.from ?? call?.caller ?? call?.calling);
  const callee = partyAccount(call?.to ?? call?.callee ?? call?.called ?? call?.remote_party ?? call?.remoteParty);
  const callerIsLocal = caller ? tenantExtensions.has(caller) : false;
  const calleeIsLocal = callee ? tenantExtensions.has(callee) : false;
  if (callerIsLocal && !calleeIsLocal) return "outbound";
  if (!callerIsLocal && calleeIsLocal) return "inbound";
  if (callerIsLocal && calleeIsLocal) return "internal";
  return call?.direction ?? call?.dir ?? null;
}

function deriveLiveCallDurationSeconds(call) {
  const connect = Number(call?.connect);
  const now = Number(call?.now);
  if (Number.isFinite(connect) && connect > 0 && Number.isFinite(now) && now >= connect) return Math.floor(now - connect);
  const existing = call?.duration ?? call?.duration_seconds ?? call?.durationSeconds;
  return existing ?? null;
}

server.registerTool(
  "list_tenant_live_calls",
  {
    title: "List active calls across a tenant",
    description: "Enumerate tenant extensions, read each account's active call legs, and group matching legs by stable call ID.",
    inputSchema: {
      domain: z.string().min(1),
      max_accounts: z.number().int().min(1).max(1000).default(500),
      concurrency: z.number().int().min(1).max(20).default(8),
    },
    outputSchema: toolOutputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  },
  async ({ domain, max_accounts, concurrency }) => {
    scopedAudit("list_tenant_live_calls", { domain, max_accounts, concurrency });
    try {
      const extensionResult = await callOperation("get_rest_domain_domain_extensions_3", {
        pathParams: { domain },
      });
      const records = Array.isArray(extensionResult.data) ? extensionResult.data : [];
      const extensions = records
        .map((record) => {
          const alias = Array.isArray(record?.alias) ? record.alias[0] : record?.alias;
          return String(record?.name ?? record?.account ?? record?.extension ?? record?.ext ?? alias ?? "").trim();
        })
        .filter(Boolean)
        .slice(0, max_accounts);
      const tenantExtensions = new Set(extensions);
      const legs = [];
      const errors = [];
      for (let offset = 0; offset < extensions.length; offset += concurrency) {
        const batch = extensions.slice(offset, offset + concurrency);
        const results = await Promise.all(batch.map(async (extension) => {
          const account = `${extension}@${domain}`;
          try {
            const result = await callOperation("get_rest_user_account_calls", { pathParams: { account } });
            const calls = Array.isArray(result.data) ? result.data : Array.isArray(result.data?.calls) ? result.data.calls : [];
            return { account, calls };
          } catch (error) {
            return { account, error: error.message || String(error) };
          }
        }));
        for (const result of results) {
          if (result.error) {
            errors.push({ account: result.account, error: result.error });
            continue;
          }
          for (const call of result.calls) {
            legs.push({
              account: result.account,
              callId: String(call?.id ?? call?.call_id ?? call?.callId ?? ""),
              legId: String(call?.leg_id ?? call?.legId ?? call?.id ?? ""),
              state: call?.state ?? call?.status ?? null,
              held: Boolean(call?.held ?? /hold/i.test(String(call?.state ?? call?.status ?? ""))),
              caller: call?.from ?? call?.caller ?? call?.calling ?? null,
              callee: call?.to ?? call?.callee ?? call?.called ?? call?.remote_party ?? call?.remoteParty ?? null,
              direction: deriveLiveCallDirection(call, tenantExtensions),
              durationSeconds: deriveLiveCallDurationSeconds(call),
              raw: call,
            });
          }
        }
      }
      const grouped = new Map();
      for (const leg of legs) {
        const key = leg.callId || `leg:${leg.account}:${leg.legId}`;
        if (!grouped.has(key)) grouped.set(key, { callId: leg.callId || null, legs: [] });
        grouped.get(key).legs.push(leg);
      }
      return scopedSuccess(
        { calls: [...grouped.values()], legs, errors },
        { domain, accountsChecked: extensions.length, activeCallCount: grouped.size, activeLegCount: legs.length, failedAccounts: errors.length },
        `Checked ${extensions.length} accounts and found ${grouped.size} active calls across ${legs.length} legs.`
      );
    } catch (error) {
      return failure(error);
    }
  }
);

registerPbXReadTool(
  "get_extension_registration_history",
  {
    title: "Get extension registration history",
    description: "Read SIP registration history for an extension account.",
    inputSchema: {
      account: z.string().min(3).describe("Extension in extension@tenant-domain form"),
    },
  },
  "get_rest_user_account_reghist",
  ({ account }) => ({ pathParams: { account } })
);

registerPbXReadTool(
  "get_voicemail_metadata",
  {
    title: "Get voicemail metadata",
    description: "Read paginated voicemail metadata only; voicemail audio remains blocked.",
    inputSchema: {
      account: z.string().min(3).describe("Extension in extension@tenant-domain form"),
      page: z.number().int().min(1).default(1),
      size: z.number().int().min(1).max(100).default(25),
      unread_only: z.boolean().default(false),
    },
  },
  "get_rest_user_account_messages_2",
  ({ account, page, size, unread_only }) => ({
    pathParams: { account },
    queryParams: { page, size, api: "2", ...(unread_only ? { filter: "unread" } : {}) },
  })
);

registerPbXReadTool(
  "get_tenant_stats",
  {
    title: "Get tenant call statistics",
    description: "Get tenant call or quality statistics, including MOS data when supported by the PBX.",
    inputSchema: {
      domain: z.string().min(1),
      type: z.string().min(1).optional(),
    },
  },
  TENANT_STATS_OPERATION_ID,
  ({ domain, type }) => ({
    pathParams: { domain },
    queryParams: type ? { type } : {},
  })
);

registerPbXReadTool(
  "get_trunk_stats",
  {
    title: "Get trunk statistics",
    description: "Get call or quality statistics for one or all tenant trunks.",
    inputSchema: {
      domain: z.string().min(1),
      trunk: z.string().min(1).optional(),
      type: z.string().min(1).optional(),
    },
  },
  TRUNK_STATS_OPERATION_ID,
  ({ domain, trunk, type }) => ({
    pathParams: { domain },
    queryParams: {
      ...(trunk ? { trunk } : {}),
      ...(type ? { type } : {}),
    },
  })
);

registerPbXReadTool(
  "get_live_queue_status",
  {
    title: "Get live call queue status",
    description: "Get current Vodia call queue state for a tenant.",
    inputSchema: { domain: z.string().min(1) },
  },
  "get_rest_domain_domain_status_acds",
  ({ domain }) => ({ pathParams: { domain } })
);

registerPbXReadTool(
  "get_queue_stats",
  {
    title: "Get call queue statistics",
    description: "Get statistics for a call queue and timeframe; useful for queue charts.",
    inputSchema: {
      account: z.string().min(1).describe("Queue account, usually queue@tenant-domain"),
      date: z.string().min(1).optional(),
      days: z.number().int().min(1).max(366).optional(),
    },
  },
  "get_rest_acd_account_stat",
  ({ account, date, days }) => ({
    pathParams: { account },
    queryParams: {
      ...(date ? { date } : {}),
      ...(days ? { days } : {}),
    },
  })
);

registerPbXReadTool(
  "get_queue_cdrs",
  {
    title: "Get call queue CDRs",
    description: "Get paginated call records for a Vodia call queue for analysis and charting.",
    inputSchema: {
      account: z.string().min(1).describe("Queue account, usually queue@tenant-domain"),
      page: z.number().int().min(1).default(1),
      size: z.number().int().min(1).max(500).default(100),
    },
  },
  "get_rest_acd_account_cdr_1",
  ({ account, page, size }) => ({
    pathParams: { account },
    queryParams: { page, size },
  })
);

server.registerTool(
  "find_read_capabilities",
  {
    title: "Find Vodia read capabilities",
    description:
      "Search the official Vodia GET capability catalog before using the universal reader.",
    inputSchema: {
      query: z.string().optional(),
      tag: z.string().optional(),
      include_blocked: z.boolean().default(false),
      limit: z.number().int().min(1).max(100).default(25),
    },
    outputSchema: toolOutputSchema,
    annotations: {
      readOnlyHint: true,
      destructiveHint: false,
      openWorldHint: false,
    },
  },
  async ({ query, tag, include_blocked, limit }) => {
    scopedAudit("find_read_capabilities", { query, tag, include_blocked, limit });
    const needles = String(query || "")
      .trim()
      .toLowerCase()
      .split(/\s+/)
      .filter(Boolean);
    const tagNeedle = String(tag || "").trim().toLowerCase();
    const matches = catalog.operations
      .filter((operation) => include_blocked || operation.callable)
      .filter((operation) => {
        if (!needles.length) return true;
        const searchable = [
          operation.operationId,
          operation.path,
          operation.summary,
          ...(operation.tags || []),
        ]
          .join(" ")
          .toLowerCase();
        return needles.every((needle) => searchable.includes(needle));
      })
      .filter((operation) => {
        if (!tagNeedle) return true;
        return (operation.tags || []).some((item) => item.toLowerCase().includes(tagNeedle));
      })
      .slice(0, limit)
      .map((operation) => ({
        operationId: operation.operationId,
        path: operation.path,
        summary: operation.summary,
        tags: operation.tags,
        parameters: operation.parameters,
        callable: operation.callable,
        blockedReason: operation.blockedReason,
      }));

    return scopedSuccess(
      matches,
      {
        totalGetOperations: catalog.totalGetOperations,
        callableOperations: catalog.callableOperations,
        returned: matches.length,
        vodiaApiVersion: catalog.vodiaApiVersion,
      },
      `Found ${matches.length} matching Vodia read capabilities.`
    );
  }
);

server.registerTool(
  "read_vodia_resource",
  {
    title: "Read any allowlisted Vodia resource",
    description:
      "Call an official Vodia GET operation by operation ID. First use find_read_capabilities to obtain the operation ID and valid parameters.",
    inputSchema: {
      operation_id: z.string().min(1),
      path_params: parameterMapSchema.optional(),
      query_params: parameterMapSchema.optional(),
    },
    outputSchema: toolOutputSchema,
    annotations: {
      readOnlyHint: true,
      destructiveHint: false,
      openWorldHint: false,
    },
  },
  async ({ operation_id, path_params, query_params }) => {
    scopedAudit("read_vodia_resource", { operation_id, path_params, query_params });
    try {
      const result = await callOperation(operation_id, {
        pathParams: path_params || {},
        queryParams: query_params || {},
      });
      return scopedSuccess(
        result.data,
        result.meta,
        `Read '${operation_id}' from Vodia without changing PBX state.`
      );
    } catch (error) {
      return failure(error);
    }
  }
);

server.registerTool(
  "aws_chime_test_connection",
  {
    title: "Test Amazon Chime SDK Voice connection",
    description:
      "Verify the AWS identity available to this MCP host and confirm read access to Amazon Chime SDK Voice. Uses the AWS SDK default credential provider chain; on EC2 this can use the instance IAM role without stored access keys.",
    inputSchema: {
      region: z.string().optional().describe("AWS region such as us-east-1 or ap-northeast-1. Defaults to AWS_CHIME_REGION/AWS_REGION."),
    },
    outputSchema: toolOutputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: true },
  },
  async ({ region } = {}) => {
    scopedAudit("aws_chime_test_connection", { region });
    try {
      const data = await testAwsChimeConnection({ region });
      return scopedSuccess(
        data,
        { provider: "AWS", service: "ChimeSDKVoice", operation: "GetCallerIdentity+ListVoiceConnectors" },
        `AWS authentication and Amazon Chime SDK Voice read access succeeded in ${data.region}.`
      );
    } catch (error) {
      return failure(error, "AWS read");
    }
  }
);

server.registerTool(
  "aws_chime_list_voice_connectors",
  {
    title: "List Amazon Chime Voice Connectors",
    description: "List Amazon Chime SDK Voice Connectors in an AWS region. Read-only.",
    inputSchema: {
      region: z.string().optional(),
      max_results: z.number().int().min(1).max(99).default(20),
      next_token: z.string().optional(),
    },
    outputSchema: toolOutputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: true },
  },
  async ({ region, max_results, next_token }) => {
    scopedAudit("aws_chime_list_voice_connectors", { region, max_results });
    try {
      const data = await listAwsChimeVoiceConnectors({ region, maxResults: max_results, nextToken: next_token });
      return scopedSuccess(
        data,
        { provider: "AWS", service: "ChimeSDKVoice", operation: "ListVoiceConnectors" },
        `Returned ${data.voiceConnectors.length} Amazon Chime Voice Connector(s) from ${data.region}.`
      );
    } catch (error) {
      return failure(error, "AWS read");
    }
  }
);

server.registerTool(
  "aws_chime_get_voice_connector",
  {
    title: "Get Amazon Chime Voice Connector",
    description: "Read one Amazon Chime SDK Voice Connector by ID. Read-only.",
    inputSchema: {
      voice_connector_id: z.string().min(1),
      region: z.string().optional(),
    },
    outputSchema: toolOutputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: true },
  },
  async ({ voice_connector_id, region }) => {
    scopedAudit("aws_chime_get_voice_connector", { voice_connector_id, region });
    try {
      const data = await getAwsChimeVoiceConnector({ voiceConnectorId: voice_connector_id, region });
      return scopedSuccess(
        data,
        { provider: "AWS", service: "ChimeSDKVoice", operation: "GetVoiceConnector" },
        `Returned Amazon Chime Voice Connector '${voice_connector_id}'.`
      );
    } catch (error) {
      return failure(error, "AWS read");
    }
  }
);

server.registerTool(
  "aws_chime_get_termination",
  {
    title: "Get Amazon Chime Voice Connector termination",
    description: "Read outbound/termination settings including calling regions, allowed CIDRs, CPS limit and default phone number.",
    inputSchema: { voice_connector_id: z.string().min(1), region: z.string().optional() },
    outputSchema: toolOutputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: true },
  },
  async ({ voice_connector_id, region }) => {
    scopedAudit("aws_chime_get_termination", { voice_connector_id, region });
    try {
      const data = await getAwsChimeTermination({ voiceConnectorId: voice_connector_id, region });
      return scopedSuccess(data, { provider: "AWS", service: "ChimeSDKVoice", operation: "GetVoiceConnectorTermination" },
        `Returned termination settings for '${voice_connector_id}'.`);
    } catch (error) { return failure(error, "AWS read"); }
  }
);

server.registerTool(
  "aws_chime_get_origination",
  {
    title: "Get Amazon Chime Voice Connector origination",
    description: "Read inbound/origination routes for one Amazon Chime SDK Voice Connector.",
    inputSchema: { voice_connector_id: z.string().min(1), region: z.string().optional() },
    outputSchema: toolOutputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: true },
  },
  async ({ voice_connector_id, region }) => {
    scopedAudit("aws_chime_get_origination", { voice_connector_id, region });
    try {
      const data = await getAwsChimeOrigination({ voiceConnectorId: voice_connector_id, region });
      return scopedSuccess(data, { provider: "AWS", service: "ChimeSDKVoice", operation: "GetVoiceConnectorOrigination" },
        `Returned origination settings for '${voice_connector_id}'.`);
    } catch (error) { return failure(error, "AWS read"); }
  }
);

server.registerTool(
  "aws_chime_list_termination_credentials",
  {
    title: "List Amazon Chime termination credential usernames",
    description: "List termination credential usernames. AWS does not return stored SIP passwords.",
    inputSchema: { voice_connector_id: z.string().min(1), region: z.string().optional() },
    outputSchema: toolOutputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: true },
  },
  async ({ voice_connector_id, region }) => {
    scopedAudit("aws_chime_list_termination_credentials", { voice_connector_id, region });
    try {
      const data = await listAwsChimeTerminationCredentials({ voiceConnectorId: voice_connector_id, region });
      return scopedSuccess(data, { provider: "AWS", service: "ChimeSDKVoice", operation: "ListVoiceConnectorTerminationCredentials" },
        `Returned termination credential usernames for '${voice_connector_id}'.`);
    } catch (error) { return failure(error, "AWS read"); }
  }
);

server.registerTool(
  "aws_chime_get_termination_health",
  {
    title: "Get Amazon Chime termination health",
    description: "Read termination health information for a Voice Connector.",
    inputSchema: { voice_connector_id: z.string().min(1), region: z.string().optional() },
    outputSchema: toolOutputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: true },
  },
  async ({ voice_connector_id, region }) => {
    scopedAudit("aws_chime_get_termination_health", { voice_connector_id, region });
    try {
      const data = await getAwsChimeTerminationHealth({ voiceConnectorId: voice_connector_id, region });
      return scopedSuccess(data, { provider: "AWS", service: "ChimeSDKVoice", operation: "GetVoiceConnectorTerminationHealth" },
        `Returned termination health for '${voice_connector_id}'.`);
    } catch (error) { return failure(error, "AWS read"); }
  }
);

server.registerTool(
  "aws_chime_list_available_regions",
  {
    title: "List available Amazon Chime Voice Connector regions",
    description: "Ask AWS for Voice Connector regions available to the account.",
    inputSchema: { region: z.string().optional() },
    outputSchema: toolOutputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: true },
  },
  async ({ region } = {}) => {
    scopedAudit("aws_chime_list_available_regions", { region });
    try {
      const data = await listAwsChimeAvailableRegions({ region });
      return scopedSuccess(data, { provider: "AWS", service: "ChimeSDKVoice", operation: "ListAvailableVoiceConnectorRegions" },
        "Returned available Amazon Chime Voice Connector regions.");
    } catch (error) { return failure(error, "AWS read"); }
  }
);

server.registerTool(
  "aws_chime_recommend_region",
  {
    title: "Recommend Amazon Chime Voice Connector region",
    description: "Recommend a Voice Connector region from a deployment country and validate it against AWS live availability.",
    inputSchema: { country: z.string().min(2), region: z.string().optional() },
    outputSchema: toolOutputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: true },
  },
  async ({ country, region }) => {
    scopedAudit("aws_chime_recommend_region", { country, region });
    try {
      const data = await recommendAwsChimeRegion({ country, region });
      return scopedSuccess(data, { provider: "AWS", service: "ChimeSDKVoice", operation: "ListAvailableVoiceConnectorRegions" },
        `Recommended ${data.recommendedRegion} for ${data.countryCode}.`);
    } catch (error) { return failure(error, "AWS read"); }
  }
);


server.registerTool(
  "aws_chime_search_available_phone_numbers",
  {
    title: "Search available Amazon Chime phone numbers",
    description: "Search the live Amazon Chime SDK Voice number pool. Read-only.",
    inputSchema: {
      area_code: z.string().optional(),
      city: z.string().optional(),
      state: z.string().optional(),
      country: z.string().default("US"),
      phone_number_type: z.enum(["Local", "TollFree"]).default("Local"),
      max_results: z.number().int().min(1).max(500).default(20),
      region: z.string().optional(),
    },
    outputSchema: toolOutputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: true },
  },
  async ({ area_code, city, state, country, phone_number_type, max_results, region }) => {
    scopedAudit("aws_chime_search_available_phone_numbers", { area_code, city, state, country, phone_number_type, max_results, region });
    try {
      const data = await searchAwsChimeAvailablePhoneNumbers({ areaCode: area_code, city, state, country, phoneNumberType: phone_number_type, maxResults: max_results, region });
      return scopedSuccess(data, { provider: "AWS", service: "ChimeSDKVoice", operation: "SearchAvailablePhoneNumbers" },
        `Returned ${data.phoneNumbers.length} available Amazon Chime phone numbers.`);
    } catch (error) { return failure(error, "AWS read"); }
  }
);

server.registerTool(
  "aws_chime_list_phone_numbers",
  {
    title: "List Amazon Chime phone number inventory",
    description: "List phone numbers already in the AWS account inventory.",
    inputSchema: { region: z.string().optional(), max_results: z.number().int().min(1).max(99).default(20), next_token: z.string().optional() },
    outputSchema: toolOutputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: true },
  },
  async ({ region, max_results, next_token }) => {
    scopedAudit("aws_chime_list_phone_numbers", { region, max_results });
    try {
      const data = await listAwsChimePhoneNumbers({ region, maxResults: max_results, nextToken: next_token });
      return scopedSuccess(data, { provider: "AWS", service: "ChimeSDKVoice", operation: "ListPhoneNumbers" },
        `Returned ${data.phoneNumbers.length} Amazon Chime phone numbers.`);
    } catch (error) { return failure(error, "AWS read"); }
  }
);

server.registerTool(
  "aws_chime_get_phone_number",
  {
    title: "Get Amazon Chime phone number",
    description: "Read details for one Amazon Chime phone number by E.164 number or phone-number ID.",
    inputSchema: { phone_number: z.string().min(1), region: z.string().optional() },
    outputSchema: toolOutputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: true },
  },
  async ({ phone_number, region }) => {
    scopedAudit("aws_chime_get_phone_number", { phone_number, region });
    try {
      const data = await getAwsChimePhoneNumber({ phoneNumber: phone_number, region });
      return scopedSuccess(data, { provider: "AWS", service: "ChimeSDKVoice", operation: "GetPhoneNumber" },
        `Returned Amazon Chime phone number '${phone_number}'.`);
    } catch (error) { return failure(error, "AWS read"); }
  }
);

server.registerTool(
  "aws_chime_list_phone_number_orders",
  {
    title: "List Amazon Chime phone number orders",
    description: "List phone-number orders and statuses.",
    inputSchema: { region: z.string().optional(), max_results: z.number().int().min(1).max(99).default(20), next_token: z.string().optional() },
    outputSchema: toolOutputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: true },
  },
  async ({ region, max_results, next_token }) => {
    scopedAudit("aws_chime_list_phone_number_orders", { region, max_results });
    try {
      const data = await listAwsChimePhoneNumberOrders({ region, maxResults: max_results, nextToken: next_token });
      return scopedSuccess(data, { provider: "AWS", service: "ChimeSDKVoice", operation: "ListPhoneNumberOrders" },
        `Returned ${data.orders.length} Amazon Chime phone-number orders.`);
    } catch (error) { return failure(error, "AWS read"); }
  }
);

server.registerTool(
  "aws_chime_get_phone_number_order",
  {
    title: "Get Amazon Chime phone number order",
    description: "Read one phone-number order by order ID.",
    inputSchema: { order_id: z.string().min(1), region: z.string().optional() },
    outputSchema: toolOutputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: true },
  },
  async ({ order_id, region }) => {
    scopedAudit("aws_chime_get_phone_number_order", { order_id, region });
    try {
      const data = await getAwsChimePhoneNumberOrder({ orderId: order_id, region });
      return scopedSuccess(data, { provider: "AWS", service: "ChimeSDKVoice", operation: "GetPhoneNumberOrder" },
        `Returned Amazon Chime phone-number order '${order_id}'.`);
    } catch (error) { return failure(error, "AWS read"); }
  }
);

if (adminMode) {
  server.registerTool(
    "plan_create_tenant",
    {
      title: "Plan Vodia tenant creation",
      description: "Create an expiring guarded plan for one new Vodia tenant/domain. Performs a live duplicate pre-check and makes no PBX change.",
      inputSchema: {
        tenant: z.string().min(3).max(253),
        reason: z.string().max(1000).optional(),
      },
      outputSchema: toolOutputSchema,
      annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
    },
    async ({ tenant, reason }) => {
      scopedAudit("plan_create_tenant", { tenant, reason });
      try {
        const data = await planCreateTenant({ actor, tenant, reason });
        return scopedSuccess(
          data,
          { operation: "PLAN_CREATE_TENANT", tenant: data.tenant },
          `Prepared Vodia tenant creation for '${data.tenant}'. No PBX changes were made.`
        );
      } catch (error) {
        return failure(error, "tenant creation plan");
      }
    }
  );

  server.registerTool(
    "apply_tenant_change",
    {
      title: "Apply planned Vodia tenant creation",
      description: "Apply one unchanged, unexpired tenant-creation plan through POST /rest/system/domains after exact confirmation, then independently verify the new tenant through GET /rest/system/domains.",
      inputSchema: {
        change_id: z.string().min(1),
        confirmation: z.string().min(1),
      },
      outputSchema: toolOutputSchema,
      annotations: { readOnlyHint: false, destructiveHint: false, openWorldHint: false },
    },
    async ({ change_id, confirmation }) => {
      scopedAudit("apply_tenant_change", {
        change_id,
        confirmation: "[REDACTED_CONFIRMATION]",
      });
      try {
        const data = await applyCreateTenant({
          actor,
          changeId: change_id,
          confirmation,
        });
        scopedAudit("vodia_change_applied", {
          operationId: "CreateVodiaTenant",
          status: "verified",
          tenant: data.tenant,
          changed_fields: ["tenant"],
        });
        return scopedSuccess(
          data,
          { operation: "APPLY_CREATE_TENANT", tenant: data.tenant },
          `Created and verified Vodia tenant '${data.tenant}'.`
        );
      } catch (error) {
        return failure(error, "tenant creation apply");
      }
    }
  );

  server.registerTool(
    "aws_chime_plan_create_voice_connector",
    {
      title: "Plan Amazon Chime Voice Connector creation",
      description: "Create an expiring guarded plan. This does not change AWS.",
      inputSchema: {
        name: z.string().min(1).max(256),
        deployment_country: z.string().min(2),
        region: z.string().optional(),
        require_encryption: z.boolean().default(true),
        network_type: z.enum(["IPV4_ONLY", "DUAL_STACK"]).default("IPV4_ONLY"),
      },
      outputSchema: toolOutputSchema,
      annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: true },
    },
    async ({ name, deployment_country, region, require_encryption, network_type }) => {
      scopedAudit("aws_chime_plan_create_voice_connector", { name, deployment_country, region, require_encryption, network_type });
      try {
        const data = await planAwsChimeCreateVoiceConnector({
          actor, name, deploymentCountry: deployment_country, region,
          requireEncryption: require_encryption, networkType: network_type,
        });
        return scopedSuccess(data, { provider: "AWS", service: "ChimeSDKVoice", operation: "PLAN CreateVoiceConnector" },
          `Planned Amazon Chime Voice Connector '${name}'. Review and apply only with the exact confirmation.`);
      } catch (error) { return failure(error, "AWS plan"); }
    }
  );


  server.registerTool(
    "aws_chime_plan_order_phone_number",
    {
      title: "Plan Amazon Chime phone number order",
      description: "Create an expiring guarded plan to order one available phone number. Does not change AWS.",
      inputSchema: { phone_number: z.string().min(1), region: z.string().optional() },
      outputSchema: toolOutputSchema,
      annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: true },
    },
    async ({ phone_number, region }) => {
      scopedAudit("aws_chime_plan_order_phone_number", { phone_number, region });
      try {
        const data = await planAwsChimeOrderPhoneNumber({ actor, phoneNumber: phone_number, region });
        return scopedSuccess(data, { provider: "AWS", service: "ChimeSDKVoice", operation: "PLAN CreatePhoneNumberOrder" },
          `Planned order of '${phone_number}'.`);
      } catch (error) { return failure(error, "AWS plan"); }
    }
  );

  server.registerTool(
    "aws_chime_plan_assign_phone_number",
    {
      title: "Plan Amazon Chime phone number assignment",
      description: "Create an expiring guarded plan to assign an owned phone number to a Voice Connector. ForceAssociate is always false.",
      inputSchema: { phone_number: z.string().min(1), voice_connector_id: z.string().min(1), region: z.string().optional() },
      outputSchema: toolOutputSchema,
      annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: true },
    },
    async ({ phone_number, voice_connector_id, region }) => {
      scopedAudit("aws_chime_plan_assign_phone_number", { phone_number, voice_connector_id, region });
      try {
        const data = await planAwsChimeAssignPhoneNumber({ actor, phoneNumber: phone_number, voiceConnectorId: voice_connector_id, region });
        return scopedSuccess(data, { provider: "AWS", service: "ChimeSDKVoice", operation: "PLAN AssociatePhoneNumbersWithVoiceConnector" },
          `Planned assignment of '${phone_number}' to Voice Connector '${voice_connector_id}'.`);
      } catch (error) { return failure(error, "AWS plan"); }
    }
  );


  server.registerTool(
    "aws_chime_plan_set_termination_credentials",
    {
      title: "Plan Amazon Chime termination credentials",
      description: "Create an expiring guarded plan to set or replace SIP termination credentials on one Voice Connector. The password is never returned in clear text and is redacted from audit output.",
      inputSchema: {
        voice_connector_id: z.string().min(1),
        username: z.string().min(1).max(256),
        password: z.string().min(8).max(256),
        region: z.string().optional(),
      },
      outputSchema: toolOutputSchema,
      annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: true },
    },
    async ({ voice_connector_id, username, password, region }) => {
      scopedAudit("aws_chime_plan_set_termination_credentials", {
        voice_connector_id, username, password: "[REDACTED]", region
      });
      try {
        const data = await planAwsChimeSetTerminationCredentials({
          actor, voiceConnectorId: voice_connector_id, username, password, region
        });
        return scopedSuccess(
          data,
          { provider: "AWS", service: "ChimeSDKVoice", operation: "PLAN PutVoiceConnectorTerminationCredentials" },
          `Planned Amazon Chime termination credential update for '${username}' on '${voice_connector_id}'.`
        );
      } catch (error) { return failure(error, "AWS plan"); }
    }
  );

  server.registerTool(
    "aws_chime_plan_update_termination",
    {
      title: "Plan Amazon Chime termination update",
      description: "Create an expiring guarded plan to update Voice Connector termination settings such as calling regions, allowed CIDRs, CPS limit, default phone number, or disabled state.",
      inputSchema: {
        voice_connector_id: z.string().min(1),
        calling_regions: z.array(z.string().min(1)).optional(),
        cidr_allowed_list: z.array(z.string().min(1)).optional(),
        cps_limit: z.number().int().min(1).max(100).optional(),
        default_phone_number: z.string().optional(),
        disabled: z.boolean().optional(),
        region: z.string().optional(),
      },
      outputSchema: toolOutputSchema,
      annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: true },
    },
    async ({ voice_connector_id, calling_regions, cidr_allowed_list, cps_limit, default_phone_number, disabled, region }) => {
      scopedAudit("aws_chime_plan_update_termination", {
        voice_connector_id, calling_regions, cidr_allowed_list, cps_limit,
        default_phone_number, disabled, region
      });
      try {
        const data = await planAwsChimeUpdateTermination({
          actor, voiceConnectorId: voice_connector_id, callingRegions: calling_regions,
          cidrAllowedList: cidr_allowed_list, cpsLimit: cps_limit,
          defaultPhoneNumber: default_phone_number, disabled, region
        });
        return scopedSuccess(
          data,
          { provider: "AWS", service: "ChimeSDKVoice", operation: "PLAN PutVoiceConnectorTermination" },
          `Planned Amazon Chime termination update for '${voice_connector_id}'.`
        );
      } catch (error) { return failure(error, "AWS plan"); }
    }
  );

  server.registerTool(
    "aws_chime_plan_update_origination",
    {
      title: "Plan Amazon Chime origination update",
      description: "Create an expiring guarded plan to update Voice Connector origination routes toward the PBX.",
      inputSchema: {
        voice_connector_id: z.string().min(1),
        disabled: z.boolean().optional(),
        routes: z.array(z.object({
          host: z.string().min(1),
          port: z.number().int().min(1).max(65535).default(5060),
          priority: z.number().int().min(1).max(100).default(1),
          protocol: z.enum(["TCP","UDP"]).default("TCP"),
          weight: z.number().int().min(1).max(100).default(1),
        })).optional(),
        region: z.string().optional(),
      },
      outputSchema: toolOutputSchema,
      annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: true },
    },
    async ({ voice_connector_id, disabled, routes, region }) => {
      scopedAudit("aws_chime_plan_update_origination", {
        voice_connector_id, disabled, routes, region
      });
      try {
        const data = await planAwsChimeUpdateOrigination({
          actor, voiceConnectorId: voice_connector_id, disabled, routes, region
        });
        return scopedSuccess(
          data,
          { provider: "AWS", service: "ChimeSDKVoice", operation: "PLAN PutVoiceConnectorOrigination" },
          `Planned Amazon Chime origination update for '${voice_connector_id}'.`
        );
      } catch (error) { return failure(error, "AWS plan"); }
    }
  );

  server.registerTool(
    "aws_chime_apply_change",
    {
      title: "Apply planned Amazon Chime change",
      description: "Apply one unchanged, unexpired AWS Chime plan. Phase 2 supports guarded Voice Connector creation.",
      inputSchema: { change_id: z.string().min(1), confirmation: z.string().min(1) },
      outputSchema: toolOutputSchema,
      annotations: { readOnlyHint: false, destructiveHint: false, openWorldHint: true },
    },
    async ({ change_id, confirmation }) => {
      scopedAudit("aws_chime_apply_change", { change_id });
      try {
        const data = await applyAwsChimeChange({ actor, changeId: change_id, confirmation });
        scopedAudit("aws_chime_change_applied", {
          change_id, operation: data.operation, region: data.region,
          voice_connector_id: data.voiceConnector?.voiceConnectorId || null,
          name: data.voiceConnector?.name || null,
        });
        return scopedSuccess(data, { provider: "AWS", service: "ChimeSDKVoice", operation: data.operation },
          `Applied AWS Chime change '${change_id}'.`);
      } catch (error) { return failure(error, "AWS write"); }
    }
  );
}


server.registerTool(
  "pbx_ai_get_workflow_catalog",
  {
    title: "Get AI PBX workflow catalog",
    description: "Describe the high-level PBX operational workflows, safe defaults, approval model, and tool families that the MCP knows. Use this to turn natural-language administrator requests into consistent PBX workflows.",
    inputSchema: {},
    outputSchema: toolOutputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  },
  async () => {
    scopedAudit("pbx_ai_get_workflow_catalog", {});
    try {
      const data = getAiWorkflowCatalog();
      return scopedSuccess(
        data,
        { operation: "AI_WORKFLOW_CATALOG" },
        "Returned the Vodia MCP AI workflow catalog."
      );
    } catch (error) {
      return failure(error, "workflow catalog");
    }
  }
);


server.registerTool(
  "pbx_ai_prepare_guided_workflow",
  {
    title: "Prepare guided PBX administrator workflow",
    description: "Turn a normal human PBX request into a minimal-question guided workflow. The MCP cross-checks live tenant/account/trunk/routing state when possible, asks only for essential business inputs it cannot discover, and never changes the PBX. Use this before planning normal administrator tasks such as creating extensions, dial plans, trunks, DID routes, queues, IVRs, phones, voicemail, or Amazon Chime.",
    inputSchema: {
      request: z.string().min(1).max(2000),
      tenant: z.string().optional(),
      first_name: z.string().optional(),
      last_name: z.string().optional(),
      extension: z.string().optional(),
      email: z.string().email().optional(),
      mac_address: z.string().optional(),
      provider: z.string().optional(),
      country: z.string().optional(),
      area_code: z.string().optional(),
      did: z.string().optional(),
      destination: z.string().optional(),
      purpose: z.string().optional(),
      dialing_pattern: z.string().optional(),
      trunk: z.string().optional(),
      queue_number: z.string().optional(),
      queue_name: z.string().optional(),
      agents: z.array(z.string()).optional(),
      ivr_number: z.string().optional(),
      ivr_name: z.string().optional(),
      menu_options: z.any().optional(),
      region: z.string().optional(),
      details: z.record(z.string(), z.any()).optional(),
    },
    outputSchema: toolOutputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: true },
  },
  async (args) => {
    const {
      request, tenant, first_name, last_name, extension, email, mac_address,
      provider, country, area_code, did, destination, purpose, dialing_pattern,
      trunk, queue_number, queue_name, agents, ivr_number, ivr_name,
      menu_options, region, details
    } = args;

    scopedAudit("pbx_ai_prepare_guided_workflow", {
      request, tenant, first_name, last_name, extension, email,
      mac_address: mac_address ? "[REDACTED_MAC]" : undefined,
      provider, country, area_code, did, destination, purpose,
      dialing_pattern, trunk, queue_number, queue_name, agents,
      ivr_number, ivr_name, region,
    });

    try {
      const base = await prepareAiWorkflow({
        request, tenant, country, areaCode: area_code, provider, region
      });
      const workflowId = base.workflow?.id || "general";
      const discovery = {
        resolvedTenant: tenant || null,
        tenantExists: null,
        accountNumberConflict: null,
        existingAccount: null,
        existingTrunks: [],
        existingDialPlans: [],
        existingQueues: [],
        existingAutoAttendants: [],
        existingServiceFlags: [],
        checks: [],
        warnings: [],
      };

      // Resolve tenant automatically only when there is exactly one visible tenant.
      let visibleDomains = [];
      try {
        const domainsResult = await callOperation("get_rest_system_domains");
        const rawDomains = Array.isArray(domainsResult.data) ? domainsResult.data : [];
        visibleDomains = rawDomains
          .map((x) => String(x?.domain ?? x?.name ?? x?.id ?? x ?? "").trim())
          .filter(Boolean);

        if (!discovery.resolvedTenant && visibleDomains.length === 1) {
          discovery.resolvedTenant = visibleDomains[0];
          discovery.checks.push(`Resolved the only visible tenant: ${visibleDomains[0]}.`);
        }
        if (discovery.resolvedTenant) {
          discovery.tenantExists = visibleDomains.some(
            (d) => d.toLowerCase() === String(discovery.resolvedTenant).toLowerCase()
          );
          if (!discovery.tenantExists) {
            discovery.warnings.push(`Tenant '${discovery.resolvedTenant}' was not found in the visible tenant list.`);
          }
        }
      } catch (error) {
        discovery.warnings.push(`Tenant discovery could not be completed: ${error.message || error}`);
      }

      const domain = discovery.resolvedTenant;

      if (domain) {
        // Cross-check the complete tenant account namespace for number conflicts.
        try {
          const accountsResult = await callOperation("get_rest_domain_domain_users", {
            pathParams: { domain }
          });
          const accounts = Array.isArray(accountsResult.data) ? accountsResult.data : [];
          discovery.accountCount = accounts.length;

          const requestedNumber = extension || queue_number || ivr_number || null;
          if (requestedNumber) {
            const hit = accounts.find((record) => {
              const candidates = [
                record?.name, record?.account, record?.extension, record?.ext,
                Array.isArray(record?.alias) ? record.alias[0] : record?.alias
              ].filter((v) => v !== undefined && v !== null).map(String);
              return candidates.includes(String(requestedNumber));
            });
            discovery.accountNumberConflict = Boolean(hit);
            discovery.existingAccount = hit || null;
            discovery.checks.push(
              hit
                ? `Account number ${requestedNumber} is already in use.`
                : `Account number ${requestedNumber} is available across the returned tenant account list.`
            );
          }
        } catch (error) {
          discovery.warnings.push(`Account conflict check failed: ${error.message || error}`);
        }

        const safeRead = async (operationId, key) => {
          try {
            const result = await callOperation(operationId, { pathParams: { domain } });
            discovery[key] = Array.isArray(result.data) ? result.data : result.data ? [result.data] : [];
          } catch (error) {
            discovery.warnings.push(`${key} discovery failed: ${error.message || error}`);
          }
        };

        if (workflowId === "dial_plan") {
          await safeRead("get_rest_domain_domain_dialplans", "existingDialPlans");
          await safeRead("get_rest_domain_domain_domain_trunks", "existingTrunks");
          if (!trunk && discovery.existingTrunks.length === 1) {
            const only = discovery.existingTrunks[0];
            discovery.recommendedTrunk = String(only?.name ?? only?.id ?? only?.trunk ?? "").trim() || null;
            if (discovery.recommendedTrunk) {
              discovery.checks.push(`Only one trunk was returned; recommended '${discovery.recommendedTrunk}'.`);
            }
          }
        } else if (workflowId === "sip_trunk") {
          await safeRead("get_rest_domain_domain_domain_trunks", "existingTrunks");
        } else if (workflowId === "queue") {
          await safeRead("get_rest_domain_domain_acds_1", "existingQueues");
        } else if (workflowId === "ivr") {
          await safeRead("get_rest_domain_domain_attendants", "existingAutoAttendants");
        } else if (workflowId === "extension" || workflowId === "phone" || workflowId === "voicemail") {
          try {
            const extResult = await callOperation("get_rest_domain_domain_extensions_3", {
              pathParams: { domain },
              queryParams: extension ? { account: extension } : {},
            });
            const rows = Array.isArray(extResult.data) ? extResult.data : extResult.data ? [extResult.data] : [];
            discovery.extensionMatches = rows;
            if (extension) {
              discovery.extensionExists = rows.length > 0;
            }
          } catch (error) {
            discovery.warnings.push(`Extension discovery failed: ${error.message || error}`);
          }
        }
      }

      const inputState = buildGuidedInputState(workflowId, {
        request, tenant: discovery.resolvedTenant || tenant,
        first_name, last_name, extension, email, mac_address,
        provider, country, area_code, did, destination, purpose,
        dialing_pattern, trunk, queue_number, queue_name, agents,
        ivr_number, ivr_name, menu_options, region, details
      }, discovery);

      const blockers = [];
      if (discovery.resolvedTenant && discovery.tenantExists === false) {
        blockers.push({
          type: "tenant",
          reason: `Tenant '${discovery.resolvedTenant}' does not exist or is not visible to this MCP.`
        });
      }
      if (discovery.accountNumberConflict && ["extension","queue","ivr"].includes(workflowId)) {
        blockers.push({
          type: "account_number_conflict",
          reason: "The requested account number is already in use. Choose another number or explicitly request an update to the existing account."
        });
      }

      const requiredQuestions = inputState.questions.filter((q) => !q.optional);
      const status = blockers.length
        ? "BLOCKED"
        : requiredQuestions.length
          ? "NEEDS_INPUT"
          : "READY_FOR_PLAN";

      return scopedSuccess(
        {
          workflow: base.workflow,
          humanGoal: inputState.definition.humanGoal,
          status,
          resolvedInputs: inputState.resolved,
          questions: inputState.questions,
          automaticChecks: inputState.definition.automaticChecks || [],
          recommendedDefaults: inputState.definition.defaults || [],
          verificationGoals: inputState.definition.verify || [],
          discovery,
          blockers,
          policy: {
            askOnlyForMissingHumanFacts: true,
            discoverBeforeAsking: true,
            noChangesFromThisTool: true,
            writeFlow: "DISCOVER → ASK ONLY WHAT IS MISSING → RECOMMEND → PLAN → APPROVAL → APPLY → VERIFY → REPORT",
          },
          changesMade: false,
        },
        { operation: "AI_PREPARE_GUIDED_WORKFLOW", workflowId, status },
        status === "READY_FOR_PLAN"
          ? `Guided ${workflowId} workflow is ready for guarded planning. No changes were made.`
          : status === "NEEDS_INPUT"
            ? `Guided ${workflowId} workflow needs ${requiredQuestions.length} essential answer(s). No changes were made.`
            : `Guided ${workflowId} workflow is blocked. No changes were made.`
      );
    } catch (error) {
      return failure(error, "guided workflow preparation");
    }
  }
);



server.registerTool(
  "pbx_ai_get_3cx_inventory",
  {
    title: "Get 3CX migration object inventory",
    description: "Read object-level sanitized inventory from a normalized 3CX import file so the AI can build concrete Vodia plans from real extensions, MACs, groups, queues, IVRs, trunks, gateways, outbound rules, park orbits, fax, and conference objects. Read-only. Use pagination for large collections.",
    inputSchema: {
      filename: z.string().min(1),
      category: z.enum([
        "users",
        "extensions",
        "phones",
        "ring_groups",
        "queues",
        "ivrs",
        "trunks",
        "gateways",
        "outbound_rules",
        "groups",
        "park_orbits",
        "fax_extensions",
        "conference_extensions",
      ]),
      offset: z.number().int().min(0).default(0),
      limit: z.number().int().min(1).max(100).default(25),
    },
    outputSchema: toolOutputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  },
  async ({ filename, category, offset, limit }) => {
    scopedAudit("pbx_ai_get_3cx_inventory", { filename, category, offset, limit });
    try {
      const loaded = load3cxNormalizedImport(filename);
      const inventory = get3cxInventoryCategory(loaded.data, category);

      const total = inventory.items.length;
      const start = Math.min(offset, total);
      const end = Math.min(start + limit, total);
      const items = inventory.items
        .slice(start, end)
        .map((item) => sanitize3cxInventoryItem(category, item));

      return scopedSuccess(
        {
          sourceFile: loaded.filename,
          category,
          sourceShape: inventory.sourceShape,
          total,
          offset: start,
          limit,
          returned: items.length,
          hasMore: end < total,
          nextOffset: end < total ? end : null,
          items,
          changesMade: false,
          security: {
            secretsRedacted: true,
            note: "Object inventory comes from the sanitized analyzer output and is redacted again before return.",
          },
        },
        { operation: "AI_GET_3CX_INVENTORY", category, total },
        `Returned ${items.length} of ${total} sanitized 3CX ${category} objects. No PBX changes were made.`
      );
    } catch (error) {
      return failure(error, "3CX inventory read");
    }
  }
);



const THREE_CX_RAW_IMPORT_DIR = process.env.VODIA_MCP_3CX_RAW_IMPORT_DIR || "/var/lib/vodia-mcp/3cx-raw-imports";
const THREE_CX_ANALYZER = process.env.VODIA_MCP_3CX_ANALYZER || "/root/analyze-3cx-backup.py";
const THREE_CX_MAX_ZIP_BYTES = Number(process.env.VODIA_MCP_3CX_MAX_ZIP_BYTES || 1073741824);

function resolve3cxRawZip(filename) {
  const safe = path.basename(String(filename || ""));
  if (!safe || !/^[A-Za-z0-9._ -]+\.zip$/i.test(safe)) throw new Error("Use a simple .zip filename.");
  const root = path.resolve(THREE_CX_RAW_IMPORT_DIR);
  const full = path.resolve(root, safe);
  if (!full.startsWith(root + path.sep)) throw new Error("Invalid raw import path.");
  const st = fs.statSync(full);
  if (!st.isFile()) throw new Error("3CX backup is not a regular file.");
  if (st.size > THREE_CX_MAX_ZIP_BYTES) throw new Error("3CX backup exceeds configured size limit.");
  return { safe, full, size: st.size };
}

function inspect3cxZipSafety(zipPath) {
  const code = [
    "import sys,zipfile",
    "p=sys.argv[1]",
    "z=zipfile.ZipFile(p)",
    "total=0",
    "count=0",
    "for i in z.infolist():",
    " n=i.filename.replace('\\\\\\\\','/')",
    " if n.startswith('/') or n.startswith('../') or '/../' in n: raise SystemExit('unsafe ZIP path: '+n)",
    " total += int(i.file_size or 0); count += 1",
    " if total > 5*1024*1024*1024: raise SystemExit('ZIP uncompressed size exceeds limit')",
    "print(count,total)"
  ].join("\n");
  const r=spawnSync("python3",["-c",code,zipPath],{encoding:"utf8",timeout:30000});
  if(r.status!==0) throw new Error(`3CX ZIP safety check failed: ${(r.stderr||r.stdout||"").trim()}`);
  const [members,uncompressedBytes]=String(r.stdout||"").trim().split(/\s+/).map(Number);
  return {members,uncompressedBytes};
}

function run3cxAnalyzer(zipPath, normalizedOut) {
  if(!fs.existsSync(THREE_CX_ANALYZER)) throw new Error(`3CX analyzer not found at ${THREE_CX_ANALYZER}`);
  const r=spawnSync("python3",[THREE_CX_ANALYZER,zipPath,"--json-out",normalizedOut],
    {encoding:"utf8",timeout:120000,maxBuffer:8*1024*1024});
  if(r.status!==0) throw new Error(`3CX analyzer failed: ${(r.stderr||r.stdout||"").trim()}`);
  if(!fs.existsSync(normalizedOut)) throw new Error("Analyzer produced no normalized JSON.");
}

function classify3cxMigration(inv) {
  const automatic=[], review=[], productionBlockers=[];
  if(inv.counts.extensions) automatic.push(`${inv.counts.extensions} users/extensions`);
  if(inv.counts.ringGroups) automatic.push(`${inv.counts.ringGroups} ring groups`);
  if(inv.counts.queues) automatic.push(`${inv.counts.queues} queues`);
  if(inv.counts.faxExtensions) automatic.push(`${inv.counts.faxExtensions} fax extensions`);
  if(inv.counts.conferenceExtensions) automatic.push(`${inv.counts.conferenceExtensions} conference extensions`);
  const multi=inv.extensions.filter(u=>arr(u?.phones).length>1).length;
  if(multi) review.push(`${multi} users have multiple device records`);
  if(inv.counts.ivrs) review.push(`${inv.counts.ivrs} IVRs need action/destination validation`);
  if(inv.counts.parkOrbits) review.push(`${inv.counts.parkOrbits} park-orbit records need Vodia mapping`);
  if(inv.counts.outboundRules) review.push(`${inv.counts.outboundRules} outbound rules need ordered dial-plan translation`);
  if(inv.counts.trunks+inv.counts.gateways) productionBlockers.push("Carrier/trunk connectivity must be verified before cutover.");
  if(inv.counts.outboundRules) productionBlockers.push("Emergency/outbound routing must be verified before cutover.");
  return {automatic,review,productionBlockers};
}


server.registerTool(
  "pbx_ai_ingest_3cx_backup",
  {
    title: "Ingest raw 3CX backup ZIP",
    description: "Safely analyze a raw 3CX backup ZIP already staged in the protected MCP raw-import directory, normalize it, inventory it, and prepare it for the high-level new-tenant conversion wizard. Read-only with respect to Vodia PBX.",
    inputSchema: { filename: z.string().min(1) },
    outputSchema: toolOutputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  },
  async ({ filename }) => {
    scopedAudit("pbx_ai_ingest_3cx_backup",{filename});
    try {
      const raw=resolve3cxRawZip(filename);
      const zipSafety=inspect3cxZipSafety(raw.full);
      fs.mkdirSync(THREE_CX_IMPORT_DIR,{recursive:true,mode:0o750});
      const normalizedFile=raw.safe.replace(/\.zip$/i,"")+"-normalized.json";
      const normalizedPath=path.join(THREE_CX_IMPORT_DIR,normalizedFile);
      run3cxAnalyzer(raw.full,normalizedPath);
      const loaded=load3cxNormalizedImport(normalizedFile);
      const inv=migrationInventory(loaded.data);
      return scopedSuccess({
        status:"INGESTED",changesMade:false,sourceZip:raw.safe,sourceBytes:raw.size,
        zipSafety,normalizedFile,counts:inv.counts,missingEmailExtensions:inv.missingEmail,
        classification:classify3cxMigration(inv),
        nextStep:{tool:"pbx_ai_prepare_3cx_tenant_conversion",filename:normalizedFile}
      },{operation:"AI_INGEST_3CX_BACKUP",sourceZip:raw.safe},
      "3CX backup analyzed and normalized. No Vodia PBX changes were made.");
    } catch(error) { return failure(error,"3CX backup ingestion"); }
  }
);


function compact3cxUserForPlan(user) {
  return sanitize3cxInventoryItem("extensions", {
    extension: user?.extension ?? user?.number ?? user?.ext ?? null,
    first_name: user?.first_name ?? user?.firstname ?? null,
    last_name: user?.last_name ?? user?.lastname ?? null,
    display_name: user?.display_name ?? user?.name ?? null,
    email: user?.email ?? null,
    outbound_caller_id: user?.outbound_caller_id ?? user?.caller_id ?? null,
    enabled: user?.enabled,
    voicemail_enabled: user?.voicemail_enabled,
    record_calls: user?.record_calls,
    phones: arr(user?.phones),
  });
}

function build3cxCompleteConversionPlan(data, decisions = {}) {
  const inv = migrationInventory(data);
  const newTenant = decisions.new_tenant ? normalizeTenantName(decisions.new_tenant) : null;

  const users = inv.extensions.map(compact3cxUserForPlan);
  const phones = get3cxInventoryCategory(data, "phones").items
    .map((x) => sanitize3cxInventoryItem("phones", x));
  const ringGroups = get3cxInventoryCategory(data, "ring_groups").items
    .map((x) => sanitize3cxInventoryItem("ring_groups", x));
  const queues = get3cxInventoryCategory(data, "queues").items
    .map((x) => sanitize3cxInventoryItem("queues", x));
  const ivrs = get3cxInventoryCategory(data, "ivrs").items
    .map((x) => sanitize3cxInventoryItem("ivrs", x));
  const outboundRules = get3cxInventoryCategory(data, "outbound_rules").items
    .map((x) => sanitize3cxInventoryItem("outbound_rules", x));
  const parkOrbits = get3cxInventoryCategory(data, "park_orbits").items
    .map((x) => sanitize3cxInventoryItem("park_orbits", x));
  const fax = get3cxInventoryCategory(data, "fax_extensions").items
    .map((x) => sanitize3cxInventoryItem("fax_extensions", x));
  const conference = get3cxInventoryCategory(data, "conference_extensions").items
    .map((x) => sanitize3cxInventoryItem("conference_extensions", x));
  const trunks = get3cxInventoryCategory(data, "trunks").items
    .map((x) => sanitize3cxInventoryItem("trunks", x));
  const gateways = get3cxInventoryCategory(data, "gateways").items
    .map((x) => sanitize3cxInventoryItem("gateways", x));
  const groups = get3cxInventoryCategory(data, "groups").items
    .map((x) => sanitize3cxInventoryItem("groups", x));

  const missingEmail = users.filter(u => !String(u?.email || "").trim());
  const multiDevice = users.filter(u => arr(u?.phones).length > 1);

  const questions = [];
  if (!newTenant) {
    questions.push({
      id: "new_tenant",
      question: "What domain should I use for the NEW Vodia tenant?",
      required: true,
    });
  }
  if (missingEmail.length && !decisions.email_policy) {
    questions.push({
      id: "email_policy",
      question: `${missingEmail.length} accounts have no email. Create without email, skip them, or require email first?`,
      choices: ["create_without_email", "skip_missing_email", "require_email"],
      required: true,
    });
  }
  if ((trunks.length + gateways.length) && !decisions.trunk_strategy) {
    questions.push({
      id: "trunk_strategy",
      question: "How should trunks/gateways be handled for the first pass?",
      choices: ["skip_first_pass", "manual_review", "migrate_where_possible"],
      required: true,
    });
  }
  if (multiDevice.length && !decisions.device_strategy) {
    questions.push({
      id: "device_strategy",
      question: `${multiDevice.length} users have multiple device records. Review duplicates, keep all, or prefer current candidates?`,
      choices: ["review_duplicates", "all_devices", "prefer_current"],
      required: true,
    });
  }

  const autoTranslations = [];
  const reviewItems = [];
  const cutoverBlockers = [];

  // Vodia-native translations that should not become needless customer questions.
  for (const ivr of ivrs) {
    const token = String(ivr?.number ?? ivr?.extension ?? ivr?.name ?? "").trim().toUpperCase();
    if (token === "HOL") {
      autoTranslations.push({
        source: "HOL",
        action: "translate_to_vodia_service_flag_timeframe",
        reason: "3CX holiday/out-of-office system construct should not become a literal Vodia auto attendant.",
      });
    } else if (token === "QCB") {
      autoTranslations.push({
        source: "QCB",
        action: "translate_to_vodia_queue_callback_setting",
        reason: "3CX QueueCallback is queue behavior, not a standalone dialable Vodia account.",
      });
    }
  }

  for (const group of groups) {
    const name = String(group?.name ?? group?.display_name ?? "").toUpperCase();
    if (name.includes("__DEFAULT__") || name.includes("___FAVORITES___")) {
      autoTranslations.push({
        source: group?.name ?? group,
        action: "skip_3cx_internal_group",
        reason: "3CX default/favorites constructs are not hunt/ring groups.",
      });
    } else {
      reviewItems.push({
        type: "group_mapping",
        source: group,
        reason: "Non-system 3CX group requires Vodia semantic mapping.",
      });
    }
  }

  // Explicit review items.
  if (multiDevice.length) {
    reviewItems.push({
      type: "multiple_device_records",
      count: multiDevice.length,
      extensions: multiDevice.map(u => u.extension).filter(Boolean),
      decision: decisions.device_strategy || null,
      reason: "Do not silently discard device records.",
    });
  }
  if (parkOrbits.length) {
    reviewItems.push({
      type: "park_orbit_mapping",
      count: parkOrbits.length,
      sourceValues: parkOrbits,
      reason: "3CX shared-parking identifiers may not be valid numeric Vodia park accounts.",
    });
  }

  // Cutover blockers do not block safe tenant/account creation.
  if (trunks.length + gateways.length) {
    cutoverBlockers.push({
      type: "carrier_connectivity",
      reason: "Carrier/gateway connectivity and credentials must be explicitly verified before production.",
    });
  }
  if (outboundRules.length) {
    cutoverBlockers.push({
      type: "emergency_outbound_routing",
      reason: "911/988 and outbound route targets must be explicitly mapped and tested before production cutover.",
    });
  }

  const stages = [
    { id: 1, name: "tenant", status: newTenant ? "READY_TO_PLAN" : "NEEDS_INPUT", objectCount: newTenant ? 1 : 0 },
    { id: 2, name: "extensions_users", status: users.length ? "READY_TO_PLAN" : "BLOCKED", objectCount: users.length, objects: users },
    { id: 3, name: "phones_macs", status: phones.length ? "REVIEW_THEN_PLAN" : "SKIP", objectCount: phones.length, objects: phones },
    { id: 4, name: "ring_groups", status: ringGroups.length ? "READY_TO_PLAN" : "SKIP", objectCount: ringGroups.length, objects: ringGroups },
    { id: 5, name: "queues", status: queues.length ? "READY_TO_PLAN" : "SKIP", objectCount: queues.length, objects: queues },
    { id: 6, name: "park_orbits", status: parkOrbits.length ? "REVIEW_THEN_PLAN" : "SKIP", objectCount: parkOrbits.length, objects: parkOrbits },
    { id: 7, name: "conference_fax", status: (conference.length + fax.length) ? "READY_TO_PLAN" : "SKIP", objectCount: conference.length + fax.length, conference, fax },
    { id: 8, name: "ivrs_auto_attendants", status: ivrs.length ? "REVIEW_THEN_PLAN" : "SKIP", objectCount: ivrs.length, objects: ivrs },
    { id: 9, name: "trunks_gateways", status: decisions.trunk_strategy === "skip_first_pass" ? "DEFERRED" : (trunks.length + gateways.length ? "REVIEW_THEN_PLAN" : "SKIP"), objectCount: trunks.length + gateways.length, trunks, gateways },
    { id: 10, name: "dial_plan_outbound_rules", status: decisions.trunk_strategy === "skip_first_pass" ? "DEFERRED" : (outboundRules.length ? "REVIEW_THEN_PLAN" : "SKIP"), objectCount: outboundRules.length, objects: outboundRules },
    { id: 11, name: "verification", status: "AFTER_APPLY", objectCount: 0 },
  ];

  const hardBlockers = [];
  if (inv.counts.extensions === 0 && (phones.length || ringGroups.length || queues.length)) {
    hardBlockers.push({
      type: "missing_extension_root_objects",
      reason: "Dependent objects exist but no users/extensions were parsed.",
    });
  }

  return {
    status: hardBlockers.length ? "BLOCKED" : questions.length ? "NEEDS_INPUT" : "COMPLETE_PLAN_READY_FOR_GUARDED_OBJECT_PLANNING",
    newTenant,
    counts: inv.counts,
    questions,
    hardBlockers,
    autoTranslations,
    reviewItems,
    productionCutoverBlockers: cutoverBlockers,
    stages,
    policy: {
      newTenantOnly: true,
      concreteSourceObjectsIncluded: true,
      neverPlanFromCountsAlone: true,
      neverInventCredentials: true,
      planBeforeApply: true,
      verifyAfterEachStage: true,
      migrationReadinessSeparateFromProductionReadiness: true,
    },
  };
}



function infer3cxAutopilotDefaults(data) {
  const inv = migrationInventory(data);

  const decisions = {
    email_policy: "create_without_email",
    trunk_strategy: "skip_first_pass",
    device_strategy: "review_duplicates",
    internal_groups: "skip",
    hol_translation: "vodia_service_flag_timeframe",
    qcb_translation: "vodia_queue_callback",
    unsupported_legacy_devices: "defer_and_flag",
    dial_plan_when_trunks_skipped: "defer",
    emergency_routing: "production_blocker_until_verified",
    did_inbound_routing: "production_blocker_if_absent",
  };

  const notes = [];
  if (inv.counts.missingEmail) {
    notes.push(`${inv.counts.missingEmail} users without email will be created without email by default.`);
  }
  if (inv.counts.trunks + inv.counts.gateways) {
    notes.push("Trunks/gateways are deferred in the first pass. Tenant creation and safe internal objects may continue.");
  }

  return { decisions, notes };
}

function classifyLikely3cxServiceAccounts(users) {
  const out = [];
  for (const u of users) {
    const ext = String(u?.extension ?? u?.number ?? "").trim();
    const name = String(u?.display_name ?? u?.name ?? `${u?.first_name ?? ""} ${u?.last_name ?? ""}`).trim();
    const email = String(u?.email ?? "").trim().toLowerCase();
    const phones = arr(u?.phones);

    const reasons = [];
    if (!phones.length && /admin|support|test|conway/i.test(name)) reasons.push("name/device pattern suggests admin/support/test account");
    if (!phones.length && email && !/@allisonmackenzie\.com$/i.test(email)) reasons.push("no device and external email domain");
    if (reasons.length) {
      out.push({ extension: ext || null, name: name || null, email: email || null, reasons });
    }
  }
  return out;
}

function suggestVodiaParkOrbitMap(parkOrbits, preferredStart = 100) {
  const count = parkOrbits.length;
  if (!count) return [];
  return parkOrbits.map((source, i) => ({
    source: source?.number ?? source?.extension ?? source?.name ?? source,
    suggestedVodiaOrbit: String(preferredStart + i),
    requiresConflictCheckBeforeApply: true,
  }));
}

function build3cxAutopilotPackage(data, { new_tenant } = {}) {
  const inv = migrationInventory(data);
  const defaults = infer3cxAutopilotDefaults(data);
  const newTenant = new_tenant ? normalizeTenantName(new_tenant) : null;

  const base = build3cxCompleteConversionPlan(data, {
    new_tenant: newTenant || undefined,
    email_policy: defaults.decisions.email_policy,
    trunk_strategy: defaults.decisions.trunk_strategy,
    device_strategy: defaults.decisions.device_strategy,
  });

  const serviceAccounts = classifyLikely3cxServiceAccounts(inv.extensions);
  const parkInventory = get3cxInventoryCategory(data, "park_orbits").items;
  const parkMap = suggestVodiaParkOrbitMap(parkInventory, 100);

  const customerQuestions = [];
  if (!newTenant) {
    customerQuestions.push({
      id: "new_tenant",
      question: "What domain should I use for the new Vodia tenant?",
      required: true,
    });
  }

  // Everything below is review information, not a blocker to safe first-pass migration.
  const reviewSummary = {
    likelyServiceOrAdminAccounts: serviceAccounts,
    proposedParkOrbitMap: parkMap,
    deviceReview: {
      strategy: "review_duplicates",
      rule: "Do not silently migrate every legacy/stale device. Keep ambiguous records visible for admin review.",
    },
    deferred: [
      "carrier trunks/gateways",
      "outbound dial plan until trunks exist",
      "DIDs/inbound rules if absent from source",
      "audio/prompts if absent from source",
      "emergency routing until explicitly configured and tested",
      "unsupported or ambiguous legacy phone models",
    ],
    automaticTranslations: base.autoTranslations,
  };

  const safeFirstPassStages = base.stages.map(stage => {
    if (["trunks_gateways", "dial_plan_outbound_rules"].includes(stage.name)) {
      return { ...stage, status: "DEFERRED_PRODUCTION_DEPENDENCY" };
    }
    if (stage.name === "park_orbits" && parkMap.length) {
      return { ...stage, status: "READY_AFTER_CONFLICT_CHECK", proposedMapping: parkMap };
    }
    if (stage.name === "phones_macs") {
      return { ...stage, status: "READY_WITH_DEVICE_REVIEW_POLICY" };
    }
    if (stage.name === "ivrs_auto_attendants") {
      return { ...stage, status: "READY_FOR_SAFE_TRANSLATION_AND_PARTIAL_DEFER" };
    }
    return stage;
  });

  const finalStatus = customerQuestions.length
    ? "NEEDS_TENANT_DOMAIN"
    : "READY_FOR_SINGLE_MIGRATION_APPROVAL";

  const approvalText = newTenant
    ? `APPROVE 3CX MIGRATION TO ${newTenant}`
    : null;

  return {
    status: finalStatus,
    customerQuestions,
    defaultDecisions: defaults.decisions,
    defaultDecisionNotes: defaults.notes,
    sourceCounts: inv.counts,
    newTenant,
    reviewSummary,
    safeFirstPassStages,
    productionCutoverBlockers: base.productionCutoverBlockers,
    approval: {
      required: Boolean(newTenant),
      requiredConfirmation: approvalText,
      scope: "This approval authorizes the AI to begin the staged migration workflow. Existing low-level guarded apply tools still enforce their own exact confirmations until a separately validated execution orchestrator is introduced. Production-cutover blockers remain deferred and must not be silently bypassed.",
    },
    policy: {
      createNewTenantOnly: true,
      continueSafeStagesWhenProductionDependenciesAreMissing: true,
      noInventedCredentials: true,
      noInventedDids: true,
      noInventedEmergencyRoutes: true,
      noSilentLegacyDeviceDeletion: true,
      verifyEveryAppliedStage: true,
    },
  };
}




function normalizeDeviceToken(value) {
  return String(value || "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "");
}

function deviceFamilyToken(model) {
  // Keep useful alphanumeric family tokens, e.g. T48, T46, X6, D785, VVX450.
  const raw = String(model || "").trim();
  const match = raw.match(/[A-Za-z]+[- ]?\d+[A-Za-z]*/);
  return normalizeDeviceToken(match ? match[0] : raw);
}

function recursivelyCollectModelObjects(value, out = [], depth = 0) {
  if (depth > 6 || value == null) return out;
  if (Array.isArray(value)) {
    for (const item of value) recursivelyCollectModelObjects(item, out, depth + 1);
    return out;
  }
  if (typeof value !== "object") return out;

  const lower = {};
  for (const [k, v] of Object.entries(value)) lower[String(k).toLowerCase()] = v;

  const model =
    lower.model ??
    lower.model_name ??
    lower.modelname ??
    lower.phone_model ??
    lower.devicemodel ??
    lower.device_model ??
    lower.name ??
    null;

  const vendor =
    lower.vendor ??
    lower.manufacturer ??
    lower.make ??
    lower.brand ??
    null;

  if (model && typeof model === "string" && model.length <= 120) {
    out.push({
      vendor: vendor == null ? null : String(vendor),
      model: String(model),
      raw: value,
    });
  }

  for (const child of Object.values(value)) {
    if (child && typeof child === "object") recursivelyCollectModelObjects(child, out, depth + 1);
  }
  return out;
}

function scoreDeviceCandidate({ sourceVendor, sourceModel, candidateVendor, candidateModel }) {
  const sv = normalizeDeviceToken(sourceVendor);
  const sm = normalizeDeviceToken(sourceModel);
  const fam = deviceFamilyToken(sourceModel);
  const cv = normalizeDeviceToken(candidateVendor);
  const cm = normalizeDeviceToken(candidateModel);

  let score = 0;
  if (sv && cv && (sv === cv || cv.includes(sv) || sv.includes(cv))) score += 50;
  if (sm && cm === sm) score += 100;
  if (fam && cm.startsWith(fam)) score += 75;
  else if (fam && cm.includes(fam)) score += 55;
  if (sm && cm.startsWith(sm)) score += 65;
  if (sm && cm.includes(sm)) score += 40;

  return score;
}

function canonicalizeVodiaDeviceModel(vendor, model) {
  let raw = String(model || "").trim();
  const v = normalizeDeviceToken(vendor);
  const fw = raw.match(/^fw[-_ ]+([a-z0-9]+)[-_ ]+(.+)$/i);
  if (fw) {
    const fv = normalizeDeviceToken(fw[1]);
    if (!v || fv === v || fv.includes(v) || v.includes(fv)) raw = fw[2];
  }
  return raw.replace(/^phone[-_ ]+/i, "").replace(/^model[-_ ]+/i, "").toUpperCase();
}

function findDeviceCatalogReadOperations() {
  const blocked = /(audiocache|\/moh\b|webtempl|translation|recording|prompt|ringtone|music)/i;
  return catalog.operations
    .filter(op => op.callable && String(op.method || "GET").toUpperCase() === "GET")
    .filter(op => {
      const q = [op.operationId, op.path, op.summary, ...(op.tags || [])].join(" ");
      return !blocked.test(q) && /(system\/parameters|phone.*model|model.*phone|device.*model|model.*device|provision.*model|model.*provision|supported.*phone|supported.*device)/i.test(q);
    })
    .filter(op => !(Array.isArray(op.parameters) ? op.parameters : []).some(x => x?.required && String(x.in || "").toLowerCase() === "path"));
}

async function fetchLiveVodiaDeviceCatalog() {
  const sources = [], candidates = [], seen = new Set();
  for (const op of findDeviceCatalogReadOperations()) {
    try {
      const result = await callOperation(op.operationId, {});
      const found = recursivelyCollectModelObjects(result.data);
      let accepted = 0;
      for (const row of found) {
        if (/system\/parameters/i.test(String(op.path || "")) && !/^fw[-_ ]+/i.test(String(row.model || ""))) continue;
        const model = canonicalizeVodiaDeviceModel(row.vendor, row.model);
        if (!normalizeDeviceToken(model)) continue;
        const key = `${normalizeDeviceToken(row.vendor)}:${normalizeDeviceToken(model)}`;
        if (seen.has(key)) continue;
        seen.add(key); accepted++;
        candidates.push({ vendor: row.vendor, model, rawCatalogValue: row.model, sourceOperationId: op.operationId });
      }
      if (accepted) sources.push({ operationId: op.operationId, path: op.path, summary: op.summary, returnedCandidates: accepted });
    } catch {}
  }
  return { sources, candidates };
}

function matchLiveDeviceCandidates(sourceVendor, sourceModel, liveCatalog, limit = 12) {
  const sv = normalizeDeviceToken(sourceVendor);
  return liveCatalog.candidates
    .filter(c => {
      if (!sv) return true;
      const cv = normalizeDeviceToken(c.vendor);
      return cv && (cv === sv || cv.includes(sv) || sv.includes(cv));
    })
    .map(c => ({ ...c, score: scoreDeviceCandidate({ sourceVendor, sourceModel, candidateVendor: c.vendor, candidateModel: c.model }) }))
    .filter(c => c.score >= 55)
    .sort((a,b) => b.score-a.score || String(a.model).localeCompare(String(b.model)))
    .slice(0,limit);
}

function flattenEvidenceStrings(value, path = "", out = [], depth = 0) {
  if (depth > 6 || value == null) return out;
  if (Array.isArray(value)) { value.forEach((v,i) => flattenEvidenceStrings(v, `${path}[${i}]`, out, depth+1)); return out; }
  if (typeof value === "object") { for (const [k,v] of Object.entries(value)) flattenEvidenceStrings(v, path ? `${path}.${k}` : k, out, depth+1); return out; }
  if (typeof value === "string" || typeof value === "number") { const text=String(value).trim(); if(text) out.push({path,value:text}); }
  return out;
}

function collect3cxModelEvidence(phone, sourceModel, liveMatches) {
  const sourceToken = normalizeDeviceToken(sourceModel);
  const clues = [];
  for (const field of flattenEvidenceStrings(phone)) {
    if (!/(model|template|firmware|fw|user.?agent|ua|device|phone|provision|config|filename|vendor.?class)/i.test(field.path)) continue;
    const valueToken = normalizeDeviceToken(field.value);
    for (const c of liveMatches || []) {
      const mt = normalizeDeviceToken(c.model);
      if (mt && mt !== sourceToken && valueToken.includes(mt)) clues.push({candidate:c.model,field:field.path,value:field.value,strength:/model|user.?agent|template/i.test(field.path)?"HIGH":"MEDIUM"});
    }
  }
  const map={}; for(const x of clues) (map[x.candidate] ||= []).push(x);
  const ranked=Object.entries(map).map(([candidate,items])=>({candidate,score:items.reduce((n,x)=>n+(x.strength==="HIGH"?3:1),0),clues:items.slice(0,8)})).sort((a,b)=>b.score-a.score);
  const unique = ranked.length && (ranked.length===1 || ranked[0].score>ranked[1].score);
  return { suggestedModel: unique?ranked[0].candidate:null, confidence: unique?(ranked[0].score>=3?"HIGH":"MEDIUM"):"NONE", rankedCandidates:ranked, evidenceFound:clues.length>0 };
}

function classify3cxDeviceForMigration(phone, modelOverrides = {}, liveCatalog = { candidates: [] }) {
  const ext=String(phone?.extension??phone?.ext??phone?.user??"").trim();
  const mac=String(phone?.mac??phone?.mac_address??phone?.macaddr??"").trim().toUpperCase();
  const rawModel=String(phone?.model??phone?.device_model??phone?.phone_model??"").trim();
  const vendor=String(phone?.vendor??phone?.manufacturer??"").trim();
  const serial=String(phone?.serial_number??phone?.serial??"").trim();
  const key=`${vendor} ${rawModel}`.trim().toLowerCase();
  const override=modelOverrides[key]||modelOverrides[rawModel.toLowerCase()]||null;
  const matches=matchLiveDeviceCandidates(vendor,rawModel,liveCatalog);
  const evidence=collect3cxModelEvidence(phone,rawModel,matches);
  const out={extension:ext||null,mac:mac||null,vendor:vendor||null,sourceModel:rawModel||null,sourceSerial:serial||null,selectedVodiaModel:null,serialToWrite:null,status:null,reason:null,adminAction:null,flags:[],liveCatalogCandidates:matches,sourceEvidence:evidence};
  if (override) {
    const chosen=matches.find(c=>normalizeDeviceToken(c.model)===normalizeDeviceToken(override));
    if(!chosen){out.status="DEFERRED_INVALID_OVERRIDE";out.reason=`Override '${override}' is not a live Vodia candidate.`;out.adminAction="Choose a model returned by the live Vodia catalog.";return out;}
    out.selectedVodiaModel=chosen.model; out.flags.push("MODEL_SELECTED_BY_ADMIN");
  } else {
    const exact=matches.filter(c=>normalizeDeviceToken(c.model)===normalizeDeviceToken(rawModel));
    if(exact.length===1){out.selectedVodiaModel=exact[0].model;out.flags.push("MODEL_EXACT_LIVE_CATALOG");}
    else if(matches.length===1){out.selectedVodiaModel=matches[0].model;out.flags.push("MODEL_RESOLVED_FROM_LIVE_CATALOG");}
    else if(matches.length>1){out.status="DEFERRED_AMBIGUOUS_MODEL";out.reason=`3CX source model '${rawModel}' maps to ${matches.length} live Vodia models.`;out.adminAction=evidence.suggestedModel?`3CX evidence suggests ${evidence.suggestedModel} (${evidence.confidence} confidence). Administrator must confirm or choose another live candidate.`:"3CX contains insufficient evidence to distinguish the exact variant. Administrator must choose from the live Vodia candidates.";return out;}
  }
  if(!out.selectedVodiaModel){out.status="DEFERRED_UNSUPPORTED";out.reason="No compatible model was found in the live Vodia device catalog.";out.adminAction="Select a supported replacement or configure manually later.";return out;}
  out.serialToWrite=serial||"#"; if(!serial) out.flags.push("SERIAL_PLACEHOLDER_USED");
  out.status="READY_TO_MIGRATE";out.reason=serial?"Supported live-catalog model and serial available.":"Supported live-catalog model; missing serial will use validated '#' placeholder.";return out;
}

server.registerTool(
  "pbx_ai_resolve_device_model",
  {
    title: "Resolve incomplete device model against live Vodia catalog",
    description: "Read-only helper that takes a source vendor/model (for example Yealink T46 or T48), searches the live Vodia device/model catalog, and returns only compatible live Vodia candidates. If exactly one candidate matches, it can be selected automatically; if several match, present those choices to the administrator. Never invent a model.",
    inputSchema: {
      vendor: z.string().min(1),
      source_model: z.string().min(1),
      limit: z.number().int().min(1).max(25).default(12),
    },
    outputSchema: toolOutputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  },
  async ({ vendor, source_model, limit }) => {
    scopedAudit("pbx_ai_resolve_device_model", { vendor, source_model, limit });
    try {
      const liveCatalog = await fetchLiveVodiaDeviceCatalog();
      const candidates = matchLiveDeviceCandidates(vendor, source_model, liveCatalog, limit);

      let matchType = "NONE";
      let recommendedAction = "DEFER_UNSUPPORTED";
      let selectedModel = null;

      const normalizedSource = normalizeDeviceToken(source_model);
      const exact = candidates.filter(c => normalizeDeviceToken(c.model) === normalizedSource);

      if (exact.length === 1) {
        matchType = "EXACT";
        recommendedAction = "AUTO_SELECT";
        selectedModel = exact[0].model;
      } else if (candidates.length === 1) {
        matchType = "SINGLE_FAMILY_MATCH";
        recommendedAction = "AUTO_SELECT";
        selectedModel = candidates[0].model;
      } else if (candidates.length > 1) {
        matchType = "FAMILY";
        recommendedAction = "ADMIN_SELECT_MODEL";
      }

      return scopedSuccess(
        {
          changesMade: false,
          source: { vendor, model: source_model },
          matchType,
          selectedModel,
          recommendedAction,
          candidates,
          liveCatalogSources: liveCatalog.sources,
          policy: {
            sourceOfTruth: "LIVE_VODIA_CATALOG",
            neverInventModel: true,
            adminMustChooseWhenMultipleCandidates: true,
            applyChoiceToMatchingSourceModelsAllowed: true,
          },
        },
        { operation: "AI_RESOLVE_DEVICE_MODEL", vendor, source_model, matchType },
        candidates.length
          ? `Found ${candidates.length} compatible live Vodia model candidate(s) for ${vendor} ${source_model}.`
          : `No compatible live Vodia model candidates found for ${vendor} ${source_model}.`
      );
    } catch (error) {
      return failure(error, "device model resolution");
    }
  }
);

server.registerTool(
  "pbx_ai_prepare_3cx_device_migration",
  {
    title: "Prepare non-blocking 3CX phone migration",
    description: "Classify every 3CX phone without blocking the wider migration. Missing serials use the validated '#' placeholder. Incomplete or ambiguous model names are resolved against the LIVE Vodia device catalog for Yealink and any other vendor; when multiple candidates exist, identical source model strings are grouped so the administrator chooses once and can apply that selection to all matching devices. Uses pbx_ai_resolve_device_model semantics. Unsupported devices are deferred with an action report. Source IP/provisioning interface is informational only and never drives migration eligibility. Read-only; no phone is provisioned.",
    inputSchema: {
      filename: z.string().min(1),
      model_overrides: z.record(z.string()).optional(),
    },
    outputSchema: toolOutputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  },
  async ({ filename, model_overrides }) => {
    scopedAudit("pbx_ai_prepare_3cx_device_migration", { filename, model_overrides });
    try {
      const loaded = load3cxNormalizedImport(filename);
      const phones = get3cxInventoryCategory(loaded.data, "phones").items;

      // Fetch the current Vodia model catalog at migration time. This prevents
      // hard-coded Yealink-only logic from becoming stale and also works for
      // future incomplete model names from other manufacturers.
      const liveCatalog = await fetchLiveVodiaDeviceCatalog();
      const rows = phones.map(p =>
        classify3cxDeviceForMigration(p, model_overrides || {}, liveCatalog)
      );
      const counts = {};
      for (const r of rows) counts[r.status] = (counts[r.status] || 0) + 1;

      const unresolvedModelGroups = {};
      for (const row of rows) {
        if (row.status !== "DEFERRED_AMBIGUOUS_MODEL") continue;
        const key = `${row.vendor || ""}::${row.sourceModel || ""}`;
        if (!unresolvedModelGroups[key]) {
          unresolvedModelGroups[key] = {
            vendor: row.vendor || null,
            sourceModel: row.sourceModel || null,
            devicesFoundInSourceBackup: 0,
            macs: [],
            extensions: [],
            candidates: (row.liveCatalogCandidates || []).map(c => c.model),
            evidenceSuggestions: {},
            recommendedAction: "ADMIN_SELECT_MODEL",
            applySelectionToAllMatchingSourceModels: true,
          };
        }
        unresolvedModelGroups[key].devicesFoundInSourceBackup += 1;
        if (row.mac) unresolvedModelGroups[key].macs.push(row.mac);
        if (row.extension) unresolvedModelGroups[key].extensions.push(row.extension);
        if (row.sourceEvidence?.suggestedModel) {
          const m = row.sourceEvidence.suggestedModel;
          unresolvedModelGroups[key].evidenceSuggestions[m] = (unresolvedModelGroups[key].evidenceSuggestions[m] || 0) + 1;
        }
      }

      const adminActions = rows.filter(r => r.status !== "READY_TO_MIGRATE");
      const migratedWithPlaceholder = rows.filter(r => r.flags.includes("SERIAL_PLACEHOLDER_USED") && r.status === "READY_TO_MIGRATE");
      const overallStatus = adminActions.length ? "COMPLETED_WITH_ACTIONS_REQUIRED" : "COMPLETED";
      return scopedSuccess({
        sourceFile: loaded.filename,
        changesMade: false,
        overallStatus,
        deviceCount: rows.length,
        counts,
        devices: rows,
        adminActions,
        unresolvedModelGroups: Object.values(unresolvedModelGroups),
        migratedWithSerialPlaceholder: migratedWithPlaceholder,
        liveModelCatalog: {
          sources: liveCatalog.sources,
          candidateCount: liveCatalog.candidates.length,
          policy: "Incomplete source models are resolved against the LIVE Vodia catalog at conversion time. Never rely only on hard-coded Yealink mappings.",
        },
        rules: {
          missingSerial: "Use '#' and continue for otherwise-supported devices.",
          incompleteModel: "Fetch live Vodia catalog candidates for the same vendor/model family. If one exact candidate exists, resolve automatically; if several exist, administrator chooses from those live candidates.",
          ambiguousModel: "Admin selects only from live Vodia catalog candidates; do not guess silently.",
          unsupported: "Only classify unsupported after live catalog lookup finds no compatible candidate. Defer and report; do not block other migration stages.",
          sourceInterface: "Informational only; source IP/provisioning interface never determines migration eligibility.",
          sourceInventoryCount: "Report exact device count from the uploaded 3CX backup, with MACs and extensions, for every ambiguous source-model group.",
          sourceEvidence: "Inspect 3CX model/template/firmware/user-agent/provisioning clues. Evidence may recommend a live candidate, but administrator confirmation is required when multiple variants remain.",
        },
        continuationPolicy: "Device exceptions never block independently migratable PBX objects.",
      }, { operation: "AI_PREPARE_3CX_DEVICE_MIGRATION", overallStatus },
      "3CX device migration classification prepared. No PBX changes were made.");
    } catch (error) { return failure(error, "3CX device migration preparation"); }
  }
);

server.registerTool(
  "pbx_ai_prepare_3cx_autopilot",
  {
    title: "Prepare one-click 3CX to Vodia migration",
    description: "Customer-facing autopilot preparation for converting a normalized 3CX backup into a NEW Vodia tenant. Applies safe defaults instead of stopping on every review item, automatically defers production-only dependencies, and returns one final migration approval phrase. Read-only: no PBX change is made.",
    inputSchema: {
      filename: z.string().min(1),
      new_tenant: z.string().optional(),
    },
    outputSchema: toolOutputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  },
  async ({ filename, new_tenant }) => {
    scopedAudit("pbx_ai_prepare_3cx_autopilot", { filename, new_tenant });
    try {
      const loaded = load3cxNormalizedImport(filename);
      const pkg = build3cxAutopilotPackage(loaded.data, { new_tenant });

      return scopedSuccess(
        {
          sourceFile: loaded.filename,
          changesMade: false,
          ...pkg,
          humanSummary:
            pkg.status === "READY_FOR_SINGLE_MIGRATION_APPROVAL"
              ? `Ready to migrate safe first-pass objects into new tenant ${pkg.newTenant}. Trunks, emergency routing, DIDs/inbound routing, and any unsupported legacy devices remain explicitly deferred where necessary.`
              : "Only the new tenant domain is still required before the migration can be presented for one final approval.",
        },
        { operation: "AI_PREPARE_3CX_AUTOPILOT", status: pkg.status },
        "3CX autopilot migration package prepared. No PBX changes were made."
      );
    } catch (error) {
      return failure(error, "3CX autopilot preparation");
    }
  }
);

server.registerTool(
  "pbx_ai_build_3cx_conversion_plan",
  {
    title: "Build complete 3CX to Vodia conversion plan",
    description: "High-level read-only orchestrator that automatically retrieves all normalized 3CX object categories, includes the exact source values needed for planning, applies safe Vodia-native translations, separates migration readiness from production-cutover readiness, and asks only genuinely necessary decisions. It does not create the tenant or any PBX object.",
    inputSchema: {
      filename: z.string().min(1),
      new_tenant: z.string().optional(),
      email_policy: z.enum(["create_without_email", "skip_missing_email", "require_email"]).optional(),
      trunk_strategy: z.enum(["skip_first_pass", "manual_review", "migrate_where_possible"]).optional(),
      device_strategy: z.enum(["review_duplicates", "all_devices", "prefer_current"]).optional(),
    },
    outputSchema: toolOutputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  },
  async ({ filename, new_tenant, email_policy, trunk_strategy, device_strategy }) => {
    scopedAudit("pbx_ai_build_3cx_conversion_plan", {
      filename, new_tenant, email_policy, trunk_strategy, device_strategy
    });
    try {
      const loaded = load3cxNormalizedImport(filename);
      const plan = build3cxCompleteConversionPlan(loaded.data, {
        new_tenant, email_policy, trunk_strategy, device_strategy
      });
      return scopedSuccess(
        {
          sourceFile: loaded.filename,
          changesMade: false,
          ...plan,
          nextStep: plan.status === "COMPLETE_PLAN_READY_FOR_GUARDED_OBJECT_PLANNING"
            ? "Use existing guarded Vodia planners in stage order. Stop for explicit approval before every apply."
            : "Answer only the listed required questions, then rerun this one tool.",
        },
        { operation: "AI_BUILD_3CX_CONVERSION_PLAN", status: plan.status },
        plan.status === "COMPLETE_PLAN_READY_FOR_GUARDED_OBJECT_PLANNING"
          ? "Complete object-level 3CX conversion plan prepared. No PBX changes were made."
          : "3CX conversion plan preparation needs input or is blocked. No PBX changes were made."
      );
    } catch (error) {
      return failure(error, "3CX complete conversion plan");
    }
  }
);

server.registerTool(
  "pbx_ai_prepare_3cx_tenant_conversion",
  {
    title: "Prepare 3CX backup conversion to a new Vodia tenant",
    description: "High-level 3CX-to-Vodia migration wizard. Reads a sanitized normalized 3CX import, discovers the real object inventory, checks essential decisions, and returns a dependency-ordered conversion manifest for a NEW Vodia tenant. Read-only: it never creates the tenant or PBX objects. Ask only for missing essentials; do not expose low-level MCP steps to the customer.",
    inputSchema: {
      filename: z.string().min(1),
      new_tenant: z.string().optional(),
      email_policy: z.enum(["create_without_email", "skip_missing_email", "require_email"]).optional(),
      trunk_strategy: z.enum(["skip_first_pass", "manual_review", "migrate_where_possible"]).optional(),
      device_strategy: z.enum(["review_duplicates", "all_devices", "prefer_current"]).optional(),
    },
    outputSchema: toolOutputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  },
  async ({ filename, new_tenant, email_policy, trunk_strategy, device_strategy }) => {
    scopedAudit("pbx_ai_prepare_3cx_tenant_conversion", {
      filename,
      new_tenant,
      email_policy,
      trunk_strategy,
      device_strategy,
    });

    try {
      const loaded = load3cxNormalizedImport(filename);
      const inv = migrationInventory(loaded.data);

      const requiredQuestions = [];
      const warnings = [];
      const blockers = [];

      if (!new_tenant) {
        requiredQuestions.push({
          id: "new_tenant",
          question: "What domain should I use for the new Vodia tenant?",
          required: true,
        });
      }

      if (inv.counts.missingEmail > 0 && !email_policy) {
        requiredQuestions.push({
          id: "email_policy",
          question: `${inv.counts.missingEmail} users/extensions have no email. Create them without email, skip them, or require email before migration?`,
          choices: ["create_without_email", "skip_missing_email", "require_email"],
          required: true,
        });
      }

      if ((inv.counts.trunks + inv.counts.gateways) > 0 && !trunk_strategy) {
        requiredQuestions.push({
          id: "trunk_strategy",
          question: `I found ${inv.counts.trunks} trunks and ${inv.counts.gateways} gateways. Skip them for the first pass, review manually, or migrate where possible?`,
          choices: ["skip_first_pass", "manual_review", "migrate_where_possible"],
          required: true,
        });
      }

      const multiDeviceUsers = inv.extensions.filter((u) => arr(u?.phones).length > 1).length;
      if (multiDeviceUsers > 0 && !device_strategy) {
        requiredQuestions.push({
          id: "device_strategy",
          question: `I found ${multiDeviceUsers} users with multiple device records. Review possible duplicates, keep all devices, or prefer the apparently current device?`,
          choices: ["review_duplicates", "all_devices", "prefer_current"],
          required: true,
        });
      }

      const accountDependent =
        inv.counts.phones +
        inv.counts.ringGroups +
        inv.counts.queues +
        inv.counts.ivrs +
        inv.counts.outboundRules +
        inv.counts.parkOrbits +
        inv.counts.faxExtensions +
        inv.counts.conferenceExtensions;

      if (inv.counts.extensions === 0 && accountDependent > 0) {
        blockers.push({
          type: "missing_extension_root_objects",
          reason: `Found ${accountDependent} account-dependent objects but zero parsed users/extensions.`,
        });
      }

      if (inv.counts.ivrs > 0) {
        warnings.push("IVR actions must be translated and destination-validated before apply.");
      }
      if (inv.counts.outboundRules > 0) {
        warnings.push("3CX outbound rules must be translated into ordered Vodia dial-plan rules and checked for pattern overlap.");
      }
      if ((inv.counts.trunks + inv.counts.gateways) > 0) {
        warnings.push("Carrier credentials may be absent or redacted and must never be invented.");
      }
      if (multiDeviceUsers > 0) {
        warnings.push("Multiple device records exist for some users; no device may be silently discarded without the selected device strategy.");
      }

      const manifest = {
        tenant: {
          action: "create_new_tenant",
          domain: new_tenant || null,
          mustNotReuseExistingTenant: true,
        },
        dependencyOrder: [
          "tenant",
          "extensions_users",
          "phones_macs",
          "groups_ring_groups",
          "queues",
          "park_orbits",
          "conference_fax",
          "ivrs_auto_attendants",
          "trunks_gateways",
          "dial_plan_outbound_rules",
          "verification",
        ],
        source: {
          filename: loaded.filename,
          sourceShape: inv.sourceShape,
        },
        counts: inv.counts,
        missingEmailExtensions: inv.missingEmail,
        decisions: {
          email_policy: email_policy || null,
          trunk_strategy: trunk_strategy || null,
          device_strategy: device_strategy || null,
        },
        inventoryRetrieval: {
          tool: "pbx_ai_get_3cx_inventory",
          instruction: "Retrieve every object needed for a concrete plan. Paginate until hasMore=false. Never construct write plans from counts alone.",
          categories: [
            "extensions",
            "phones",
            "groups",
            "ring_groups",
            "queues",
            "park_orbits",
            "conference_extensions",
            "fax_extensions",
            "ivrs",
            "trunks",
            "gateways",
            "outbound_rules",
          ],
        },
        approvalPolicy: {
          planBeforeApply: true,
          exactValuesOnly: true,
          noInventedExtensions: true,
          noInventedMacs: true,
          noInventedCredentials: true,
          verifyAfterEachStage: true,
        },
      };

      const status =
        blockers.length > 0 ? "BLOCKED" :
        requiredQuestions.length > 0 ? "NEEDS_INPUT" :
        "READY_FOR_OBJECT_PLANNING";

      return scopedSuccess(
        {
          status,
          changesMade: false,
          blockers,
          warnings,
          requiredQuestions,
          manifest,
        },
        { operation: "AI_PREPARE_3CX_TENANT_CONVERSION", status },
        status === "READY_FOR_OBJECT_PLANNING"
          ? "3CX conversion is ready for object-level planning. No PBX changes were made."
          : "3CX conversion assessment completed. No PBX changes were made."
      );
    } catch (error) {
      return failure(error, "3CX tenant conversion preparation");
    }
  }
);

server.registerTool(
  "pbx_ai_prepare_3cx_migration",
  {
    title: "Prepare 3CX to Vodia migration",
    description: "Read a sanitized normalized 3CX migration JSON file from the protected import directory and produce a read-only Vodia migration assessment. It asks only for essential migration decisions and never creates PBX objects. After assessment, use pbx_ai_get_3cx_inventory to retrieve the real object-level values before constructing any Vodia plan.",
    inputSchema: {
      filename: z.string().min(1),
      target_tenant: z.string().optional(),
      email_policy: z.enum(["create_without_email","skip_missing_email","provide_emails_before_import"]).optional(),
      trunk_strategy: z.enum(["map_to_existing_vodia_trunk","create_or_configure_manually","skip_trunks_for_first_pass"]).optional(),
    },
    outputSchema: toolOutputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  },
  async ({ filename, target_tenant, email_policy, trunk_strategy }) => {
    scopedAudit("pbx_ai_prepare_3cx_migration", {
      filename, target_tenant, email_policy, trunk_strategy
    });
    try {
      const loaded = load3cxNormalizedImport(filename);
      const assessment = build3cxMigrationAssessment(loaded.data, {
        targetTenant: target_tenant ? normalizeTenantName(target_tenant) : undefined,
        emailPolicy: email_policy,
        trunkStrategy: trunk_strategy,
      });
      return scopedSuccess(
        {
          sourceFile: loaded.filename,
          ...assessment,
          security: {
            credentialsExpected: false,
            voicemailPinsExpected: false,
            certificateMaterialExpected: false,
            note: "Phase 3.5 expects the sanitized analyzer output and does not require secret-bearing 3CX backup content in AI context.",
          },
          changesMade: false,
        },
        { operation: "AI_PREPARE_3CX_MIGRATION", status: assessment.status },
        `3CX migration assessment is ${assessment.status}. No PBX changes were made.`
      );
    } catch (error) {
      return failure(error, "3CX migration assessment");
    }
  }
);

server.registerTool(
  "pbx_ai_prepare_workflow",
  {
    title: "Prepare AI PBX workflow",
    description: "Turn a natural-language PBX administrator request into a structured, read-first workflow with recommended defaults, missing inputs, user choices, approval boundaries, verification goals, and relevant MCP tool families. For Amazon Chime, this also performs live AWS discovery when enough context is supplied. This tool never changes the PBX or AWS.",
    inputSchema: {
      request: z.string().min(1).max(2000),
      tenant: z.string().optional(),
      country: z.string().optional(),
      area_code: z.string().optional(),
      provider: z.string().optional(),
      region: z.string().optional(),
    },
    outputSchema: toolOutputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: true },
  },
  async ({ request, tenant, country, area_code, provider, region }) => {
    scopedAudit("pbx_ai_prepare_workflow", {
      request,
      tenant,
      country,
      area_code,
      provider,
      region,
    });
    try {
      const data = await prepareAiWorkflow({
        request,
        tenant,
        country,
        areaCode: area_code,
        provider,
        region,
      });
      return scopedSuccess(
        data,
        { operation: "AI_PREPARE_WORKFLOW" },
        `Prepared ${data.workflow.id} workflow. No changes were made.`
      );
    } catch (error) {
      return failure(error, "workflow preparation");
    }
  }
);

server.registerTool(
  "get_connector_info",
  {
    title: "Get Vodia connector information",
    description: "Show connector version, API catalog coverage and enforced safety limits.",
    inputSchema: {},
    outputSchema: toolOutputSchema,
    annotations: {
      readOnlyHint: true,
      destructiveHint: false,
      openWorldHint: false,
    },
  },
  async () => {
    scopedAudit("get_connector_info");
    return scopedSuccess(
      {
        connectorVersion: CONNECTOR_VERSION,
        mode: approvalMode ? "learning-approval-only" : adminMode ? "policy-controlled-full-admin" : "strict-read-only",
        vodiaApiVersion: catalog.vodiaApiVersion,
        totalGetOperations: catalog.totalGetOperations,
        callableOperations: catalog.callableOperations,
        blockedOperations: catalog.blockedOperations,
        responseLimitBytes: RESPONSE_LIMIT_BYTES,
        redactionApplied: true,
        tenantRestrictionsEnabled: ALLOWED_DOMAINS.size > 0,
        allowedDomains: [...ALLOWED_DOMAINS],
        persistentAuditLogEnabled: Boolean(AUDIT_LOG_PATH),
        awsChime: getAwsChimeConfig(),
        ...(adminMode || approvalMode ? { admin: getAdminRuntimeInfo() } : {}),
      },
      { source: catalog.source },
      "Returned Vodia connector coverage and safety information."
    );
  }
);

if (adminMode) {
  registerAdminTools(server, { audit: scopedAudit, success: scopedSuccess, failure, redactSensitive, callOperation: callOperationRaw, actor });
  registerLearningApprovalTools(server, { audit: scopedAudit, success: scopedSuccess, failure, actor });
}
if (approvalMode) {
  registerLearningApprovalTools(server, { audit: scopedAudit, success: scopedSuccess, failure, actor });
}

return server;
}

export function getRuntimeInfo(accessMode = "read") {
  return {
    connectorVersion: CONNECTOR_VERSION,
    mode: accessMode === "approver" ? "learning-approval-only" : accessMode === "admin" ? "policy-controlled-full-admin" : "strict-read-only",
    pbxUrl: PBX_URL,
    apiUser: PBX_USER,
    vodiaApiVersion: catalog.vodiaApiVersion,
    totalGetOperations: catalog.totalGetOperations,
    callableOperations: catalog.callableOperations,
    blockedOperations: catalog.blockedOperations,
    responseLimitBytes: RESPONSE_LIMIT_BYTES,
    tenantRestrictionsEnabled: ALLOWED_DOMAINS.size > 0,
    allowedDomains: [...ALLOWED_DOMAINS],
    persistentAuditLogEnabled: Boolean(AUDIT_LOG_PATH),
    ...(accessMode === "admin" || accessMode === "approver" ? { admin: getAdminRuntimeInfo() } : {}),
  };
}

async function startStdio() {
  const server = createVodiaServer();
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error(
    `[vodia-mcp] connected read-only endpoint. PBX=${PBX_URL} ` +
      `VodiaAPI=${catalog.vodiaApiVersion} GET=${catalog.callableOperations}/${catalog.totalGetOperations}`
  );
}

const invokedPath = process.argv[1] ? pathToFileURL(resolve(process.argv[1])).href : "";
if (invokedPath === import.meta.url) {
  await startStdio();
}

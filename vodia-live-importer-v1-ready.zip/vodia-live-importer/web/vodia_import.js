import { app } from "../../scripts/app.js";

const TYPE_ORDER = [
    "service_flag",
    "auto_attendant",
    "voice_agent",
    "ring_group",
    "call_queue",
    "conference",
    "paging_group",
    "park_orbit",
    "calling_card",
    "shared_line",
    "extension",
    "unknown",
];

const TYPE_COLORS = {
    extension: "#304e6b",
    auto_attendant: "#75612d",
    ring_group: "#315e61",
    call_queue: "#315d36",
    conference: "#584476",
    paging_group: "#5e4931",
    park_orbit: "#5c3c52",
    service_flag: "#34375e",
    voice_agent: "#5b3d65",
    calling_card: "#5b4f34",
    shared_line: "#3d5757",
    unknown: "#5b3535",
};

function setWidget(node, name, value) {
    const widget = node.widgets?.find((item) => item.name === name);
    if (widget) {
        widget.value = value ?? "";
        widget.callback?.(widget.value);
    }
}

function importedNodes() {
    return (app.graph?._nodes || []).filter(
        (node) => node.type === "VodiaImportedAccount"
    );
}

function canvasStartX() {
    const nodes = app.graph?._nodes || [];
    if (!nodes.length) return 100;
    return Math.max(...nodes.map((node) => (node.pos?.[0] || 0) + (node.size?.[0] || 300))) + 300;
}

function createCanvas(topology) {
    if (!topology?.accounts || !Array.isArray(topology.accounts)) {
        alert("Run the Vodia tenant scan before creating canvas nodes.");
        return;
    }

    const tenant = topology.tenant || "tenant";
    const existing = new Map();
    for (const node of importedNodes()) {
        if (node.properties?.vodia_import_id) {
            existing.set(node.properties.vodia_import_id, node);
        }
    }

    const startX = canvasStartX();
    const columnWidth = 390;
    const rowHeight = 250;
    const rows = new Map();
    const byNumber = new Map();
    const created = [];

    for (const account of topology.accounts) {
        const type = account.account_type || "unknown";
        const typeIndex = TYPE_ORDER.indexOf(type);
        const column = typeIndex >= 0 ? typeIndex : TYPE_ORDER.length - 1;
        const row = rows.get(type) || 0;
        rows.set(type, row + 1);

        let node = existing.get(account.id);
        if (!node) {
            node = LiteGraph.createNode("VodiaImportedAccount");
            if (!node) {
                alert("Vodia Imported Account node is unavailable. Restart ComfyUI.");
                return;
            }
            app.graph.add(node);
            created.push(node);
        }

        node.properties ||= {};
        node.properties.vodia_import_id = account.id;
        node.properties.vodia_tenant = tenant;
        node.properties.vodia_account_number = account.number;
        node.pos = [startX + column * columnWidth, 100 + row * rowHeight];
        node.color = TYPE_COLORS[type] || TYPE_COLORS.unknown;
        node.bgcolor = node.color;
        node.title = `${type.replaceAll("_", " ")} ${account.number}`;

        const related = (topology.relations || [])
            .filter((edge) => edge.source === account.number)
            .map((edge) => `${edge.label} -> ${edge.target}`)
            .join("\n");

        setWidget(node, "account_type", type);
        setWidget(node, "account_number", account.number);
        setWidget(node, "display_name", account.display_name || account.number);
        setWidget(node, "relation_summary", related);
        byNumber.set(String(account.number), node);
    }

    for (const relation of topology.relations || []) {
        const source = byNumber.get(String(relation.source));
        const target = byNumber.get(String(relation.target));
        if (!source || !target || !source.outputs?.length || !target.inputs?.length) {
            continue;
        }
        const alreadyLinked = source.outputs[0].links?.some((linkId) => {
            const link = app.graph.links?.[linkId];
            return link?.target_id === target.id;
        });
        if (!alreadyLinked) source.connect(0, target, 0);
    }

    app.graph.setDirtyCanvas(true, true);
    app.canvas?.setDirty(true, true);
    alert(
        `Vodia import complete: ${topology.accounts.length} accounts, ` +
        `${(topology.relations || []).length} discovered links, ` +
        `${created.length} new canvas nodes.`
    );
}

app.registerExtension({
    name: "VodiaPBX.LiveTenantImporter",

    async beforeRegisterNodeDef(nodeType, nodeData) {
        if (nodeData.name !== "VodiaTenantCanvasImporter") return;

        const originalCreated = nodeType.prototype.onNodeCreated;
        nodeType.prototype.onNodeCreated = function () {
            originalCreated?.apply(this, arguments);
            this.addWidget(
                "button",
                "Create/Refresh Imported Nodes",
                null,
                () => createCanvas(this._vodiaTopology)
            );
        };

        const originalExecuted = nodeType.prototype.onExecuted;
        nodeType.prototype.onExecuted = function (message) {
            originalExecuted?.apply(this, arguments);
            const raw = Array.isArray(message?.vodia_topology)
                ? message.vodia_topology[0]
                : message?.vodia_topology;
            if (!raw) return;
            try {
                this._vodiaTopology = typeof raw === "string" ? JSON.parse(raw) : raw;
                this.setDirtyCanvas(true, true);
            } catch (error) {
                console.error("Unable to parse Vodia topology", error);
            }
        };
    },
});

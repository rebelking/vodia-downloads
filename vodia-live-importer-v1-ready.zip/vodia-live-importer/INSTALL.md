# Vodia Live Tenant Importer v1

This package adds a read-only Vodia tenant scanner and a ComfyUI browser
extension that creates and connects imported account nodes on the canvas.

## Files

- `import_nodes.py`
- `web/vodia_import.js`

## Install

Copy both files into the existing custom-node project:

```text
~/ComfyUI/custom_nodes/ComfyUI-VodiaPBX/import_nodes.py
~/ComfyUI/custom_nodes/ComfyUI-VodiaPBX/web/vodia_import.js
```

Add these lines to `ComfyUI-VodiaPBX/__init__.py`:

```python
from .import_nodes import NODE_CLASS_MAPPINGS as IMPORT_NODES
from .import_nodes import NODE_DISPLAY_NAME_MAPPINGS as IMPORT_NAMES
```

Add `**IMPORT_NODES,` to `NODE_CLASS_MAPPINGS` and `**IMPORT_NAMES,` to
`NODE_DISPLAY_NAME_MAPPINGS`.

Also add this module-level value:

```python
WEB_DIRECTORY = "./web"
```

Compile before restarting:

```bash
python -m py_compile \
  custom_nodes/ComfyUI-VodiaPBX/import_nodes.py \
  custom_nodes/ComfyUI-VodiaPBX/__init__.py
```

## Use

1. Export `VODIA_PBX_PASSWORD` before starting ComfyUI.
2. Add `Vodia Import Tenant to Canvas (Read Only)`.
3. Enter the PBX URL, tenant and username.
4. Run the workflow.
5. Click `Create/Refresh Imported Nodes` on the importer node.

The scanner never sends POST, PUT, PATCH or DELETE requests.

# Vodia MCP 0.7 tester installation and validation

This guide installs the v0.7 test release without replacing a working v0.6
deployment until you deliberately run the installer.

## 1. Prepare the PBX account

Create a dedicated Vodia system administrator API account for the connector.
Do not reuse a human administrator password. For an all-tenant test, the API
account must be able to list system domains and administer the tenants under
test.

## 2. Back up the current connector

On the connector server:

```bash
sudo cp /etc/vodia-mcp.env /etc/vodia-mcp.env.before-v0.7
sudo cp -a /opt/vodia-mcp /opt/vodia-mcp.before-v0.7
```

The second command may consume space because it preserves the installed Node
modules. Remove the backup only after testing is accepted.

## 3. Install the package

For an unpublished test ZIP copied to the server:

```bash
unzip -q vodia-mcp-v0.7.0-test.zip -d /tmp/vodia-mcp-v0.7-test
sudo env VODIA_MCP_PACKAGE_FILE="$PWD/vodia-mcp-v0.7.0-test.zip" \
  VODIA_MCP_ROTATE_TOKENS="true" \
  bash /tmp/vodia-mcp-v0.7-test/vodia-mcp/install-vodia-mcp.sh
```

Resolve `$PWD` before using `sudo` if the ZIP is not in your current directory.

After the release is published, the normal installer command is:

```bash
wget -O /tmp/install-vodia-mcp.sh \
  https://raw.githubusercontent.com/rebelking/vodia-downloads/main/install-vodia-mcp.sh
sudo bash /tmp/install-vodia-mcp.sh
```

For system-administrator visibility across all tenants, leave the allowed
tenant-domain prompt blank. For a limited tester, enter only explicitly allowed
tenant domains.

The installer creates three different secrets: dashboard, read-only MCP and
administrator MCP. They are stored at mode 0600 in:

```text
/root/vodia-mcp-credentials.txt
```

## 4. Validate the Linux services

```bash
sudo systemctl daemon-reload
sudo systemctl restart vodia-mcp
sudo systemctl reload caddy
sudo systemctl status vodia-mcp caddy --no-pager
curl -fsS http://127.0.0.1:3100/health
curl -fsS https://YOUR-MCP-DOMAIN/health
node -p "require('/opt/vodia-mcp/package.json').version"
sudo stat -c '%A %U:%G %n' /var/log/vodia-mcp/audit.jsonl
```

Expected version: `0.7.0`. Port 3100 must listen only on `127.0.0.1`.

## 5. Configure Codex on Windows

Open a fresh Windows PowerShell window and store the two tokens without placing
them directly in command history:

```powershell
$secureRead = Read-Host "Paste read-only MCP token" -AsSecureString
$readToken = [System.Net.NetworkCredential]::new("", $secureRead).Password
[Environment]::SetEnvironmentVariable("VODIA_MCP_TOKEN", $readToken, "User")

$secureAdmin = Read-Host "Paste administrator MCP token" -AsSecureString
$adminMcpToken = [System.Net.NetworkCredential]::new("", $secureAdmin).Password
[Environment]::SetEnvironmentVariable("VODIA_MCP_ADMIN_TOKEN", $adminMcpToken, "User")

Remove-Variable readToken,adminMcpToken,secureRead,secureAdmin
```

Add both servers to `%USERPROFILE%\.codex\config.toml`:

```toml
[mcp_servers.vodia]
url = "https://YOUR-MCP-DOMAIN/mcp"
bearer_token_env_var = "VODIA_MCP_TOKEN"
enabled = true
required = true
default_tools_approval_mode = "auto"

[mcp_servers.vodia_admin]
url = "https://YOUR-MCP-DOMAIN/mcp-admin"
bearer_token_env_var = "VODIA_MCP_ADMIN_TOKEN"
enabled = true
required = false
default_tools_approval_mode = "writes"
```

Do not set the administrator endpoint to automatic approval. Restart Codex so
the desktop application inherits the new user environment variables.

## 6. Read-only acceptance tests

Ask Codex:

```text
Using only Vodia MCP, call get_connector_info and list_domains. Return the
connector version, access mode, total tenant count and tenant names. Do not
display credentials or private configuration.
```

Then:

```text
Using only Vodia MCP, list accounts, extensions and registrations for tenant
TENANT-DOMAIN. Return record counts only.
```

## 7. Administrator inventory test

```text
Using only the Vodia administrator MCP, find extension 2037 across all visible
tenants. Return the matching tenant and account type without displaying SIP
passwords or authentication material.
```

## 8. Safe PCAP write test

First create the plan only:

```text
Using Vodia administrator MCP, plan enabling PCAP for extension 2037 in tenant
TENANT-DOMAIN for troubleshooting ticket TEST-001. Do not apply it. Show the
current value, proposed value, expiration and request hash.
```

Review the result. Then explicitly request:

```text
Apply the previously displayed PCAP change plan using confirmation APPLY. Read
the extension settings afterward and confirm whether PCAP is enabled.
```

Place a short test call, note its call ID, and request:

```text
Using Vodia administrator MCP, retrieve and analyze the SIP trace for call ID
CALL-ID in tenant TENANT-DOMAIN. Show the chronological SIP start lines, final
response, Reason/Q.850 cause and which message terminated the call. Do not show
SIP Authorization values.
```

Finally plan and apply disabling PCAP. Confirm the read-back value is off.

## 9. Temporary PBX SIP logging test

```text
Using Vodia administrator MCP, plan a 10-minute SIP dialog trace with SIP level
9, media level 7, REGISTER disabled and SUBSCRIBE/NOTIFY disabled. Use reason
TEST-002. Do not apply until I approve the displayed configuration.
```

After approval, reproduce the call problem. Vodia stops logging based on the
configured duration, and the connector schedules restoration of changed fields
when their previous values were readable. Verify the settings afterward.

## 10. Dropped-call evidence test

```text
Using Vodia administrator MCP, troubleshoot dropped call CALL-ID in tenant
TENANT-DOMAIN for extension EXTENSION. Correlate the CDR, tenant log,
registration history, extension syslog, tenant quality statistics and trunk
statistics. Separate confirmed evidence from inference.
```

## 11. Audit verification

```bash
sudo tail -n 50 /var/log/vodia-mcp/audit.jsonl
sudo grep -E 'plan_extension_pcap|apply_vodia_change|get_call_sip_trace' \
  /var/log/vodia-mcp/audit.jsonl
```

The file must remain owned by `vodiamcp:vodiamcp` and mode 0600. Passwords,
tokens and SIP Authorization values must not appear.

## 12. Roll back to v0.6

If the test fails:

```bash
sudo systemctl stop vodia-mcp
sudo find /opt/vodia-mcp -mindepth 1 -maxdepth 1 -exec rm -rf -- {} +
sudo cp -a /opt/vodia-mcp.before-v0.7/. /opt/vodia-mcp/
sudo cp /etc/vodia-mcp.env.before-v0.7 /etc/vodia-mcp.env
sudo systemctl daemon-reload
sudo systemctl restart vodia-mcp
curl -fsS http://127.0.0.1:3100/health
```

The deletion command targets only the explicit `/opt/vodia-mcp` application
directory. Verify the backup paths before running it.

## Known limitations of this test release

- OAuth 2.1 and per-human identity are not included yet.
- The admin token maps to the configured `MCP_ADMIN_ACTOR` audit identity.
- A historical call with no retained PCAP cannot produce a SIP trace.
- Full PBX filesystem logs are unavailable when the connector runs on a
  different machine. Use Vodia's domain log API, CDR SIP trace or a separately
  secured syslog collector.
- Elevated external actions and DELETE operations are disabled by default.

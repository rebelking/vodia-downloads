# Vodia PBX MCP 0.7.0 test release

Vodia MCP 0.7 adds a separate controlled administrator endpoint while preserving
the v0.6 read-only endpoint. It is generated from the official Vodia REST API
70.3 schema and is intended for Vodia PBX 70.x testing.

## What is included

- Read-only MCP endpoint: `/mcp`
- Controlled administrator endpoint: `/mcp-admin`
- Complete 299-operation API catalog: 200 GET, 63 POST, 3 PUT and 33 DELETE
- All-tenant inventory and cross-tenant extension search for system administrators
- Tenant accounts, extensions, registrations, CDRs, logs, statistics and audit history
- Dropped-call evidence collection
- Tenant-validated, size-limited PCAP retrieval and SIP-dialog parsing
- SIP `Authorization` and related secrets redacted before model output
- Two-step `plan_vodia_change` and `apply_vodia_change` workflow
- Dedicated extension-PCAP and temporary SIP-logging change planners
- Persistent JSONL audit logging

## Important test-release boundary

This release uses separate bearer tokens for the read-only and administrator MCP
endpoints. It does **not** yet implement per-user OAuth 2.1. Do not treat this
test package as the final shared production administrator service. Give each
tester access only through a controlled test environment and rotate the admin
token when testing is complete.

POST and PUT configuration operations can be planned by default. Operations
classified as external actions (calls, messages, email, fax, uploads, software
actions, tokens or certificates) require `VODIA_ENABLE_ELEVATED_WRITES=true`.
DELETE operations require `VODIA_ENABLE_DESTRUCTIVE=true`. Both are false by
default.

## Requirements

- Ubuntu or Debian server
- Node.js 18 or newer
- Vodia PBX 70.x with a dedicated system administrator API account
- DNS name pointing to the connector host
- TCP 80 and 443 open to Caddy
- Do not expose TCP 3100; the service listens on localhost

## Install

See [TESTING-GUIDE.md](TESTING-GUIDE.md) for complete server, Windows Codex,
validation, SIP tracing and rollback instructions.

For a packaged release:

```bash
wget -O /tmp/install-vodia-mcp.sh \
  https://raw.githubusercontent.com/rebelking/vodia-downloads/main/install-vodia-mcp.sh
sudo bash /tmp/install-vodia-mcp.sh
```

The installer saves root-only credentials in:

```text
/root/vodia-mcp-credentials.txt
```

## Endpoints

| Endpoint | Purpose | Token variable on Codex computer |
|---|---|---|
| `/mcp` | Strict read-only support | `VODIA_MCP_TOKEN` |
| `/mcp-admin` | Planned and approved writes | `VODIA_MCP_ADMIN_TOKEN` |
| `/health` | Non-sensitive health check | None |
| `/admin/` | Connector dashboard | Dashboard administrator token |

Never configure automatic tool approval for `/mcp-admin`.

## High-value troubleshooting tools

- `list_domains`
- `list_accounts`
- `list_extensions`
- `find_extension_across_tenants`
- `get_extension_settings`
- `list_registrations`
- `get_extension_registration_history`
- `get_extension_syslog`
- `get_tenant_cdrs`
- `get_specific_cdr`
- `get_tenant_log`
- `get_tenant_stats`
- `get_trunk_stats`
- `troubleshoot_dropped_call`
- `get_call_sip_trace`

`get_call_sip_trace` first verifies the call ID against the requested tenant,
then calls the otherwise-blocked binary PCAP endpoint. The capture is limited in
size and converted into a redacted chronological SIP dialog. A historical call
with no retained PCAP cannot be reconstructed.

## Controlled writes

Generic writes always require two MCP calls:

1. `plan_vodia_change` validates the operation, tenant, parameters and policy,
   reads a pre-change value when a matching GET exists, and returns an expiring
   change ID and request hash.
2. `apply_vodia_change` accepts that unchanged change ID plus the literal
   confirmation `APPLY`. A second call cannot modify the planned body.

Dedicated safe planners include:

- `plan_extension_pcap`
- `plan_trunk_pcap`
- `plan_sip_trace_logging`

The SIP logging planner permits only 60–3,600 seconds. The PBX receives its own
logging duration and the connector also schedules restoration of the changed
fields when a preimage is available.

## API catalog

Use `find_read_capabilities` for GET operations and `find_api_capabilities` on
the administrator endpoint for the complete catalog. Raw URLs are never
accepted; only generated operation IDs and declared parameters are allowed.

Regenerate and review the catalog after Vodia publishes a new schema:

```bash
npm run generate:catalog
```

## Security model

- Read and administrator MCP credentials are separate.
- The read endpoint does not register write tools.
- Write plans expire after five minutes by default and are single-use.
- The actor, tenant, operation, redacted request, reason and result are audited.
- Secret fields are recursively redacted.
- SIP authentication headers are redacted.
- Binary reads remain blocked except for the dedicated PCAP parser.
- Destructive and elevated actions are disabled by default.
- `VODIA_ALLOWED_DOMAINS` remains available for tenant-limited deployments.

For a multitenant system-administrator test, leave `VODIA_ALLOWED_DOMAINS`
blank. Do this only with the separate administrator endpoint and a dedicated
PBX API account.

## Environment variables

| Variable | Purpose |
|---|---|
| `VODIA_URL` | HTTPS PBX base URL |
| `VODIA_USER` / `VODIA_PASS` | Dedicated PBX API account |
| `VODIA_ALLOWED_DOMAINS` | Optional comma-separated tenant allowlist |
| `MCP_BEARER_TOKEN` | Read-only endpoint token |
| `MCP_ADMIN_BEARER_TOKEN` | Administrator endpoint token |
| `MCP_ADMIN_ACTOR` | Audit identity for the test administrator token |
| `ADMIN_TOKEN` | Dashboard token |
| `VODIA_ENABLE_ELEVATED_WRITES` | Enable external-action writes; default false |
| `VODIA_ENABLE_DESTRUCTIVE` | Enable DELETE operations; default false |
| `VODIA_CHANGE_PLAN_TTL_MS` | Write-plan lifetime; default 300000 |
| `VODIA_PCAP_LIMIT_BYTES` | Maximum PCAP download; default 20000000 |
| `VODIA_AUDIT_LOG` | Persistent JSONL audit path |

## Local verification

```bash
npm ci
npm run check
npm test
```

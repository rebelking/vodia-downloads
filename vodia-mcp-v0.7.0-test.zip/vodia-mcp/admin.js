import { createHash, randomUUID } from "node:crypto";
import { readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { z } from "zod";
import { parseSipFromPcap, summarizeSipDialog } from "./pcap.js";

const projectRoot = dirname(fileURLToPath(import.meta.url));
export const apiCatalog = JSON.parse(readFileSync(resolve(projectRoot, "generated/api-catalog.json"), "utf8"));
const operationsById = new Map(apiCatalog.operations.map((operation) => [operation.operationId, operation]));
const PBX_URL = String(process.env.VODIA_URL || "").replace(/\/+$/, "");
const PBX_USER = String(process.env.VODIA_USER || "");
const PBX_PASS = String(process.env.VODIA_PASS || "");
const PLAN_TTL_MS = Math.max(60_000, Math.min(Number(process.env.VODIA_CHANGE_PLAN_TTL_MS || 300_000), 900_000));
const PCAP_LIMIT_BYTES = Math.max(100_000, Math.min(Number(process.env.VODIA_PCAP_LIMIT_BYTES || 20_000_000), 100_000_000));
const DESTRUCTIVE_ENABLED = /^true$/i.test(process.env.VODIA_ENABLE_DESTRUCTIVE || "");
const ELEVATED_ENABLED = /^true$/i.test(process.env.VODIA_ENABLE_ELEVATED_WRITES || "");
const ALLOWED_DOMAINS = new Set(String(process.env.VODIA_ALLOWED_DOMAINS || "").split(",").map((v) => v.trim().toLowerCase()).filter(Boolean));
const plans = new Map();

function authorization() {
  return `Basic ${Buffer.from(`${PBX_USER}:${PBX_PASS}`, "utf8").toString("base64")}`;
}

function tenantFrom(args = {}) {
  if (args.domain) return String(args.domain).toLowerCase();
  for (const key of ["account", "user", "queue"]) {
    const value = String(args[key] || "");
    if (value.includes("@")) return value.slice(value.lastIndexOf("@") + 1).toLowerCase();
  }
  return null;
}

function enforceTenant(args) {
  const tenant = tenantFrom(args);
  if (ALLOWED_DOMAINS.size && (!tenant || !ALLOWED_DOMAINS.has(tenant))) {
    throw new Error(tenant ? `Tenant '${tenant}' is outside VODIA_ALLOWED_DOMAINS.` : "A tenant-scoped operation is required in restricted mode.");
  }
  return tenant;
}

function buildUrl(operation, pathParams = {}, queryParams = {}) {
  let path = operation.path;
  const required = [...path.matchAll(/\{([^}]+)\}/g)].map((match) => match[1]);
  for (const name of required) {
    const value = pathParams[name];
    if (value === undefined || value === null || String(value).trim() === "") throw new Error(`Missing required path parameter '${name}'.`);
    path = path.replace(`{${name}}`, encodeURIComponent(String(value)));
  }
  const unknown = Object.keys(pathParams).filter((name) => !required.includes(name));
  if (unknown.length) throw new Error(`Unknown path parameter(s): ${unknown.join(", ")}`);
  const allowedQuery = new Set(operation.parameters.filter((p) => p.in === "query").map((p) => p.name));
  const unknownQuery = Object.keys(queryParams).filter((name) => !allowedQuery.has(name));
  if (unknownQuery.length) throw new Error(`Unsupported query parameter(s): ${unknownQuery.join(", ")}`);
  enforceTenant(pathParams);
  const url = new URL(`${PBX_URL}${path}`);
  for (const [key, value] of Object.entries(queryParams)) if (value !== undefined && value !== null && value !== "") url.searchParams.set(key, String(value));
  return { url, path };
}

async function limitedBuffer(response, limit = PCAP_LIMIT_BYTES) {
  const declared = Number(response.headers.get("content-length") || 0);
  if (declared > limit) throw new Error(`Response is ${declared} bytes; limit is ${limit}.`);
  const buffer = Buffer.from(await response.arrayBuffer());
  if (buffer.length > limit) throw new Error(`Response exceeded ${limit} bytes.`);
  return buffer;
}

async function rawRequest(operation, { pathParams = {}, queryParams = {}, body } = {}) {
  const { url, path } = buildUrl(operation, pathParams, queryParams);
  const response = await fetch(url, {
    method: operation.method,
    headers: {
      Accept: "application/json, text/plain;q=0.9",
      Authorization: authorization(),
      "Content-Type": "application/json",
      "User-Agent": "vodia-mcp-admin/0.7.0",
    },
    body: body === undefined ? undefined : JSON.stringify(body),
    signal: AbortSignal.timeout(30_000),
  });
  const text = (await response.text()).slice(0, 2_000_000);
  if (!response.ok) throw new Error(`Vodia API ${operation.method} ${path} returned HTTP ${response.status}: ${text.slice(0, 400)}`);
  let data = {};
  if (text) {
    try { data = JSON.parse(text); } catch { data = { text }; }
  }
  return { data, status: response.status, path };
}

async function preimageFor(operation, pathParams, queryParams, callOperation) {
  const reader = apiCatalog.operations.find((candidate) => candidate.method === "GET" && candidate.path === operation.path && candidate.callable);
  if (!reader) return { available: false, data: null };
  const allowed = new Set(reader.parameters.filter((p) => p.in === "query").map((p) => p.name));
  const safeQuery = Object.fromEntries(Object.entries(queryParams || {}).filter(([name]) => allowed.has(name)));
  try {
    const result = await callOperation(reader.operationId, { pathParams, queryParams: safeQuery });
    return { available: true, operationId: reader.operationId, data: result.data };
  } catch (error) {
    return { available: false, error: error.message || String(error), data: null };
  }
}

function planHash(plan) {
  return createHash("sha256").update(JSON.stringify({ operationId: plan.operationId, pathParams: plan.pathParams, queryParams: plan.queryParams, body: plan.body })).digest("hex");
}

async function makePlan({ operationId, pathParams = {}, queryParams = {}, body = {}, reason, actor, callOperation, safeWrapper = false }) {
  for (const [id, existing] of plans) if (Date.parse(existing.expiresAt) <= Date.now()) plans.delete(id);
  if (plans.size >= 1000) throw new Error("Too many pending change plans; wait for existing plans to expire.");
  const operation = operationsById.get(operationId);
  if (!operation) throw new Error(`Unknown operation '${operationId}'.`);
  if (operation.method === "GET") throw new Error("Use the read tools for GET operations.");
  if (!operation.callable) throw new Error(`Operation is blocked: ${operation.blockedReason}`);
  if (operation.risk === "destructive" && !DESTRUCTIVE_ENABLED) throw new Error("Destructive operations are disabled. Set VODIA_ENABLE_DESTRUCTIVE=true only in an isolated test deployment.");
  if (operation.risk === "elevated" && !ELEVATED_ENABLED && !safeWrapper) throw new Error("Elevated external-action writes are disabled by policy.");
  const tenant = enforceTenant(pathParams);
  const preimage = await preimageFor(operation, pathParams, queryParams, callOperation);
  const changeId = randomUUID();
  const plan = {
    changeId,
    actor,
    operationId,
    method: operation.method,
    path: operation.path,
    risk: operation.risk,
    tenant,
    pathParams,
    queryParams,
    body,
    reason,
    preimage,
    createdAt: new Date().toISOString(),
    expiresAt: new Date(Date.now() + PLAN_TTL_MS).toISOString(),
  };
  plan.requestHash = planHash(plan);
  plans.set(changeId, plan);
  return plan;
}

function publicPlan(plan, redactSensitive) {
  return redactSensitive({
    changeId: plan.changeId,
    operationId: plan.operationId,
    method: plan.method,
    path: plan.path,
    risk: plan.risk,
    tenant: plan.tenant,
    request: { pathParams: plan.pathParams, queryParams: plan.queryParams, body: plan.body },
    preimage: plan.preimage,
    reason: plan.reason,
    requestHash: plan.requestHash,
    expiresAt: plan.expiresAt,
    confirmationRequired: "APPLY",
  });
}

export function registerAdminTools(server, { audit, success, failure, redactSensitive, callOperation, actor = "system-admin" }) {
  const parameterValue = z.union([z.string(), z.number(), z.boolean()]);
  const parameterMap = z.record(z.string(), parameterValue);
  const outputSchema = { data: z.any(), meta: z.record(z.string(), z.any()) };
  const writeAnnotations = { readOnlyHint: false, destructiveHint: false, openWorldHint: false };

  server.registerTool("find_extension_across_tenants", {
    title: "Find an extension across all tenants",
    description: "System-administrator inventory search across every visible Vodia tenant.",
    inputSchema: { extension: z.string().min(1).optional(), max_tenants: z.number().int().min(1).max(500).default(100) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ extension, max_tenants }) => {
    audit("find_extension_across_tenants", { actor, extension, max_tenants });
    try {
      const domainsResult = await callOperation("get_rest_system_domains");
      const domains = (Array.isArray(domainsResult.data) ? domainsResult.data : []).map((item) => item.domain || item.name || item.primary || item.primary_dns).filter(Boolean).slice(0, max_tenants);
      const matches = [];
      const errors = [];
      for (const domain of domains) {
        try {
          const result = await callOperation("get_rest_domain_domain_extensions_3", { pathParams: { domain }, queryParams: extension ? { account: extension } : {} });
          const records = Array.isArray(result.data) ? result.data : result.data ? [result.data] : [];
          if (records.length) matches.push({ domain, records });
        } catch (error) { errors.push({ domain, error: error.message || String(error) }); }
      }
      return success(redactSensitive({ matches, errors }), { tenantsChecked: domains.length, tenantsMatched: matches.length }, `Checked ${domains.length} tenants and found matches in ${matches.length}.`);
    } catch (error) { return failure(error); }
  });

  server.registerTool("troubleshoot_dropped_call", {
    title: "Collect dropped-call evidence",
    description: "Collect the tenant CDR, logs, call-quality statistics, trunk statistics, and optional extension evidence for one call.",
    inputSchema: { domain: z.string().min(1), call_id: z.string().min(1).max(256), extension: z.string().min(1).optional() },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ domain, call_id, extension }) => {
    audit("troubleshoot_dropped_call", { actor, domain, call_id, extension });
    enforceTenant({ domain });
    const evidence = {};
    const errors = {};
    const collect = async (name, operationId, args) => {
      try { evidence[name] = (await callOperation(operationId, args)).data; }
      catch (error) { errors[name] = error.message || String(error); }
    };
    await Promise.all([
      collect("cdr", "get_rest_domain_domain_cdr", { pathParams: { domain }, queryParams: { id: call_id } }),
      collect("tenantLog", "get_rest_domain_domain_log", { pathParams: { domain } }),
      collect("tenantStats", "get_rest_domain_domain_stats_6", { pathParams: { domain } }),
      collect("trunkStats", "get_rest_domain_domain_trunk_stats_1", { pathParams: { domain } }),
      ...(extension ? [
        collect("registrationHistory", "get_rest_user_account_reghist", { pathParams: { account: `${extension}@${domain}` } }),
        collect("extensionSyslog", "get_rest_user_account_syslog", { pathParams: { account: `${extension}@${domain}` } }),
      ] : []),
    ]);
    return success(redactSensitive({ evidence, errors }), { domain, callId: call_id, sourcesCollected: Object.keys(evidence), unavailableSources: Object.keys(errors) }, "Collected available dropped-call evidence. Use get_call_sip_trace separately when the CDR indicates a retained PCAP.");
  });

  server.registerTool("find_api_capabilities", {
    title: "Find Vodia API capabilities",
    description: "Search the full official Vodia API catalog, including reads and policy-gated writes.",
    inputSchema: { query: z.string().optional(), method: z.enum(["GET", "POST", "PUT", "PATCH", "DELETE"]).optional(), include_blocked: z.boolean().default(false), limit: z.number().int().min(1).max(100).default(25) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ query, method, include_blocked, limit }) => {
    const words = String(query || "").toLowerCase().split(/\s+/).filter(Boolean);
    const data = apiCatalog.operations.filter((op) => (!method || op.method === method) && (include_blocked || op.callable)).filter((op) => {
      const haystack = `${op.operationId} ${op.path} ${op.summary} ${(op.tags || []).join(" ")}`.toLowerCase();
      return words.every((word) => haystack.includes(word));
    }).slice(0, limit).map(({ operationId, method: opMethod, path, summary, risk, callable, blockedReason, parameters }) => ({ operationId, method: opMethod, path, summary, risk, callable, blockedReason, parameters }));
    return success(data, { totalOperations: apiCatalog.totalOperations, counts: apiCatalog.counts }, `Found ${data.length} Vodia API capabilities.`);
  });

  server.registerTool("plan_vodia_change", {
    title: "Plan a Vodia PBX change",
    description: "Validate and preview a policy-allowed Vodia API write. This tool does not change PBX state.",
    inputSchema: { operation_id: z.string().min(1), path_params: parameterMap.optional(), query_params: parameterMap.optional(), body: z.record(z.string(), z.any()).default({}), reason: z.string().min(3).max(500) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ operation_id, path_params, query_params, body, reason }) => {
    audit("plan_vodia_change", { actor, operation_id, path_params, query_params, body, reason });
    try {
      const plan = await makePlan({ operationId: operation_id, pathParams: path_params || {}, queryParams: query_params || {}, body, reason, actor, callOperation });
      return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt }, "Change planned. Review the exact request and preimage before applying it.");
    } catch (error) { return failure(error, "plan"); }
  });

  server.registerTool("apply_vodia_change", {
    title: "Apply an approved Vodia PBX change",
    description: "Apply an unexpired change plan after explicit confirmation. The body cannot be altered after planning.",
    inputSchema: { change_id: z.string().uuid(), confirmation: z.literal("APPLY") },
    outputSchema,
    annotations: writeAnnotations,
  }, async ({ change_id }) => {
    const plan = plans.get(change_id);
    audit("apply_vodia_change", { actor, change_id, operation_id: plan?.operationId, reason: plan?.reason });
    try {
      if (!plan) throw new Error("Unknown or already-used change plan.");
      if (Date.parse(plan.expiresAt) <= Date.now()) { plans.delete(change_id); throw new Error("Change plan expired; create a new plan."); }
      if (plan.actor !== actor) throw new Error("Change plan belongs to a different administrator.");
      const operation = operationsById.get(plan.operationId);
      if (plan.preimage?.available) {
        const current = await preimageFor(operation, plan.pathParams, plan.queryParams, callOperation);
        if (!current.available || createHash("sha256").update(JSON.stringify(current.data)).digest("hex") !== createHash("sha256").update(JSON.stringify(plan.preimage.data)).digest("hex")) {
          throw new Error("PBX state changed after the plan was created. Nothing was written; create and review a new plan.");
        }
      }
      const result = await rawRequest(operation, plan);
      if (plan.autoRestoreSeconds && plan.preimage?.available && plan.preimage.data && typeof plan.preimage.data === "object") {
        const source = Array.isArray(plan.preimage.data) ? plan.preimage.data[0] : plan.preimage.data;
        const restoreBody = Object.fromEntries(Object.keys(plan.body).filter((key) => Object.hasOwn(source || {}, key)).map((key) => [key, source[key]]));
        if (Object.keys(restoreBody).length) {
          const timer = setTimeout(async () => {
            try {
              await rawRequest(operation, { pathParams: plan.pathParams, queryParams: plan.queryParams, body: restoreBody });
              audit("temporary_change_restored", { actor: plan.actor, operation_id: plan.operationId, tenant: plan.tenant, reason: plan.reason });
            } catch (error) {
              audit("temporary_change_restore_failed", { actor: plan.actor, operation_id: plan.operationId, error: error.message || String(error) });
            }
          }, plan.autoRestoreSeconds * 1000);
          timer.unref();
        }
      }
      plans.delete(change_id);
      const verification = await preimageFor(operation, plan.pathParams, plan.queryParams, callOperation);
      const data = redactSensitive({ operationId: plan.operationId, status: result.status, tenant: plan.tenant, reason: plan.reason, result: result.data, verification });
      audit("vodia_change_applied", data);
      return success(data, { requestHash: plan.requestHash }, "Approved Vodia change applied and verification read attempted.");
    } catch (error) { return failure(error, "write"); }
  });

  server.registerTool("plan_extension_pcap", {
    title: "Plan extension PCAP change",
    description: "Plan enabling or disabling packet capture for one extension. Applying requires a separate explicit confirmation.",
    inputSchema: { domain: z.string().min(1), extension: z.string().min(1), enabled: z.boolean(), reason: z.string().min(3).max(500) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ domain, extension, enabled, reason }) => {
    audit("plan_extension_pcap", { actor, domain, extension, enabled, reason });
    try {
      const plan = await makePlan({ operationId: "post_rest_domain_domain_user_settings_ext", pathParams: { domain, ext: extension }, body: { pcap: enabled ? "true" : "" }, reason, actor, callOperation, safeWrapper: true });
      return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt }, `PCAP ${enabled ? "enable" : "disable"} change planned for the extension.`);
    } catch (error) { return failure(error, "plan"); }
  });

  server.registerTool("plan_trunk_pcap", {
    title: "Plan trunk PCAP change",
    description: "Plan enabling or disabling packet capture for one SIP trunk. Applying requires a separate explicit confirmation.",
    inputSchema: { domain: z.string().min(1), trunk_id: z.union([z.string().min(1), z.number().int().nonnegative()]), enabled: z.boolean(), reason: z.string().min(3).max(500) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ domain, trunk_id, enabled, reason }) => {
    audit("plan_trunk_pcap", { actor, domain, trunk_id, enabled, reason });
    try {
      const plan = await makePlan({ operationId: "post_rest_domain_domain_edit_trunk_trunk_id", pathParams: { domain, trunk_id }, body: { pcap: enabled ? "true" : "" }, reason, actor, callOperation, safeWrapper: true });
      return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt }, `PCAP ${enabled ? "enable" : "disable"} change planned for the trunk.`);
    } catch (error) { return failure(error, "plan"); }
  });

  server.registerTool("plan_sip_trace_logging", {
    title: "Plan temporary SIP trace logging",
    description: "Plan a short-lived PBX SIP dialog trace. Applying requires confirmation; logging automatically restores afterward.",
    inputSchema: { duration_seconds: z.number().int().min(60).max(3600).default(600), sip_level: z.number().int().min(7).max(9).default(9), media_level: z.number().int().min(0).max(9).default(7), include_register: z.boolean().default(false), include_subscribe_notify: z.boolean().default(false), watch_ip: z.string().optional(), reason: z.string().min(3).max(500) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ duration_seconds, sip_level, media_level, include_register, include_subscribe_notify, watch_ip, reason }) => {
    audit("plan_sip_trace_logging", { actor, duration_seconds, sip_level, media_level, include_register, include_subscribe_notify, watch_ip, reason });
    try {
      const body = { log_duration: String(duration_seconds), log_event_sip: String(sip_level), log_event_media: String(media_level), log_sip_dialog: "true", log_sip_register: String(include_register), log_sip_subnot: String(include_subscribe_notify), ...(watch_ip ? { log_sip_watchlist: watch_ip } : {}) };
      const plan = await makePlan({ operationId: "post_rest_system_config", body, reason, actor, callOperation, safeWrapper: true });
      plan.autoRestoreSeconds = duration_seconds;
      return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt, autoRestoreSeconds: duration_seconds }, "Temporary SIP logging change planned.");
    } catch (error) { return failure(error, "plan"); }
  });

  server.registerTool("get_call_sip_trace", {
    title: "Get a call SIP trace",
    description: "Validate a call against its tenant, retrieve its size-limited PCAP, and return a redacted chronological SIP dialog.",
    inputSchema: { domain: z.string().min(1), call_id: z.string().min(1).max(256), include_sdp: z.boolean().default(false), include_raw_messages: z.boolean().default(false) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ domain, call_id, include_sdp, include_raw_messages }) => {
    audit("get_call_sip_trace", { actor, domain, call_id, include_sdp, include_raw_messages });
    try {
      enforceTenant({ domain });
      const cdr = await callOperation("get_rest_domain_domain_cdr", { pathParams: { domain }, queryParams: { id: call_id } });
      const rows = Array.isArray(cdr.data) ? cdr.data : [cdr.data];
      if (!rows.length || !rows.some(Boolean)) throw new Error("Call ID was not found in the requested tenant.");
      const pcapOperation = operationsById.get("get_rest_system_pcap");
      const { url } = buildUrl(pcapOperation, {}, { id: call_id });
      const response = await fetch(url, { headers: { Accept: "application/vnd.tcpdump.pcap, application/octet-stream", Authorization: authorization(), "User-Agent": "vodia-mcp-admin/0.7.0" }, signal: AbortSignal.timeout(30_000) });
      if (!response.ok) throw new Error(`No retained PCAP is available for this call (HTTP ${response.status}).`);
      const buffer = await limitedBuffer(response);
      const messages = parseSipFromPcap(buffer, { includeSdp: include_sdp });
      if (!messages.length) throw new Error("PCAP was retrieved but contained no recognizable SIP messages.");
      const safeMessages = messages.map((message) => include_raw_messages ? message : { timestamp: message.timestamp, startLine: message.startLine, callId: message.callId, cseq: message.cseq, reason: message.reason, userAgent: message.userAgent });
      return success(redactSensitive({ summary: summarizeSipDialog(messages), messages: safeMessages }), { domain, callId: call_id, pcapBytes: buffer.length, redactionApplied: true }, `Retrieved and parsed ${messages.length} SIP messages.`);
    } catch (error) { return failure(error); }
  });
}

export function getAdminRuntimeInfo() {
  return { apiVersion: apiCatalog.vodiaApiVersion, totalOperations: apiCatalog.totalOperations, counts: apiCatalog.counts, destructiveEnabled: DESTRUCTIVE_ENABLED, elevatedWritesEnabled: ELEVATED_ENABLED, planTtlMs: PLAN_TTL_MS, pcapLimitBytes: PCAP_LIMIT_BYTES };
}

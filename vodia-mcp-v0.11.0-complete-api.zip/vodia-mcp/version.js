export const CONNECTOR_VERSION = "0.11.0";

# Amazon Chime SDK Voice Phase 2 for Vodia MCP

Adds deeper read-only inspection and guarded Voice Connector creation.

New reads:
- aws_chime_get_termination
- aws_chime_get_origination
- aws_chime_list_termination_credentials
- aws_chime_get_termination_health
- aws_chime_list_available_regions
- aws_chime_recommend_region

New guarded admin tools:
- aws_chime_plan_create_voice_connector
- aws_chime_apply_change

Phase 2 creates only the top-level Voice Connector. Termination/origination writes, phone-number association, SIP credential creation, and Vodia trunk creation are intentionally deferred until this phase is validated.

Install:
sudo bash apply-aws-chime-phase2.sh

Then update the EC2 role inline policy with aws-chime-phase2-policy.json and restart vodia-mcp.

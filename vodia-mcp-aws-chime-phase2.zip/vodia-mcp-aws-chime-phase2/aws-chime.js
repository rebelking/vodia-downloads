import { randomUUID } from "node:crypto";
import {
  ChimeSDKVoiceClient,
  CreateVoiceConnectorCommand,
  GetVoiceConnectorCommand,
  GetVoiceConnectorOriginationCommand,
  GetVoiceConnectorTerminationCommand,
  GetVoiceConnectorTerminationHealthCommand,
  ListAvailableVoiceConnectorRegionsCommand,
  ListVoiceConnectorTerminationCredentialsCommand,
  ListVoiceConnectorsCommand,
} from "@aws-sdk/client-chime-sdk-voice";
import { GetCallerIdentityCommand, STSClient } from "@aws-sdk/client-sts";

const DEFAULT_REGION = String(process.env.AWS_CHIME_REGION || process.env.AWS_REGION || process.env.AWS_DEFAULT_REGION || "us-east-1").trim();
const REGION_RE = /^[a-z]{2}(?:-gov)?-[a-z]+-\d$/;
const PLAN_TTL_MS = 5 * 60 * 1000;
const plans = new Map();

const COUNTRY_ALIASES = new Map([
  ["US","US"],["USA","US"],["UNITED STATES","US"],["UNITED STATES OF AMERICA","US"],
  ["CA","CA"],["CANADA","CA"],["JP","JP"],["JAPAN","JP"],["KR","KR"],["KOREA","KR"],["SOUTH KOREA","KR"],
  ["SG","SG"],["SINGAPORE","SG"],["AU","AU"],["AUSTRALIA","AU"],["GB","GB"],["UK","GB"],["UNITED KINGDOM","GB"],
  ["IE","IE"],["IRELAND","IE"],["DE","DE"],["GERMANY","DE"],["FR","FR"],["FRANCE","FR"],["ES","ES"],["SPAIN","ES"],
  ["IT","IT"],["ITALY","IT"],["NL","NL"],["NETHERLANDS","NL"]
]);
const PREFERRED_REGIONS = {
  US:["us-east-1","us-west-2"], CA:["ca-central-1","us-east-1"],
  JP:["ap-northeast-1","ap-northeast-2"], KR:["ap-northeast-2","ap-northeast-1"],
  SG:["ap-southeast-1","ap-northeast-1"], AU:["ap-southeast-2","ap-southeast-1"],
  GB:["eu-west-2","eu-west-1","eu-central-1"], IE:["eu-west-1","eu-west-2","eu-central-1"],
  DE:["eu-central-1","eu-west-1","eu-west-2"], FR:["eu-central-1","eu-west-1","eu-west-2"],
  ES:["eu-central-1","eu-west-1","eu-west-2"], IT:["eu-central-1","eu-west-1","eu-west-2"],
  NL:["eu-central-1","eu-west-1","eu-west-2"]
};

function normalizeRegion(region) {
  const value = String(region || DEFAULT_REGION).trim();
  if (!REGION_RE.test(value)) throw new Error(`Invalid AWS region '${value}'.`);
  return value;
}
function normalizeCountry(country) {
  const key = String(country || "").trim().toUpperCase();
  if (!key) throw new Error("country is required.");
  const code = COUNTRY_ALIASES.get(key) || (/^[A-Z]{2}$/.test(key) ? key : null);
  if (!code) throw new Error(`Country '${country}' is not in the built-in recommendation map. Use an ISO alpha-2 code or specify region explicitly.`);
  return code;
}
function clientOptions(region) { return { region: normalizeRegion(region), maxAttempts: 3 }; }
function voiceClient(region) { return new ChimeSDKVoiceClient(clientOptions(region)); }
function awsError(error) {
  const name = String(error?.name || "AwsError");
  const message = String(error?.message || error || "Unknown AWS error");
  if (name === "CredentialsProviderError") return new Error("AWS credentials were not found. Attach an EC2 IAM role/instance profile and retry.");
  if (name === "AccessDeniedException" || name === "AccessDenied" || name === "UnauthorizedOperation") return new Error(`AWS access denied: ${message}`);
  return new Error(`${name}: ${message}`);
}
function connectorSummary(c, region) {
  return c ? {
    voiceConnectorId:c.VoiceConnectorId||null, voiceConnectorArn:c.VoiceConnectorArn||null, name:c.Name||null,
    outboundHostName:c.OutboundHostName||null, requireEncryption:Boolean(c.RequireEncryption),
    awsRegion:c.AwsRegion||region, networkType:c.NetworkType||null,
    createdTimestamp:c.CreatedTimestamp?.toISOString?.()||c.CreatedTimestamp||null,
    updatedTimestamp:c.UpdatedTimestamp?.toISOString?.()||c.UpdatedTimestamp||null,
  } : null;
}

export function getAwsChimeConfig() {
  return { defaultRegion:DEFAULT_REGION, credentialMode:"AWS SDK v3 default provider chain", explicitAccessKeysRequired:false, phase:2 };
}
export async function testAwsChimeConnection({region}={}) {
  const r=normalizeRegion(region);
  try {
    const identity=await new STSClient(clientOptions(r)).send(new GetCallerIdentityCommand({}));
    const connectors=await voiceClient(r).send(new ListVoiceConnectorsCommand({MaxResults:1}));
    return {connected:true,region:r,identity:{account:identity.Account||null,arn:identity.Arn||null,userId:identity.UserId||null},
      chimeSdkVoice:{accessible:true,voiceConnectorCountSampled:Array.isArray(connectors.VoiceConnectors)?connectors.VoiceConnectors.length:0,hasMore:Boolean(connectors.NextToken)}};
  } catch(e){throw awsError(e);}
}
export async function listAwsChimeVoiceConnectors({region,maxResults=20,nextToken}={}) {
  const r=normalizeRegion(region), m=Math.max(1,Math.min(Number(maxResults)||20,100));
  try {
    const x=await voiceClient(r).send(new ListVoiceConnectorsCommand({MaxResults:m,...(nextToken?{NextToken:String(nextToken)}:{})}));
    return {region:r,voiceConnectors:(x.VoiceConnectors||[]).map(c=>connectorSummary(c,r)),nextToken:x.NextToken||null};
  } catch(e){throw awsError(e);}
}
export async function getAwsChimeVoiceConnector({voiceConnectorId,region}={}) {
  const id=String(voiceConnectorId||"").trim(); if(!id) throw new Error("voiceConnectorId is required."); const r=normalizeRegion(region);
  try { const x=await voiceClient(r).send(new GetVoiceConnectorCommand({VoiceConnectorId:id})); return {region:r,voiceConnector:connectorSummary(x.VoiceConnector,r)}; }
  catch(e){throw awsError(e);}
}
export async function getAwsChimeTermination({voiceConnectorId,region}={}) {
  const id=String(voiceConnectorId||"").trim(); if(!id) throw new Error("voiceConnectorId is required."); const r=normalizeRegion(region);
  try { const x=await voiceClient(r).send(new GetVoiceConnectorTerminationCommand({VoiceConnectorId:id})); return {region:r,voiceConnectorId:id,termination:x.Termination||null}; }
  catch(e){throw awsError(e);}
}
export async function getAwsChimeOrigination({voiceConnectorId,region}={}) {
  const id=String(voiceConnectorId||"").trim(); if(!id) throw new Error("voiceConnectorId is required."); const r=normalizeRegion(region);
  try { const x=await voiceClient(r).send(new GetVoiceConnectorOriginationCommand({VoiceConnectorId:id})); return {region:r,voiceConnectorId:id,origination:x.Origination||null}; }
  catch(e){throw awsError(e);}
}
export async function listAwsChimeTerminationCredentials({voiceConnectorId,region}={}) {
  const id=String(voiceConnectorId||"").trim(); if(!id) throw new Error("voiceConnectorId is required."); const r=normalizeRegion(region);
  try { const x=await voiceClient(r).send(new ListVoiceConnectorTerminationCredentialsCommand({VoiceConnectorId:id}));
    return {region:r,voiceConnectorId:id,usernames:(x.Usernames||[]).map(String),note:"AWS lists usernames but does not return stored SIP passwords."}; }
  catch(e){throw awsError(e);}
}
export async function getAwsChimeTerminationHealth({voiceConnectorId,region}={}) {
  const id=String(voiceConnectorId||"").trim(); if(!id) throw new Error("voiceConnectorId is required."); const r=normalizeRegion(region);
  try { const x=await voiceClient(r).send(new GetVoiceConnectorTerminationHealthCommand({VoiceConnectorId:id}));
    return {region:r,voiceConnectorId:id,terminationHealth:x.TerminationHealth||null}; }
  catch(e){throw awsError(e);}
}
export async function listAwsChimeAvailableRegions({region}={}) {
  const r=normalizeRegion(region);
  try { const x=await voiceClient(r).send(new ListAvailableVoiceConnectorRegionsCommand({})); return {lookupRegion:r,regions:(x.VoiceConnectorRegions||[]).map(String)}; }
  catch(e){throw awsError(e);}
}
export async function recommendAwsChimeRegion({country,region}={}) {
  const cc=normalizeCountry(country), available=await listAwsChimeAvailableRegions({region}), set=new Set(available.regions);
  const prefs=PREFERRED_REGIONS[cc]||["us-east-1","us-west-2"];
  const recommendedRegion=prefs.find(x=>set.has(x))||available.regions[0]||null;
  if(!recommendedRegion) throw new Error("AWS returned no available Voice Connector regions.");
  return {country:String(country),countryCode:cc,recommendedRegion,preferredCandidates:prefs,availableRegions:available.regions,validatedAgainstAws:true};
}
export async function planAwsChimeCreateVoiceConnector({actor,name,deploymentCountry,region,requireEncryption=true,networkType="IPV4_ONLY"}={}) {
  const a=String(actor||"unknown"), n=String(name||"").trim(); if(!n) throw new Error("name is required."); if(n.length>256) throw new Error("name exceeds 256 characters.");
  const cc=normalizeCountry(deploymentCountry);
  let awsRegion;
  if(region) {
    awsRegion=normalizeRegion(region);
    const available=await listAwsChimeAvailableRegions({region:awsRegion});
    if(!available.regions.includes(awsRegion)) throw new Error(`AWS region '${awsRegion}' is not currently available for Voice Connectors.`);
  } else {
    awsRegion=(await recommendAwsChimeRegion({country:cc})).recommendedRegion;
  }
  if(!["IPV4_ONLY","DUAL_STACK"].includes(networkType)) throw new Error("networkType must be IPV4_ONLY or DUAL_STACK.");
  const changeId=`aws-chime-${randomUUID()}`, expiresAt=new Date(Date.now()+PLAN_TTL_MS);
  const confirmation=`CREATE AWS CHIME CONNECTOR ${n} IN ${awsRegion}`;
  plans.set(changeId,{changeId,actor:a,operation:"CreateVoiceConnector",expiresAt,used:false,confirmation,
    request:{Name:n,AwsRegion:awsRegion,RequireEncryption:Boolean(requireEncryption),NetworkType:networkType},deploymentCountry:cc});
  return {changeId,operation:"CreateVoiceConnector",expiresAt:expiresAt.toISOString(),deploymentCountry:cc,awsRegion,
    request:{Name:n,AwsRegion:awsRegion,RequireEncryption:Boolean(requireEncryption),NetworkType:networkType},
    requiredConfirmation:confirmation,changesAws:false,
    guidance:"Review this plan. Apply only with aws_chime_apply_change and the exact requiredConfirmation before expiry."};
}
export async function applyAwsChimeChange({actor,changeId,confirmation}={}) {
  const id=String(changeId||"").trim(), p=plans.get(id); if(!p) throw new Error("Unknown or expired AWS Chime change plan.");
  if(p.used) throw new Error("This AWS Chime change plan has already been used.");
  if(Date.now()>p.expiresAt.getTime()){plans.delete(id);throw new Error("This AWS Chime change plan has expired.");}
  if(String(actor||"unknown")!==p.actor) throw new Error("This AWS Chime change plan belongs to a different authenticated actor.");
  if(String(confirmation||"")!==p.confirmation) throw new Error(`Confirmation mismatch. Required exact confirmation: ${p.confirmation}`);
  p.used=true;
  try {
    const x=await voiceClient(p.request.AwsRegion).send(new CreateVoiceConnectorCommand(p.request));
    plans.delete(id);
    return {changeId:id,operation:p.operation,region:p.request.AwsRegion,deploymentCountry:p.deploymentCountry,voiceConnector:connectorSummary(x.VoiceConnector,p.request.AwsRegion)};
  } catch(e){plans.delete(id);throw awsError(e);}
}

#!/usr/bin/env bash
set -Eeuo pipefail
APP_DIR="/opt/vodia-mcp"
BACKUP="/var/backups/vodia-mcp-aws-phase2-$(date +%Y%m%d-%H%M%S)"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
[[ ${EUID} -eq 0 ]] || { echo "Run: sudo bash apply-aws-chime-phase2.sh"; exit 1; }
[[ -f "$APP_DIR/index.js" ]] || { echo "Missing $APP_DIR/index.js"; exit 1; }
echo "[1/6] Backup..."
mkdir -p "$BACKUP"
cp -a "$APP_DIR/index.js" "$BACKUP/index.js"
[[ -f "$APP_DIR/aws-chime.js" ]] && cp -a "$APP_DIR/aws-chime.js" "$BACKUP/aws-chime.js"
echo "[2/6] AWS SDK..."
cd "$APP_DIR"
npm install --save @aws-sdk/client-chime-sdk-voice @aws-sdk/client-sts
echo "[3/6] Install Phase 2..."
install -m 0644 "$HERE/aws-chime.js" "$APP_DIR/aws-chime.js"
install -m 0644 "$HERE/index.js" "$APP_DIR/index.js"
echo "[4/6] Syntax..."
node --check "$APP_DIR/aws-chime.js"
node --check "$APP_DIR/index.js"
echo "[5/6] Restart..."
systemctl restart vodia-mcp
systemctl is-active --quiet vodia-mcp
echo "[6/6] Complete. Backup: $BACKUP"
echo "Now expand the EC2 IAM inline policy using: $HERE/aws-chime-phase2-policy.json"

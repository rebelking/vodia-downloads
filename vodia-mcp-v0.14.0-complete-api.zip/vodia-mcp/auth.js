import { createHash, randomBytes, randomUUID, timingSafeEqual } from "node:crypto";
import { chmodSync, mkdirSync } from "node:fs";
import { dirname } from "node:path";
import { DatabaseSync } from "node:sqlite";
import bcrypt from "bcryptjs";
import {
  AccessDeniedError,
  CustomOAuthError,
  InvalidGrantError,
  InvalidRequestError,
  InvalidScopeError,
  InvalidTargetError,
} from "@modelcontextprotocol/sdk/server/auth/errors.js";

const DEFAULT_SCOPES = ["mcp:read"];
const ROLE_SCOPES = {
  viewer: new Set(["mcp:read"]),
  approver: new Set(["mcp:read", "mcp:approve"]),
  admin: new Set(["mcp:read", "mcp:admin", "mcp:approve"]),
};
const DUMMY_PASSWORD_HASH = "$2b$12$IrFOwWYFC872VsplfhG0jOhDFd81ukxqMhdwx93Q.op2suptGEINW";
const LOOPBACK_HOSTS = new Set(["localhost", "127.0.0.1", "[::1]"]);

function envInteger(name, fallback, minimum, maximum) {
  const value = Number(process.env[name] || fallback);
  if (!Number.isInteger(value) || value < minimum || value > maximum) {
    throw new Error(`${name} must be an integer from ${minimum} through ${maximum}.`);
  }
  return value;
}

function nowSeconds() {
  return Math.floor(Date.now() / 1000);
}

function opaque(bytes = 32) {
  return randomBytes(bytes).toString("base64url");
}

function digest(value) {
  return createHash("sha256").update(String(value)).digest("hex");
}

function constantEqual(left, right) {
  const a = Buffer.from(String(left || ""));
  const b = Buffer.from(String(right || ""));
  return a.length === b.length && timingSafeEqual(a, b);
}

function parseJson(value, fallback) {
  try {
    return JSON.parse(value);
  } catch {
    return fallback;
  }
}

function normalizeEmail(value) {
  const email = String(value || "").trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) {
    throw new Error("A valid email address is required.");
  }
  return email;
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function parseCookies(req) {
  const result = {};
  for (const part of String(req.headers.cookie || "").split(";")) {
    const index = part.indexOf("=");
    if (index < 1) continue;
    const key = part.slice(0, index).trim();
    try {
      result[key] = decodeURIComponent(part.slice(index + 1).trim());
    } catch {
      // Ignore malformed cookie values.
    }
  }
  return result;
}

function page(title, body) {
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escapeHtml(title)}</title><style>
  :root{color-scheme:dark}body{margin:0;background:#0c111b;color:#eef2f7;font:16px system-ui,-apple-system,Segoe UI,sans-serif}.card{max-width:520px;margin:8vh auto;padding:32px;border:1px solid #283347;border-radius:16px;background:#151d2a;box-shadow:0 18px 60px #0008}h1{margin-top:0}label{display:block;margin:16px 0 6px}input{box-sizing:border-box;width:100%;padding:12px;border:1px solid #3a4963;border-radius:8px;background:#0e1521;color:#fff}button{margin-top:20px;padding:11px 18px;border:0;border-radius:8px;background:#e31b23;color:#fff;font-weight:700;cursor:pointer}.secondary{background:#46536a;margin-left:8px}.error{padding:10px;border-radius:8px;background:#521d25;color:#ffd7dc}.muted{color:#aeb9c9}.scope{font-family:ui-monospace,monospace;background:#0e1521;padding:10px;border-radius:8px}</style></head><body><main class="card">${body}</main></body></html>`;
}

function hiddenAuthorizationFields(client, params) {
  const values = {
    response_type: "code",
    client_id: client.client_id,
    redirect_uri: params.redirectUri,
    code_challenge: params.codeChallenge,
    code_challenge_method: "S256",
    state: params.state,
    scope: (params.scopes || []).join(" "),
    resource: params.resource?.href,
  };
  return Object.entries(values)
    .filter(([, value]) => value !== undefined && value !== "")
    .map(([key, value]) => `<input type="hidden" name="${escapeHtml(key)}" value="${escapeHtml(value)}">`)
    .join("");
}

export function readAuthConfig() {
  const publicBase = String(process.env.PUBLIC_BASE_URL || "").trim().replace(/\/+$/, "");
  const sessionSecret = String(process.env.SESSION_SECRET || "");
  const enabled = Boolean(publicBase && sessionSecret);
  if (publicBase) {
    const url = new URL(publicBase);
    if (url.protocol !== "https:" && !LOOPBACK_HOSTS.has(url.hostname)) {
      throw new Error("PUBLIC_BASE_URL must use HTTPS except for loopback testing.");
    }
    if (url.pathname !== "/" || url.search || url.hash) throw new Error("PUBLIC_BASE_URL must be an origin without a path, query string, or fragment.");
  }
  if (enabled && Buffer.byteLength(sessionSecret) < 32) throw new Error("SESSION_SECRET must contain at least 32 bytes.");
  return {
    enabled,
    publicBase,
    dbPath: String(process.env.DB_PATH || "/var/lib/vodia-mcp/auth.db"),
    sessionSecret,
    accessTtl: envInteger("ACCESS_TOKEN_TTL_SECONDS", 3600, 300, 86400),
    refreshTtl: envInteger("REFRESH_TOKEN_TTL_SECONDS", 2592000, 3600, 31536000),
    codeTtl: envInteger("AUTH_CODE_TTL_SECONDS", 120, 30, 600),
    sessionTtl: envInteger("SESSION_TTL_SECONDS", 43200, 300, 604800),
    allowLoopback: /^true$/i.test(process.env.ALLOW_LOOPBACK_REDIRECTS || "true"),
    allowedRedirects: new Set(String(process.env.ALLOWED_REDIRECT_URIS || "https://claude.ai/api/mcp/auth_callback,https://claude.com/api/mcp/auth_callback").split(",").map((v) => v.trim()).filter(Boolean)),
    legacyEnabled: !/^false$/i.test(process.env.LEGACY_STATIC_TOKEN_ENABLED || "true"),
    trustProxy: /^true$/i.test(process.env.TRUST_PROXY || "true"),
    oauthToolResultLimit: envInteger("OAUTH_TOOL_RESULT_LIMIT_BYTES", 140000, 10000, 1000000),
  };
}

export class AuthService {
  constructor(config = readAuthConfig()) {
    this.config = config;
    mkdirSync(dirname(config.dbPath), { recursive: true, mode: 0o700 });
    this.db = new DatabaseSync(config.dbPath);
    chmodSync(config.dbPath, 0o600);
    this.db.exec("PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;");
    this.migrate();
    this.clientsStore = {
      getClient: async (clientId) => this.getClient(clientId),
      registerClient: async (client) => this.registerClient(client),
    };
  }

  migrate() {
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY, email TEXT NOT NULL UNIQUE, display_name TEXT NOT NULL,
        password_hash TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('viewer','admin','approver')),
        status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','disabled')),
        failed_login_count INTEGER NOT NULL DEFAULT 0, locked_until INTEGER,
        created_at INTEGER NOT NULL, last_login_at INTEGER
      );
      CREATE TABLE IF NOT EXISTS oauth_clients (
        client_id TEXT PRIMARY KEY, metadata_json TEXT NOT NULL, created_at INTEGER NOT NULL,
        last_used_at INTEGER
      );
      CREATE TABLE IF NOT EXISTS auth_codes (
        code_hash TEXT PRIMARY KEY, client_id TEXT NOT NULL, user_id TEXT NOT NULL,
        redirect_uri TEXT NOT NULL, code_challenge TEXT NOT NULL, scopes TEXT NOT NULL,
        resource TEXT NOT NULL, expires_at INTEGER NOT NULL, used_at INTEGER, family_id TEXT,
        FOREIGN KEY(user_id) REFERENCES users(id), FOREIGN KEY(client_id) REFERENCES oauth_clients(client_id)
      );
      CREATE TABLE IF NOT EXISTS tokens (
        token_hash TEXT PRIMARY KEY, token_type TEXT NOT NULL CHECK(token_type IN ('access','refresh','pat')),
        user_id TEXT NOT NULL, client_id TEXT NOT NULL, name TEXT, scopes TEXT NOT NULL,
        resource TEXT, expires_at INTEGER, revoked_at INTEGER, rotated_at INTEGER,
        family_id TEXT NOT NULL, last_used_at INTEGER, created_at INTEGER NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id)
      );
      CREATE TABLE IF NOT EXISTS browser_sessions (
        session_hash TEXT PRIMARY KEY, user_id TEXT, csrf_token TEXT NOT NULL,
        expires_at INTEGER NOT NULL, created_at INTEGER NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id)
      );
      CREATE INDEX IF NOT EXISTS idx_tokens_user ON tokens(user_id);
      CREATE INDEX IF NOT EXISTS idx_tokens_family ON tokens(family_id);
      CREATE INDEX IF NOT EXISTS idx_codes_expires ON auth_codes(expires_at);
      CREATE INDEX IF NOT EXISTS idx_sessions_expires ON browser_sessions(expires_at);
    `);
  }

  close() {
    this.db.close();
  }

  createUser({ email, displayName, password, role = "viewer" }) {
    const cleanEmail = normalizeEmail(email);
    const cleanName = String(displayName || "").trim();
    if (!cleanName || cleanName.length > 120) throw new Error("Display name is required and must not exceed 120 characters.");
    if (!ROLE_SCOPES[role]) throw new Error("Role must be viewer, admin, or approver.");
    if (String(password || "").length < 12) throw new Error("Password must contain at least 12 characters.");
    const id = randomUUID();
    const passwordHash = bcrypt.hashSync(String(password), 12);
    this.db.prepare("INSERT INTO users (id,email,display_name,password_hash,role,status,created_at) VALUES (?,?,?,?,?,'active',?)")
      .run(id, cleanEmail, cleanName, passwordHash, role, nowSeconds());
    return this.getUser(id);
  }

  getUser(id) {
    return this.db.prepare("SELECT id,email,display_name,role,status,failed_login_count,locked_until,created_at,last_login_at FROM users WHERE id=?").get(id);
  }

  listUsers() {
    return this.db.prepare("SELECT id,email,display_name,role,status,failed_login_count,locked_until,created_at,last_login_at FROM users ORDER BY email").all();
  }

  setUserStatus(id, status) {
    if (!new Set(["active", "disabled"]).has(status)) throw new Error("Invalid user status.");
    const result = this.db.prepare("UPDATE users SET status=? WHERE id=?").run(status, id);
    if (!result.changes) throw new Error("User not found.");
    if (status === "disabled") {
      const now = nowSeconds();
      this.db.prepare("UPDATE tokens SET revoked_at=COALESCE(revoked_at,?) WHERE user_id=?").run(now, id);
      this.db.prepare("DELETE FROM browser_sessions WHERE user_id=?").run(id);
      this.db.prepare("DELETE FROM auth_codes WHERE user_id=? AND used_at IS NULL").run(id);
    }
    return this.getUser(id);
  }

  setUserRole(id, role) {
    if (!ROLE_SCOPES[role]) throw new Error("Invalid role.");
    const result = this.db.prepare("UPDATE users SET role=? WHERE id=?").run(role, id);
    if (!result.changes) throw new Error("User not found.");
    const now = nowSeconds();
    this.db.prepare("UPDATE tokens SET revoked_at=COALESCE(revoked_at,?) WHERE user_id=?").run(now, id);
    return this.getUser(id);
  }

  resetPassword(id, password) {
    if (String(password || "").length < 12) throw new Error("Password must contain at least 12 characters.");
    const hash = bcrypt.hashSync(String(password), 12);
    const result = this.db.prepare("UPDATE users SET password_hash=?,failed_login_count=0,locked_until=NULL WHERE id=?").run(hash, id);
    if (!result.changes) throw new Error("User not found.");
    const now = nowSeconds();
    this.db.prepare("UPDATE users SET status='active' WHERE id=?").run(id);
    this.db.prepare("UPDATE tokens SET revoked_at=COALESCE(revoked_at,?) WHERE user_id=?").run(now, id);
    this.db.prepare("DELETE FROM browser_sessions WHERE user_id=?").run(id);
    this.db.prepare("DELETE FROM auth_codes WHERE user_id=? AND used_at IS NULL").run(id);
    return this.getUser(id);
  }

  authenticate(email, password) {
    let cleanEmail;
    try { cleanEmail = normalizeEmail(email); } catch { return null; }
    const user = this.db.prepare("SELECT * FROM users WHERE email=?").get(cleanEmail);
    const now = nowSeconds();
    const passwordMatches = bcrypt.compareSync(String(password || ""), user?.password_hash || DUMMY_PASSWORD_HASH);
    if (!user || user.status !== "active" || (user.locked_until && user.locked_until > now)) return null;
    if (!passwordMatches) {
      const failures = user.failed_login_count + 1;
      const lockedUntil = failures >= 5 ? now + 900 : null;
      this.db.prepare("UPDATE users SET failed_login_count=?,locked_until=? WHERE id=?").run(failures, lockedUntil, user.id);
      return null;
    }
    this.db.prepare("UPDATE users SET failed_login_count=0,locked_until=NULL,last_login_at=? WHERE id=?").run(now, user.id);
    return this.getUser(user.id);
  }

  isAllowedRedirect(uri) {
    if (this.config.allowedRedirects.has(uri)) return true;
    if (!this.config.allowLoopback) return false;
    try {
      const url = new URL(uri);
      return url.protocol === "http:" && LOOPBACK_HOSTS.has(url.hostname) && url.pathname === "/callback" && !url.username && !url.password && !url.search && !url.hash;
    } catch {
      return false;
    }
  }

  registerClient(client) {
    if (client.token_endpoint_auth_method !== "none") throw new Error("Only public OAuth clients are supported.");
    if (!Array.isArray(client.redirect_uris) || !client.redirect_uris.length || client.redirect_uris.some((uri) => !this.isAllowedRedirect(uri))) {
      throw new CustomOAuthError("invalid_redirect_uri", "One or more redirect URIs are not allowed.");
    }
    const stored = { ...client, token_endpoint_auth_method: "none", grant_types: ["authorization_code", "refresh_token"], response_types: ["code"] };
    this.db.prepare("INSERT INTO oauth_clients (client_id,metadata_json,created_at) VALUES (?,?,?)")
      .run(stored.client_id, JSON.stringify(stored), nowSeconds());
    return stored;
  }

  getClient(clientId) {
    const row = this.db.prepare("SELECT metadata_json FROM oauth_clients WHERE client_id=?").get(clientId);
    return row ? parseJson(row.metadata_json, undefined) : undefined;
  }

  createSession(res, userId = null) {
    const raw = opaque();
    const csrf = opaque();
    const now = nowSeconds();
    this.db.prepare("INSERT INTO browser_sessions (session_hash,user_id,csrf_token,expires_at,created_at) VALUES (?,?,?,?,?)")
      .run(digest(`${this.config.sessionSecret}:${raw}`), userId, csrf, now + this.config.sessionTtl, now);
    res.setHeader("Set-Cookie", `vodia_auth_session=${encodeURIComponent(raw)}; Path=/; Max-Age=${this.config.sessionTtl}; HttpOnly; Secure; SameSite=Lax`);
    return { raw, csrf_token: csrf, user_id: userId, expires_at: now + this.config.sessionTtl };
  }

  getSession(req) {
    const raw = parseCookies(req).vodia_auth_session;
    if (!raw) return null;
    const session = this.db.prepare("SELECT * FROM browser_sessions WHERE session_hash=? AND expires_at>?")
      .get(digest(`${this.config.sessionSecret}:${raw}`), nowSeconds());
    if (!session) return null;
    return { ...session, raw };
  }

  attachSessionUser(session, userId) {
    this.db.prepare("UPDATE browser_sessions SET user_id=? WHERE session_hash=?").run(userId, session.session_hash);
    return { ...session, user_id: userId };
  }

  allowedScopes(user, requested, resource) {
    const maximum = ROLE_SCOPES[user.role] || ROLE_SCOPES.viewer;
    const resourcePath = new URL(resource).pathname;
    const resourceScopes = resourcePath === "/mcp-admin"
      ? new Set(["mcp:read", "mcp:admin"])
      : resourcePath === "/mcp-approver"
        ? new Set(["mcp:read", "mcp:approve"])
        : new Set(["mcp:read"]);
    const desired = requested?.length ? requested : [...resourceScopes];
    if (desired.some((scope) => !maximum.has(scope) || !resourceScopes.has(scope))) throw new InvalidScopeError("Requested scope is not allowed for this user or resource.");
    return [...new Set(desired)];
  }

  validateResource(resource) {
    const url = resource instanceof URL ? resource : new URL(String(resource || `${this.config.publicBase}/mcp`));
    const allowed = new Set(["/mcp", "/mcp-admin", "/mcp-approver"]);
    if (url.origin !== new URL(this.config.publicBase).origin || !allowed.has(url.pathname) || url.search || url.hash) {
      throw new InvalidTargetError("Unknown Vodia MCP resource.");
    }
    return url.href;
  }

  authorizationRedirect(client, params, result) {
    const target = new URL(params.redirectUri);
    for (const [key, value] of Object.entries(result)) if (value !== undefined) target.searchParams.set(key, value);
    if (params.state !== undefined) target.searchParams.set("state", params.state);
    return target.href;
  }

  async authorize(client, params, res) {
    const req = res.req;
    const resource = this.validateResource(params.resource || new URL(`${this.config.publicBase}/mcp`));
    let session = this.getSession(req);
    if (!session) session = this.createSession(res);
    let user = session.user_id ? this.getUser(session.user_id) : null;
    const action = String(req.body?.action || "");
    const csrf = String(req.body?.csrf || "");

    if (!user && req.method === "POST" && action === "login") {
      if (!constantEqual(csrf, session.csrf_token)) throw new AccessDeniedError("Invalid login request.");
      user = this.authenticate(req.body?.email, req.body?.password);
      if (user) session = this.attachSessionUser(session, user.id);
    }

    const hidden = hiddenAuthorizationFields(client, { ...params, resource: new URL(resource) });
    if (!user || user.status !== "active") {
      const error = action === "login" ? '<p class="error">Invalid email or password</p>' : "";
      res.status(200).type("html").send(page("Sign in to Vodia MCP", `<h1>Vodia MCP</h1><p class="muted">Sign in to continue to ${escapeHtml(client.client_name || "an MCP client")}.</p>${error}<form method="post" action="/authorize">${hidden}<input type="hidden" name="action" value="login"><input type="hidden" name="csrf" value="${escapeHtml(session.csrf_token)}"><label>Email</label><input name="email" type="email" required autocomplete="username"><label>Password</label><input name="password" type="password" required autocomplete="current-password"><button type="submit">Sign in</button></form>`));
      return;
    }

    const scopes = this.allowedScopes(user, params.scopes, resource);
    if (req.method === "POST" && (action === "approve" || action === "deny")) {
      if (!constantEqual(csrf, session.csrf_token)) throw new AccessDeniedError("Invalid consent request.");
      if (action === "deny") {
        res.redirect(302, this.authorizationRedirect(client, params, { error: "access_denied" }));
        return;
      }
      const rawCode = opaque();
      this.db.prepare("INSERT INTO auth_codes (code_hash,client_id,user_id,redirect_uri,code_challenge,scopes,resource,expires_at) VALUES (?,?,?,?,?,?,?,?)")
        .run(digest(rawCode), client.client_id, user.id, params.redirectUri, params.codeChallenge, scopes.join(" "), resource, nowSeconds() + this.config.codeTtl);
      res.redirect(302, this.authorizationRedirect(client, params, { code: rawCode }));
      return;
    }

    res.status(200).type("html").send(page("Authorize Vodia MCP", `<h1>Authorize access</h1><p><strong>${escapeHtml(client.client_name || "MCP client")}</strong> wants access to Vodia PBX as <strong>${escapeHtml(user.email)}</strong>.</p><p class="scope">${escapeHtml(scopes.join(" "))}</p><p class="muted">PBX changes still require a separate Vodia plan and exact confirmation.</p><form method="post" action="/authorize">${hidden}<input type="hidden" name="csrf" value="${escapeHtml(session.csrf_token)}"><button type="submit" name="action" value="approve">Approve</button><button class="secondary" type="submit" name="action" value="deny">Deny</button></form>`));
  }

  codeRow(rawCode) {
    return this.db.prepare("SELECT * FROM auth_codes WHERE code_hash=?").get(digest(rawCode));
  }

  async challengeForAuthorizationCode(client, rawCode) {
    const row = this.codeRow(rawCode);
    if (!row || row.client_id !== client.client_id || row.expires_at <= nowSeconds()) throw new InvalidGrantError("Invalid or expired authorization code.");
    if (row.used_at) {
      if (row.family_id) this.revokeFamily(row.family_id);
      throw new InvalidGrantError("Authorization code was already used.");
    }
    return row.code_challenge;
  }

  issueTokenPair({ userId, clientId, scopes, resource, familyId = randomUUID() }) {
    const access = opaque();
    const refresh = opaque();
    const now = nowSeconds();
    const insert = this.db.prepare("INSERT INTO tokens (token_hash,token_type,user_id,client_id,scopes,resource,expires_at,family_id,created_at) VALUES (?,?,?,?,?,?,?,?,?)");
    this.db.exec("BEGIN IMMEDIATE");
    try {
      insert.run(digest(access), "access", userId, clientId, scopes, resource, now + this.config.accessTtl, familyId, now);
      insert.run(digest(refresh), "refresh", userId, clientId, scopes, resource, now + this.config.refreshTtl, familyId, now);
      this.db.prepare("UPDATE oauth_clients SET last_used_at=? WHERE client_id=?").run(now, clientId);
      this.db.exec("COMMIT");
    } catch (error) {
      this.db.exec("ROLLBACK");
      throw error;
    }
    return { access_token: access, token_type: "Bearer", expires_in: this.config.accessTtl, refresh_token: refresh, scope: scopes };
  }

  async exchangeAuthorizationCode(client, rawCode, _verifier, redirectUri, resource) {
    const row = this.codeRow(rawCode);
    if (!row || row.used_at || row.expires_at <= nowSeconds() || row.client_id !== client.client_id) throw new InvalidGrantError("Invalid authorization code.");
    if (redirectUri && redirectUri !== row.redirect_uri) throw new InvalidGrantError("redirect_uri does not match.");
    if (resource && this.validateResource(resource) !== row.resource) throw new InvalidGrantError("resource does not match.");
    const user = this.getUser(row.user_id);
    if (!user || user.status !== "active") throw new InvalidGrantError("User is disabled or unavailable.");
    try {
      this.allowedScopes(user, row.scopes.split(" ").filter(Boolean), row.resource);
    } catch {
      throw new InvalidGrantError("The user's role no longer permits this grant.");
    }
    const familyId = randomUUID();
    this.db.prepare("UPDATE auth_codes SET used_at=?,family_id=? WHERE code_hash=? AND used_at IS NULL").run(nowSeconds(), familyId, digest(rawCode));
    return this.issueTokenPair({ userId: row.user_id, clientId: row.client_id, scopes: row.scopes, resource: row.resource, familyId });
  }

  revokeFamily(familyId) {
    this.db.prepare("UPDATE tokens SET revoked_at=COALESCE(revoked_at,?) WHERE family_id=?").run(nowSeconds(), familyId);
  }

  async exchangeRefreshToken(client, rawRefresh, requestedScopes, resource) {
    const row = this.db.prepare("SELECT * FROM tokens WHERE token_hash=? AND token_type='refresh'").get(digest(rawRefresh));
    if (!row || row.client_id !== client.client_id || row.expires_at <= nowSeconds()) throw new InvalidGrantError("Invalid refresh token.");
    if (row.rotated_at || row.revoked_at) {
      this.revokeFamily(row.family_id);
      throw new InvalidGrantError("Refresh token reuse detected.");
    }
    const user = this.getUser(row.user_id);
    if (!user || user.status !== "active") throw new InvalidGrantError("User is disabled or unavailable.");
    if (resource && this.validateResource(resource) !== row.resource) throw new InvalidGrantError("resource does not match.");
    const original = row.scopes.split(" ").filter(Boolean);
    const scopes = requestedScopes?.length ? requestedScopes : original;
    if (scopes.some((scope) => !original.includes(scope))) throw new InvalidScopeError("Refresh scope exceeds the original grant.");
    this.db.prepare("UPDATE tokens SET rotated_at=?,revoked_at=? WHERE token_hash=?").run(nowSeconds(), nowSeconds(), row.token_hash);
    return this.issueTokenPair({ userId: row.user_id, clientId: row.client_id, scopes: scopes.join(" "), resource: row.resource, familyId: row.family_id });
  }

  async revokeToken(_client, request) {
    const hash = digest(request.token);
    this.db.prepare("UPDATE tokens SET revoked_at=COALESCE(revoked_at,?) WHERE token_hash=?").run(nowSeconds(), hash);
  }

  async verifyAccessToken(rawToken) {
    const row = this.db.prepare("SELECT * FROM tokens WHERE token_hash=? AND token_type IN ('access','pat')").get(digest(rawToken));
    const now = nowSeconds();
    if (!row || row.revoked_at || (row.expires_at && row.expires_at <= now)) throw new Error("Invalid or expired token.");
    const user = this.getUser(row.user_id);
    if (!user || user.status !== "active") throw new Error("User is disabled or unavailable.");
    const client = row.token_type === "pat" ? null : this.getClient(row.client_id);
    this.db.prepare("UPDATE tokens SET last_used_at=? WHERE token_hash=?").run(now, row.token_hash);
    return {
      token: rawToken,
      clientId: row.client_id,
      scopes: row.scopes.split(" ").filter(Boolean),
      expiresAt: row.expires_at || undefined,
      resource: row.resource ? new URL(row.resource) : undefined,
      extra: {
        user_id: user.id,
        email: user.email,
        display_name: user.display_name,
        role: user.role,
        client: row.token_type === "pat" ? `PAT: ${row.name}` : (client?.client_name || row.client_id),
        auth_type: row.token_type === "pat" ? "pat" : "oauth",
      },
    };
  }

  createPat(userId, name, scopes = ["mcp:read"]) {
    const user = this.getUser(userId);
    if (!user || user.status !== "active") throw new Error("Active user not found.");
    const cleanName = String(name || "").trim();
    if (!cleanName || cleanName.length > 80) throw new Error("PAT name is required.");
    const allowed = ROLE_SCOPES[user.role];
    if (scopes.some((scope) => !allowed.has(scope))) throw new Error("PAT scope exceeds the user's role.");
    const raw = `vodia_pat_${opaque()}`;
    const now = nowSeconds();
    this.db.prepare("INSERT INTO tokens (token_hash,token_type,user_id,client_id,name,scopes,resource,family_id,created_at) VALUES (?,?,?,?,?,?,?,?,?)")
      .run(digest(raw), "pat", user.id, `pat:${randomUUID()}`, cleanName, scopes.join(" "), null, randomUUID(), now);
    return { token: raw, name: cleanName, scopes };
  }

  listPats(userId) {
    return this.db.prepare("SELECT client_id,name,scopes,created_at,last_used_at,revoked_at FROM tokens WHERE user_id=? AND token_type='pat' ORDER BY created_at DESC").all(userId)
      .map((row) => ({ ...row, scopes: row.scopes.split(" ").filter(Boolean), active: !row.revoked_at }));
  }

  revokePat(userId, clientId) {
    this.db.prepare("UPDATE tokens SET revoked_at=COALESCE(revoked_at,?) WHERE user_id=? AND client_id=? AND token_type='pat'").run(nowSeconds(), userId, clientId);
  }

  listConnectedApps(userId) {
    return this.db.prepare(`SELECT t.client_id,c.metadata_json,MIN(t.created_at) created_at,MAX(t.last_used_at) last_used_at,
      MAX(CASE WHEN t.revoked_at IS NULL THEN 1 ELSE 0 END) active
      FROM tokens t LEFT JOIN oauth_clients c ON c.client_id=t.client_id
      WHERE t.user_id=? AND t.token_type IN ('access','refresh') GROUP BY t.client_id,c.metadata_json ORDER BY created_at DESC`).all(userId)
      .map((row) => ({ client_id: row.client_id, client_name: parseJson(row.metadata_json, {})?.client_name || row.client_id, created_at: row.created_at, last_used_at: row.last_used_at, active: Boolean(row.active) }));
  }

  revokeClientGrant(userId, clientId) {
    this.db.prepare("UPDATE tokens SET revoked_at=COALESCE(revoked_at,?) WHERE user_id=? AND client_id=?").run(nowSeconds(), userId, clientId);
  }

  cleanup() {
    const now = nowSeconds();
    this.db.prepare("DELETE FROM browser_sessions WHERE expires_at<=?").run(now);
    this.db.prepare("DELETE FROM auth_codes WHERE expires_at<=? AND used_at IS NULL").run(now);
  }
}

export function identityFromAuthInfo(authInfo) {
  const extra = authInfo?.extra || {};
  return {
    user_id: String(extra.user_id || authInfo?.clientId || "unknown"),
    email: extra.email ? String(extra.email) : null,
    display_name: extra.display_name ? String(extra.display_name) : null,
    role: String(extra.role || "viewer"),
    client_id: String(authInfo?.clientId || "unknown"),
    client: String(extra.client || authInfo?.clientId || "unknown"),
    scopes: Array.isArray(authInfo?.scopes) ? authInfo.scopes : [],
    auth_type: String(extra.auth_type || "oauth"),
  };
}

export function legacyIdentity(accessMode, actor) {
  return {
    user_id: `legacy:${accessMode}:${actor}`,
    email: null,
    display_name: actor,
    role: accessMode === "admin" ? "admin" : accessMode === "approver" ? "approver" : "viewer",
    client_id: `legacy-${accessMode}`,
    client: "legacy-token",
    scopes: accessMode === "admin" ? ["mcp:read", "mcp:admin"] : accessMode === "approver" ? ["mcp:approve"] : ["mcp:read"],
    auth_type: "legacy",
  };
}

export function createMcpAuthMiddleware({ service, accessMode, requiredScope, resourceUrl, legacyTokens, legacyActor }) {
  const metadataUrl = `${service.config.publicBase}/.well-known/oauth-protected-resource${new URL(resourceUrl).pathname}`;
  return async (req, res, next) => {
    const header = String(req.get("authorization") || "");
    const token = header.startsWith("Bearer ") ? header.slice(7) : "";
    if (token) {
      try {
        const auth = await service.verifyAccessToken(token);
        const identity = identityFromAuthInfo(auth);
        const tokenResource = auth.resource?.href;
        if (tokenResource && tokenResource !== resourceUrl) throw new Error("Token resource mismatch.");
        if (!auth.scopes.includes(requiredScope)) throw new Error("Insufficient token scope.");
        req.auth = auth;
        req.vodiaIdentity = identity;
        return next();
      } catch {
        // Legacy check follows during migration.
      }
      if (service.config.legacyEnabled && legacyTokens.some((candidate) => constantEqual(token, candidate))) {
        req.vodiaIdentity = legacyIdentity(accessMode, legacyActor);
        return next();
      }
    }
    res.setHeader("WWW-Authenticate", `Bearer resource_metadata="${metadataUrl}"${token ? ', error="invalid_token"' : ""}`);
    return res.status(401).json({ error: token ? "invalid_token" : "authorization_required" });
  };
}

export function protectedResourceMetadata(publicBase, path, scopes) {
  return {
    resource: `${publicBase}${path}`,
    authorization_servers: [publicBase],
    scopes_supported: scopes,
    bearer_methods_supported: ["header"],
  };
}

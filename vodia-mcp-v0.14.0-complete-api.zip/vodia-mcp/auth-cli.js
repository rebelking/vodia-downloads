#!/usr/bin/env node

import { AuthService, readAuthConfig } from "./auth.js";

function argument(name, fallback = "") {
  const index = process.argv.indexOf(`--${name}`);
  return index >= 0 ? String(process.argv[index + 1] || "") : fallback;
}

function passwordFromEnvironment() {
  const variable = argument("password-env", "VODIA_BOOTSTRAP_PASSWORD");
  const value = process.env[variable] || "";
  if (!value) throw new Error(`Set ${variable} to the password, then run this command again.`);
  return value;
}

function output(value) {
  process.stdout.write(`${JSON.stringify(value, null, 2)}\n`);
}

const command = process.argv[2];
const service = new AuthService(readAuthConfig());

try {
  switch (command) {
    case "create-admin":
    case "create-user": {
      const role = command === "create-admin" ? "admin" : argument("role", "viewer");
      output(service.createUser({
        email: argument("email"),
        displayName: argument("name"),
        password: passwordFromEnvironment(),
        role,
      }));
      break;
    }
    case "list-users":
      output(service.listUsers());
      break;
    case "reset-password":
      output(service.resetPassword(argument("user-id"), passwordFromEnvironment()));
      break;
    case "set-role":
      output(service.setUserRole(argument("user-id"), argument("role")));
      break;
    case "enable-user":
      output(service.setUserStatus(argument("user-id"), "active"));
      break;
    case "disable-user":
      output(service.setUserStatus(argument("user-id"), "disabled"));
      break;
    case "create-pat": {
      const scopes = argument("scopes", "mcp:read").split(",").map((value) => value.trim()).filter(Boolean);
      output(service.createPat(argument("user-id"), argument("name"), scopes));
      break;
    }
    default:
      process.stderr.write("Usage:\n  node auth-cli.js create-admin --email EMAIL --name NAME [--password-env VAR]\n  node auth-cli.js create-user --email EMAIL --name NAME --role viewer|admin|approver [--password-env VAR]\n  node auth-cli.js list-users\n  node auth-cli.js reset-password --user-id ID [--password-env VAR]\n  node auth-cli.js set-role --user-id ID --role viewer|admin|approver\n  node auth-cli.js enable-user|disable-user --user-id ID\n  node auth-cli.js create-pat --user-id ID --name NAME --scopes mcp:read,mcp:admin\n");
      process.exitCode = 2;
  }
} catch (error) {
  process.stderr.write(`Authentication command failed: ${error.message || error}\n`);
  process.exitCode = 1;
} finally {
  service.close();
}


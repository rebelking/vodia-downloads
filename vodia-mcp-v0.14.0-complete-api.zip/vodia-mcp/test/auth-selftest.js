import assert from "node:assert/strict";
import { createHash, randomBytes } from "node:crypto";
import { mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { AuthService } from "../auth.js";

function challenge(verifier) {
  return createHash("sha256").update(verifier).digest("base64url");
}

function mockResponse(req) {
  return {
    req,
    statusCode: 200,
    headers: {},
    body: "",
    redirectUrl: "",
    setHeader(name, value) { this.headers[name.toLowerCase()] = value; },
    status(code) { this.statusCode = code; return this; },
    type(value) { this.headers["content-type"] = value; return this; },
    send(value) { this.body = value; return this; },
    redirect(code, value) { this.statusCode = code; this.redirectUrl = value; return this; },
  };
}

const directory = mkdtempSync(join(tmpdir(), "vodia-auth-test-"));
const config = {
  enabled: true,
  publicBase: "https://mcp.example.test",
  dbPath: join(directory, "auth.db"),
  sessionSecret: "s".repeat(64),
  accessTtl: 3600,
  refreshTtl: 2592000,
  codeTtl: 120,
  sessionTtl: 43200,
  allowLoopback: true,
  allowedRedirects: new Set(["https://claude.ai/api/mcp/auth_callback"]),
  legacyEnabled: true,
  trustProxy: true,
};
const auth = new AuthService(config);

try {
  const admin = auth.createUser({ email: "admin@example.test", displayName: "Admin User", password: "correct horse battery staple", role: "admin" });
  assert.equal(auth.authenticate("admin@example.test", "wrong"), null);
  assert.equal(auth.authenticate("admin@example.test", "correct horse battery staple").id, admin.id);

  const client = auth.registerClient({
    client_id: "client-1",
    client_id_issued_at: Math.floor(Date.now() / 1000),
    client_name: "Claude",
    redirect_uris: ["https://claude.ai/api/mcp/auth_callback"],
    token_endpoint_auth_method: "none",
    grant_types: ["authorization_code", "refresh_token"],
    response_types: ["code"],
  });
  assert.equal(client.client_id, "client-1");
  assert.equal(auth.isAllowedRedirect("http://127.0.0.1:49152/callback"), true);
  assert.equal(auth.isAllowedRedirect("https://evil.example/callback"), false);
  assert.throws(() => auth.registerClient({ client_id: "evil", redirect_uris: ["https://evil.example/callback"], token_endpoint_auth_method: "none" }), /redirect/i);

  const verifier = randomBytes(48).toString("base64url");
  const params = {
    state: "state-1",
    scopes: ["mcp:read", "mcp:admin"],
    codeChallenge: challenge(verifier),
    redirectUri: "https://claude.ai/api/mcp/auth_callback",
    resource: new URL("https://mcp.example.test/mcp-admin"),
  };

  const firstReq = { method: "GET", headers: {}, body: {} };
  const firstRes = mockResponse(firstReq);
  await auth.authorize(client, params, firstRes);
  assert.match(firstRes.body, /Sign in to Vodia MCP/);
  const cookie = firstRes.headers["set-cookie"].split(";")[0];
  const session = auth.getSession({ headers: { cookie } });

  const loginReq = { method: "POST", headers: { cookie }, body: { action: "login", csrf: session.csrf_token, email: "admin@example.test", password: "correct horse battery staple" } };
  const loginRes = mockResponse(loginReq);
  await auth.authorize(client, params, loginRes);
  assert.match(loginRes.body, /Authorize access/);

  const approveReq = { method: "POST", headers: { cookie }, body: { action: "approve", csrf: session.csrf_token } };
  const approveRes = mockResponse(approveReq);
  await auth.authorize(client, params, approveRes);
  assert.equal(approveRes.statusCode, 302);
  const rawCode = new URL(approveRes.redirectUrl).searchParams.get("code");
  assert.ok(rawCode);
  assert.equal(await auth.challengeForAuthorizationCode(client, rawCode), challenge(verifier));

  const tokens = await auth.exchangeAuthorizationCode(client, rawCode, undefined, params.redirectUri, params.resource);
  assert.equal(tokens.token_type, "Bearer");
  const accessInfo = await auth.verifyAccessToken(tokens.access_token);
  assert.equal(accessInfo.extra.email, "admin@example.test");
  assert.deepEqual(accessInfo.scopes, ["mcp:read", "mcp:admin"]);

  await assert.rejects(() => auth.challengeForAuthorizationCode(client, rawCode), /already used/i);
  await assert.rejects(() => auth.verifyAccessToken(tokens.access_token), /invalid|expired/i);

  const secondCodeReq = { method: "POST", headers: { cookie }, body: { action: "approve", csrf: session.csrf_token } };
  const secondCodeRes = mockResponse(secondCodeReq);
  await auth.authorize(client, params, secondCodeRes);
  const secondCode = new URL(secondCodeRes.redirectUrl).searchParams.get("code");
  const secondPair = await auth.exchangeAuthorizationCode(client, secondCode, undefined, params.redirectUri, params.resource);
  const rotated = await auth.exchangeRefreshToken(client, secondPair.refresh_token, undefined, params.resource);
  assert.ok(rotated.refresh_token);
  await assert.rejects(() => auth.exchangeRefreshToken(client, secondPair.refresh_token, undefined, params.resource), /reuse/i);
  await assert.rejects(() => auth.verifyAccessToken(rotated.access_token), /invalid|expired/i);

  const pat = auth.createPat(admin.id, "Codex", ["mcp:read", "mcp:admin"]);
  const patInfo = await auth.verifyAccessToken(pat.token);
  assert.equal(patInfo.extra.auth_type, "pat");
  auth.setUserStatus(admin.id, "disabled");
  await assert.rejects(() => auth.verifyAccessToken(pat.token), /invalid|disabled|unavailable/i);

  console.log(JSON.stringify({
    passwordHashingWorked: true,
    redirectAllowlistWorked: true,
    loopbackRedirectWorked: true,
    loginAndConsentWorked: true,
    authorizationCodeSingleUseWorked: true,
    refreshRotationAndReuseRevocationWorked: true,
    patWorked: true,
    disabledUserInvalidatedTokens: true,
  }, null, 2));
} finally {
  auth.close();
}


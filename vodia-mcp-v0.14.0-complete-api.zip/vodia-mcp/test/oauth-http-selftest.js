import assert from "node:assert/strict";
import { createHash, randomBytes } from "node:crypto";
import { spawn } from "node:child_process";
import { mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { AuthService } from "../auth.js";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StreamableHTTPClientTransport } from "@modelcontextprotocol/sdk/client/streamableHttp.js";

const directory = mkdtempSync(join(tmpdir(), "vodia-oauth-http-"));
const dbPath = join(directory, "auth.db");
const port = 3198;
const base = `http://127.0.0.1:${port}`;
const password = "correct horse battery staple";
const legacyToken = "b".repeat(64);
const config = {
  enabled: true, publicBase: base, dbPath, sessionSecret: "s".repeat(64), accessTtl: 3600,
  refreshTtl: 2592000, codeTtl: 120, sessionTtl: 43200, allowLoopback: true,
  allowedRedirects: new Set(["https://claude.ai/api/mcp/auth_callback"]), legacyEnabled: true, trustProxy: true,
};
const seed = new AuthService(config);
const user = seed.createUser({ email: "admin@example.test", displayName: "Admin", password, role: "admin" });
seed.close();

const child = spawn(process.execPath, ["http.js"], {
  cwd: new URL("..", import.meta.url).pathname,
  env: {
    ...process.env,
    VODIA_URL: "https://pbx.example.test",
    VODIA_USER: "test",
    VODIA_PASS: "test",
    ADMIN_TOKEN: "a".repeat(64),
    MCP_BEARER_TOKEN: legacyToken,
    MCP_ADMIN_BEARER_TOKEN: "c".repeat(64),
    MCP_APPROVER_BEARER_TOKEN: "d".repeat(64),
    PUBLIC_BASE_URL: base,
    SESSION_SECRET: "s".repeat(64),
    DB_PATH: dbPath,
    HOST: "127.0.0.1",
    PORT: String(port),
  },
  stdio: ["ignore", "pipe", "pipe"],
});
let childErrors = "";
child.stderr.on("data", (chunk) => { childErrors += chunk; });

async function waitForServer() {
  for (let attempt = 0; attempt < 50; attempt += 1) {
    try {
      const response = await fetch(`${base}/health`);
      if (response.ok) return;
    } catch {}
    await new Promise((resolve) => setTimeout(resolve, 50));
  }
  throw new Error(`OAuth HTTP test server did not start: ${childErrors}`);
}

function authorizationFields(clientId, verifier) {
  return {
    response_type: "code",
    client_id: clientId,
    redirect_uri: "https://claude.ai/api/mcp/auth_callback",
    code_challenge: createHash("sha256").update(verifier).digest("base64url"),
    code_challenge_method: "S256",
    state: "test-state",
    scope: "mcp:read",
    resource: `${base}/mcp`,
  };
}

try {
  await waitForServer();
  const unauthorized = await fetch(`${base}/mcp`, { method: "POST" });
  assert.equal(unauthorized.status, 401);
  assert.match(unauthorized.headers.get("www-authenticate"), /oauth-protected-resource\/mcp/);

  for (const path of ["/.well-known/oauth-protected-resource", "/.well-known/oauth-protected-resource/mcp", "/.well-known/oauth-authorization-server"]) {
    const response = await fetch(`${base}${path}`);
    assert.equal(response.status, 200);
    assert.match(response.headers.get("content-type"), /json/);
  }

  const registration = await fetch(`${base}/register`, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ client_name: "Claude Test", redirect_uris: ["https://claude.ai/api/mcp/auth_callback"], token_endpoint_auth_method: "none", grant_types: ["authorization_code", "refresh_token"], response_types: ["code"] }),
  });
  assert.equal(registration.status, 201);
  const client = await registration.json();

  const evil = await fetch(`${base}/register`, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ client_name: "Evil", redirect_uris: ["https://evil.example/cb"], token_endpoint_auth_method: "none" }),
  });
  assert.equal(evil.status, 400);
  assert.equal((await evil.json()).error, "invalid_redirect_uri");

  const verifier = randomBytes(48).toString("base64url");
  const fields = authorizationFields(client.client_id, verifier);
  const loginPage = await fetch(`${base}/authorize?${new URLSearchParams(fields)}`, { redirect: "manual" });
  assert.equal(loginPage.status, 200);
  const cookie = loginPage.headers.get("set-cookie").split(";")[0];
  const html = await loginPage.text();
  const csrfMatch = html.match(/name="csrf" value="([^"]+)"/);
  assert.ok(csrfMatch, `Login page did not contain a CSRF token: ${html.slice(0, 3000)}`);
  const csrf = csrfMatch[1];

  const login = await fetch(`${base}/authorize`, {
    method: "POST", redirect: "manual", headers: { "Content-Type": "application/x-www-form-urlencoded", Cookie: cookie },
    body: new URLSearchParams({ ...fields, action: "login", csrf, email: "admin@example.test", password }),
  });
  assert.equal(login.status, 200);
  assert.match(await login.text(), /Authorize access/);

  const approve = await fetch(`${base}/authorize`, {
    method: "POST", redirect: "manual", headers: { "Content-Type": "application/x-www-form-urlencoded", Cookie: cookie },
    body: new URLSearchParams({ ...fields, action: "approve", csrf }),
  });
  assert.equal(approve.status, 302);
  const code = new URL(approve.headers.get("location")).searchParams.get("code");

  const wrongVerifier = await fetch(`${base}/token`, {
    method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ grant_type: "authorization_code", client_id: client.client_id, code, code_verifier: "wrong", redirect_uri: fields.redirect_uri, resource: fields.resource }),
  });
  assert.equal(wrongVerifier.status, 400);
  assert.equal((await wrongVerifier.json()).error, "invalid_grant");

  const exchange = await fetch(`${base}/token`, {
    method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ grant_type: "authorization_code", client_id: client.client_id, code, code_verifier: verifier, redirect_uri: fields.redirect_uri, resource: fields.resource }),
  });
  assert.equal(exchange.status, 200);
  const tokens = await exchange.json();

  const mcpClient = new Client({ name: "oauth-http-selftest", version: "1.0.0" });
  const transport = new StreamableHTTPClientTransport(new URL(`${base}/mcp`), { requestInit: { headers: { Authorization: `Bearer ${tokens.access_token}` } } });
  await mcpClient.connect(transport);
  const tools = await mcpClient.listTools();
  assert.ok(tools.tools.some((tool) => tool.name === "get_system_status"));
  await mcpClient.close();

  const refresh = await fetch(`${base}/token`, {
    method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ grant_type: "refresh_token", client_id: client.client_id, refresh_token: tokens.refresh_token, resource: fields.resource }),
  });
  assert.equal(refresh.status, 200);
  const rotated = await refresh.json();
  assert.ok(rotated.refresh_token);
  const reuse = await fetch(`${base}/token`, {
    method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ grant_type: "refresh_token", client_id: client.client_id, refresh_token: tokens.refresh_token, resource: fields.resource }),
  });
  assert.equal(reuse.status, 400);

  const dashboardHeaders = { Authorization: `Bearer ${"a".repeat(64)}`, "Content-Type": "application/json" };
  const createViewer = await fetch(`${base}/api/auth/users`, {
    method: "POST", headers: dashboardHeaders,
    body: JSON.stringify({ email: "viewer@example.test", display_name: "Viewer", password: "viewer password long enough", role: "viewer" }),
  });
  assert.equal(createViewer.status, 201);
  const viewer = (await createViewer.json()).user;
  const createPat = await fetch(`${base}/api/auth/users/${viewer.id}/pats`, {
    method: "POST", headers: dashboardHeaders,
    body: JSON.stringify({ name: "Viewer Codex", scopes: ["mcp:read"] }),
  });
  assert.equal(createPat.status, 201);
  const patBody = await createPat.json();
  assert.match(patBody.pat.token, /^vodia_pat_/);
  const accessInventory = await fetch(`${base}/api/auth/users/${viewer.id}/apps`, { headers: dashboardHeaders });
  const accessBody = await accessInventory.json();
  assert.equal(accessBody.pats.length, 1);
  assert.equal(Object.hasOwn(accessBody.pats[0], "token"), false);

  const manager = new AuthService(config);
  manager.setUserStatus(user.id, "disabled");
  manager.close();
  const disabled = await fetch(`${base}/mcp`, { method: "POST", headers: { Authorization: `Bearer ${rotated.access_token}` } });
  assert.equal(disabled.status, 401);

  const legacyClient = new Client({ name: "legacy-http-selftest", version: "1.0.0" });
  const legacyTransport = new StreamableHTTPClientTransport(new URL(`${base}/mcp`), { requestInit: { headers: { Authorization: `Bearer ${legacyToken}` } } });
  await legacyClient.connect(legacyTransport);
  assert.ok((await legacyClient.listTools()).tools.length > 0);
  await legacyClient.close();

  const unknownClient = await fetch(`${base}/token`, {
    method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ grant_type: "refresh_token", client_id: "missing", refresh_token: "missing" }),
  });
  assert.equal(unknownClient.status, 401);

  console.log(JSON.stringify({
    oauthChallengeAdvertised: true,
    discoveryDocumentsWorked: true,
    dynamicRegistrationRestricted: true,
    browserLoginAndConsentWorked: true,
    pkceEnforced: true,
    oauthMcpToolsListed: true,
    refreshRotationWorked: true,
    disabledUserRejected: true,
    legacyMigrationTokenWorked: true,
    unknownClientReturns401: true,
    dashboardUserAndPatManagementWorked: true,
  }, null, 2));
} finally {
  child.kill("SIGTERM");
  await new Promise((resolve) => child.once("exit", resolve));
}

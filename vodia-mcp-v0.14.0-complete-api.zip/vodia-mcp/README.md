# Vodia PBX MCP 0.14.0 OAuth and User Identity release

Vodia MCP 0.14.0 adds individual user accounts and a built-in OAuth 2.1
authorization flow. It provides a read-only support endpoint, a policy-controlled
administrator endpoint, and a separate supervised-learning approver endpoint
for Vodia PBX 70.x. The API
catalog is generated from the official Vodia REST API 70.3 schema.

## OAuth and user identity

When `PUBLIC_BASE_URL` and a 32-byte-or-longer `SESSION_SECRET` are configured,
the service publishes OAuth discovery metadata and supports Authorization Code
with PKCE, dynamic public-client registration, rotating refresh tokens,
revocation, individual users, roles, connected apps and personal access tokens.

| Endpoint | OAuth scope | Minimum role |
| --- | --- | --- |
| `/mcp` | `mcp:read` | viewer |
| `/mcp-admin` | `mcp:admin` | admin |
| `/mcp-approver` | `mcp:approve` | approver or admin |

OAuth does not bypass the plan/confirm/apply gate or any tenant, operation,
destructive or critical-write policy. Static bearer tokens continue to work
while `LEGACY_STATIC_TOKEN_ENABLED=true`.

Create or manage users from `/admin/` or with the CLI:

```bash
sudo -u vodiamcp env \
  DB_PATH=/var/lib/vodia-mcp/auth.db \
  VODIA_BOOTSTRAP_PASSWORD='replace-with-a-long-password' \
  node /opt/vodia-mcp/auth-cli.js create-admin \
  --email admin@example.com --name 'PBX Administrator'
```

Add the read-only connector to Claude Code and complete browser login:

```bash
claude mcp add --transport http vodia https://mcp.example.com/mcp
```

## Included

- Read-only MCP endpoint: `/mcp`
- Full-administrator MCP endpoint: `/mcp-admin`
- 301 catalog operations in the v0.13.2 baseline: 202 GET, 63 POST, 3 PUT and 33 DELETE
- Direct access to all 188 JSON-safe GET operations through the read endpoint
- Full-admin access to all 285 directly callable operations, plus bounded
  base64 access to 9 documented binary GET resources (294 of 301 total)
- First-class per-account and tenant-wide live-call enumeration
- Live PBX vendor/model discovery and guarded MAC-address provisioning
- Typed planners for account creation/update/deletion, SIP-trunk update,
  enable/disable and deletion, dial-plan creation/update/deletion, and tenant settings
- Live-call hangup, reject, blind-transfer, hold, resume and answer planners
- Call-ID-aware live-state validation that ignores volatile call timestamps
- Generic plan/apply access to allowed operations in the generated catalog
- Per-operation schema/example inspection through inspect_vodia_operation
- Guarded full-profile phone-button reads and replacement plans
- Tenant DID listing and conflict-checked DID assignment plans
- All-tenant inventory and cross-tenant extension search
- CDR, log, registration, statistics, audit and dropped-call diagnostics
- Tenant-validated PCAP retrieval with redacted SIP-dialog parsing and a
  protected binary-download endpoint
- Expiring, immutable, single-use write plans and persistent JSONL auditing
- Persistent supervised learning for reviewed portal operations
- Separate teacher and approver identities; a teacher cannot approve its own lesson
- Dynamic learning permanently rejects DELETE, destructive-looking operations,
  arbitrary URLs, traversal and system-level writes

## Administration model

`VODIA_ADMIN_PROFILE` controls the write surface:

| Profile | Access |
|---|---|
| `diagnostic` | Dedicated diagnostic wrappers only |
| `operator` | Standard configuration writes |
| `full` | Standard and elevated administration writes |

The installer selects `full`. Ordinary create, update, rename, enable/disable,
and settings operations are therefore available. Permanent deletion and
critical system-level writes remain independent break-glass capabilities:

| Operation tier | Extra switch | Exact apply confirmation |
|---|---|---|
| Standard/elevated | None with `full` profile | Operation and tenant-specific phrase |
| Destructive DELETE | `VODIA_ENABLE_DESTRUCTIVE=true` | `DELETE <operation> ON <target>` |
| Critical system write | `VODIA_ENABLE_CRITICAL_WRITES=true` | `APPLY-CRITICAL <operation> ON SYSTEM` |
| Critical DELETE | Both switches | `DELETE-CRITICAL <operation> ON <target>` |

Every write requires two MCP calls. `plan_vodia_change` or a typed planner
validates the request and returns an expiring change ID, request hash and exact
confirmation. `apply_vodia_change` accepts only that unchanged plan and exact
confirmation. Plans expire after five minutes by default and can be used once.
Live-call plans expire after one minute and require an action-specific phrase,
such as `HANGUP <call-id>`.

## SIP trunk boundary

The Vodia API 70.3 schema documents listing, reading, renaming/updating,
enabling/disabling and deleting existing SIP trunks. It does not document a
create-SIP-trunk REST operation. This connector intentionally does not invent
an unsupported endpoint. Use the PBX web interface to create a trunk, then use
MCP to manage it, or regenerate the catalog when Vodia publishes a creation
operation.

## Requirements

- Ubuntu or Debian connector server
- Node.js 22.13 or newer
- Vodia PBX 70.x and a dedicated system-administrator API account
- HTTPS DNS name for the connector; TCP 80 and 443 open to Caddy
- Codex on macOS, Windows, or Linux

Port 3100 listens only on localhost and must not be exposed publicly.

## Install

See [TESTING-GUIDE.md](TESTING-GUIDE.md) for installation, macOS Keychain and
Codex setup, acceptance tests, break-glass controls, and rollback.

The installer stores the generated endpoint tokens in the root-only file:

```text
/root/vodia-mcp-credentials.txt
```

## Codex endpoints

| Endpoint | Purpose | Local token variable |
|---|---|---|
| `/mcp` | Strictly read-only support | `VODIA_MCP_TOKEN` |
| `/mcp-admin` | Planned administrator changes | `VODIA_MCP_ADMIN_TOKEN` |
| `/mcp-approver` | Independent learning review and approval | `VODIA_MCP_APPROVER_TOKEN` |
| `/health` | Non-sensitive health check | None |
| `/admin/` | Connector dashboard | Dashboard administrator token |
| `/api/pcap/{call-id}?domain=...` | Protected binary PCAP download | Dashboard administrator token |

Keep `default_tools_approval_mode = "writes"` on the administrator endpoint.

## High-value tools

- Read/support: `list_domains`, `list_accounts`, `list_extensions`,
  `find_extension_across_tenants`, `list_registrations`,
  `get_extension_registration_history`, `get_tenant_cdrs`,
  `troubleshoot_dropped_call`, `get_call_sip_trace`
- Typed administration: `plan_create_account`, `plan_update_account`,
  `plan_update_sip_trunk`, `plan_set_sip_trunk_enabled`,
  `plan_create_dial_plan`, `plan_update_dial_plan`, `plan_delete_dial_plan`,
  `plan_update_tenant_settings`,
  `plan_delete_account`, `plan_delete_sip_trunk`
- Live calls: `plan_hangup_call`, `plan_reject_call`, `plan_transfer_call`,
  `plan_hold_call`, `plan_resume_call`, `plan_answer_call`,
  `get_account_live_calls`, `list_tenant_live_calls`
- Catalog administration: `find_api_capabilities`, `read_vodia_api`,
  `read_vodia_binary`, `plan_vodia_change`, `apply_vodia_change`
- Phone provisioning: `list_supported_phone_models`, `plan_provision_mac`,
  `get_extension_buttons`, `plan_set_extension_buttons`
- DID management: `list_tenant_dids`, `plan_assign_did`
- Supervised learning: `propose_learned_operation`, `test_learned_read`,
  `run_learned_read`, `plan_learned_write`, `disable_learned_operation`
- Independent approval: `list_learning_proposals`,
  `inspect_learning_proposal`, `approve_learned_operation`

## Supervised teaching workflow

Teaching does not retrain Codex and it does not execute a captured request. It
stores a narrowly validated operation definition plus sanitized evidence in
`/var/lib/vodia-mcp/learned-operations.json`. A normal workflow is:

1. Observe a successful administrator-portal request and sanitize the evidence.
2. Use `propose_learned_operation` on `/mcp-admin`.
3. For GET lessons, use `test_learned_read` with a safe tenant target.
4. Review and approve through the separately-tokened `/mcp-approver` endpoint.
5. Use `run_learned_read`, or use `plan_learned_write` followed by the existing
   `apply_vodia_change` confirmation flow.

The teacher identity cannot approve its own proposal. Learned DELETE operations
are always rejected, even when catalogued destructive operations have been
enabled separately. Disabling a lesson preserves its evidence and audit trail.
Do not configure the approver token in the normal teacher/administrator Codex
process. Use `codex_approver_config.example.toml` in a separate human-review
profile; possession of both endpoint tokens defeats role separation.

## Phone provisioning workflow

`list_supported_phone_models` reads the same live catalog used by the Vodia
tenant GUI (`GET /rest/domain/{domain}/button_templates?id=all`).
`plan_provision_mac` requires a MAC address, extension, vendor, model, proposed
SIP transport (`Default`, `TLS`, `TCP`, or `UDP`), T.38 mode (`Default`, `On`,
or `Off`), and refresh behavior (`Automatic`, `No`, or `Yes`). It
normalizes the MAC, confirms the extension exists, canonicalizes vendor/model
capitalization against that live catalog, and rejects unsupported combinations
or missing GUI choices before creating a write plan. Applying the plan posts the complete provisioning
payload to `/rest/domain/{domain}/macs` and performs a targeted verification
read. Newly supported PBX models therefore do not require a connector release.

For Yealink devices, `serial_number` is also mandatory. Supply the full serial
number printed on the device, not only the last five digits used by some legacy
handsets as an on-screen challenge. Vodia PBX 69.5.16+ uses Yealink RPS API V2
and transmits this value in the API's legacy `pin` field. The connector keeps
the administrator-facing name clear and redacts the mapped value from plan
previews, tool responses, and audit records. Do not supply `serial_number` for
other vendors in this workflow.

### Provisioned-device actions

Vodia MCP 0.13.2 adds verified tenant-MAC operations observed on PBX 70.5:

- `get_mac_provisioning_history(domain, mac)` reads generated-file history.
- `plan_trigger_mac_provisioning(domain, mac, reason)` prepares CHECK-SYNC with
  `reboot=false`.
- `plan_trigger_mac_reboot(domain, mac, reason)` prepares CHECK-SYNC with
  `reboot=true` and warns that active calls may be interrupted.
- `plan_clear_mac_provisioning_history(domain, mac, reason)` prepares
  `generated?reset=1`; it does not remove the phone or extension.

Each action validates that the normalized MAC exists in the requested tenant.
The three action tools only create plans. `apply_vodia_change` requires the
exact per-device confirmation returned by the plan. Provisioning history may
contain HTTP authorization headers from phone downloads; Basic, Bearer and
Digest credentials are redacted from tool responses and audit records.

The only operations intentionally unavailable are seven documented private or
arbitrary server endpoints (`syncrpc`, raw HTTP, arbitrary page/template reads,
and text editing). They are not normal administrator-portal operations and can
execute or retrieve unbounded server content.

Raw arbitrary URLs are never accepted. Operations must exist in the generated
catalog, pass tenant validation and policy checks, and satisfy request limits.

## Security boundary

The two MCP endpoints use different bearer tokens. The administrator token maps
to `MCP_ADMIN_ACTOR` for auditing; this release does not yet implement per-human
OAuth 2.1 identity. Use a dedicated PBX API account, protect the administrator
token, retain human approval for writes, and rotate tokens after a test.

Secrets are recursively redacted from plans, results and audit records. SIP
authentication headers are also redacted. `VODIA_ALLOWED_DOMAINS` can restrict
the connector to named tenants; leave it blank only for intended system-wide
administration.

## Environment variables

| Variable | Purpose |
|---|---|
| `VODIA_URL` | HTTPS PBX base URL |
| `VODIA_USER` / `VODIA_PASS` | Dedicated PBX API account |
| `VODIA_ALLOWED_DOMAINS` | Optional comma-separated tenant allowlist |
| `MCP_BEARER_TOKEN` | Read endpoint token |
| `MCP_ADMIN_BEARER_TOKEN` | Administrator endpoint token |
| `MCP_ADMIN_ACTOR` | Administrator audit identity |
| `MCP_APPROVER_BEARER_TOKEN` | Separate learning-approver endpoint token |
| `MCP_APPROVER_ACTOR` | Independent approver audit identity |
| `VODIA_ADMIN_PROFILE` | `diagnostic`, `operator`, or `full` |
| `VODIA_ENABLE_DESTRUCTIVE` | Permit DELETE operations; default `false` |
| `VODIA_ENABLE_CRITICAL_WRITES` | Permit critical system writes; default `false` |
| `VODIA_ALLOWED_WRITE_OPERATIONS` | Optional comma-separated operation-ID allowlist |
| `VODIA_BLOCKED_WRITE_OPERATIONS` | Optional comma-separated operation-ID denylist |
| `VODIA_MAX_WRITE_BODY_BYTES` | Maximum serialized write body; default 262144 |
| `VODIA_CHANGE_PLAN_TTL_MS` | Plan lifetime; default 300000 |
| `VODIA_PCAP_LIMIT_BYTES` | Maximum PCAP download; default 20000000 |
| `VODIA_AUDIT_LOG` | Persistent JSONL audit path |
| `VODIA_LEARNING_STORE` | Persistent learned-operation store path |

## Download a retained PCAP

Use the dashboard administrator token, not either MCP bearer token:

```bash
curl -fsS \
  -H "Authorization: Bearer $ADMIN_TOKEN" \
  -o call.pcap \
  "https://YOUR-MCP-DOMAIN/api/pcap/CALL-ID?domain=TENANT-DOMAIN"
```

The connector first verifies that the call ID belongs to the requested tenant,
enforces `VODIA_PCAP_LIMIT_BYTES`, disables caching and audits the download.

## Local verification

```bash
npm ci
npm run check
npm test
npm audit --omit=dev --audit-level=high
```

Regenerate the catalog after reviewing a new Vodia API schema:

```bash
npm run generate:catalog
```

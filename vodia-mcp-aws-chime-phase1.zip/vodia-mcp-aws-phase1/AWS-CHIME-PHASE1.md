# Amazon Chime SDK Voice integration — Phase 1

This phase adds read-only AWS connectivity to the existing Vodia MCP.

## Authentication

No AWS access key or secret is stored by the connector. The AWS SDK v3 default
credential provider chain is used. For an MCP running on EC2, attach an IAM
instance role to the EC2 instance.

## MCP tools

- `aws_chime_test_connection` — calls STS GetCallerIdentity and Chime SDK Voice ListVoiceConnectors.
- `aws_chime_list_voice_connectors` — lists Voice Connectors in the selected region.
- `aws_chime_get_voice_connector` — reads one Voice Connector.

All three tools are read-only. No Voice Connector, phone number, route, credential,
or PBX configuration is created or changed in Phase 1.

## Required npm packages

```bash
npm install @aws-sdk/client-sts @aws-sdk/client-chime-sdk-voice
```

## Minimal IAM permissions for the Phase 1 test

The EC2 role needs permission to list and read Chime SDK Voice Connectors. STS
`GetCallerIdentity` does not require an explicit allow in the usual case.

Start with a narrowly scoped policy for the test, then refine it before adding
write operations in Phase 2.

## Test prompt

After attaching the EC2 IAM role and restarting the MCP, ask the MCP:

> Test the Amazon Chime SDK Voice connection in us-east-1.

Then:

> List my Amazon Chime Voice Connectors in us-east-1.

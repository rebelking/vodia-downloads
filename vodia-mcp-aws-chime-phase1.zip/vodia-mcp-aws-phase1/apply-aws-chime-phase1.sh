#!/usr/bin/env bash
set -Eeuo pipefail

APP_DIR="${VODIA_MCP_APP_DIR:-/opt/vodia-mcp}"
SERVICE="${VODIA_MCP_SERVICE:-vodia-mcp}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STAMP="$(date +%Y%m%d-%H%M%S)"

[[ ${EUID} -eq 0 ]] || { echo "Run with sudo: sudo bash apply-aws-chime-phase1.sh"; exit 1; }
[[ -f "$APP_DIR/index.js" ]] || { echo "Vodia MCP index.js not found at $APP_DIR/index.js"; exit 1; }
[[ -f "$HERE/index.js" && -f "$HERE/aws-chime.js" ]] || { echo "Patch files are missing."; exit 1; }

BACKUP="/var/backups/vodia-mcp-aws-phase1-$STAMP"
mkdir -p "$BACKUP"
cp -a "$APP_DIR/index.js" "$BACKUP/index.js"
[[ -f "$APP_DIR/aws-chime.js" ]] && cp -a "$APP_DIR/aws-chime.js" "$BACKUP/aws-chime.js"

echo "[1/5] Installing AWS SDK v3 Chime Voice + STS clients..."
cd "$APP_DIR"
npm install --omit=dev --no-save @aws-sdk/client-chime-sdk-voice @aws-sdk/client-sts

echo "[2/5] Installing Phase 1 source files..."
install -m 0644 "$HERE/aws-chime.js" "$APP_DIR/aws-chime.js"
install -m 0755 "$HERE/index.js" "$APP_DIR/index.js"

echo "[3/5] Syntax checks..."
node --check "$APP_DIR/aws-chime.js"
node --check "$APP_DIR/index.js"

echo "[4/5] Restarting $SERVICE..."
systemctl restart "$SERVICE"
systemctl is-active --quiet "$SERVICE"

echo "[5/5] Complete. Backup: $BACKUP"
echo
cat <<'MSG'
Next:
1. Attach an IAM role to this EC2 instance with the Phase 1 read-only Chime permissions.
2. Optional: add AWS_CHIME_REGION="us-east-1" (or your chosen region) to /etc/vodia-mcp.env.
3. Restart: sudo systemctl restart vodia-mcp
4. Ask the MCP: "Test the Amazon Chime SDK Voice connection."
MSG

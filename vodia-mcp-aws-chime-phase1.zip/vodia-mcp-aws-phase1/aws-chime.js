import {
  ChimeSDKVoiceClient,
  ListVoiceConnectorsCommand,
  GetVoiceConnectorCommand,
} from "@aws-sdk/client-chime-sdk-voice";
import { GetCallerIdentityCommand, STSClient } from "@aws-sdk/client-sts";

const DEFAULT_REGION = String(
  process.env.AWS_CHIME_REGION || process.env.AWS_REGION || process.env.AWS_DEFAULT_REGION || "us-east-1"
).trim();

const REGION_RE = /^[a-z]{2}(?:-gov)?-[a-z]+-\d$/;

function normalizeRegion(region) {
  const value = String(region || DEFAULT_REGION).trim();
  if (!REGION_RE.test(value)) throw new Error(`Invalid AWS region '${value}'.`);
  return value;
}

function clientOptions(region) {
  return {
    region: normalizeRegion(region),
    maxAttempts: 3,
  };
}

function awsError(error) {
  const name = String(error?.name || "AwsError");
  const message = String(error?.message || error || "Unknown AWS error");
  if (name === "CredentialsProviderError") {
    return new Error(
      "AWS credentials were not found. On EC2, attach an IAM instance profile/role to the MCP instance, then retry."
    );
  }
  if (name === "AccessDeniedException" || name === "AccessDenied" || name === "UnauthorizedOperation") {
    return new Error(`AWS access denied: ${message}`);
  }
  return new Error(`${name}: ${message}`);
}

export function getAwsChimeConfig() {
  return {
    defaultRegion: DEFAULT_REGION,
    credentialMode: "AWS SDK v3 default provider chain",
    explicitAccessKeysRequired: false,
  };
}

export async function testAwsChimeConnection({ region } = {}) {
  const selectedRegion = normalizeRegion(region);
  try {
    // No credentials are supplied here intentionally. The AWS SDK v3 default
    // provider chain resolves EC2 instance-profile credentials automatically.
    const sts = new STSClient(clientOptions(selectedRegion));
    const identity = await sts.send(new GetCallerIdentityCommand({}));

    const voice = new ChimeSDKVoiceClient(clientOptions(selectedRegion));
    const connectors = await voice.send(new ListVoiceConnectorsCommand({ MaxResults: 1 }));

    return {
      connected: true,
      region: selectedRegion,
      identity: {
        account: identity.Account || null,
        arn: identity.Arn || null,
        userId: identity.UserId || null,
      },
      chimeSdkVoice: {
        accessible: true,
        voiceConnectorCountSampled: Array.isArray(connectors.VoiceConnectors)
          ? connectors.VoiceConnectors.length
          : 0,
        hasMore: Boolean(connectors.NextToken),
      },
    };
  } catch (error) {
    throw awsError(error);
  }
}

export async function listAwsChimeVoiceConnectors({ region, maxResults = 20, nextToken } = {}) {
  const selectedRegion = normalizeRegion(region);
  const safeMax = Math.max(1, Math.min(Number(maxResults) || 20, 100));
  try {
    const voice = new ChimeSDKVoiceClient(clientOptions(selectedRegion));
    const response = await voice.send(
      new ListVoiceConnectorsCommand({
        MaxResults: safeMax,
        ...(nextToken ? { NextToken: String(nextToken) } : {}),
      })
    );
    return {
      region: selectedRegion,
      voiceConnectors: (response.VoiceConnectors || []).map((connector) => ({
        voiceConnectorId: connector.VoiceConnectorId || null,
        voiceConnectorArn: connector.VoiceConnectorArn || null,
        name: connector.Name || null,
        outboundHostName: connector.OutboundHostName || null,
        requireEncryption: Boolean(connector.RequireEncryption),
        awsRegion: connector.AwsRegion || selectedRegion,
        networkType: connector.NetworkType || null,
        createdTimestamp: connector.CreatedTimestamp?.toISOString?.() || connector.CreatedTimestamp || null,
        updatedTimestamp: connector.UpdatedTimestamp?.toISOString?.() || connector.UpdatedTimestamp || null,
      })),
      nextToken: response.NextToken || null,
    };
  } catch (error) {
    throw awsError(error);
  }
}

export async function getAwsChimeVoiceConnector({ voiceConnectorId, region } = {}) {
  const id = String(voiceConnectorId || "").trim();
  if (!id) throw new Error("voiceConnectorId is required.");
  const selectedRegion = normalizeRegion(region);
  try {
    const voice = new ChimeSDKVoiceClient(clientOptions(selectedRegion));
    const response = await voice.send(new GetVoiceConnectorCommand({ VoiceConnectorId: id }));
    const connector = response.VoiceConnector;
    return {
      region: selectedRegion,
      voiceConnector: connector
        ? {
            voiceConnectorId: connector.VoiceConnectorId || null,
            voiceConnectorArn: connector.VoiceConnectorArn || null,
            name: connector.Name || null,
            outboundHostName: connector.OutboundHostName || null,
            requireEncryption: Boolean(connector.RequireEncryption),
            awsRegion: connector.AwsRegion || selectedRegion,
            networkType: connector.NetworkType || null,
            createdTimestamp: connector.CreatedTimestamp?.toISOString?.() || connector.CreatedTimestamp || null,
            updatedTimestamp: connector.UpdatedTimestamp?.toISOString?.() || connector.UpdatedTimestamp || null,
          }
        : null,
    };
  } catch (error) {
    throw awsError(error);
  }
}

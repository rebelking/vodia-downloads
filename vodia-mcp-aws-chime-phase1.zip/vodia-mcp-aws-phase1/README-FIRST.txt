Vodia MCP Amazon Chime SDK Voice — Phase 1 TEST BUILD

This is a read-only test overlay for Vodia MCP v0.14.7.
It adds:
  - aws_chime_test_connection
  - aws_chime_list_voice_connectors
  - aws_chime_get_voice_connector

It intentionally does NOT create or modify Amazon Chime resources yet.

Install on the MCP EC2 server:
  unzip vodia-mcp-aws-chime-phase1.zip
  cd vodia-mcp-aws-phase1
  sudo bash apply-aws-chime-phase1.sh

AWS authentication:
  Attach an EC2 IAM role/instance profile. Do not paste AWS access keys into MCP config.

IAM policy:
  See aws-chime-phase1-readonly-policy.json

Then ask the MCP:
  Test the Amazon Chime SDK Voice connection in us-east-1.

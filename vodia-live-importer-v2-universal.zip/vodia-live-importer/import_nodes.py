import copy
import json
import os
import re
from collections import Counter

import requests


SENSITIVE_KEY = re.compile(
    r"pass|secret|token|auth|credential|private|cert|oauth|hash|pin|mac|"
    r"email|cell|mobile|address|web_hist|sip_hist",
    re.IGNORECASE,
)

ROUTING_KEY = re.compile(
    r"dest|target|agent|member|stage|hunt|queue|redirect|overflow|choice|"
    r"digit|direct|extension|mailbox|xfer|transfer|final|night|ring|ivr|"
    r"attendant|flag|orbit|page|conference|timeout|hour|schedule|name",
    re.IGNORECASE,
)

DISPLAY_KEY = re.compile(
    r"display|first_name|last_name|shortname|department|position|disabled|"
    r"dial_plan|language|lang_|timezone|tz|codec|moh|mailbox|vmail|hours_|"
    r"hunt|queue|acd|agent|member|redirect|overflow|destination|target|"
    r"timeout|ring|choice|digit|ivr|attendant|flag|orbit|conference|"
    r"schedule|prompt|greeting|caller|ani|did|alias|extension|number|name",
    re.IGNORECASE,
)

ACCOUNT_TYPES = {
    "extensions": "extension",
    "attendants": "auto_attendant",
    "conferences": "conference",
    "hunts": "ring_group",
    "acds": "call_queue",
    "orbits": "park_orbit",
    "hoots": "paging_group",
    "srvflags": "service_flag",
    "ivrnodes": "voice_agent",
    "callingcards": "calling_card",
    "colines": "shared_line",
}


def _first_string(record, keys):
    for key in keys:
        value = record.get(key)
        if isinstance(value, (str, int)) and str(value).strip():
            return str(value).strip()
        if isinstance(value, list) and value:
            candidate = value[0]
            if isinstance(candidate, (str, int)) and str(candidate).strip():
                return str(candidate).strip()
    return ""


def _account_number(record):
    return _first_string(
        record,
        (
            "account",
            "account_ext",
            "extension",
            "number",
            "alias",
            "id",
        ),
    )


def _display_name(record, fallback):
    return _first_string(
        record,
        ("display_name", "name", "label", "shortname", "description"),
    ) or fallback


def _safe_routing_settings(settings):
    safe = {}
    for key, value in settings.items():
        key_text = str(key)
        if SENSITIVE_KEY.search(key_text):
            continue
        if not ROUTING_KEY.search(key_text):
            continue
        if isinstance(value, (str, int, float, bool)) or value is None:
            safe[key_text] = value
        elif isinstance(value, list):
            safe[key_text] = value[:100]
        elif isinstance(value, dict):
            safe[key_text] = {
                str(k): v
                for k, v in list(value.items())[:100]
                if not SENSITIVE_KEY.search(str(k))
            }
    return safe


def _safe_display_settings(settings):
    """Keep useful PBX configuration fields while excluding secrets and PII."""
    safe = {}
    for key, value in settings.items():
        key_text = str(key)
        if SENSITIVE_KEY.search(key_text) or not DISPLAY_KEY.search(key_text):
            continue
        if isinstance(value, (str, int, float, bool)) or value is None:
            safe[key_text] = value
        elif isinstance(value, list):
            safe[key_text] = value[:100]
        elif isinstance(value, dict):
            safe[key_text] = {
                str(k): v
                for k, v in list(value.items())[:100]
                if not SENSITIVE_KEY.search(str(k))
            }
        if len(safe) >= 120:
            break
    return safe


def _tokens(value):
    if isinstance(value, dict):
        for nested in value.values():
            yield from _tokens(nested)
    elif isinstance(value, list):
        for nested in value:
            yield from _tokens(nested)
    elif value is not None:
        yield from re.findall(r"[A-Za-z0-9_+.*#-]+", str(value))


def _relations(accounts):
    known = {item["number"] for item in accounts}
    found = set()
    output = []

    for item in accounts:
        source = item["number"]
        for key, value in item.get("routing_settings", {}).items():
            if not ROUTING_KEY.search(key):
                continue
            for token in _tokens(value):
                if token == source or token not in known:
                    continue
                signature = (source, token, key)
                if signature in found:
                    continue
                found.add(signature)
                output.append(
                    {
                        "source": source,
                        "target": token,
                        "label": key,
                        "confidence": "heuristic",
                    }
                )
    return output


class VodiaTenantCanvasImporter:
    """Read a tenant through the REST API and return sanitized topology JSON."""

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "pbx_url": (
                    "STRING",
                    {"default": "https://pbx.example.com", "multiline": False},
                ),
                "tenant": (
                    "STRING",
                    {"default": "tenant.example.com", "multiline": False},
                ),
                "username": (
                    "STRING",
                    {"default": "", "multiline": False},
                ),
                "password_env": (
                    "STRING",
                    {"default": "VODIA_PBX_PASSWORD", "multiline": False},
                ),
                "verify_tls": (["true", "false"],),
                "include_account_settings": (["true", "false"],),
            }
        }

    RETURN_TYPES = ("STRING", "STRING")
    RETURN_NAMES = ("topology_json", "import_report")
    FUNCTION = "scan"
    OUTPUT_NODE = True
    CATEGORY = "Vodia PBX / Import"

    def scan(
        self,
        pbx_url,
        tenant,
        username,
        password_env,
        verify_tls,
        include_account_settings,
    ):
        password = os.environ.get(password_env)
        if not password:
            raise ValueError(
                f"Environment variable {password_env} is not set. "
                "Restart ComfyUI from the shell where it is exported."
            )

        base_url = pbx_url.rstrip("/")
        verify = verify_tls == "true"
        fetch_settings = include_account_settings == "true"
        session = requests.Session()
        session.auth = (username, password)
        session.headers.update({"Accept": "application/json"})

        accounts = []
        errors = []
        successful_lists = 0

        for api_type, normalized_type in ACCOUNT_TYPES.items():
            path = f"/rest/domain/{tenant}/userlist/{api_type}"
            try:
                response = session.get(
                    base_url + path,
                    timeout=30,
                    verify=verify,
                )
            except requests.RequestException as exc:
                errors.append(
                    {"source": api_type, "status": "ERROR", "detail": str(exc)}
                )
                continue

            if response.status_code != 200:
                errors.append(
                    {
                        "source": api_type,
                        "status": response.status_code,
                        "detail": response.reason,
                    }
                )
                continue

            successful_lists += 1
            try:
                payload = response.json()
            except ValueError:
                errors.append(
                    {"source": api_type, "status": 200, "detail": "Non-JSON response"}
                )
                continue

            rows = payload.get("accounts", []) if isinstance(payload, dict) else []
            if not isinstance(rows, list):
                errors.append(
                    {"source": api_type, "status": 200, "detail": "accounts is not a list"}
                )
                continue

            for row in rows:
                if not isinstance(row, dict):
                    continue
                number = _account_number(row)
                if not number:
                    continue
                accounts.append(
                    {
                        "id": f"{tenant}:{normalized_type}:{number}",
                        "number": number,
                        "account_type": normalized_type,
                        "display_name": _display_name(row, number),
                        "routing_settings": {},
                        "display_settings": {},
                    }
                )

        unique = {}
        for item in accounts:
            unique[(item["account_type"], item["number"])] = item
        accounts = list(unique.values())

        if fetch_settings:
            for item in accounts:
                path = f"/rest/domain/{tenant}/user_settings/{item['number']}"
                try:
                    response = session.get(
                        base_url + path,
                        timeout=30,
                        verify=verify,
                    )
                except requests.RequestException as exc:
                    errors.append(
                        {
                            "source": f"settings:{item['number']}",
                            "status": "ERROR",
                            "detail": str(exc),
                        }
                    )
                    continue

                if response.status_code != 200:
                    errors.append(
                        {
                            "source": f"settings:{item['number']}",
                            "status": response.status_code,
                            "detail": response.reason,
                        }
                    )
                    continue

                try:
                    settings = response.json()
                except ValueError:
                    continue
                if isinstance(settings, dict):
                    item["display_name"] = _display_name(
                        settings, item["display_name"]
                    )
                    item["routing_settings"] = _safe_routing_settings(settings)
                    item["display_settings"] = _safe_display_settings(settings)

        accounts.sort(key=lambda item: (item["account_type"], item["number"]))
        relations = _relations(accounts)
        type_counts = Counter(item["account_type"] for item in accounts)

        topology = {
            "schema": "vodia-topology-v1",
            "mode": "read_only",
            "pbx_changes_made": False,
            "pbx_url": base_url,
            "tenant": tenant,
            "accounts": accounts,
            "relations": relations,
            "warnings": errors,
        }
        topology_json = json.dumps(topology, separators=(",", ":"))

        report_object = {
            "status": "CONNECTED" if successful_lists else "FAILED",
            "tenant": tenant,
            "mode": "read_only",
            "pbx_changes_made": False,
            "account_count": len(accounts),
            "relation_count": len(relations),
            "counts": dict(sorted(type_counts.items())),
            "warning_count": len(errors),
            "canvas_action": "Use Create/Refresh PBX Account Nodes on the importer node",
        }
        report = json.dumps(report_object, indent=2)

        print("\n===== VODIA CANVAS IMPORT SCAN =====")
        print(report)
        print("===== NO PBX CHANGES MADE =====\n")

        return {
            "ui": {"vodia_topology": [topology_json], "import_report": [report]},
            "result": (topology_json, report),
        }


class VodiaImportedAccount:
    """A read-only visual account produced by the browser-side importer."""

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "account_type": ("STRING", {"default": "unknown"}),
                "account_number": ("STRING", {"default": ""}),
                "display_name": ("STRING", {"default": ""}),
                "relation_summary": (
                    "STRING",
                    {"default": "", "multiline": True},
                ),
            },
            "optional": {
                "call_flow": ("VODIA_FLOW",),
            },
        }

    RETURN_TYPES = ("VODIA_FLOW",)
    RETURN_NAMES = ("call_flow",)
    FUNCTION = "emit"
    CATEGORY = "Vodia PBX / Import"

    def emit(
        self,
        account_type,
        account_number,
        display_name,
        relation_summary,
        call_flow=None,
    ):
        flow = copy.deepcopy(call_flow) if isinstance(call_flow, dict) else {}
        flow.setdefault("imported_accounts", []).append(
            {
                "type": account_type,
                "number": account_number,
                "name": display_name,
                "relations": relation_summary,
            }
        )
        return (flow,)


class VodiaPBXAccount:
    """Universal visual representation of an existing or proposed PBX account."""

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "source_tenant": ("STRING", {"default": "tenant.example.com"}),
                "account_type": (
                    [
                        "extension",
                        "auto_attendant",
                        "ring_group",
                        "call_queue",
                        "park_orbit",
                        "service_flag",
                        "voice_agent",
                        "calling_card",
                        "conference",
                        "paging_group",
                        "shared_line",
                        "unknown",
                    ],
                ),
                "account_number": ("STRING", {"default": ""}),
                "display_name": ("STRING", {"default": ""}),
                "pbx_status": (
                    ["EXISTS", "NEW", "CHANGED", "CONFLICT", "STALE"],
                ),
                "desired_action": (["none", "create_if_missing", "review_changes"],),
                "settings_summary": (
                    "STRING",
                    {"default": "", "multiline": True},
                ),
                "relation_summary": (
                    "STRING",
                    {"default": "", "multiline": True},
                ),
            },
            "optional": {
                "linked_account": ("VODIA_ACCOUNT",),
            },
        }

    RETURN_TYPES = ("VODIA_ACCOUNT", "STRING")
    RETURN_NAMES = ("account", "account_json")
    FUNCTION = "emit"
    CATEGORY = "Vodia PBX / Accounts"

    def emit(
        self,
        source_tenant,
        account_type,
        account_number,
        display_name,
        pbx_status,
        desired_action,
        settings_summary,
        relation_summary,
        linked_account=None,
    ):
        account = {
            "schema": "vodia-account-v1",
            "tenant": source_tenant.strip(),
            "account_type": account_type,
            "number": account_number.strip(),
            "display_name": display_name.strip(),
            "pbx_status": pbx_status,
            "desired_action": desired_action,
            "settings_summary": settings_summary,
            "relation_summary": relation_summary,
            "pbx_changes_made": False,
        }
        if isinstance(linked_account, dict):
            account["linked_account"] = {
                "type": linked_account.get("account_type", "unknown"),
                "number": linked_account.get("number", ""),
            }
        return (account, json.dumps(account, indent=2))


NODE_CLASS_MAPPINGS = {
    "VodiaTenantCanvasImporter": VodiaTenantCanvasImporter,
    "VodiaImportedAccount": VodiaImportedAccount,
    "VodiaPBXAccount": VodiaPBXAccount,
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "VodiaTenantCanvasImporter": "Vodia Import Tenant to Canvas (Read Only)",
    "VodiaImportedAccount": "Vodia Imported Account (Read Only)",
    "VodiaPBXAccount": "Vodia PBX Account (Universal)",
}

import { app } from "../../scripts/app.js";

const TYPE_ORDER = [
    "service_flag",
    "auto_attendant",
    "voice_agent",
    "ring_group",
    "call_queue",
    "conference",
    "paging_group",
    "park_orbit",
    "calling_card",
    "shared_line",
    "extension",
    "unknown",
];

const TYPE_COLORS = {
    extension: "#304e6b",
    auto_attendant: "#75612d",
    ring_group: "#315e61",
    call_queue: "#315d36",
    conference: "#584476",
    paging_group: "#5e4931",
    park_orbit: "#5c3c52",
    service_flag: "#34375e",
    voice_agent: "#5b3d65",
    calling_card: "#5b4f34",
    shared_line: "#3d5757",
    unknown: "#5b3535",
};

function setWidget(node, name, value) {
    const widget = node.widgets?.find((item) => item.name === name);
    if (widget) {
        widget.value = value ?? "";
        widget.callback?.(widget.value);
    }
}

function importedNodes() {
    return (app.graph?._nodes || []).filter(
        (node) => node.type === "VodiaPBXAccount"
    );
}

function canvasStartX() {
    const nodes = app.graph?._nodes || [];
    if (!nodes.length) return 100;
    return Math.max(...nodes.map((node) => (node.pos?.[0] || 0) + (node.size?.[0] || 300))) + 300;
}

function friendlyType(value) {
    return String(value || "unknown")
        .replaceAll("_", " ")
        .replace(/\b\w/g, (letter) => letter.toUpperCase());
}

function settingsSummary(account) {
    const settings = account?.display_settings || {};
    const entries = Object.entries(settings).sort(([a], [b]) => a.localeCompare(b));
    if (!entries.length) return "No safe display settings returned.";
    return entries
        .slice(0, 120)
        .map(([key, value]) => {
            let rendered;
            if (typeof value === "string") rendered = value;
            else rendered = JSON.stringify(value);
            if (rendered.length > 500) rendered = `${rendered.slice(0, 500)}…`;
            return `${key}: ${rendered}`;
        })
        .join("\n")
        .slice(0, 16000);
}

function relationSummary(topology, number) {
    const outgoing = (topology.relations || [])
        .filter((edge) => String(edge.source) === String(number))
        .map((edge) => `OUT  ${edge.label} -> ${edge.target}`);
    const incoming = (topology.relations || [])
        .filter((edge) => String(edge.target) === String(number))
        .map((edge) => `IN   ${edge.source} -> ${edge.label}`);
    return [...outgoing, ...incoming].join("\n") || "No discovered account links.";
}

function createCanvas(topology) {
    if (!topology?.accounts || !Array.isArray(topology.accounts)) {
        alert("Run the Vodia tenant scan before creating canvas nodes.");
        return;
    }

    const tenant = topology.tenant || "tenant";
    const existing = new Map();
    for (const node of importedNodes()) {
        if (node.properties?.vodia_import_id) {
            existing.set(node.properties.vodia_import_id, node);
        }
    }

    const startX = canvasStartX();
    const columnWidth = 390;
    const rowHeight = 360;
    const columnsPerGroup = 4;
    const byNumber = new Map();
    const created = [];
    const seenIds = new Set();

    const accountsByType = new Map();
    for (const account of topology.accounts) {
        const type = account.account_type || "unknown";
        if (!accountsByType.has(type)) accountsByType.set(type, []);
        accountsByType.get(type).push(account);
    }

    let groupY = 100;
    const orderedTypes = [
        ...TYPE_ORDER.filter((type) => accountsByType.has(type)),
        ...[...accountsByType.keys()].filter((type) => !TYPE_ORDER.includes(type)),
    ];

    for (const type of orderedTypes) {
        const typeAccounts = accountsByType.get(type) || [];
        typeAccounts.sort((a, b) => String(a.number).localeCompare(String(b.number)));

        for (let index = 0; index < typeAccounts.length; index += 1) {
            const account = typeAccounts[index];
            const column = index % columnsPerGroup;
            const row = Math.floor(index / columnsPerGroup);
            seenIds.add(account.id);

            let node = existing.get(account.id);
            if (!node) {
                node = LiteGraph.createNode("VodiaPBXAccount");
                if (!node) {
                    alert("Vodia PBX Account node is unavailable. Restart ComfyUI.");
                    return;
                }
                app.graph.add(node);
                created.push(node);
            }

            node.properties ||= {};
            node.properties.vodia_import_id = account.id;
            node.properties.vodia_tenant = tenant;
            node.properties.vodia_account_number = account.number;
            node.properties.vodia_import_managed = true;
            node.pos = [startX + column * columnWidth, groupY + row * rowHeight];
            node.color = TYPE_COLORS[type] || TYPE_COLORS.unknown;
            node.bgcolor = node.color;
            node.title = `${friendlyType(type)} ${account.number} — EXISTS`;

            setWidget(node, "source_tenant", tenant);
            setWidget(node, "account_type", type);
            setWidget(node, "account_number", account.number);
            setWidget(node, "display_name", account.display_name || account.number);
            setWidget(node, "pbx_status", "EXISTS");
            setWidget(node, "desired_action", "none");
            setWidget(node, "settings_summary", settingsSummary(account));
            setWidget(node, "relation_summary", relationSummary(topology, account.number));
            node.setSize?.([350, 330]);
            byNumber.set(String(account.number), node);
        }

        const rowsUsed = Math.max(1, Math.ceil(typeAccounts.length / columnsPerGroup));
        groupY += rowsUsed * rowHeight + 180;
    }

    let staleCount = 0;
    for (const node of importedNodes()) {
        const id = node.properties?.vodia_import_id;
        if (
            node.properties?.vodia_tenant === tenant &&
            id &&
            !seenIds.has(id)
        ) {
            setWidget(node, "pbx_status", "STALE");
            node.title = `${node.title?.replace(/ — .+$/, "") || "Vodia Account"} — STALE`;
            staleCount += 1;
        }
    }

    for (const relation of topology.relations || []) {
        const source = byNumber.get(String(relation.source));
        const target = byNumber.get(String(relation.target));
        if (!source || !target || !source.outputs?.length || !target.inputs?.length) {
            continue;
        }
        const alreadyLinked = source.outputs[0].links?.some((linkId) => {
            const link = app.graph.links?.[linkId];
            return link?.target_id === target.id;
        });
        if (!alreadyLinked) source.connect(0, target, 0);
    }

    app.graph.setDirtyCanvas(true, true);
    app.canvas?.setDirty(true, true);
    alert(
        `Vodia import complete: ${topology.accounts.length} accounts, ` +
        `${(topology.relations || []).length} discovered links, ` +
        `${created.length} new canvas nodes, ${staleCount} stale nodes.`
    );
}

app.registerExtension({
    name: "VodiaPBX.LiveTenantImporter",

    async beforeRegisterNodeDef(nodeType, nodeData) {
        if (nodeData.name !== "VodiaTenantCanvasImporter") return;

        const originalCreated = nodeType.prototype.onNodeCreated;
        nodeType.prototype.onNodeCreated = function () {
            originalCreated?.apply(this, arguments);
            this.addWidget(
                "button",
                "Create/Refresh PBX Account Nodes",
                null,
                () => createCanvas(this._vodiaTopology)
            );
        };

        const originalExecuted = nodeType.prototype.onExecuted;
        nodeType.prototype.onExecuted = function (message) {
            originalExecuted?.apply(this, arguments);
            const raw = Array.isArray(message?.vodia_topology)
                ? message.vodia_topology[0]
                : message?.vodia_topology;
            if (!raw) return;
            try {
                this._vodiaTopology = typeof raw === "string" ? JSON.parse(raw) : raw;
                this.setDirtyCanvas(true, true);
            } catch (error) {
                console.error("Unable to parse Vodia topology", error);
            }
        };
    },
});

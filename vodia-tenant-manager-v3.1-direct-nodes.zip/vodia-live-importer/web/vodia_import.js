import { app } from "../../scripts/app.js";
import { api } from "../../scripts/api.js";

const TYPE_ORDER = [
    "service_flag", "auto_attendant", "voice_agent", "ring_group",
    "call_queue", "conference", "paging_group", "park_orbit",
    "calling_card", "shared_line", "extension", "unknown",
];

const TYPE_COLORS = {
    extension: "#304e6b", auto_attendant: "#75612d",
    ring_group: "#315e61", call_queue: "#315d36",
    conference: "#584476", paging_group: "#5e4931",
    park_orbit: "#5c3c52", service_flag: "#34375e",
    voice_agent: "#5b3d65", calling_card: "#5b4f34",
    shared_line: "#3d5757", unknown: "#5b3535",
};

const STATUS_COLORS = {
    EXISTS: "#285943",
    NEW: "#285a78",
    CHANGED: "#8a5a18",
    CONFLICT: "#8a2828",
    STALE: "#555555",
};

// Normal call-flow/account nodes that can also propose guarded PBX account
// creation.  This keeps the Universal node available as an advanced option,
// while allowing users to build with the familiar Vodia nodes directly.
const ACCOUNT_NODE_DEFINITIONS = {
    VodiaExtensionAccount: {
        account_type: "extension",
        number_widget: "account_number",
        name_widget: "display_name",
    },
    VodiaAutoAttendant: {
        account_type: "auto_attendant",
        number_widget: "auto_attendant_number",
        name_widget: "menu_name",
    },
    VodiaHuntGroup: {
        account_type: "ring_group",
        number_widget: "group_number",
        name_widget: "group_name",
    },
    VodiaACDQueue: {
        account_type: "call_queue",
        number_widget: "queue_number",
        name_widget: "queue_name",
    },
    VodiaParkOrbit: {
        account_type: "park_orbit",
        number_widget: "orbit_number",
        name_widget: "orbit_name",
    },
    VodiaServiceFlag: {
        account_type: "service_flag",
        number_widget: "service_flag_number",
        name_widget: "flag_name",
    },
    VodiaVoiceAgent: {
        account_type: "voice_agent",
        number_widget: "voice_agent_number",
        name_widget: "agent_name",
    },
    VodiaCallingCard: {
        account_type: "calling_card",
        number_widget: "calling_card_number",
        name_widget: "card_name",
    },
};

function widget(node, name) {
    return node.widgets?.find((item) => item.name === name);
}

function widgetValue(node, name) {
    return widget(node, name)?.value ?? "";
}

function setWidget(node, name, value) {
    const item = widget(node, name);
    if (!item) return;
    item.value = value ?? "";
    item.callback?.(item.value);
}

function importedNodes() {
    return (app.graph?._nodes || []).filter(
        (node) => node.type === "VodiaPBXAccount"
    );
}

function normalAccountNodes() {
    return (app.graph?._nodes || []).filter(
        (node) => Boolean(ACCOUNT_NODE_DEFINITIONS[node.type])
    );
}

function canvasStartX() {
    const nodes = app.graph?._nodes || [];
    if (!nodes.length) return 100;
    return Math.max(
        ...nodes.map((node) => (node.pos?.[0] || 0) + (node.size?.[0] || 300))
    ) + 300;
}

function friendlyType(value) {
    return String(value || "unknown")
        .replaceAll("_", " ")
        .replace(/\b\w/g, (letter) => letter.toUpperCase());
}

function settingsSummary(account) {
    const settings = account?.display_settings || {};
    const entries = Object.entries(settings).sort(([a], [b]) => a.localeCompare(b));
    if (!entries.length) return "No safe display settings returned.";
    return entries
        .slice(0, 120)
        .map(([key, value]) => {
            let rendered = typeof value === "string" ? value : JSON.stringify(value);
            if (rendered.length > 500) rendered = `${rendered.slice(0, 500)}…`;
            return `${key}: ${rendered}`;
        })
        .join("\n")
        .slice(0, 16000);
}

function relationSummary(topology, number) {
    const outgoing = (topology.relations || [])
        .filter((edge) => String(edge.source) === String(number))
        .map((edge) => `OUT  ${edge.label} -> ${edge.target}`);
    const incoming = (topology.relations || [])
        .filter((edge) => String(edge.target) === String(number))
        .map((edge) => `IN   ${edge.source} -> ${edge.label}`);
    return [...outgoing, ...incoming].join("\n") || "No discovered account links.";
}

function liveIdentity(account) {
    return {
        account_type: String(account.account_type || "unknown"),
        number: String(account.number || ""),
        display_name: String(account.display_name || account.number || ""),
    };
}

function desiredIdentity(node) {
    return {
        account_type: String(widgetValue(node, "account_type")),
        number: String(widgetValue(node, "account_number")).trim(),
        display_name: String(widgetValue(node, "display_name")).trim(),
    };
}

function normalNodeIdentity(node) {
    const definition = ACCOUNT_NODE_DEFINITIONS[node.type];
    if (!definition) return null;
    const number = String(widgetValue(node, definition.number_widget)).trim();
    const displayName = String(widgetValue(node, definition.name_widget)).trim();
    return {
        account_type: definition.account_type,
        number,
        display_name: displayName || number,
    };
}

function markNormalNode(node, status, detail, tenant) {
    const identity = normalNodeIdentity(node);
    if (!identity) return;
    node.properties ||= {};
    node.properties.vodia_target_tenant = tenant;
    node.properties.vodia_account_status = status;
    node.properties.vodia_compare_detail = detail;
    node.color = STATUS_COLORS[status] || TYPE_COLORS[identity.account_type];
    node.bgcolor = node.color;
}

function sameIdentity(left, right) {
    return left?.account_type === right?.account_type &&
        left?.number === right?.number &&
        left?.display_name === right?.display_name;
}

function setStatus(node, status, detail = "") {
    setWidget(node, "pbx_status", status);
    const type = widgetValue(node, "account_type") || "unknown";
    const number = widgetValue(node, "account_number") || "?";
    node.title = `${friendlyType(type)} ${number} — ${status}`;
    node.color = STATUS_COLORS[status] || TYPE_COLORS[type] || TYPE_COLORS.unknown;
    node.bgcolor = node.color;
    node.properties ||= {};
    node.properties.vodia_compare_detail = detail;
}

function topologyIndex(topology) {
    const index = new Map();
    for (const account of topology?.accounts || []) {
        index.set(`${account.account_type}:${account.number}`, account);
    }
    return index;
}

function compareNode(node, topology) {
    const tenant = topology.tenant || "";
    const desired = desiredIdentity(node);
    const live = topologyIndex(topology).get(
        `${desired.account_type}:${desired.number}`
    );
    const managed = Boolean(node.properties?.vodia_import_managed);
    const baseline = node.properties?.vodia_baseline;

    if (String(widgetValue(node, "source_tenant")) !== tenant) {
        return { status: "STALE", detail: "Node belongs to a different tenant." };
    }

    if (!live) {
        if (managed) {
            return { status: "STALE", detail: "Imported account is no longer present on the PBX." };
        }
        return { status: "NEW", detail: "Account does not exist on the live PBX." };
    }

    const currentLive = liveIdentity(live);
    if (!managed) {
        if (sameIdentity(desired, currentLive)) {
            return { status: "EXISTS", detail: "Account already exists and matches." };
        }
        return { status: "CONFLICT", detail: "Account number exists with different values." };
    }

    if (baseline && (
        desired.account_type !== baseline.account_type ||
        desired.number !== baseline.number
    )) {
        return {
            status: "CONFLICT",
            detail: "Existing account identity was changed. Add a new node instead of renaming an account number.",
        };
    }

    const localChanged = baseline ? !sameIdentity(desired, baseline) : false;
    const liveChanged = baseline ? !sameIdentity(currentLive, baseline) : false;
    if (localChanged && liveChanged && !sameIdentity(desired, currentLive)) {
        return {
            status: "CONFLICT",
            detail: "Both the canvas and PBX changed since import.",
        };
    }
    if (!sameIdentity(desired, currentLive)) {
        return { status: "CHANGED", detail: "Canvas values differ from the live PBX." };
    }
    return { status: "EXISTS", detail: "Canvas matches the live PBX." };
}

function compareCanvas(importer, showAlert = true) {
    const topology = importer._vodiaTopology;
    if (!topology?.accounts) {
        alert("Run the Vodia importer first, then import the PBX to the canvas.");
        return null;
    }

    const counts = { EXISTS: 0, NEW: 0, CHANGED: 0, CONFLICT: 0, STALE: 0 };
    const operations = [];
    const errors = [];
    for (const node of importedNodes()) {
        if (String(widgetValue(node, "source_tenant")) !== String(topology.tenant)) {
            continue;
        }
        const result = compareNode(node, topology);
        const desired = desiredIdentity(node);
        if (!desired.number) {
            const message = `Universal account node ${node.id} has a blank account number.`;
            errors.push(message);
            counts.CONFLICT += 1;
            setStatus(node, "CONFLICT", message);
            continue;
        }
        counts[result.status] += 1;
        setStatus(node, result.status, result.detail);
        if (result.status === "NEW") {
            setWidget(node, "desired_action", "create_if_missing");
            operations.push({
                action: "create_if_missing",
                account_type: desired.account_type,
                number: desired.number,
                display_name: desired.display_name,
            });
        } else if (result.status === "CHANGED") {
            setWidget(node, "desired_action", "review_changes");
        } else if (result.status === "EXISTS") {
            setWidget(node, "desired_action", "none");
        }
    }


    const liveByIdentity = topologyIndex(topology);
    const liveByNumber = new Map();
    for (const account of topology.accounts || []) {
        liveByNumber.set(String(account.number), account);
    }

    for (const node of normalAccountNodes()) {
        const desired = normalNodeIdentity(node);
        if (!desired?.number) {
            const message = `${friendlyType(desired?.account_type)} node ${node.id} has a blank account number.`;
            errors.push(message);
            counts.CONFLICT += 1;
            markNormalNode(node, "CONFLICT", message, topology.tenant);
            continue;
        }

        const exact = liveByIdentity.get(
            `${desired.account_type}:${desired.number}`
        );
        const numberCollision = liveByNumber.get(desired.number);

        if (!exact && numberCollision) {
            const message = `Account ${desired.number} already exists as ${friendlyType(numberCollision.account_type)}.`;
            errors.push(message);
            counts.CONFLICT += 1;
            markNormalNode(node, "CONFLICT", message, topology.tenant);
            continue;
        }

        if (!exact) {
            counts.NEW += 1;
            markNormalNode(
                node,
                "NEW",
                "Account does not exist on the live PBX and will be created.",
                topology.tenant
            );
            operations.push({
                action: "create_if_missing",
                account_type: desired.account_type,
                number: desired.number,
                display_name: desired.display_name,
                source_node_id: node.id,
                source_node_type: node.type,
            });
            continue;
        }

        const live = liveIdentity(exact);
        if (desired.display_name && desired.display_name !== live.display_name) {
            counts.CHANGED += 1;
            const message = `Account ${desired.number} exists, but its live display name differs. Updates remain disabled.`;
            markNormalNode(node, "CHANGED", message, topology.tenant);
        } else {
            counts.EXISTS += 1;
            markNormalNode(node, "EXISTS", "Account exists on the live PBX.", topology.tenant);
        }
    }


    // A Universal node and a normal Vodia node may describe the same account.
    // Keep one operation so the confirmation count is honest.
    const uniqueOperations = [];
    const operationKeys = new Set();
    for (const operation of operations) {
        const key = `${operation.account_type}:${operation.number}`;
        if (operationKeys.has(key)) continue;
        operationKeys.add(key);
        uniqueOperations.push(operation);
    }

    const plan = {
        schema: "vodia-change-plan-v1",
        tenant: topology.tenant,
        counts,
        operations: uniqueOperations,
        errors,
        updates_enabled: false,
        deletions_enabled: false,
    };
    importer._vodiaChangePlan = plan;
    app.graph.setDirtyCanvas(true, true);

    if (showAlert) {
        alert(
            `PBX comparison complete\n\n` +
            `Synced: ${counts.EXISTS}\n` +
            `New: ${counts.NEW}\n` +
            `Modified: ${counts.CHANGED}\n` +
            `Conflicts: ${counts.CONFLICT}\n` +
            `Stale: ${counts.STALE}\n\n` +
            (errors.length ? `Problems:\n${errors.slice(0, 8).join("\n")}\n\n` : "") +
            `Updates and deletions remain blocked.`
        );
    }
    return plan;
}

function createCanvas(importer) {
    const topology = importer._vodiaTopology;
    if (!topology?.accounts || !Array.isArray(topology.accounts)) {
        alert("Click the main ComfyUI Run button before importing PBX account nodes.");
        return;
    }

    const tenant = topology.tenant || "tenant";
    const existing = new Map();
    for (const node of importedNodes()) {
        if (node.properties?.vodia_import_id) {
            existing.set(node.properties.vodia_import_id, node);
        }
    }

    const startX = canvasStartX();
    const columnWidth = 390;
    const rowHeight = 360;
    const columnsPerGroup = 4;
    const byNumber = new Map();
    const created = [];
    const seenIds = new Set();
    const accountsByType = new Map();

    for (const account of topology.accounts) {
        const type = account.account_type || "unknown";
        if (!accountsByType.has(type)) accountsByType.set(type, []);
        accountsByType.get(type).push(account);
    }

    let groupY = 100;
    const orderedTypes = [
        ...TYPE_ORDER.filter((type) => accountsByType.has(type)),
        ...[...accountsByType.keys()].filter((type) => !TYPE_ORDER.includes(type)),
    ];

    for (const type of orderedTypes) {
        const typeAccounts = accountsByType.get(type) || [];
        typeAccounts.sort((a, b) => String(a.number).localeCompare(String(b.number)));

        for (let index = 0; index < typeAccounts.length; index += 1) {
            const account = typeAccounts[index];
            const column = index % columnsPerGroup;
            const row = Math.floor(index / columnsPerGroup);
            const currentLive = liveIdentity(account);
            seenIds.add(account.id);

            let node = existing.get(account.id);
            const isNewCanvasNode = !node;
            if (!node) {
                node = LiteGraph.createNode("VodiaPBXAccount");
                if (!node) {
                    alert("Vodia PBX Account node is unavailable. Restart ComfyUI.");
                    return;
                }
                app.graph.add(node);
                created.push(node);
            }

            node.properties ||= {};
            const oldBaseline = node.properties.vodia_baseline;
            const localChanged = oldBaseline
                ? !sameIdentity(desiredIdentity(node), oldBaseline)
                : false;

            node.properties.vodia_import_id = account.id;
            node.properties.vodia_tenant = tenant;
            node.properties.vodia_account_number = account.number;
            node.properties.vodia_import_managed = true;
            node.properties.vodia_live = currentLive;

            if (isNewCanvasNode || !localChanged) {
                setWidget(node, "source_tenant", tenant);
                setWidget(node, "account_type", type);
                setWidget(node, "account_number", account.number);
                setWidget(node, "display_name", account.display_name || account.number);
                node.properties.vodia_baseline = currentLive;
            }

            setWidget(node, "settings_summary", settingsSummary(account));
            setWidget(node, "relation_summary", relationSummary(topology, account.number));
            node.pos = [startX + column * columnWidth, groupY + row * rowHeight];
            node.setSize?.([350, 330]);
            byNumber.set(String(account.number), node);
        }

        const rowsUsed = Math.max(1, Math.ceil(typeAccounts.length / columnsPerGroup));
        groupY += rowsUsed * rowHeight + 180;
    }

    let staleCount = 0;
    for (const node of importedNodes()) {
        const id = node.properties?.vodia_import_id;
        if (node.properties?.vodia_tenant === tenant && id && !seenIds.has(id)) {
            setStatus(node, "STALE", "Imported account is not present in the latest scan.");
            staleCount += 1;
        }
    }

    for (const relation of topology.relations || []) {
        const source = byNumber.get(String(relation.source));
        const target = byNumber.get(String(relation.target));
        if (!source || !target || !source.outputs?.length || !target.inputs?.length) continue;
        const alreadyLinked = source.outputs[0].links?.some((linkId) => {
            const link = app.graph.links?.[linkId];
            return link?.target_id === target.id;
        });
        if (!alreadyLinked) source.connect(0, target, 0);
    }

    compareCanvas(importer, false);
    app.graph.setDirtyCanvas(true, true);
    app.canvas?.setDirty(true, true);
    alert(
        `PBX imported: ${topology.accounts.length} accounts, ` +
        `${(topology.relations || []).length} discovered links, ` +
        `${created.length} new canvas nodes, ${staleCount} stale nodes.`
    );
}

async function applyChanges(importer) {
    const plan = compareCanvas(importer, false);
    if (!plan) return;
    if (plan.counts.CONFLICT > 0) {
        alert(
            `Deployment blocked: resolve ${plan.counts.CONFLICT} problem(s) first.\n\n` +
            (plan.errors || []).slice(0, 10).join("\n")
        );
        return;
    }
    if (!plan.operations.length) {
        alert(
            "There are no missing accounts to create. " +
            "Modified-account updates are not enabled in this guarded version."
        );
        return;
    }

    const tenant = plan.tenant;
    const expected = `CREATE MISSING IN ${tenant}`;
    const confirmation = prompt(
        `This will CREATE ${plan.operations.length} missing PBX account(s).\n` +
        `It will not update or delete anything.\n\n` +
        `Type exactly:\n${expected}`
    );
    if (confirmation !== expected) {
        alert("Deployment cancelled: confirmation did not match.");
        return;
    }

    const response = await api.fetchApi("/vodia/pbx/apply-create-plan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            pbx_url: widgetValue(importer, "pbx_url"),
            tenant: widgetValue(importer, "tenant"),
            username: widgetValue(importer, "username"),
            password_env: widgetValue(importer, "password_env"),
            verify_tls: widgetValue(importer, "verify_tls") === "true",
            confirmation,
            operations: plan.operations,
        }),
    });
    const report = await response.json();
    if (!response.ok) {
        alert(`Deployment blocked:\n${report.error || response.statusText}`);
        return;
    }
    alert(
        `Guarded deployment finished\n\n` +
        `Created and verified: ${report.created}\n` +
        `Already existed: ${report.skipped_existing}\n` +
        `Unverified: ${report.unverified}\n\n` +
        `Run Import PBX again to refresh the canvas.`
    );
}

app.registerExtension({
    name: "VodiaPBX.TenantManagerV3",

    async beforeRegisterNodeDef(nodeType, nodeData) {
        if (nodeData.name !== "VodiaTenantCanvasImporter") return;

        const originalCreated = nodeType.prototype.onNodeCreated;
        nodeType.prototype.onNodeCreated = function () {
            originalCreated?.apply(this, arguments);
            this.addWidget("button", "1. Import PBX to Canvas", null, () => createCanvas(this));
            this.addWidget("button", "2. Check Changes", null, () => compareCanvas(this));
            this.addWidget("button", "3. Apply Changes (Guarded)", null, () => applyChanges(this));
            this.setSize?.([430, 420]);
        };

        const originalExecuted = nodeType.prototype.onExecuted;
        nodeType.prototype.onExecuted = function (message) {
            originalExecuted?.apply(this, arguments);
            const raw = Array.isArray(message?.vodia_topology)
                ? message.vodia_topology[0]
                : message?.vodia_topology;
            if (!raw) return;
            try {
                this._vodiaTopology = typeof raw === "string" ? JSON.parse(raw) : raw;
                this.setDirtyCanvas(true, true);
            } catch (error) {
                console.error("Unable to parse Vodia topology", error);
            }
        };
    },
});

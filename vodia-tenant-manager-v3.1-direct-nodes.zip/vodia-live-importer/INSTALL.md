# Vodia Tenant Manager v3.1

This package turns the live tenant importer into a simple three-action PBX
manager:

1. Import PBX to Canvas
2. Check Changes
3. Apply Changes (Guarded)

The importer reads existing Vodia accounts and creates universal account nodes.
The comparison engine marks nodes as `EXISTS`, `NEW`, `CHANGED`, `CONFLICT`, or
`STALE`. Canvas edits survive a refresh when they differ from the import
baseline.

Guarded deployment can only create missing account shells through:

```text
POST /rest/domain/{tenant}/addacc
```

It performs a pre-check, requires exact tenant confirmation, creates the
account, and verifies it with a read-back. Updates and deletions are blocked.

Version 3.1 also collects guarded creation proposals directly from these normal
canvas nodes:

- `Vodia Extension Account`
- `Vodia Auto Attendant`
- `Vodia Hunt Group`
- `Vodia ACD Queue`
- `Vodia Park Orbit`
- `Vodia Service Flag`
- `Vodia Voice Agent`
- `Vodia Calling Card`

`Vodia Inbound DID / Extension` remains a call-flow entry point and is not
treated as an extension account. This prevents an external DID from being
accidentally submitted to `/addacc`.

## Files

- `import_nodes.py`
- `web/vodia_import.js`

## Upgrade from v2

From `~/ComfyUI`, copy both files over the existing importer:

```bash
cp vodia-live-importer/import_nodes.py \
custom_nodes/ComfyUI-VodiaPBX/import_nodes.py

cp vodia-live-importer/web/vodia_import.js \
custom_nodes/ComfyUI-VodiaPBX/web/vodia_import.js
```

No `__init__.py` change is required when the v2 importer is already registered.

Compile before restarting:

```bash
source .venv/bin/activate
python -m py_compile \
  custom_nodes/ComfyUI-VodiaPBX/import_nodes.py \
  custom_nodes/ComfyUI-VodiaPBX/__init__.py
```

Start ComfyUI from a shell containing the password environment variable:

```bash
read -r -s -p "Vodia API password: " VODIA_PBX_PASSWORD
echo
export VODIA_PBX_PASSWORD
python main.py --cpu --listen 0.0.0.0
```

## Use

1. Add or reuse `Vodia Import Tenant to Canvas (Read Only)`.
2. Click the main ComfyUI **Run** button to retrieve the latest PBX state.
3. Click **1. Import PBX to Canvas**.
4. Add a normal supported Vodia node and enter its PBX account number, or use
   `Vodia PBX Account (Universal)` for advanced account types.
5. Click **2. Check Changes**.
6. Review the color/status summary.
7. Click **3. Apply Changes (Guarded)** only when creating missing accounts.
8. Type the exact tenant confirmation shown by the dialog.
9. Run the importer again to verify and refresh the canvas.

## Safety boundary

- Creates missing accounts only.
- Does not apply display-name or settings updates yet.
- Never deletes accounts.
- Skips an account if it appeared after the comparison.
- Stops on unexpected pre-check responses.
- Requires HTTPS and exact tenant confirmation.

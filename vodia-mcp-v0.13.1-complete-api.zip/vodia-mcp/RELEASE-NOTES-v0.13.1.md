# Vodia MCP 0.13.1

Vodia MCP 0.13.1 adds focused, tenant-safe Park Orbit inventory and live
occupancy tools for agent applications such as Vodia Flex.

## Added

- `list_park_orbits(domain, page, size)` reads
  `GET /rest/domain/{domain}/orbits`.
- `get_live_park_status(account)` reads
  `GET /rest/user/{account}/orbits`.
- Both tools normalize every orbit to `number`, `name`, `occupied`, and
  `calls`, while preserving the PBX call records after sensitive-field
  redaction.
- Regression coverage for available and occupied park-orbit states.

## Safety

- Both tools are GET-only and carry MCP `readOnlyHint: true`.
- Existing `VODIA_ALLOWED_DOMAINS` enforcement applies to both domain and
  `extension@domain` inputs.
- No call-control or PBX write capability was added.

## Upgrade

Use `upgrade-vodia-mcp-v0.13.1.sh`. The upgrade preserves the environment,
systemd service, audit configuration, supervised-learning state, and the
previous application directory for rollback.

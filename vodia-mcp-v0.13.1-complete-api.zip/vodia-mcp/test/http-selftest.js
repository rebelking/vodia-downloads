import http from "node:http";
import { spawn } from "node:child_process";
import { unlinkSync } from "node:fs";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StreamableHTTPClientTransport } from "@modelcontextprotocol/sdk/client/streamableHttp.js";

let pcapEnabled = false;
let createdAccount = null;
let trunkConfig = { id: "4", name: "Original trunk", proxy: "sip:old.example.com", reg_password: "must-redact" };
let dialPlans = [{ name: "Default", value: "1", inuse: true }];
let nextDialPlanId = 2;
let provisionedMacs = [];
const macWrites = [];
let buttonProfiles = [{
  address: "0004F2C785BE",
  name: "Extension 2033",
  template: "0",
  buttons: JSON.stringify({
    buttons: [{ number: "0", type: "private", sort: 1, group: 1, mode: "1", name: "P", identity: "", parameter: "", label: "2033", fixed: false, pickup: "" }],
    modes: { "1": ["none", "private", "extension", "park", "speed"] },
  }),
}];
let didState = {
  policy: "",
  numbers: [{ did: "+16175550100", name: "Test DID", user: "", ani: "", trunk: "1", areas: "+1" }],
};
let activeCallReads = 0;
let testEmails = 0;
let activeCalls = [
  { id: "live-call-1", from: "2010", to: "2009", state: "holding", now: 100 },
  { id: "live-call-2", from: "2011", to: "2009", state: "connected", now: 100 },
];
const callActions = [];
function testPcap() {
  const sip = Buffer.from("INVITE sip:2037@remote.example.com SIP/2.0\r\nCall-ID: call-1\r\nCSeq: 1 INVITE\r\nAuthorization: Digest hidden\r\nContent-Length: 0\r\n\r\n", "latin1");
  const globalHeader = Buffer.alloc(24);
  globalHeader.writeUInt32LE(0xa1b2c3d4, 0);
  globalHeader.writeUInt16LE(2, 4);
  globalHeader.writeUInt16LE(4, 6);
  globalHeader.writeUInt32LE(65535, 16);
  globalHeader.writeUInt32LE(1, 20);
  const record = Buffer.alloc(16);
  record.writeUInt32LE(1_786_200_000, 0);
  record.writeUInt32LE(sip.length, 8);
  record.writeUInt32LE(sip.length, 12);
  return Buffer.concat([globalHeader, record, sip]);
}

const mockPbx = http.createServer((request, response) => {
  response.setHeader("content-type", "application/json");
  const decodedUrl = decodeURIComponent(request.url);
  if (request.url === "/rest/system/status") {
    return response.end(JSON.stringify({ status: "ok", password: "must-redact" }));
  }
  if (request.url === "/rest/system/domains") {
    return response.end(JSON.stringify([{ name: "remote.example.com" }]));
  }
  if (request.url === "/rest/system/testemail" && request.method === "GET") {
    testEmails += 1;
    return response.end(JSON.stringify({ ok: true }));
  }
  if (request.url === "/rest/domain/remote.example.com/extensions" && request.method === "GET") {
    return response.end(JSON.stringify([{ name: "2009", usertype: "extensions" }]));
  }
  if (request.url === "/rest/domain/remote.example.com/widget?id=3" && request.method === "GET") {
    return response.end(JSON.stringify({ id: 3, enabled: true, learned: true }));
  }
  if (request.url === "/rest/domain/remote.example.com/button_templates?id=all" && request.method === "GET") {
    return response.end(JSON.stringify([
      { vendor: "Polycom", model: ["Edge-E100", "VVX450", "VVX601"] },
      { vendor: "Unify", model: ["CP100", "CP110", "CP710"] },
      { vendor: "Shandong", model: ["Hotel Phone"] },
      { vendor: "snom", model: ["D375"] },
      { vendor: "Yealink", model: ["T73U", "T54W"] },
      { vendor: "Fanvil", model: ["V64", "V66Pro"] },
    ]));
  }
  if (request.url === "/rest/domain/remote.example.com/user_settings/2009" && request.method === "GET") {
    return response.end(JSON.stringify({ extension: "2009", display: "Provisioning Test" }));
  }
  if (request.url === "/rest/domain/remote.example.com/user_settings/2033" && request.method === "GET") {
    return response.end(JSON.stringify({ extension: "2033", display: "Button Test" }));
  }
  if (request.url?.startsWith("/rest/domain/remote.example.com/macs?adr=") && request.method === "GET") {
    const mac = new URL(request.url, "http://mock.invalid").searchParams.get("adr");
    return response.end(JSON.stringify(provisionedMacs.filter((entry) => entry.mac === mac)));
  }
  if (request.url === "/rest/system/prov_phones" && request.method === "GET") {
    return response.end(JSON.stringify(provisionedMacs));
  }
  if (request.url === "/rest/system/prov_phones" && request.method === "POST") {
    let body = "";
    request.on("data", (chunk) => { body += chunk; });
    return request.on("end", () => {
      const input = JSON.parse(body);
      macWrites.push(input);
      provisionedMacs = [...provisionedMacs.filter((entry) => entry.mac !== input.mac), input];
      response.end(JSON.stringify(true));
    });
  }
  if (decodedUrl === "/rest/user/2033@remote.example.com/buttons" && request.method === "GET") {
    return response.end(JSON.stringify(buttonProfiles));
  }
  if (decodedUrl === "/rest/user/2033@remote.example.com/buttons" && request.method === "POST") {
    let body = "";
    request.on("data", (chunk) => { body += chunk; });
    return request.on("end", () => {
      const input = JSON.parse(body);
      buttonProfiles = [{
        address: input.mac,
        name: "Extension 2033",
        template: input.template,
        buttons: input.buttons,
      }];
      response.end(JSON.stringify(true));
    });
  }
  if (request.url === "/rest/domain/remote.example.com/did" && request.method === "GET") {
    return response.end(JSON.stringify(didState));
  }
  if (request.url === "/rest/domain/remote.example.com/did" && request.method === "POST") {
    let body = "";
    request.on("data", (chunk) => { body += chunk; });
    return request.on("end", () => {
      const input = JSON.parse(body);
      didState = {
        ...didState,
        numbers: didState.numbers.map((row) => row.did === input.did ? { ...row, user: input.assign, outbound: input.outbound } : row),
      };
      response.end(JSON.stringify(true));
    });
  }
  if (request.url === "/rest/domain/remote.example.com/user_settings/2037" && request.method === "GET") {
    return response.end(JSON.stringify({ extension: "2037", pcap: pcapEnabled ? "true" : "" }));
  }
  if (request.url === "/rest/domain/remote.example.com/user_settings/2037" && request.method === "POST") {
    let body = "";
    request.on("data", (chunk) => { body += chunk; });
    return request.on("end", () => {
      pcapEnabled = JSON.parse(body).pcap === "true";
      response.end(JSON.stringify({ ok: true }));
    });
  }
  if (request.url === "/rest/domain/remote.example.com/addacc" && request.method === "POST") {
    let body = "";
    request.on("data", (chunk) => { body += chunk; });
    return request.on("end", () => {
      createdAccount = JSON.parse(body);
      response.end(JSON.stringify({ ok: true }));
    });
  }
  if (request.url === "/rest/domain/remote.example.com/edit_trunk/4" && request.method === "GET") {
    return response.end(JSON.stringify(trunkConfig));
  }
  if (request.url === "/rest/domain/remote.example.com/edit_trunk/4" && request.method === "POST") {
    let body = "";
    request.on("data", (chunk) => { body += chunk; });
    return request.on("end", () => {
      trunkConfig = { ...trunkConfig, ...JSON.parse(body) };
      response.end(JSON.stringify({ ok: true }));
    });
  }
  if (request.url === "/rest/domain/remote.example.com/domain_trunks" && request.method === "GET") {
    return response.end(JSON.stringify([trunkConfig]));
  }
  if (request.url === "/rest/domain/remote.example.com/dialplans" && request.method === "GET") {
    return response.end(JSON.stringify(dialPlans));
  }
  if (request.url === "/rest/domain/remote.example.com/dialplans" && request.method === "POST") {
    let body = "";
    request.on("data", (chunk) => { body += chunk; });
    return request.on("end", () => {
      const input = JSON.parse(body);
      const created = { name: input.name, value: String(nextDialPlanId++), inuse: false };
      dialPlans.push(created);
      response.end(JSON.stringify(Number(created.value)));
    });
  }
  if (decodedUrl === "/rest/user/2009@remote.example.com/calls" && request.method === "GET") {
    activeCallReads += 1;
    return response.end(JSON.stringify(activeCalls.map((call) => ({ ...call, now: call.now + activeCallReads }))));
  }
  if (decodedUrl === "/rest/user/2009@remote.example.com/calls" && request.method === "POST") {
    let body = "";
    request.on("data", (chunk) => { body += chunk; });
    return request.on("end", () => {
      const input = JSON.parse(body);
      callActions.push(input);
      const terminalId = input.hangup || input.reject;
      if (terminalId) activeCalls = activeCalls.filter((call) => call.id !== terminalId);
      response.end(JSON.stringify({ ok: true }));
    });
  }
  if (request.url === "/rest/domain/remote.example.com/cdr?id=call-1") {
    return response.end(JSON.stringify([{ id: "call-1", pcap: true }]));
  }
  if (request.url === "/rest/system/pcap?id=call-1") {
    response.setHeader("content-type", "application/vnd.tcpdump.pcap");
    return response.end(testPcap());
  }
  response.statusCode = 404;
  response.end(JSON.stringify({ error: request.url }));
});

await new Promise((resolve) => mockPbx.listen(0, "127.0.0.1", resolve));
const pbxPort = mockPbx.address().port;
const httpPort = 32000 + Math.floor(Math.random() * 1000);
const learningStore = `/tmp/vodia-mcp-http-learning-selftest-${process.pid}.json`;
const child = spawn(process.execPath, ["http.js"], {
  cwd: process.cwd(),
  env: {
    ...process.env,
    VODIA_URL: `http://127.0.0.1:${pbxPort}`,
    VODIA_USER: "mcp-api",
    VODIA_PASS: "test-pass",
    MCP_BEARER_TOKEN: "test-mcp-token",
    MCP_ADMIN_BEARER_TOKEN: "test-admin-mcp-token",
    MCP_ADMIN_ACTOR: "selftest-admin",
    MCP_APPROVER_BEARER_TOKEN: "test-approver-mcp-token",
    MCP_APPROVER_ACTOR: "selftest-human-approver",
    VODIA_LEARNING_STORE: learningStore,
    VODIA_ADMIN_PROFILE: "full",
    VODIA_ENABLE_DESTRUCTIVE: "false",
    VODIA_ENABLE_CRITICAL_WRITES: "false",
    ADMIN_TOKEN: "test-admin-token",
    PORT: String(httpPort),
  },
  stdio: ["ignore", "pipe", "pipe"],
});

let startupLog = "";
child.stdout.on("data", (chunk) => { startupLog += chunk.toString(); });
child.stderr.on("data", (chunk) => { startupLog += chunk.toString(); });

for (let attempt = 0; attempt < 60; attempt += 1) {
  if (startupLog.includes("HTTP server listening")) break;
  if (child.exitCode !== null) throw new Error(`HTTP server exited early: ${startupLog}`);
  await new Promise((resolve) => setTimeout(resolve, 50));
}

const baseUrl = `http://127.0.0.1:${httpPort}`;
const unauthorized = await fetch(`${baseUrl}/api/status`);
const dashboard = await fetch(`${baseUrl}/admin/`);
const adminStatus = await fetch(`${baseUrl}/api/status`, {
  headers: { Authorization: "Bearer test-admin-token" },
}).then((response) => response.json());
const health = await fetch(`${baseUrl}/health`).then((response) => response.json());
const downloadedPcap = await fetch(`${baseUrl}/api/pcap/call-1?domain=remote.example.com`, {
  headers: { Authorization: "Bearer test-admin-token" },
});
const downloadedPcapBytes = Buffer.from(await downloadedPcap.arrayBuffer());

const transport = new StreamableHTTPClientTransport(new URL(`${baseUrl}/mcp`), {
  requestInit: { headers: { Authorization: "Bearer test-mcp-token" } },
});
const client = new Client({ name: "vodia-http-selftest", version: "1.0.0" });
const adminTransport = new StreamableHTTPClientTransport(new URL(`${baseUrl}/mcp-admin`), {
  requestInit: { headers: { Authorization: "Bearer test-admin-mcp-token" } },
});
const adminClient = new Client({ name: "vodia-http-admin-selftest", version: "1.0.0" });
const approverTransport = new StreamableHTTPClientTransport(new URL(`${baseUrl}/mcp-approver`), {
  requestInit: { headers: { Authorization: "Bearer test-approver-mcp-token" } },
});
const approverClient = new Client({ name: "vodia-http-approver-selftest", version: "1.0.0" });

try {
  await client.connect(transport);
  await adminClient.connect(adminTransport);
  await approverClient.connect(approverTransport);
  const tools = await client.listTools();
  const adminTools = await adminClient.listTools();
  const approverTools = await approverClient.listTools();
  const adminInfo = await adminClient.callTool({ name: "get_connector_info", arguments: {} });
  const domains = await client.callTool({ name: "list_domains", arguments: {} });
  const accountLiveCalls = await adminClient.callTool({ name: "get_account_live_calls", arguments: { account: "2009@remote.example.com" } });
  const tenantLiveCalls = await adminClient.callTool({ name: "list_tenant_live_calls", arguments: { domain: "remote.example.com" } });
  const genericRead = await adminClient.callTool({ name: "read_vodia_api", arguments: { operation_id: "get_rest_system_status" } });
  const inspectedButtons = await adminClient.callTool({ name: "inspect_vodia_operation", arguments: { operation_id: "post_rest_user_account_buttons" } });
  const supportedPolycom = await adminClient.callTool({ name: "list_supported_phone_models", arguments: { domain: "remote.example.com", vendor: "polycom" } });
  const defaultPhonePlan = await adminClient.callTool({ name: "plan_provision_mac", arguments: { domain: "remote.example.com", mac: "00:04:13:91:04:61", extension: "2009", vendor: "Polycom", model: "VVX450", reason: "optional defaults self-test" } });
  const defaultPhoneApply = await adminClient.callTool({ name: "apply_vodia_change", arguments: { change_id: defaultPhonePlan.structuredContent?.data?.changeId, confirmation: defaultPhonePlan.structuredContent?.data?.confirmationRequired } });
  const unsupportedPhone = await adminClient.callTool({ name: "plan_provision_mac", arguments: { domain: "remote.example.com", mac: "00:04:13:91:04:61", extension: "2009", vendor: "Polycom", model: "Not-A-Phone", sip_transport: "Default", t38: "Default", reason: "catalog rejection self-test" } });
  const yealinkWithoutSerial = await adminClient.callTool({ name: "plan_provision_mac", arguments: { domain: "remote.example.com", mac: "44:DB:D2:8A:06:D2", extension: "2009", vendor: "Yealink", model: "T73U", sip_transport: "TLS", t38: "Default", reason: "Yealink serial requirement self-test" } });
  const yealinkPlan = await adminClient.callTool({ name: "plan_provision_mac", arguments: { domain: "remote.example.com", mac: "44:DB:D2:8A:06:D2", extension: "2009", vendor: "yealink", model: "t73u", serial_number: "801012G100000240", sip_transport: "TLS", t38: "Default", reason: "Yealink RPS provisioning self-test" } });
  const yealinkApply = await adminClient.callTool({ name: "apply_vodia_change", arguments: { change_id: yealinkPlan.structuredContent?.data?.changeId, confirmation: yealinkPlan.structuredContent?.data?.confirmationRequired } });
  const macPlan = await adminClient.callTool({ name: "plan_provision_mac", arguments: { domain: "remote.example.com", mac: "00:04:13:91:04:61", extension: "2009", vendor: "polycom", model: "vvx450", name: "Front Desk", sip_transport: "TLS", t38: "On", reason: "MAC provisioning self-test" } });
  const macApply = await adminClient.callTool({ name: "apply_vodia_change", arguments: { change_id: macPlan.structuredContent?.data?.changeId, confirmation: macPlan.structuredContent?.data?.confirmationRequired } });
  const preservePhonePlan = await adminClient.callTool({ name: "plan_provision_mac", arguments: { domain: "remote.example.com", mac: "00:04:13:91:04:61", extension: "2009", vendor: "Polycom", model: "VVX450", name: "Front Desk Preserved", reason: "preserve optional values self-test" } });
  const preservePhoneApply = await adminClient.callTool({ name: "apply_vodia_change", arguments: { change_id: preservePhonePlan.structuredContent?.data?.changeId, confirmation: preservePhonePlan.structuredContent?.data?.confirmationRequired } });
  const fanvilWritesBeforePlan = macWrites.length;
  const fanvilPlan = await adminClient.callTool({ name: "plan_provision_mac", arguments: { domain: "remote.example.com", mac: "0c:38:3e:15:c5:77", extension: "2009", vendor: "fanvil", model: "v64", reason: "Fanvil V64 payload self-test" } });
  const fanvilPlanBody = fanvilPlan.structuredContent?.data?.request?.body;
  const fanvilApply = await adminClient.callTool({ name: "apply_vodia_change", arguments: { change_id: fanvilPlan.structuredContent?.data?.changeId, confirmation: fanvilPlan.structuredContent?.data?.confirmationRequired } });
  const missingProvisionDomain = await adminClient.callTool({ name: "plan_provision_mac", arguments: { mac: "0C383E15C578", extension: "2009", vendor: "Fanvil", model: "V64", reason: "missing domain self-test" } });
  const missingProvisionMac = await adminClient.callTool({ name: "plan_provision_mac", arguments: { domain: "remote.example.com", extension: "2009", vendor: "Fanvil", model: "V64", reason: "missing MAC self-test" } });
  const missingProvisionExtension = await adminClient.callTool({ name: "plan_provision_mac", arguments: { domain: "remote.example.com", mac: "0C383E15C578", vendor: "Fanvil", model: "V64", reason: "missing extension self-test" } });
  const buttonsRead = await adminClient.callTool({ name: "get_extension_buttons", arguments: { account: "2033@remote.example.com" } });
  const buttonsPlan = await adminClient.callTool({ name: "plan_set_extension_buttons", arguments: {
    account: "2033@remote.example.com",
    mac: "00:04:F2:C7:85:BE",
    replace_all: true,
    buttons: [
      { number: "0", type: "private", parameter: "", label: "2033" },
      { number: "1", type: "park", parameter: "100", label: "100" },
      { number: "2", type: "extension", parameter: "2009", label: "2009" },
    ],
    reason: "button profile self-test",
  } });
  const buttonsApply = await adminClient.callTool({ name: "apply_vodia_change", arguments: { change_id: buttonsPlan.structuredContent?.data?.changeId, confirmation: buttonsPlan.structuredContent?.data?.confirmationRequired } });
  const staleButtonsPlan = await adminClient.callTool({ name: "plan_set_extension_buttons", arguments: {
    account: "2033@remote.example.com",
    mac: "0004F2C785BE",
    replace_all: true,
    buttons: [{ number: "0", type: "private", label: "2033" }],
    reason: "stale buttons self-test",
  } });
  buttonProfiles = buttonProfiles.map((profile) => ({ ...profile, name: "Changed elsewhere" }));
  const staleButtonsApply = await adminClient.callTool({ name: "apply_vodia_change", arguments: { change_id: staleButtonsPlan.structuredContent?.data?.changeId, confirmation: staleButtonsPlan.structuredContent?.data?.confirmationRequired } });
  const didList = await adminClient.callTool({ name: "list_tenant_dids", arguments: { domain: "remote.example.com" } });
  const didPlan = await adminClient.callTool({ name: "plan_assign_did", arguments: { domain: "remote.example.com", extension: "2009", did: "+16175550100", outbound: true, reason: "DID assignment self-test" } });
  const didApply = await adminClient.callTool({ name: "apply_vodia_change", arguments: { change_id: didPlan.structuredContent?.data?.changeId, confirmation: didPlan.structuredContent?.data?.confirmationRequired } });
  const didConflict = await adminClient.callTool({ name: "plan_assign_did", arguments: { domain: "remote.example.com", extension: "2033", did: "+16175550100", reason: "DID conflict self-test" } });
  const binaryRead = await adminClient.callTool({ name: "read_vodia_binary", arguments: { operation_id: "get_rest_system_pcap", query_params: { id: "call-1" }, max_bytes: 1000000 } });
  const actionGetPlan = await adminClient.callTool({ name: "plan_vodia_change", arguments: { operation_id: "get_rest_system_testemail", reason: "action-like GET self-test" } });
  const actionGetApply = await adminClient.callTool({ name: "apply_vodia_change", arguments: { change_id: actionGetPlan.structuredContent?.data?.changeId, confirmation: actionGetPlan.structuredContent?.data?.confirmationRequired } });
  const createPlan = await adminClient.callTool({ name: "plan_create_account", arguments: { domain: "remote.example.com", type: "extensions", accounts: "2040", reason: "full-admin self-test" } });
  const wrongConfirmation = await adminClient.callTool({ name: "apply_vodia_change", arguments: { change_id: createPlan.structuredContent?.data?.changeId, confirmation: "DELETE" } });
  const createApply = await adminClient.callTool({ name: "apply_vodia_change", arguments: { change_id: createPlan.structuredContent?.data?.changeId, confirmation: createPlan.structuredContent?.data?.confirmationRequired } });
  const trunkPlan = await adminClient.callTool({ name: "plan_update_sip_trunk", arguments: { domain: "remote.example.com", trunk_id: "4", changes: { name: "Renamed trunk" }, reason: "trunk update self-test" } });
  const trunkApply = await adminClient.callTool({ name: "apply_vodia_change", arguments: { change_id: trunkPlan.structuredContent?.data?.changeId, confirmation: trunkPlan.structuredContent?.data?.confirmationRequired } });
  const dialPlan = await adminClient.callTool({ name: "plan_create_dial_plan", arguments: { domain: "remote.example.com", name: "Emergency", reason: "dial-plan creation self-test" } });
  const dialPlanApply = await adminClient.callTool({ name: "apply_vodia_change", arguments: { change_id: dialPlan.structuredContent?.data?.changeId, confirmation: dialPlan.structuredContent?.data?.confirmationRequired } });
  const hangupPlan = await adminClient.callTool({ name: "plan_hangup_call", arguments: { account: "2009@remote.example.com", call_id: "live-call-1", reason: "live-call hangup self-test" } });
  const hangupWrongConfirmation = await adminClient.callTool({ name: "apply_vodia_change", arguments: { change_id: hangupPlan.structuredContent?.data?.changeId, confirmation: "APPLY" } });
  const hangupApply = await adminClient.callTool({ name: "apply_vodia_change", arguments: { change_id: hangupPlan.structuredContent?.data?.changeId, confirmation: "HANGUP live-call-1" } });
  const disappearedCallPlan = await adminClient.callTool({ name: "plan_hold_call", arguments: { account: "2009@remote.example.com", call_id: "live-call-2", reason: "disappearing-call self-test" } });
  activeCalls = activeCalls.filter((call) => call.id !== "live-call-2");
  const disappearedCallApply = await adminClient.callTool({ name: "apply_vodia_change", arguments: { change_id: disappearedCallPlan.structuredContent?.data?.changeId, confirmation: "HOLD live-call-2" } });
  const deleteBlocked = await adminClient.callTool({ name: "plan_delete_sip_trunk", arguments: { domain: "remote.example.com", trunk_id: "4", reason: "destructive policy self-test" } });
  const criticalBlocked = await adminClient.callTool({ name: "plan_vodia_change", arguments: { operation_id: "post_rest_system_config", body: { web_port: "443" }, reason: "critical policy self-test" } });
  const plan = await adminClient.callTool({ name: "plan_extension_pcap", arguments: { domain: "remote.example.com", extension: "2037", enabled: true, reason: "self-test" } });
  const apply = await adminClient.callTool({ name: "apply_vodia_change", arguments: { change_id: plan.structuredContent?.data?.changeId, confirmation: plan.structuredContent?.data?.confirmationRequired } });
  const replay = await adminClient.callTool({ name: "apply_vodia_change", arguments: { change_id: plan.structuredContent?.data?.changeId, confirmation: plan.structuredContent?.data?.confirmationRequired } });
  const stalePlan = await adminClient.callTool({ name: "plan_extension_pcap", arguments: { domain: "remote.example.com", extension: "2037", enabled: false, reason: "stale-state self-test" } });
  await fetch(`http://127.0.0.1:${pbxPort}/rest/domain/remote.example.com/user_settings/2037`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ pcap: "" }) });
  const staleApply = await adminClient.callTool({ name: "apply_vodia_change", arguments: { change_id: stalePlan.structuredContent?.data?.changeId, confirmation: stalePlan.structuredContent?.data?.confirmationRequired } });
  const trace = await adminClient.callTool({ name: "get_call_sip_trace", arguments: { domain: "remote.example.com", call_id: "call-1", include_raw_messages: true } });
  const learningProposal = await adminClient.callTool({ name: "propose_learned_operation", arguments: {
    name: "Read custom domain widget",
    description: "Read the custom domain widget shown in the tenant portal.",
    method: "GET",
    path: "/rest/domain/{domain}/widget",
    path_parameters: ["domain"],
    query_parameters: ["id"],
    input_parameters: [],
    body_template: {},
    pbx_version: "70.5",
    evidence_source: "Vodia admin portal Network log",
    evidence_note: "Observed a 200 JSON response after opening the custom widget page.",
  } });
  const learnedOperationId = learningProposal.structuredContent?.data?.operationId;
  const learnedTest = await adminClient.callTool({ name: "test_learned_read", arguments: { operation_id: learnedOperationId, path_params: { domain: "remote.example.com" }, query_params: { id: 3 } } });
  const learningApproval = await approverClient.callTool({ name: "approve_learned_operation", arguments: { operation_id: learnedOperationId, confirmation: `APPROVE LEARNING ${learnedOperationId}` } });
  const learnedRead = await adminClient.callTool({ name: "run_learned_read", arguments: { operation_id: learnedOperationId, path_params: { domain: "remote.example.com" }, query_params: { id: 3 } } });
  const result = {
    unauthorizedAdminBlocked: unauthorized.status === 401,
    dashboardServed: dashboard.ok && (await dashboard.text()).includes("Vodia MCP Control Center"),
    adminPbxTestWorked: adminStatus.ok === true && adminStatus.pbx?.password === "[REDACTED]",
    streamableHttpConnected: tools.tools.length >= 15,
    bearerProtectedToolWorked: domains.structuredContent?.data?.[0]?.name === "remote.example.com",
    adminToolsSeparated: !tools.tools.some((tool) => tool.name === "apply_vodia_change") && adminTools.tools.some((tool) => tool.name === "apply_vodia_change"),
    fullAdminProfileReported: adminInfo.structuredContent?.data?.admin?.adminProfile === "full" && adminInfo.structuredContent?.data?.admin?.elevatedWritesAllowed === true,
    connectorVersionReported: health.version === "0.13.1" && adminInfo.structuredContent?.data?.connectorVersion === "0.13.1",
    completeApiToolsPresent: ["read_vodia_api", "read_vodia_binary", "inspect_vodia_operation", "find_api_capabilities", "plan_vodia_change", "apply_vodia_change"].every((name) => adminTools.tools.some((tool) => tool.name === name)),
    accountLiveCallsReturned: accountLiveCalls.structuredContent?.data?.some?.((call) => call.id === "live-call-1"),
    tenantLiveCallsAggregated: tenantLiveCalls.structuredContent?.meta?.activeCallCount === 2 && tenantLiveCalls.structuredContent?.meta?.activeLegCount === 2,
    genericAdminReadWorked: genericRead.structuredContent?.data?.status === "ok",
    provisioningToolsPresent: ["list_supported_phone_models", "plan_provision_mac"].every((name) => adminTools.tools.some((tool) => tool.name === name)),
    liveCatalogFiltered: supportedPolycom.structuredContent?.data?.[0]?.vendor === "Polycom" && supportedPolycom.structuredContent?.data?.[0]?.models?.includes("VVX450"),
    operationSchemaInspectable: inspectedButtons.structuredContent?.data?.operationId === "post_rest_user_account_buttons",
    optionalProvisioningDefaultsApplied: !defaultPhoneApply.isError && macWrites.some((entry) => entry.mac === "000413910461" && entry.siptrans === "" && entry.prov_t38 === "" && !Object.hasOwn(entry, "refresh")),
    unsupportedPhoneRejected: unsupportedPhone.isError === true && JSON.stringify(unsupportedPhone).includes("not supported"),
    yealinkSerialRequired: yealinkWithoutSerial.isError === true && JSON.stringify(yealinkWithoutSerial).includes("full Yealink serial number"),
    yealinkSerialMappedAndRedacted: !yealinkApply.isError && provisionedMacs.some((entry) => entry.mac === "44DBD28A06D2" && entry.vendor === "Yealink" && entry.model === "T73U" && entry.pin === "801012G100000240") && !JSON.stringify(yealinkPlan).includes("801012G100000240") && JSON.stringify(yealinkPlan).includes("[REDACTED]"),
    macProvisioningApplied: !macApply.isError && macWrites.some((entry) => entry.mac === "000413910461" && entry.vendor === "Polycom" && entry.model === "VVX450" && entry.extension === "2009" && entry.siptrans === "tls" && entry.prov_t38 === "true" && entry.domain === "remote.example.com" && !Object.hasOwn(entry, "extensions") && !Object.hasOwn(entry, "refresh")),
    optionalProvisioningValuesDefaulted: !preservePhoneApply.isError && provisionedMacs.some((entry) => entry.mac === "000413910461" && entry.name === "Front Desk Preserved" && entry.siptrans === "" && entry.prov_t38 === "" && entry.pin === ""),
    fanvilPlanUsesVerifiedUiPayload: fanvilWritesBeforePlan + 1 === macWrites.length && !fanvilPlan.isError && !fanvilApply.isError && JSON.stringify(fanvilPlanBody) === JSON.stringify({ mac: "0C383E15C577", pin: "[REDACTED]", vendor: "Fanvil", model: "V64", ip: "", extension: "2009", name: "Fanvil", siptrans: "", prov_t38: "", domain: "remote.example.com" }) && macWrites.some((entry) => JSON.stringify(entry) === JSON.stringify({ mac: "0C383E15C577", pin: "", vendor: "Fanvil", model: "V64", ip: "", extension: "2009", name: "Fanvil", siptrans: "", prov_t38: "", domain: "remote.example.com" })),
    fanvilPlanDoesNotWrite: fanvilWritesBeforePlan === macWrites.findIndex((entry) => entry.mac === "0C383E15C577"),
    requiredProvisioningFieldsEnforced: missingProvisionDomain.isError === true && missingProvisionMac.isError === true && missingProvisionExtension.isError === true,
    buttonToolsPresentAndApplied: ["get_extension_buttons", "plan_set_extension_buttons"].every((name) => adminTools.tools.some((tool) => tool.name === name)) && !buttonsRead.isError && !buttonsApply.isError && JSON.parse(buttonProfiles[0].buttons).buttons.some((button) => button.type === "park" && button.parameter === "100"),
    staleButtonPlanBlocked: staleButtonsApply.isError === true && JSON.stringify(staleButtonsApply).includes("changed after the plan"),
    didToolsPresentAndApplied: ["list_tenant_dids", "plan_assign_did"].every((name) => adminTools.tools.some((tool) => tool.name === name)) && !didList.isError && !didApply.isError && didState.numbers.some((row) => row.did === "+16175550100" && row.user === "2009" && row.outbound === true),
    didConflictBlocked: didConflict.isError === true && JSON.stringify(didConflict).includes("already assigned"),
    binaryAdminReadWorked: binaryRead.structuredContent?.data?.bytes > 24 && typeof binaryRead.structuredContent?.data?.base64 === "string",
    actionLikeGetPlannedAndApplied: !actionGetApply.isError && testEmails === 1,
    fullAdminPlannersPresent: ["plan_create_account", "plan_update_account", "plan_update_sip_trunk", "plan_set_sip_trunk_enabled", "plan_create_dial_plan", "plan_update_dial_plan", "plan_update_tenant_settings", "plan_delete_account", "plan_delete_sip_trunk"].every((name) => adminTools.tools.some((tool) => tool.name === name)),
    liveCallPlannersPresent: ["plan_hangup_call", "plan_reject_call", "plan_transfer_call", "plan_hold_call", "plan_resume_call", "plan_answer_call"].every((name) => adminTools.tools.some((tool) => tool.name === name)),
    exactConfirmationEnforced: wrongConfirmation.isError === true && !createApply.isError,
    accountCreationApplied: createdAccount?.type === "extensions" && createdAccount?.account_ext === "2040",
    elevatedTrunkUpdateApplied: !trunkApply.isError && trunkConfig.name === "Renamed trunk",
    dialPlanCreationApplied: !dialPlanApply.isError && dialPlans.some((item) => item.name === "Emergency"),
    volatileCallPlanApplied: hangupWrongConfirmation.isError === true && !hangupApply.isError && callActions.some((action) => action.hangup === "live-call-1"),
    disappearedCallBlocked: disappearedCallApply.isError === true && JSON.stringify(disappearedCallApply).includes("no longer exists"),
    secretsRedactedFromTrunkPlan: !JSON.stringify(trunkPlan).includes("must-redact"),
    destructiveWriteBlockedByDefault: deleteBlocked.isError === true,
    criticalWriteBlockedByDefault: criticalBlocked.isError === true,
    plannedWriteApplied: !apply.isError,
    writePlanSingleUse: replay.isError === true,
    stalePlanBlocked: staleApply.isError === true && JSON.stringify(staleApply).includes("PBX state changed"),
    pcapTraceParsedAndRedacted: trace.structuredContent?.data?.summary?.messageCount === 1 && !JSON.stringify(trace.structuredContent).includes("Digest hidden"),
    pcapDownloadProtectedAndWorked: downloadedPcap.ok && downloadedPcap.headers.get("content-type")?.includes("application/vnd.tcpdump.pcap") && downloadedPcapBytes.length > 24,
    learningToolsSeparated: adminTools.tools.some((tool) => tool.name === "propose_learned_operation") && !adminTools.tools.some((tool) => tool.name === "approve_learned_operation") && approverTools.tools.some((tool) => tool.name === "approve_learned_operation") && !approverTools.tools.some((tool) => tool.name === "apply_vodia_change"),
    learnedReadTestedApprovedAndRun: !learnedTest.isError && !learningApproval.isError && learnedRead.structuredContent?.data?.learned === true,
  };
  console.log(JSON.stringify(result, null, 2));
  if (!result.plannedWriteApplied) console.error(JSON.stringify({ plan, apply, pcapEnabled, startupLog }, null, 2));
  if (Object.values(result).some((value) => value !== true)) process.exitCode = 1;
} finally {
  await client.close().catch(() => {});
  await adminClient.close().catch(() => {});
  await approverClient.close().catch(() => {});
  child.kill("SIGTERM");
  await new Promise((resolve) => child.once("exit", resolve));
  await new Promise((resolve) => mockPbx.close(resolve));
  try { unlinkSync(learningStore); } catch {}
}

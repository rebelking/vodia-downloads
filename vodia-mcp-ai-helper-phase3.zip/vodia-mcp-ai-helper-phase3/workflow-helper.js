import {
  listAwsChimePhoneNumbers,
  listAwsChimeVoiceConnectors,
  recommendAwsChimeRegion,
} from "./aws-chime.js";

const WORKFLOWS = {
  amazon_chime: {
    id: "amazon_chime",
    title: "Amazon Chime tenant connection",
    examples: [
      "Set up Amazon Chime for this tenant",
      "Create a Chime connection for customer.example.com",
      "Get this tenant a local number on Chime",
    ],
    policy: "Discover → recommend → choices → plan → explicit approval → apply → verify → audit",
    defaultRecommendations: {
      region: "automatic from deployment country, validated against AWS",
      encryption: "TLS/SRTP",
      networkType: "IPV4_ONLY",
      forcePhoneNumberReassignment: false,
    },
    toolFamilies: [
      "aws_chime_*",
      "Vodia trunk/DID/dial-plan read tools",
      "Vodia guarded plan/apply tools",
    ],
    verify: [
      "Voice Connector exists",
      "phone number order/assignment is complete when requested",
      "Vodia trunk points at the AWS-generated Voice Connector hostname",
      "DID routing is correct",
      "test call or observable SIP state confirms the path",
    ],
  },
  sip_trunk: {
    id: "sip_trunk",
    title: "SIP trunk setup or change",
    examples: ["Set up Telnyx for this tenant", "Create a SIP trunk", "Change this carrier trunk"],
    policy: "Read existing trunks/provider context → recommend settings → guarded Vodia plan/apply → verify",
    toolFamilies: ["find_read_capabilities", "read_vodia_resource", "inspect_vodia_operation", "Vodia trunk planners", "apply_vodia_change"],
    verify: ["trunk exists/enabled", "routing references correct trunk", "inbound/outbound test result"],
  },
  extension: {
    id: "extension",
    title: "Extension/user administration",
    examples: ["Create extension 205 for John", "Update extension 3005", "Disable this user"],
    policy: "Check tenant and number conflicts → recommend defaults → guarded plan/apply → verify",
    toolFamilies: ["extension/account reads", "account planners", "apply_vodia_change"],
    verify: ["account exists with intended settings", "registration/provisioning state where applicable"],
  },
  phone: {
    id: "phone",
    title: "Phone provisioning",
    examples: ["Provision this Yealink", "Assign this MAC to extension 205", "Why did this phone stop provisioning?"],
    policy: "Discover vendor/model/MAC/tenant → inspect existing assignment → plan → approve → apply → verify registration",
    toolFamilies: ["MAC/device reads", "vendor/model discovery", "MAC provisioning planners", "registration reads"],
    verify: ["MAC assigned", "provisioning generated", "device registered"],
  },
  did: {
    id: "did",
    title: "DID and phone-number routing",
    examples: ["Send this DID to extension 205", "Assign this number to the queue", "Find DID conflicts"],
    policy: "Read DID inventory/conflicts → propose destination → guarded plan/apply → verify",
    toolFamilies: ["DID reads", "DID assignment planners", "dial-plan/routing reads"],
    verify: ["DID uniquely assigned", "inbound route reaches intended target"],
  },
  dial_plan: {
    id: "dial_plan",
    title: "Dial plan and routing",
    examples: ["Route 9 plus number through Chime", "Create an outbound rule", "Change international routing"],
    policy: "Inspect existing rules/trunks → detect overlap → guarded plan/apply → verify",
    toolFamilies: ["dial-plan reads", "dial-plan planners", "trunk reads"],
    verify: ["rule order and pattern are correct", "expected trunk is selected"],
  },
  queue: {
    id: "queue",
    title: "ACD/queue operations",
    examples: ["Create a support queue", "Add these agents", "Why are calls abandoning?"],
    policy: "Inspect queue/agents/live state/stats → recommend → plan/apply when changing → verify",
    toolFamilies: ["ACD reads", "queue stats", "agent state", "generic guarded admin operations"],
    verify: ["agents and algorithm match intent", "live/queue stats show expected behavior"],
  },
  ivr: {
    id: "ivr",
    title: "IVR/auto attendant",
    examples: ["Create a main menu", "Change option 2 to support", "Route after-hours differently"],
    policy: "Read existing IVR/routing/audio → propose menu → guarded change → verify",
    toolFamilies: ["resource discovery", "generic Vodia reads", "guarded admin operations"],
    verify: ["menu destinations resolve", "audio/routing behavior matches plan"],
  },
  voicemail: {
    id: "voicemail",
    title: "Voicemail",
    examples: ["Configure voicemail for 205", "Why is voicemail not taking calls?"],
    policy: "Read account/forwarding/voicemail state → recommend → guarded change → verify",
    toolFamilies: ["account reads", "resource discovery", "guarded admin operations"],
    verify: ["voicemail settings and forwarding path are correct"],
  },
  troubleshoot_call: {
    id: "troubleshoot_call",
    title: "Call/SIP/audio troubleshooting",
    examples: ["Why did this call fail?", "Find one-way audio", "Why did this call get 408?"],
    policy: "Read-only diagnosis first; correlate CDR, live state, SIP/PCAP, trunk, routing and registrations before proposing a fix",
    toolFamilies: ["CDR reads", "live-call reads", "PCAP/SIP diagnostics", "trunk stats", "registration reads"],
    verify: ["root cause is evidence-backed", "post-fix test no longer reproduces issue"],
  },
  troubleshoot_registration: {
    id: "troubleshoot_registration",
    title: "Registration troubleshooting",
    examples: ["Why is extension 3005 offline?", "Which phones are not registered?"],
    policy: "Read registration/account/provisioning state first; make no changes until cause is identified",
    toolFamilies: ["registration reads", "extension reads", "provisioning reads", "system/network diagnostics"],
    verify: ["device registers and remains stable"],
  },
  cdr: {
    id: "cdr",
    title: "CDR and reporting",
    examples: ["Show abandoned calls", "How many calls connected?", "Report outbound attempts"],
    policy: "Read-only analytics by default",
    toolFamilies: ["CDR reads", "tenant stats", "queue stats"],
    verify: ["filters and definitions are stated with the report"],
  },
  system_health: {
    id: "system_health",
    title: "PBX system health",
    examples: ["Check CPU RAM and disk", "Is the PBX healthy?", "Check license and update state"],
    policy: "Read system status/stats first; privileged remediation requires guarded plan/apply",
    toolFamilies: ["system status", "system stats", "license/update reads", "audit"],
    verify: ["health indicators return to expected range after remediation"],
  },
  maintenance: {
    id: "maintenance",
    title: "Backup/upgrade/maintenance",
    examples: ["Is this PBX safe to upgrade?", "Prepare an upgrade", "Check backup readiness"],
    policy: "Inventory/version/health/backup checks first; high-impact changes require explicit approval and post-change verification",
    toolFamilies: ["system/version reads", "health reads", "critical guarded operations"],
    verify: ["service health, version, registrations, trunks and test calls after change"],
  },
  certificates: {
    id: "certificates",
    title: "DNS/certificate troubleshooting",
    examples: ["Why isn't the certificate renewing?", "Check this tenant DNS", "Validate HTTPS readiness"],
    policy: "Read/validate before any DNS or system change",
    toolFamilies: ["system/domain reads", "logs", "external diagnostics when available"],
    verify: ["DNS resolves correctly", "certificate is valid and served"],
  },
  general: {
    id: "general",
    title: "General PBX administration",
    examples: ["Help me configure this tenant", "Check this PBX"],
    policy: "Discover context first → choose a specific workflow → read before write",
    toolFamilies: ["find_read_capabilities", "read_vodia_resource", "inspect_vodia_operation"],
    verify: ["select a more specific workflow before applying changes"],
  },
};

function classify(request, provider) {
  const text = `${request || ""} ${provider || ""}`.toLowerCase();
  if (/\b(chime|amazon chime|aws voice|voice connector)\b/.test(text)) return "amazon_chime";
  if (/\b(one[- ]way audio|no audio|sip|408|486|487|call fail|failed call|dropped call|rtp|pcap)\b/.test(text)) return "troubleshoot_call";
  if (/\b(register|registration|offline phone|not registered)\b/.test(text)) return "troubleshoot_registration";
  if (/\b(sip trunk|trunk|telnyx|bandwidth|skyetel|flowroute|carrier)\b/.test(text)) return "sip_trunk";
  if (/\b(extension|account|user)\b/.test(text)) return "extension";
  if (/\b(phone|yealink|snom|fanvil|poly|grandstream|mac|provision)\b/.test(text)) return "phone";
  if (/\b(did|phone number|number route|inbound number)\b/.test(text)) return "did";
  if (/\b(dial plan|outbound rule|route calls|routing rule)\b/.test(text)) return "dial_plan";
  if (/\b(queue|acd|agent|abandon)\b/.test(text)) return "queue";
  if (/\b(ivr|auto attendant|menu)\b/.test(text)) return "ivr";
  if (/\b(voicemail|mailbox)\b/.test(text)) return "voicemail";
  if (/\b(cdr|call report|call history|analytics)\b/.test(text)) return "cdr";
  if (/\b(cpu|memory|ram|disk|system health|license)\b/.test(text)) return "system_health";
  if (/\b(upgrade|backup|maintenance|reboot)\b/.test(text)) return "maintenance";
  if (/\b(certificate|cert|dns|acme|https)\b/.test(text)) return "certificates";
  return "general";
}

function basePrepared(workflow, input) {
  const missingInputs = [];
  const choices = [];
  if (["amazon_chime", "sip_trunk", "extension", "phone", "did", "dial_plan", "queue", "ivr", "voicemail"].includes(workflow.id) && !input.tenant) {
    missingInputs.push({ field: "tenant", reason: "Target tenant/domain is needed before configuration changes can be planned." });
  }
  return {
    workflow,
    request: input.request,
    tenant: input.tenant || null,
    provider: input.provider || null,
    safety: {
      readsMayRunAutomatically: true,
      writesRequirePlanAndExplicitApproval: true,
      destructiveOrCriticalChangesNeedStrongerConfirmation: true,
      verifyAfterApply: true,
      auditExpected: true,
    },
    missingInputs,
    choices,
    nextAction: missingInputs.length ? "Collect the missing information, then prepare again." : "Continue with workflow discovery and planning.",
    changesMade: false,
  };
}

export function getAiWorkflowCatalog() {
  return {
    schemaVersion: 1,
    principle: "The AI interprets intent; the MCP supplies deterministic discovery, recommendations, guarded plans, execution, verification goals and audit boundaries.",
    interactionPattern: ["DISCOVER", "RECOMMEND", "CHOICES", "PLAN", "APPROVAL", "APPLY", "VERIFY", "REPORT"],
    workflows: Object.values(WORKFLOWS),
  };
}

export async function prepareAiWorkflow(input = {}) {
  const request = String(input.request || "").trim();
  if (!request) throw new Error("request is required.");
  const id = classify(request, input.provider);
  const workflow = WORKFLOWS[id] || WORKFLOWS.general;
  const result = basePrepared(workflow, { ...input, request });

  if (id !== "amazon_chime") return result;

  const country = String(input.country || "").trim();
  if (!country) {
    result.missingInputs.push({
      field: "country",
      reason: "Deployment country is used to recommend and validate the AWS Voice Connector region.",
    });
  }

  let regionInfo = null;
  if (country) {
    regionInfo = await recommendAwsChimeRegion({ country, region: input.region });
  }

  const connectors = await listAwsChimeVoiceConnectors({ region: regionInfo?.recommendedRegion || input.region, maxResults: 100 });
  const matching = input.tenant
    ? connectors.voiceConnectors.filter((c) => String(c.name || "").toLowerCase() === String(input.tenant).toLowerCase())
    : [];

  const inventory = await listAwsChimePhoneNumbers({ region: regionInfo?.recommendedRegion || input.region, maxResults: 100 });

  result.discovery = {
    awsConnected: true,
    recommendedRegion: regionInfo?.recommendedRegion || null,
    countryCode: regionInfo?.countryCode || null,
    availableVoiceConnectorCount: connectors.voiceConnectors.length,
    matchingVoiceConnectors: matching,
    phoneNumberInventory: inventory.phoneNumbers,
  };

  result.recommendations = {
    region: regionInfo?.recommendedRegion || "automatic after country is known",
    encryption: "TLS/SRTP",
    networkType: "IPV4_ONLY",
    connectorStrategy: matching.length === 1 ? "reuse-existing" : matching.length > 1 ? "choose-existing" : "create-new",
    numberStrategy: inventory.phoneNumbers.length ? "ask: existing inventory vs search new vs no number yet" : "ask: search new vs no number yet",
    forcePhoneNumberReassignment: false,
  };

  result.choices = [
    {
      id: "connector",
      question: "Voice Connector",
      options: matching.length
        ? [
            { value: "reuse-existing", label: `Reuse matching connector ${matching[0]?.name || ""}`, recommended: matching.length === 1 },
            { value: "create-new", label: "Create a new Voice Connector", recommended: false },
          ]
        : [{ value: "create-new", label: "Create a new Voice Connector", recommended: true }],
    },
    {
      id: "phone_number",
      question: "Phone number",
      options: [
        ...(inventory.phoneNumbers.length ? [{ value: "use-existing", label: "Use an existing AWS phone number", recommended: false }] : []),
        { value: "search-new", label: "Search for a new local number", recommended: true },
        { value: "none", label: "Configure SIP only; no number yet", recommended: false },
      ],
    },
    {
      id: "security",
      question: "Security",
      options: [
        { value: "tls-srtp", label: "TLS/SRTP", recommended: true },
        { value: "standard-sip", label: "Standard SIP", recommended: false },
      ],
    },
    {
      id: "region",
      question: "AWS region",
      options: [
        { value: regionInfo?.recommendedRegion || "automatic", label: `Automatic${regionInfo?.recommendedRegion ? ` (${regionInfo.recommendedRegion})` : ""}`, recommended: true },
        { value: "manual", label: "Choose manually", recommended: false },
      ],
    },
  ];

  if (input.areaCode) {
    result.preferences = { areaCode: String(input.areaCode) };
  }

  result.nextAction = result.missingInputs.length
    ? "Collect missing inputs, then rerun preparation."
    : "Present the choices to the administrator. After choices are selected, build guarded AWS and Vodia plans; do not apply without explicit approval.";

  return result;
}

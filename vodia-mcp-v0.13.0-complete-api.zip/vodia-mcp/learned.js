import { randomUUID } from "node:crypto";
import { chmodSync, mkdirSync, readFileSync, renameSync, writeFileSync } from "node:fs";
import { dirname } from "node:path";

const STORE_PATH = String(process.env.VODIA_LEARNING_STORE || "/var/lib/vodia-mcp/learned-operations.json").trim();
const MAX_OPERATIONS = 250;
const SAFE_METHODS = new Set(["GET", "POST", "PUT", "PATCH"]);
const SENSITIVE_KEY = /(?:pass(?:word)?|secret|token|authorization|cookie|session|pin|serial|private.?key|api.?key|credential)/i;
const DESTRUCTIVE_WORD = /(?:delete|remove|purge|erase|destroy|drop|factory[ _-]?reset|wipe)/i;
const PLACEHOLDER = /^\{\{([A-Za-z][A-Za-z0-9_]*)\}\}$/;

function emptyStore() {
  return { schemaVersion: 1, operations: [] };
}

function readStore() {
  try {
    const parsed = JSON.parse(readFileSync(STORE_PATH, "utf8"));
    if (parsed?.schemaVersion !== 1 || !Array.isArray(parsed.operations)) throw new Error("Unsupported learning-store schema.");
    return parsed;
  } catch (error) {
    if (error?.code === "ENOENT") return emptyStore();
    throw new Error(`Unable to read the MCP learning store: ${error.message || error}`);
  }
}

function writeStore(store) {
  mkdirSync(dirname(STORE_PATH), { recursive: true, mode: 0o700 });
  const temporary = `${STORE_PATH}.${process.pid}.${Date.now()}.tmp`;
  writeFileSync(temporary, `${JSON.stringify(store, null, 2)}\n`, { encoding: "utf8", mode: 0o600, flag: "wx" });
  chmodSync(temporary, 0o600);
  renameSync(temporary, STORE_PATH);
}

function cleanText(value, name, maximum = 500) {
  const text = String(value || "").trim();
  if (!text) throw new Error(`${name} is required.`);
  if (text.length > maximum) throw new Error(`${name} exceeds ${maximum} characters.`);
  return text;
}

function cleanEvidence(value) {
  const text = cleanText(value, "evidence_note", 1_000);
  if (/(?:authorization|proxy-authorization|cookie|set-cookie)\s*:|(?:password|passwd|secret|token|session|serial(?:_number)?)\s*[=:]/i.test(text)) {
    throw new Error("evidence_note appears to contain credentials, a session value, token, or serial number. Store only a sanitized description of the observation.");
  }
  return text;
}

function normalizeNames(values, label) {
  const names = [...new Set((values || []).map((value) => String(value).trim()).filter(Boolean))];
  for (const name of names) if (!/^[A-Za-z][A-Za-z0-9_]*$/.test(name)) throw new Error(`${label} '${name}' is not a safe parameter name.`);
  return names;
}

function inspectTemplate(value, declared, path = "body", depth = 0) {
  if (depth > 20) throw new Error("Body template nesting exceeds 20 levels.");
  if (typeof value === "string") {
    const match = value.match(PLACEHOLDER);
    if (match && !declared.has(match[1])) throw new Error(`Body placeholder '${match[1]}' is not declared in input_parameters.`);
    return;
  }
  if (Array.isArray(value)) return value.forEach((item, index) => inspectTemplate(item, declared, `${path}[${index}]`, depth + 1));
  if (!value || typeof value !== "object") return;
  for (const [key, child] of Object.entries(value)) {
    if (["__proto__", "prototype", "constructor"].includes(key)) throw new Error(`Unsafe body-template key '${key}'.`);
    if (SENSITIVE_KEY.test(key) && !(typeof child === "string" && PLACEHOLDER.test(child))) {
      throw new Error(`Sensitive field '${path}.${key}' must use a runtime placeholder; literal secrets are never stored.`);
    }
    inspectTemplate(child, declared, `${path}.${key}`, depth + 1);
  }
}

function validatePath(path, method, summary) {
  if (path.length > 500 || !path.startsWith("/rest/")) throw new Error("Only relative Vodia /rest/... paths may be taught.");
  if (path.includes("?") || path.includes("#") || path.includes("\\") || path.includes("..") || /%2f|%5c/i.test(path)) {
    throw new Error("The learned path may not contain a query string, fragment, traversal, encoded slash, or backslash.");
  }
  if (!/^\/rest\/(?:domain|user|acd|system)(?:\/[A-Za-z0-9_.{}-]+)*$/.test(path)) throw new Error("The learned path contains unsupported characters or namespace.");
  if (path.replace(/\{[A-Za-z][A-Za-z0-9_]*\}/g, "PARAM").includes("{") || path.replace(/\{[A-Za-z][A-Za-z0-9_]*\}/g, "PARAM").includes("}")) {
    throw new Error("The learned path contains a malformed parameter placeholder.");
  }
  if (method !== "GET" && path.startsWith("/rest/system/")) throw new Error("Learned system-level writes are blocked. Add reviewed system operations to the release catalog instead.");
  if (DESTRUCTIVE_WORD.test(`${path} ${summary}`)) throw new Error("This looks destructive. Destructive operations cannot be taught dynamically.");
}

function publicOperation(operation) {
  return {
    id: operation.id,
    operationId: operation.operationId,
    name: operation.name,
    description: operation.description,
    method: operation.method,
    path: operation.path,
    risk: operation.risk,
    status: operation.status,
    pathParameters: operation.pathParameters,
    queryParameters: operation.queryParameters,
    inputParameters: operation.inputParameters,
    bodyTemplate: redactTemplate(operation.bodyTemplate),
    evidence: operation.evidence,
    proposedBy: operation.proposedBy,
    approvedBy: operation.approvedBy || null,
    createdAt: operation.createdAt,
    approvedAt: operation.approvedAt || null,
    disabledAt: operation.disabledAt || null,
    lastReadTest: operation.lastReadTest || null,
  };
}

function redactTemplate(value) {
  if (Array.isArray(value)) return value.map(redactTemplate);
  if (!value || typeof value !== "object") return value;
  return Object.fromEntries(Object.entries(value).map(([key, child]) => [key, SENSITIVE_KEY.test(key) ? "[RUNTIME-REDACTED]" : redactTemplate(child)]));
}

function catalogOperation(operation) {
  return {
    operationId: operation.operationId,
    method: operation.method,
    path: operation.path,
    summary: operation.description,
    tags: ["learned", "supervised"],
    risk: operation.risk === "read" ? "read" : "write",
    adminTier: "standard",
    callable: operation.status === "approved",
    blockedReason: operation.status === "approved" ? null : `Learned operation is ${operation.status}.`,
    parameters: [
      ...operation.pathParameters.map((name) => ({ name, in: "path", required: true })),
      ...operation.queryParameters.map((name) => ({ name, in: "query", required: false })),
    ],
    learned: true,
    learnedId: operation.id,
  };
}

function operationId(name, id) {
  const slug = String(name).toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, "").slice(0, 48) || "operation";
  return `learned_${slug}_${id.slice(0, 8)}`;
}

export function listLearnedOperations({ status } = {}) {
  return readStore().operations.filter((item) => !status || item.status === status).map(publicOperation);
}

export function getLearnedOperation(identifier) {
  const operation = readStore().operations.find((item) => item.id === identifier || item.operationId === identifier);
  if (!operation) throw new Error(`Learned operation '${identifier}' was not found.`);
  return operation;
}

export function proposeLearnedOperation(input, actor) {
  const store = readStore();
  if (store.operations.length >= MAX_OPERATIONS) throw new Error(`The learning store is limited to ${MAX_OPERATIONS} operations.`);
  const method = String(input.method || "").toUpperCase();
  if (!SAFE_METHODS.has(method)) throw new Error("Only GET, POST, PUT, and PATCH may be taught. DELETE is always blocked from dynamic learning.");
  const name = cleanText(input.name, "name", 120);
  const description = cleanText(input.description, "description", 500);
  const path = cleanText(input.path, "path", 500);
  validatePath(path, method, `${name} ${description}`);
  const pathParameters = normalizeNames(input.path_parameters, "Path parameter");
  const queryParameters = normalizeNames(input.query_parameters, "Query parameter");
  const inputParameters = normalizeNames(input.input_parameters, "Input parameter");
  const placeholders = [...path.matchAll(/\{([^}]+)\}/g)].map((match) => match[1]);
  if (placeholders.some((name) => !pathParameters.includes(name)) || pathParameters.some((name) => !placeholders.includes(name))) {
    throw new Error("path_parameters must exactly match the {placeholders} in path.");
  }
  const declared = new Set([...pathParameters, ...queryParameters, ...inputParameters]);
  if (declared.size !== pathParameters.length + queryParameters.length + inputParameters.length) throw new Error("Parameter names must be unique across path, query, and input parameters.");
  const bodyTemplate = method === "GET" ? {} : (input.body_template || {});
  if (method === "GET" && Object.keys(input.body_template || {}).length) throw new Error("GET lessons cannot include a request body.");
  inspectTemplate(bodyTemplate, declared);
  const evidence = {
    pbxVersion: cleanText(input.pbx_version, "pbx_version", 64),
    source: cleanText(input.evidence_source, "evidence_source", 120),
    note: cleanEvidence(input.evidence_note),
  };
  const id = randomUUID();
  const now = new Date().toISOString();
  const operation = {
    id,
    operationId: operationId(name, id),
    name,
    description,
    method,
    path,
    risk: method === "GET" ? "read" : "write",
    pathParameters,
    queryParameters,
    inputParameters,
    bodyTemplate,
    evidence,
    status: "proposed",
    proposedBy: actor,
    createdAt: now,
  };
  store.operations.push(operation);
  writeStore(store);
  return publicOperation(operation);
}

export function approveLearnedOperation(identifier, actor) {
  const store = readStore();
  const operation = store.operations.find((item) => item.id === identifier || item.operationId === identifier);
  if (!operation) throw new Error(`Learned operation '${identifier}' was not found.`);
  if (operation.status !== "proposed") throw new Error(`Only proposed operations may be approved; current status is '${operation.status}'.`);
  if (operation.proposedBy === actor) throw new Error("A teacher cannot approve its own learned operation.");
  operation.status = "approved";
  operation.approvedBy = actor;
  operation.approvedAt = new Date().toISOString();
  writeStore(store);
  return publicOperation(operation);
}

export function disableLearnedOperation(identifier, actor, reason) {
  const store = readStore();
  const operation = store.operations.find((item) => item.id === identifier || item.operationId === identifier);
  if (!operation) throw new Error(`Learned operation '${identifier}' was not found.`);
  if (operation.status === "disabled") throw new Error("Learned operation is already disabled.");
  operation.status = "disabled";
  operation.disabledBy = actor;
  operation.disabledReason = cleanText(reason, "reason", 500);
  operation.disabledAt = new Date().toISOString();
  writeStore(store);
  return publicOperation(operation);
}

export function recordReadTest(identifier, actor, result) {
  const store = readStore();
  const operation = store.operations.find((item) => item.id === identifier || item.operationId === identifier);
  if (!operation) return;
  operation.lastReadTest = { actor, timestamp: new Date().toISOString(), success: Boolean(result?.success), status: result?.status || null };
  writeStore(store);
}

export function materializeLearnedRequest(identifier, { pathParams = {}, queryParams = {}, inputs = {} } = {}, { requireApproved = true } = {}) {
  const operation = getLearnedOperation(identifier);
  if (requireApproved && operation.status !== "approved") throw new Error(`Learned operation is '${operation.status}', not approved.`);
  const requiredInput = new Set(operation.inputParameters);
  const unknownInputs = Object.keys(inputs).filter((key) => !requiredInput.has(key));
  if (unknownInputs.length) throw new Error(`Unknown input parameter(s): ${unknownInputs.join(", ")}`);
  const missingInputs = operation.inputParameters.filter((key) => inputs[key] === undefined || inputs[key] === null);
  if (missingInputs.length) throw new Error(`Missing input parameter(s): ${missingInputs.join(", ")}`);
  const substitute = (value) => {
    if (typeof value === "string") {
      const match = value.match(PLACEHOLDER);
      if (match) {
        const all = { ...pathParams, ...queryParams, ...inputs };
        if (all[match[1]] === undefined || all[match[1]] === null) throw new Error(`Missing runtime value '${match[1]}'.`);
        return all[match[1]];
      }
      return value;
    }
    if (Array.isArray(value)) return value.map(substitute);
    if (!value || typeof value !== "object") return value;
    return Object.fromEntries(Object.entries(value).map(([key, child]) => [key, substitute(child)]));
  };
  return { operation, catalog: catalogOperation(operation), request: { pathParams, queryParams, body: substitute(operation.bodyTemplate) } };
}

export function loadApprovedLearnedCatalog() {
  return readStore().operations.filter((item) => item.status === "approved").map(catalogOperation);
}

export function learnedRuntimeInfo() {
  const operations = readStore().operations;
  return {
    enabled: true,
    storePath: STORE_PATH,
    proposed: operations.filter((item) => item.status === "proposed").length,
    approved: operations.filter((item) => item.status === "approved").length,
    disabled: operations.filter((item) => item.status === "disabled").length,
    destructiveLearningEnabled: false,
    approvalSeparationRequired: true,
  };
}

# Vodia MCP 0.11.0 release notes

## Validated phone provisioning

- Added `list_supported_phone_models`, which retrieves the live vendor/model
  catalog used by the Vodia tenant GUI.
- Added `plan_provision_mac`, a guarded planner for
  `POST /rest/domain/{domain}/macs`.
- MAC, extension, vendor and model are mandatory. The planner also requires
  explicit GUI-equivalent choices for SIP transport (`Default`, `TLS`, `TCP`,
  or `UDP`), T.38 (`Default`, `On`, or `Off`), and refresh connection
  (`Automatic`, `No`, or `Yes`). It does not silently choose these values.
- Vendor and model are validated as a pair against the live PBX
  catalog. Matching is case-insensitive, while the request uses the PBX's exact
  canonical spelling.
- MAC addresses accept common separators and are normalized to twelve uppercase
  hexadecimal characters.
- The assigned extension must exist before a plan can be created.
- The plan includes the existing targeted MAC entry and refuses to apply if that
  entry changes between planning and confirmation.
- Applying verifies the targeted MAC entry through a follow-up read.
- The optional device name remains available for every vendor.
- Yealink provisioning additionally requires the full device serial number for
  RPS API V2. The connector exposes this as `serial_number`, maps it to Vodia's
  legacy wire-level `pin` field, and redacts it from plans, responses and audit
  records. A five-digit legacy handset challenge is rejected as incomplete.

The connector does not hard-code phone models. New models become available
automatically when the connected PBX returns them from
`GET /rest/domain/{domain}/button_templates?id=all`.

## Compatibility

- Vodia PBX 70.x
- Existing read and administrator endpoint tokens remain compatible.
- Existing v0.10.1 API, live-call, plan/apply, PCAP and audit behavior remains
  unchanged.

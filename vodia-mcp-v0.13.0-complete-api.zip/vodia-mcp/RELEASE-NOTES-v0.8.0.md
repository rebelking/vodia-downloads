# Vodia MCP 0.8.0 release notes

## Added

- `full` administrator profile for standard and elevated Vodia configuration
- Typed account create/update/delete planners
- Typed SIP-trunk update/rename, enable/disable and delete planners
- Typed dial-plan and tenant-settings planners
- Per-operation policy reporting in the generated 299-operation API catalog
- Optional operation-ID allowlist and denylist
- Write-body size and structural validation
- Exact tier-specific confirmations for normal, destructive and critical plans

## Security defaults

- The read-only and administrator endpoints retain separate bearer tokens.
- All writes use expiring, immutable and single-use plan/apply requests.
- DELETE operations remain disabled until `VODIA_ENABLE_DESTRUCTIVE=true`.
- Critical system writes remain disabled until
  `VODIA_ENABLE_CRITICAL_WRITES=true`.
- Plans, results, audit records and SIP traces redact recognized secrets.

## Compatibility

- Target: Vodia PBX 70.x
- Catalog source: Vodia REST API 70.3
- Runtime: Node.js 18 or newer
- Connector host installer: Ubuntu/Debian with systemd and Caddy
- Client: Codex MCP over HTTPS on macOS, Windows or Linux

## Known API boundary

Vodia REST API 70.3 does not document a create-SIP-trunk operation. v0.8 can
list, read, update/rename, enable/disable and delete existing SIP trunks. It
does not send an undocumented trunk-creation request.

## Verification completed

- JavaScript and shell syntax checks
- Read-only boundary and tenant-isolation tests
- Authentication and endpoint-separation tests
- Account-create plan/apply test
- SIP-trunk rename/update plan/apply test
- Secret-redaction tests
- Exact-confirmation, stale-plan and single-use-plan tests
- Destructive and critical default-deny tests
- Production dependency audit

# Vodia MCP 0.12.0 — supervised learning

Version 0.12.0 adds a persistent, reviewable way to teach the connector a
Vodia REST operation observed in the administrator portal without granting the
model permission to invent or silently enable PBX actions.

## New tools

Administrator/teacher endpoint (`/mcp-admin`):

- `propose_learned_operation`
- `list_learned_operations`
- `inspect_learned_operation`
- `test_learned_read`
- `run_learned_read`
- `plan_learned_write`
- `disable_learned_operation`

Independent approver endpoint (`/mcp-approver`):

- `list_learning_proposals`
- `inspect_learning_proposal`
- `approve_learned_operation`

## Safety boundary

- Teaching stores a definition and evidence; it never sends the captured PBX
  request.
- The teacher identity cannot approve its own proposal.
- The approver has a separate endpoint, bearer token and audit identity.
- Learned DELETE operations, destructive-looking operations, arbitrary URLs,
  path traversal and learned system-level writes are rejected.
- Sensitive body fields must be runtime placeholders. Literal secrets are not
  stored, and evidence notes containing common credentials are rejected.
- Approved learned writes still require `plan_learned_write`, review of the
  immutable request, and `apply_vodia_change` with its exact confirmation.
- Existing destructive and critical operation switches remain `false` by
  default and are unaffected by learning.
- Disabling retains the proposal, evidence and audit trail rather than deleting
  history.

## Persistent state

Approved and proposed definitions are stored in:

```text
/var/lib/vodia-mcp/learned-operations.json
```

The systemd unit uses `StateDirectory=vodia-mcp`; the file is written atomically
with mode `0600`. The learning store survives application-directory upgrades.

## Compatibility

- Upgrade source: Vodia MCP 0.11.0
- Catalog: Vodia REST API 70.3 (299 documented operations)
- Tested runtime: Node.js 18 or newer
- Existing read and administrator endpoint tokens are retained by the upgrade
  script. A new approver token is generated once.

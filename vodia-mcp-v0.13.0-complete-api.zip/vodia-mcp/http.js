#!/usr/bin/env node

import { timingSafeEqual } from "node:crypto";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import express from "express";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import {
  audit,
  callOperation,
  createVodiaServer,
  getRecentActivity,
  getRuntimeInfo,
} from "./index.js";
import { apiCatalog, retrieveCallPcap } from "./admin.js";
import { CONNECTOR_VERSION } from "./version.js";

const projectRoot = dirname(fileURLToPath(import.meta.url));
const port = Number(process.env.PORT || 3100);
const host = process.env.HOST || "127.0.0.1";
const adminToken = process.env.ADMIN_TOKEN || "";
const mcpTokens = (process.env.MCP_BEARER_TOKENS || process.env.MCP_BEARER_TOKEN || "")
  .split(",")
  .map((token) => token.trim())
  .filter(Boolean);
const adminMcpTokens = (process.env.MCP_ADMIN_BEARER_TOKENS || process.env.MCP_ADMIN_BEARER_TOKEN || "")
  .split(",")
  .map((token) => token.trim())
  .filter(Boolean);
const approverMcpTokens = (process.env.MCP_APPROVER_BEARER_TOKENS || process.env.MCP_APPROVER_BEARER_TOKEN || "")
  .split(",")
  .map((token) => token.trim())
  .filter(Boolean);
const adminActor = String(process.env.MCP_ADMIN_ACTOR || "system-admin").trim();
const approverActor = String(process.env.MCP_APPROVER_ACTOR || "human-approver").trim();

if (!adminToken || mcpTokens.length === 0) {
  console.error("[vodia-mcp] ADMIN_TOKEN and MCP_BEARER_TOKEN(S) are required in HTTP mode.");
  process.exit(1);
}
if (!Number.isInteger(port) || port < 1 || port > 65535) {
  console.error("[vodia-mcp] PORT must be a valid TCP port.");
  process.exit(1);
}

const app = express();
app.disable("x-powered-by");
app.set("trust proxy", "loopback");
app.use(express.json({ limit: "1mb" }));

function sameSecret(provided, expected) {
  const left = Buffer.from(String(provided || ""));
  const right = Buffer.from(String(expected || ""));
  return left.length === right.length && timingSafeEqual(left, right);
}

function bearer(req) {
  const value = req.get("authorization") || "";
  return value.startsWith("Bearer ") ? value.slice(7) : "";
}

function requireMcpAuth(req, res, next) {
  const supplied = bearer(req);
  if (!mcpTokens.some((token) => sameSecret(supplied, token))) {
    return res.status(401).json({ error: "Valid MCP bearer token required." });
  }
  next();
}

function requireAdminMcpAuth(req, res, next) {
  const supplied = bearer(req);
  if (!adminMcpTokens.some((token) => sameSecret(supplied, token))) {
    return res.status(401).json({ error: "Valid administrator MCP bearer token required." });
  }
  next();
}

function requireApproverMcpAuth(req, res, next) {
  const supplied = bearer(req);
  if (!approverMcpTokens.some((token) => sameSecret(supplied, token))) {
    return res.status(401).json({ error: "Valid learning-approver MCP bearer token required." });
  }
  next();
}

function requireAdmin(req, res, next) {
  if (!sameSecret(bearer(req), adminToken)) {
    return res.status(401).json({ error: "Valid administrator token required." });
  }
  next();
}

app.get("/health", (_req, res) => {
  res.json({ ok: true, service: "vodia-mcp", version: CONNECTOR_VERSION, mode: adminMcpTokens.length ? (approverMcpTokens.length ? "read-only+policy-controlled-full-admin+supervised-learning" : "read-only+policy-controlled-full-admin") : "strict-read-only" });
});

app.use("/admin", express.static(resolve(projectRoot, "public"), {
  extensions: ["html"],
  index: "index.html",
  maxAge: "5m",
}));
app.get("/", (_req, res) => res.redirect(302, "/admin/"));

app.get("/api/status", requireAdmin, async (_req, res) => {
  const started = Date.now();
  try {
    const result = await callOperation("get_rest_system_status");
    res.json({
      ok: true,
      latencyMs: Date.now() - started,
      runtime: getRuntimeInfo(),
      pbx: result.data,
    });
  } catch (error) {
    res.status(502).json({
      ok: false,
      latencyMs: Date.now() - started,
      runtime: getRuntimeInfo(),
      error: error.message || String(error),
    });
  }
});

app.get("/api/capabilities", requireAdmin, (_req, res) => {
  res.json({
    version: apiCatalog.vodiaApiVersion,
    total: apiCatalog.totalOperations,
    callable: apiCatalog.operations.filter((operation) => operation.callable).length,
    blocked: apiCatalog.operations.filter((operation) => !operation.callable).length,
    counts: apiCatalog.counts,
    operations: apiCatalog.operations.map(({ operationId, method, path, summary, tags, risk, adminTier, callable, blockedReason }) => ({
      operationId,
      method,
      path,
      summary,
      tags,
      risk,
      adminTier,
      callable,
      blockedReason,
    })),
  });
});

app.get("/api/activity", requireAdmin, (req, res) => {
  res.json({ activity: getRecentActivity(req.query.limit) });
});

app.get("/api/pcap/:callId", requireAdmin, async (req, res) => {
  try {
    const domain = String(req.query.domain || "").trim();
    const callId = String(req.params.callId || "").trim();
    if (!domain || !callId) return res.status(400).json({ error: "Both domain and callId are required." });
    audit("download_call_pcap", { actor: adminActor, domain, call_id: callId });
    const { buffer } = await retrieveCallPcap({ domain, callId, callOperation });
    const safeName = callId.replace(/[^A-Za-z0-9._-]+/g, "_").slice(0, 128) || "call";
    res.setHeader("Content-Type", "application/vnd.tcpdump.pcap");
    res.setHeader("Content-Disposition", `attachment; filename="${safeName}.pcap"`);
    res.setHeader("Cache-Control", "no-store");
    return res.send(buffer);
  } catch (error) {
    return res.status(404).json({ error: error.message || String(error) });
  }
});

async function handleMcp(req, res, accessMode) {
  const actor = accessMode === "admin" ? adminActor : accessMode === "approver" ? approverActor : "read-user";
  const server = createVodiaServer({ accessMode, actor });
  const transport = new StreamableHTTPServerTransport({ sessionIdGenerator: undefined });
  let cleanedUp = false;
  const cleanup = async () => {
    if (cleanedUp) return;
    cleanedUp = true;
    await transport.close().catch(() => {});
    await server.close().catch(() => {});
  };
  res.on("close", cleanup);
  try {
    await server.connect(transport);
    await transport.handleRequest(req, res, req.body);
  } catch (error) {
    console.error("[vodia-mcp] HTTP request failed:", error);
    if (!res.headersSent) {
      res.status(500).json({
        jsonrpc: "2.0",
        error: { code: -32603, message: "Internal MCP server error" },
        id: null,
      });
    }
    await cleanup();
  }
}

app.post("/mcp", requireMcpAuth, async (req, res) => handleMcp(req, res, "read"));
app.post("/mcp-admin", requireAdminMcpAuth, async (req, res) => handleMcp(req, res, "admin"));
app.post("/mcp-approver", requireApproverMcpAuth, async (req, res) => handleMcp(req, res, "approver"));

app.all("/mcp", requireMcpAuth, (_req, res) => {
  res.status(405).json({
    jsonrpc: "2.0",
    error: { code: -32000, message: "Method not allowed; use POST." },
    id: null,
  });
});

app.all("/mcp-admin", requireAdminMcpAuth, (_req, res) => {
  res.status(405).json({
    jsonrpc: "2.0",
    error: { code: -32000, message: "Method not allowed; use POST." },
    id: null,
  });
});

app.all("/mcp-approver", requireApproverMcpAuth, (_req, res) => {
  res.status(405).json({
    jsonrpc: "2.0",
    error: { code: -32000, message: "Method not allowed; use POST." },
    id: null,
  });
});

app.use((_req, res) => res.status(404).json({ error: "Not found" }));

const listener = app.listen(port, host, () => {
  console.log(`[vodia-mcp] HTTP server listening on http://${host}:${port}`);
});

for (const signal of ["SIGINT", "SIGTERM"]) {
  process.on(signal, () => listener.close(() => process.exit(0)));
}

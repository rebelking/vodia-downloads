import { unlinkSync } from "node:fs";

const storePath = `/tmp/vodia-mcp-learning-selftest-${process.pid}.json`;
process.env.VODIA_LEARNING_STORE = storePath;

const {
  approveLearnedOperation,
  disableLearnedOperation,
  learnedRuntimeInfo,
  listLearnedOperations,
  materializeLearnedRequest,
  proposeLearnedOperation,
} = await import("../learned.js");

function rejected(fn, pattern) {
  try { fn(); } catch (error) { return pattern.test(String(error?.message || error)); }
  return false;
}

const read = proposeLearnedOperation({
  name: "Read custom domain widget",
  description: "Read the custom widget shown in the tenant portal.",
  method: "GET",
  path: "/rest/domain/{domain}/widget",
  path_parameters: ["domain"],
  query_parameters: ["id"],
  input_parameters: [],
  body_template: {},
  pbx_version: "70.5",
  evidence_source: "Vodia admin portal Network log",
  evidence_note: "Observed a 200 JSON response after opening the custom widget page.",
}, "teacher-codex");

const sameActorBlocked = rejected(() => approveLearnedOperation(read.id, "teacher-codex"), /cannot approve/i);
const approved = approveLearnedOperation(read.id, "human-approver");
const request = materializeLearnedRequest(approved.operationId, {
  pathParams: { domain: "test.example.com" },
  queryParams: { id: "3" },
});

const write = proposeLearnedOperation({
  name: "Update custom domain widget",
  description: "Update a custom reversible widget setting.",
  method: "POST",
  path: "/rest/domain/{domain}/widget",
  path_parameters: ["domain"],
  query_parameters: [],
  input_parameters: ["value", "api_secret"],
  body_template: { value: "{{value}}", secret: "{{api_secret}}" },
  pbx_version: "70.5",
  evidence_source: "Vodia admin portal Network log",
  evidence_note: "Observed the request while saving the reversible widget setting.",
}, "teacher-codex");
approveLearnedOperation(write.id, "human-approver");
const materializedWrite = materializeLearnedRequest(write.operationId, {
  pathParams: { domain: "test.example.com" },
  inputs: { value: "on", api_secret: "runtime-only" },
});

const deleteBlocked = rejected(() => proposeLearnedOperation({
  name: "Delete account",
  description: "Delete an account permanently.",
  method: "DELETE",
  path: "/rest/domain/{domain}/account",
  path_parameters: ["domain"],
  pbx_version: "70.5",
  evidence_source: "portal",
  evidence_note: "Observed delete.",
}, "teacher-codex"), /DELETE is always blocked/i);

const systemWriteBlocked = rejected(() => proposeLearnedOperation({
  name: "Update system widget",
  description: "Update a system setting.",
  method: "POST",
  path: "/rest/system/widget",
  pbx_version: "70.5",
  evidence_source: "portal",
  evidence_note: "Observed save.",
}, "teacher-codex"), /system-level writes are blocked/i);

disableLearnedOperation(read.operationId, "teacher-codex", "Self-test complete");
const info = learnedRuntimeInfo();
const result = {
  proposalStored: read.status === "proposed" && listLearnedOperations().length === 2,
  sameActorApprovalBlocked: sameActorBlocked,
  separateApproverAccepted: approved.status === "approved" && approved.approvedBy === "human-approver",
  learnedReadMaterialized: request.catalog.method === "GET" && request.request.pathParams.domain === "test.example.com",
  runtimeSecretNotPersisted: materializedWrite.request.body.secret === "runtime-only" && !JSON.stringify(listLearnedOperations()).includes("runtime-only"),
  destructiveLearningBlocked: deleteBlocked && info.destructiveLearningEnabled === false,
  systemWriteLearningBlocked: systemWriteBlocked,
  disableRetainsEvidence: listLearnedOperations({ status: "disabled" }).length === 1,
};

console.log(JSON.stringify(result, null, 2));
try { unlinkSync(storePath); } catch {}
if (Object.values(result).some((value) => value !== true)) process.exitCode = 1;

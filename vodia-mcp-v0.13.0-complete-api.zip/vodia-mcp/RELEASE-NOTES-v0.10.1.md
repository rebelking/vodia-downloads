# Vodia MCP 0.10.1 release notes

This hotfix corrects the final installer version check introduced in v0.10.0.
The installer now reads the installed package version from the defined
`APP_DIR` variable, verifies it against `/health`, and completes credential-file
and installation-summary output normally.

A regression assertion now fails the test suite if the undefined
`INSTALL_DIR` variable returns.

All v0.10.0 complete-API, live-call, planning, binary-read, redaction and policy
features remain unchanged.

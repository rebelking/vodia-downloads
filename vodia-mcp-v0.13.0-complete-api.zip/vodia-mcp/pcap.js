const SIP_START = /(?:^|\r?\n)(INVITE|ACK|BYE|CANCEL|OPTIONS|REGISTER|SUBSCRIBE|NOTIFY|REFER|UPDATE|PRACK|INFO|MESSAGE|PUBLISH)\s+sips?:|(?:^|\r?\n)SIP\/2\.0\s+\d{3}/i;

function redactSip(message, includeSdp) {
  let clean = message
    .replace(/^(Authorization|Proxy-Authorization):.*$/gim, "$1: [REDACTED]")
    .replace(/^(P-Asserted-Identity|Remote-Party-ID):.*$/gim, "$1: [REDACTED]")
    .replace(/^(X-[^:]*(?:Token|Secret|Password)[^:]*):.*$/gim, "$1: [REDACTED]");
  if (!includeSdp) {
    const boundary = clean.search(/\r?\n\r?\nv=/);
    if (boundary >= 0) clean = `${clean.slice(0, boundary)}\r\n\r\n[SDP OMITTED]`;
  }
  return clean.trim();
}

function messageSummary(message) {
  const lines = message.split(/\r?\n/);
  const header = (name) => lines.find((line) => line.toLowerCase().startsWith(`${name}:`))?.slice(name.length + 1).trim();
  return {
    startLine: lines[0] || "",
    callId: header("call-id") || header("i") || null,
    from: header("from") || header("f") || null,
    to: header("to") || header("t") || null,
    cseq: header("cseq") || null,
    reason: header("reason") || null,
    userAgent: header("user-agent") || null,
  };
}

export function parseSipFromPcap(buffer, { includeSdp = false, maxMessages = 500 } = {}) {
  if (!Buffer.isBuffer(buffer) || buffer.length < 24) throw new Error("PCAP response is empty or invalid.");
  const magic = buffer.subarray(0, 4).toString("hex");
  const littleEndian = magic === "d4c3b2a1" || magic === "4d3cb2a1";
  const bigEndian = magic === "a1b2c3d4" || magic === "a1b23c4d";
  if (!littleEndian && !bigEndian) throw new Error("Unsupported capture format; expected classic PCAP.");
  const read32 = littleEndian ? Buffer.prototype.readUInt32LE : Buffer.prototype.readUInt32BE;
  const nanoseconds = magic === "4d3cb2a1" || magic === "a1b23c4d";
  const messages = [];
  let offset = 24;
  while (offset + 16 <= buffer.length && messages.length < maxMessages) {
    const seconds = read32.call(buffer, offset);
    const fraction = read32.call(buffer, offset + 4);
    const included = read32.call(buffer, offset + 8);
    offset += 16;
    if (included > buffer.length - offset) break;
    const packet = buffer.subarray(offset, offset + included);
    offset += included;
    const text = packet.toString("latin1");
    const match = SIP_START.exec(text);
    if (!match) continue;
    const start = match.index + (match[0].startsWith("\r\n") ? 2 : match[0].startsWith("\n") ? 1 : 0);
    let sip = text.slice(start).replace(/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\xff]+$/g, "");
    const contentLength = /\r?\nContent-Length:\s*(\d+)/i.exec(sip);
    const separator = sip.search(/\r?\n\r?\n/);
    if (separator >= 0 && contentLength) {
      const separatorLength = sip.slice(separator).startsWith("\r\n\r\n") ? 4 : 2;
      sip = sip.slice(0, separator + separatorLength + Number(contentLength[1]));
    }
    sip = redactSip(sip, includeSdp);
    const milliseconds = seconds * 1000 + fraction / (nanoseconds ? 1_000_000 : 1_000);
    messages.push({ timestamp: new Date(milliseconds).toISOString(), ...messageSummary(sip), raw: sip });
  }
  return messages;
}

export function summarizeSipDialog(messages) {
  const responseCodes = messages
    .map((message) => /^SIP\/2\.0\s+(\d{3})\s*(.*)$/i.exec(message.startLine))
    .filter(Boolean)
    .map((match) => ({ code: Number(match[1]), phrase: match[2] }));
  const finalResponse = [...responseCodes].reverse().find(({ code }) => code >= 300) || null;
  const bye = messages.find((message) => /^BYE\s/i.test(message.startLine));
  const cancel = messages.find((message) => /^CANCEL\s/i.test(message.startLine));
  return {
    messageCount: messages.length,
    callIds: [...new Set(messages.map((message) => message.callId).filter(Boolean))],
    finalFailure: finalResponse,
    termination: bye ? "BYE" : cancel ? "CANCEL" : finalResponse ? "SIP failure response" : "Not determined",
  };
}

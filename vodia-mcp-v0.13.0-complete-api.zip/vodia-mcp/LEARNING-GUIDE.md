# Teaching Vodia MCP safely

Vodia MCP learning is a supervised operation registry. It does not retrain the
language model. It lets an administrator show the connector a sanitized,
repeatable Vodia REST request that was observed in the PBX administrator portal.

## Keep the roles separate

The normal Codex profile receives the `/mcp-admin` token and may propose and
test lessons. It must not receive the `/mcp-approver` token. Keep the approver
token in a separate Codex home/profile or another human-controlled MCP client.
That deployment separation is what prevents the teaching agent from approving
its own lesson.

## Evidence to collect

From the browser Network panel, record only:

- PBX version
- GUI action performed
- HTTP method
- relative `/rest/...` path
- path and query parameter names
- sanitized JSON body structure
- successful response status and the visible GUI result

Never copy the Host, Authorization, Cookie, Set-Cookie or CSRF headers. Never
store passwords, SIP credentials, bearer tokens, sessions, API keys, Yealink
serial numbers, or other device secrets in evidence. Sensitive request fields
must be represented with runtime placeholders such as `{{api_secret}}`.

## Example: teach a custom read

Teacher prompt:

```text
Using only the Vodia administrator MCP, propose a learned GET operation named
"Read custom domain widget" for `/rest/domain/{domain}/widget`. The path
parameter is `domain`; the optional query parameter is `id`. PBX version is
70.5. Evidence source is the Vodia admin portal Network log. Evidence note:
"Observed HTTP 200 JSON after opening the custom widget page." Do not execute
the request and do not approve the proposal.
```

Test prompt:

```text
Using only the Vodia administrator MCP, call test_learned_read for the proposed
operation against tenant example.com with query id 3. Return the response and
recorded test state. Do not approve anything and do not perform a write.
```

Independent approver prompt, run from the separate approver profile:

```text
Using only the Vodia learning approver MCP, inspect the pending proposal
OPERATION_ID. Explain its method, relative path, parameters, evidence, and
safety classification. Do not approve it yet.
```

After human review, approval uses the exact phrase returned by the connector:

```text
APPROVE LEARNING learned_operation_name_xxxxxxxx
```

## Example: teach a reversible write

Use a body template such as:

```json
{
  "setting": "{{setting}}",
  "value": "{{value}}"
}
```

After separate approval, the normal administrator profile calls
`plan_learned_write`. The result is only a plan. Inspect its path, body, tenant,
request hash and required confirmation. The PBX changes only when
`apply_vodia_change` receives the unchanged plan ID and exact confirmation.

## Operations that cannot be taught

- DELETE operations
- operations whose name, description or path looks destructive
- arbitrary or absolute URLs
- paths outside `/rest/domain`, `/rest/user`, `/rest/acd`, or `/rest/system`
- learned writes under `/rest/system`
- traversal, encoded slashes, query strings embedded in paths
- literal credentials or serial numbers in stored evidence/templates

Reviewed destructive operations may exist in the signed release catalog, but
they remain controlled by the separate `VODIA_ENABLE_DESTRUCTIVE` and critical
break-glass settings. Dynamic learning never changes those switches.

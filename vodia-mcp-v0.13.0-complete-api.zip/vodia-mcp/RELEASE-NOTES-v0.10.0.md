# Vodia MCP 0.10.0 release notes

## Complete documented API suite

- Catalogues all 299 Vodia REST API 70.3 operations.
- Exposes 283 normal JSON/action operations through direct reads or plan/apply.
- Exposes 9 binary GET resources through a bounded base64 tool.
- Keeps only seven private, arbitrary or synchronization endpoints unavailable.
- Adds `read_vodia_api` and `read_vodia_binary` to the administrator endpoint.

## Live call control

- Adds `get_account_live_calls` for `GET /rest/user/{account}/calls`.
- Adds `list_tenant_live_calls`, which enumerates tenant extensions, queries
  active call legs with bounded concurrency, and groups matching call IDs.
- Existing answer, hold, resume, reject, transfer and hangup planners now have
  a discoverable read surface for validating their targets.

## Safety and upgrade reliability

- Action-like GET operations now use the same immutable plan/apply workflow as
  POST, PUT and DELETE operations.
- Generic confirmations such as `APPLY` are replaced with operation- and
  target-specific phrases.
- Binary reads enforce explicit byte limits.
- Private keys and authorization-like scalar values receive additional
  redaction.
- The installer always restarts the service after replacing files and fails if
  `/health` does not report the installed package version.

# Vodia MCP 0.13.0

Vodia MCP 0.13.0 turns the official Vodia OpenAPI document into the primary
operation catalog while keeping the existing tenant, policy, approval and audit
boundaries.

## Added

- Request-body schemas, examples, response content types and risk metadata in
  the generated API catalog.
- `inspect_vodia_operation` for examining one imported API operation before it
  is used.
- `get_extension_buttons` and `plan_set_extension_buttons`.
- Complete phone-button profile replacement with explicit
  `REPLACE BUTTONS ...` confirmation, preimage capture, stale-state blocking
  and verification read-back.
- `list_tenant_dids` and `plan_assign_did`.
- DID conflict checks, extension validation, DID-list stale-state protection and
  verification read-back.

## Changed

- SIP transport, T.38 and refresh-connection selections are optional during MAC
  provisioning.
- New MAC entries resolve omitted values to Default, Default and Automatic.
- Existing MAC entries preserve those three current values when omitted.
- Existing device names and non-Yealink provisioning PIN fields are preserved
  on MAC updates when the caller does not replace them.
- The full documented catalog remains available through
  `find_api_capabilities`, `read_vodia_api`, `read_vodia_binary`,
  `plan_vodia_change` and `apply_vodia_change`.

## Safety boundaries

- Button POST is treated as a complete profile replacement, never a one-row
  append.
- Empty button arrays are permitted only through the explicit replacement
  planner and are shown in the plan as a complete clear operation.
- DID support in this release covers the documented assignment operation.
  Undocumented inventory creation, trunk editing, unassignment and deletion are
  not invented.
- Destructive and critical operations retain their independent break-glass
  controls.

## Upgrade

Use `upgrade-vodia-mcp-v0.13.0.sh`. The upgrade preserves
`/etc/vodia-mcp.env`, the supervised-learning store, service configuration and
the previous application directory for rollback.

# Vodia MCP Phase 3.5 — 3CX Migration Assistant + Guarded Tenant Creation

Phase 3.5 adds the first dry-run migration layer for 3CX backups and a controlled test path for creating a fresh Vodia tenant.

## New tools

- `pbx_ai_prepare_3cx_migration` — read-only migration assessment from sanitized normalized analyzer JSON.
- `plan_create_tenant` — guarded tenant-creation plan; performs live duplicate preflight.
- `apply_tenant_change` — exact-confirmation apply plus independent verification.

## Tenant creation API

The verified Vodia tenant creation flow used here is:

- `GET /rest/system/domains` — preflight/list
- `POST /rest/system/domain` with JSON body `["newtenant.example.com"]` — create
- `GET /rest/system/domains` — verify

Phase 3.5 does **not** add tenant deletion.

## 3CX import preparation

On the MCP server:

```bash
sudo /opt/vodia-mcp/prepare-3cx-import.sh /tmp/3cx-test-fixture-sanitized.zip
```

This runs the existing `/root/analyze-3cx-backup.py` by default and writes sanitized normalized JSON to:

```text
/var/lib/vodia-mcp/imports/
```

Then ask Claude/Codex:

> Prepare the 3CX migration from `3cx-test-fixture-sanitized-normalized.json`. Do not create anything yet.

The assistant should use `pbx_ai_prepare_3cx_migration`.

## First tenant smoke test

Use a disposable tenant name, for example:

```text
migrationtest-001.tryvodia.com
```

Ask:

> Plan creation of tenant migrationtest-001.tryvodia.com for a 3CX migration test. Do not apply it.

Review the returned exact confirmation. Only after explicit approval should the client call `apply_tenant_change`.

## Safety

The 3CX migration tool is read-only.
Tenant creation uses an expiring, immutable, single-use plan and:
1. checks the tenant does not exist,
2. requires an exact confirmation,
3. checks again immediately before POST,
4. creates only one tenant,
5. verifies it independently through the tenant list.

No tenant delete or migration-object writes are introduced in this phase.

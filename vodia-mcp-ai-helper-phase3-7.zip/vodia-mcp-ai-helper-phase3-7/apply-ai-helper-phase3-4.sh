#!/usr/bin/env bash
set -Eeuo pipefail

APP_DIR="/opt/vodia-mcp"
BACKUP="/var/backups/vodia-mcp-ai-helper-phase3-4-$(date +%Y%m%d-%H%M%S)"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

[[ ${EUID} -eq 0 ]] || { echo "Run: sudo bash apply-ai-helper-phase3-4.sh"; exit 1; }
[[ -f "$APP_DIR/index.js" ]] || { echo "Missing $APP_DIR/index.js"; exit 1; }
[[ -f "$APP_DIR/workflow-helper.js" ]] || { echo "Phase 3.3 must be installed first."; exit 1; }

echo "[1/5] Backup..."
mkdir -p "$BACKUP"
cp -a "$APP_DIR/index.js" "$BACKUP/index.js"
cp -a "$APP_DIR/workflow-helper.js" "$BACKUP/workflow-helper.js"

echo "[2/5] Install Phase 3.4..."
install -m 0644 "$HERE/index.js" "$APP_DIR/index.js"
install -m 0644 "$HERE/workflow-helper.js" "$APP_DIR/workflow-helper.js"

echo "[3/5] Syntax checks..."
node --check "$APP_DIR/index.js"
node --check "$APP_DIR/workflow-helper.js"

echo "[4/5] Restart..."
systemctl restart vodia-mcp
systemctl is-active --quiet vodia-mcp

echo "[5/5] Complete. Backup: $BACKUP"
echo
echo "New learned dial-plan tools:"
echo "  plan_create_dial_plan"
echo "  apply_dial_plan_change"
echo
echo "No new AWS IAM permissions are required."

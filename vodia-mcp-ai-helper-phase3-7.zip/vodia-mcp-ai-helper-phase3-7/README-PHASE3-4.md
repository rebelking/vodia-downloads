# Vodia MCP Phase 3.4 — Learned Dial-Plan Creation

Phase 3.4 teaches the MCP the dial-plan creation sequence observed in the supplied `dial plan.har`.

## Observed Vodia sequence

1. `POST /rest/domain/{domain}/dialplans`
   - Body: `{"name":"<dial plan name>"}`
   - The PBX returns the newly allocated numeric dial-plan ID.

2. `POST /rest/domain/{domain}/edit_dialplan?dialplan=<id>`
   - Sends the dial-plan settings and `dps` route entries.

3. `GET /rest/domain/{domain}/edit_dialplan?dialplan=<id>`
   - Reads the object back for verification.

The captured route used fields such as:
- `preference`
- `trunk`
- `cmc`
- `pattern`
- `replacement`
- `sf`
- `dis`

## New guarded tools

- `plan_create_dial_plan`
- `apply_dial_plan_change`

The plan tool:
- checks existing dial-plan names,
- reads current tenant trunks,
- resolves a trunk by exact ID/name,
- creates an expiring plan,
- makes **no PBX changes**.

The apply tool:
- requires the exact confirmation,
- creates the dial-plan container,
- configures the rule,
- reads the finished dial plan back,
- verifies name, trunk, pattern, replacement, and preference.

## Important partial-failure behavior

Vodia creation is two-stage. If stage 1 creates a dial-plan ID but stage 2 fails, Phase 3.4 reports the partial dial-plan ID and tells the administrator to review it before retrying. It does not silently retry or delete anything because deletion behavior was not established by the supplied HAR.

## Human-language example

`Create a dial plan called USA for vodiatech.audiomercy.com using Telynx for all calls. Show me the plan first.`

The AI should use the guided workflow to discover live trunks and existing plans, then call `plan_create_dial_plan`. It must wait for explicit approval before `apply_dial_plan_change`.

# Phase 3.7 — Raw 3CX ZIP ingestion

Adds `pbx_ai_ingest_3cx_backup`.

Flow: staged raw ZIP → ZIP safety check → local analyzer → sanitized normalized JSON → inventory/classification → `pbx_ai_prepare_3cx_tenant_conversion`.

Stage a backup:
`sudo bash /opt/vodia-mcp/stage-3cx-backup.sh /tmp/customer.zip`

Then ask the AI:
`Ingest customer.zip and prepare conversion into a new Vodia tenant. Do not create anything yet. Ask only essential questions.`

This phase intentionally separates migration readiness from production-cutover readiness. Missing carrier credentials, DIDs, or emergency routing can block cutover without blocking safe tenant/account creation.

Browser/chat attachment transport to the MCP host is a separate authenticated upload/API surface; Phase 3.7 does not pretend an attachment automatically exists on the server.

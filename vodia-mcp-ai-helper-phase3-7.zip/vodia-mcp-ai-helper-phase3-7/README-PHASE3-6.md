# Vodia MCP Phase 3.6 — 3CX → New Vodia Tenant Wizard

## Product goal

The customer experience should be:

1. Upload a 3CX backup.
2. AI analyzes it.
3. AI asks only essential questions that cannot be safely inferred.
4. AI prepares a NEW Vodia tenant conversion.
5. AI retrieves the actual source objects.
6. AI builds concrete Vodia plans in dependency order.
7. Customer/admin approves.
8. MCP applies guarded changes and verifies them.

Customers should not need to know about normalized JSON, jq, pagination, REST
endpoints, or individual low-level MCP tools.

## New tool

`pbx_ai_prepare_3cx_tenant_conversion`

Inputs:
- `filename`
- `new_tenant`
- `email_policy`
- `trunk_strategy`
- `device_strategy`

The tool is read-only. It returns:
- source counts
- essential unanswered questions
- warnings/blockers
- a dependency-ordered conversion manifest
- instructions to retrieve every concrete object with `pbx_ai_get_3cx_inventory`
- approval and verification requirements

## Important boundary

Phase 3.6 is the orchestration layer over the normalized import already stored on
the MCP host. Raw ZIP upload transport is the next front-end/API step. Do not
pretend a chat attachment is automatically present on the MCP server.

## Recommended first test

Ask:

> Convert `3cx-test-fixture-sanitized-normalized.json` into a NEW Vodia tenant.
> Do not create anything yet. Ask me only the essential questions.

Expected behavior:
- asks for a new tenant domain;
- asks what to do with 9 missing-email users;
- asks how to handle trunks/gateways;
- asks how to handle users with multiple device records;
- never asks the customer to run jq or call low-level MCP tools manually;
- never declares write plans ready until concrete object inventory is retrieved.

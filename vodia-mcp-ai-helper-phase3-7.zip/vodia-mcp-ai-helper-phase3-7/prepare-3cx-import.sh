#!/usr/bin/env bash
set -Eeuo pipefail

BACKUP="${1:-}"
NAME="${2:-}"
IMPORT_DIR="${VODIA_3CX_IMPORT_DIR:-/var/lib/vodia-mcp/imports}"
ANALYZER="${VODIA_3CX_ANALYZER:-/root/analyze-3cx-backup.py}"

[[ ${EUID} -eq 0 ]] || { echo "Run with sudo/root."; exit 1; }
[[ -n "$BACKUP" ]] || { echo "Usage: $0 /path/to/3cx-backup.zip [output-name.json]"; exit 1; }
[[ -f "$BACKUP" ]] || { echo "Backup not found: $BACKUP"; exit 1; }
[[ -f "$ANALYZER" ]] || { echo "Analyzer not found: $ANALYZER"; exit 1; }

if [[ -z "$NAME" ]]; then
  base="$(basename "$BACKUP")"
  NAME="${base%.zip}-normalized.json"
fi
[[ "$NAME" =~ ^[A-Za-z0-9._-]+\.json$ ]] || { echo "Output name must be a simple .json filename."; exit 1; }

install -d -o vodiamcp -g vodiamcp -m 0750 "$IMPORT_DIR"
tmp="$(mktemp)"
trap 'rm -f "$tmp"' EXIT

python3 "$ANALYZER" "$BACKUP" --json-out "$tmp"
python3 -m json.tool "$tmp" >/dev/null
install -o vodiamcp -g vodiamcp -m 0640 "$tmp" "$IMPORT_DIR/$NAME"

echo "Prepared: $IMPORT_DIR/$NAME"
echo "Now ask the MCP to run pbx_ai_prepare_3cx_migration with filename '$NAME'."

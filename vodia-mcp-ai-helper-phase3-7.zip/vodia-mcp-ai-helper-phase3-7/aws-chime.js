import { randomUUID } from "node:crypto";
import {
  ChimeSDKVoiceClient,
  CreateVoiceConnectorCommand,
  GetVoiceConnectorCommand,
  GetVoiceConnectorOriginationCommand,
  GetVoiceConnectorTerminationCommand,
  GetVoiceConnectorTerminationHealthCommand,
  ListAvailableVoiceConnectorRegionsCommand,
  ListVoiceConnectorTerminationCredentialsCommand,
  ListVoiceConnectorsCommand,
  SearchAvailablePhoneNumbersCommand,
  ListPhoneNumbersCommand,
  GetPhoneNumberCommand,
  ListPhoneNumberOrdersCommand,
  GetPhoneNumberOrderCommand,
  CreatePhoneNumberOrderCommand,
  AssociatePhoneNumbersWithVoiceConnectorCommand,

  PutVoiceConnectorTerminationCredentialsCommand,
  PutVoiceConnectorTerminationCommand,
  PutVoiceConnectorOriginationCommand,} from "@aws-sdk/client-chime-sdk-voice";
import { GetCallerIdentityCommand, STSClient } from "@aws-sdk/client-sts";

const DEFAULT_REGION = String(process.env.AWS_CHIME_REGION || process.env.AWS_REGION || process.env.AWS_DEFAULT_REGION || "us-east-1").trim();
const REGION_RE = /^[a-z]{2}(?:-gov)?-[a-z]+-\d$/;
const PLAN_TTL_MS = 5 * 60 * 1000;
const plans = new Map();

const COUNTRY_ALIASES = new Map([
  ["US","US"],["USA","US"],["UNITED STATES","US"],["UNITED STATES OF AMERICA","US"],
  ["CA","CA"],["CANADA","CA"],["JP","JP"],["JAPAN","JP"],["KR","KR"],["KOREA","KR"],["SOUTH KOREA","KR"],
  ["SG","SG"],["SINGAPORE","SG"],["AU","AU"],["AUSTRALIA","AU"],["GB","GB"],["UK","GB"],["UNITED KINGDOM","GB"],
  ["IE","IE"],["IRELAND","IE"],["DE","DE"],["GERMANY","DE"],["FR","FR"],["FRANCE","FR"],["ES","ES"],["SPAIN","ES"],
  ["IT","IT"],["ITALY","IT"],["NL","NL"],["NETHERLANDS","NL"]
]);
const PREFERRED_REGIONS = {
  US:["us-east-1","us-west-2"], CA:["ca-central-1","us-east-1"],
  JP:["ap-northeast-1","ap-northeast-2"], KR:["ap-northeast-2","ap-northeast-1"],
  SG:["ap-southeast-1","ap-northeast-1"], AU:["ap-southeast-2","ap-southeast-1"],
  GB:["eu-west-2","eu-west-1","eu-central-1"], IE:["eu-west-1","eu-west-2","eu-central-1"],
  DE:["eu-central-1","eu-west-1","eu-west-2"], FR:["eu-central-1","eu-west-1","eu-west-2"],
  ES:["eu-central-1","eu-west-1","eu-west-2"], IT:["eu-central-1","eu-west-1","eu-west-2"],
  NL:["eu-central-1","eu-west-1","eu-west-2"]
};

function normalizeRegion(region) {
  const value = String(region || DEFAULT_REGION).trim();
  if (!REGION_RE.test(value)) throw new Error(`Invalid AWS region '${value}'.`);
  return value;
}
function normalizeCountry(country) {
  const key = String(country || "").trim().toUpperCase();
  if (!key) throw new Error("country is required.");
  const code = COUNTRY_ALIASES.get(key) || (/^[A-Z]{2}$/.test(key) ? key : null);
  if (!code) throw new Error(`Country '${country}' is not in the built-in recommendation map. Use an ISO alpha-2 code or specify region explicitly.`);
  return code;
}
function clientOptions(region) { return { region: normalizeRegion(region), maxAttempts: 3 }; }
function voiceClient(region) { return new ChimeSDKVoiceClient(clientOptions(region)); }
function awsError(error) {
  const name = String(error?.name || "AwsError");
  const message = String(error?.message || error || "Unknown AWS error");
  if (name === "CredentialsProviderError") return new Error("AWS credentials were not found. Attach an EC2 IAM role/instance profile and retry.");
  if (name === "AccessDeniedException" || name === "AccessDenied" || name === "UnauthorizedOperation") return new Error(`AWS access denied: ${message}`);
  return new Error(`${name}: ${message}`);
}
function connectorSummary(c, region) {
  return c ? {
    voiceConnectorId:c.VoiceConnectorId||null, voiceConnectorArn:c.VoiceConnectorArn||null, name:c.Name||null,
    outboundHostName:c.OutboundHostName||null, requireEncryption:Boolean(c.RequireEncryption),
    awsRegion:c.AwsRegion||region, networkType:c.NetworkType||null,
    createdTimestamp:c.CreatedTimestamp?.toISOString?.()||c.CreatedTimestamp||null,
    updatedTimestamp:c.UpdatedTimestamp?.toISOString?.()||c.UpdatedTimestamp||null,
  } : null;
}

export function getAwsChimeConfig() {
  return { defaultRegion:DEFAULT_REGION, credentialMode:"AWS SDK v3 default provider chain", explicitAccessKeysRequired:false, phase:2 };
}
export async function testAwsChimeConnection({region}={}) {
  const r=normalizeRegion(region);
  try {
    const identity=await new STSClient(clientOptions(r)).send(new GetCallerIdentityCommand({}));
    const connectors=await voiceClient(r).send(new ListVoiceConnectorsCommand({MaxResults:1}));
    return {connected:true,region:r,identity:{account:identity.Account||null,arn:identity.Arn||null,userId:identity.UserId||null},
      chimeSdkVoice:{accessible:true,voiceConnectorCountSampled:Array.isArray(connectors.VoiceConnectors)?connectors.VoiceConnectors.length:0,hasMore:Boolean(connectors.NextToken)}};
  } catch(e){throw awsError(e);}
}
export async function listAwsChimeVoiceConnectors({region,maxResults=20,nextToken}={}) {
  const r=normalizeRegion(region), m=Math.max(1,Math.min(Number(maxResults)||20,99));
  try {
    const x=await voiceClient(r).send(new ListVoiceConnectorsCommand({MaxResults:m,...(nextToken?{NextToken:String(nextToken)}:{})}));
    return {region:r,voiceConnectors:(x.VoiceConnectors||[]).map(c=>connectorSummary(c,r)),nextToken:x.NextToken||null};
  } catch(e){throw awsError(e);}
}
export async function getAwsChimeVoiceConnector({voiceConnectorId,region}={}) {
  const id=String(voiceConnectorId||"").trim(); if(!id) throw new Error("voiceConnectorId is required."); const r=normalizeRegion(region);
  try { const x=await voiceClient(r).send(new GetVoiceConnectorCommand({VoiceConnectorId:id})); return {region:r,voiceConnector:connectorSummary(x.VoiceConnector,r)}; }
  catch(e){throw awsError(e);}
}
export async function getAwsChimeTermination({voiceConnectorId,region}={}) {
  const id=String(voiceConnectorId||"").trim(); if(!id) throw new Error("voiceConnectorId is required."); const r=normalizeRegion(region);
  try { const x=await voiceClient(r).send(new GetVoiceConnectorTerminationCommand({VoiceConnectorId:id})); return {region:r,voiceConnectorId:id,termination:x.Termination||null}; }
  catch(e){throw awsError(e);}
}
export async function getAwsChimeOrigination({voiceConnectorId,region}={}) {
  const id=String(voiceConnectorId||"").trim(); if(!id) throw new Error("voiceConnectorId is required."); const r=normalizeRegion(region);
  try { const x=await voiceClient(r).send(new GetVoiceConnectorOriginationCommand({VoiceConnectorId:id})); return {region:r,voiceConnectorId:id,origination:x.Origination||null}; }
  catch(e){throw awsError(e);}
}
export async function listAwsChimeTerminationCredentials({voiceConnectorId,region}={}) {
  const id=String(voiceConnectorId||"").trim(); if(!id) throw new Error("voiceConnectorId is required."); const r=normalizeRegion(region);
  try { const x=await voiceClient(r).send(new ListVoiceConnectorTerminationCredentialsCommand({VoiceConnectorId:id}));
    return {region:r,voiceConnectorId:id,usernames:(x.Usernames||[]).map(String),note:"AWS lists usernames but does not return stored SIP passwords."}; }
  catch(e){throw awsError(e);}
}
export async function getAwsChimeTerminationHealth({voiceConnectorId,region}={}) {
  const id=String(voiceConnectorId||"").trim(); if(!id) throw new Error("voiceConnectorId is required."); const r=normalizeRegion(region);
  try { const x=await voiceClient(r).send(new GetVoiceConnectorTerminationHealthCommand({VoiceConnectorId:id}));
    return {region:r,voiceConnectorId:id,terminationHealth:x.TerminationHealth||null}; }
  catch(e){throw awsError(e);}
}
export async function listAwsChimeAvailableRegions({region}={}) {
  const r=normalizeRegion(region);
  try { const x=await voiceClient(r).send(new ListAvailableVoiceConnectorRegionsCommand({})); return {lookupRegion:r,regions:(x.VoiceConnectorRegions||[]).map(String)}; }
  catch(e){throw awsError(e);}
}
export async function recommendAwsChimeRegion({country,region}={}) {
  const cc=normalizeCountry(country), available=await listAwsChimeAvailableRegions({region}), set=new Set(available.regions);
  const prefs=PREFERRED_REGIONS[cc]||["us-east-1","us-west-2"];
  const recommendedRegion=prefs.find(x=>set.has(x))||available.regions[0]||null;
  if(!recommendedRegion) throw new Error("AWS returned no available Voice Connector regions.");
  return {country:String(country),countryCode:cc,recommendedRegion,preferredCandidates:prefs,availableRegions:available.regions,validatedAgainstAws:true};
}

function normalizePhoneNumber(value) {
  const phone = String(value || "").trim();
  if (!/^\+[1-9]\d{7,14}$/.test(phone)) throw new Error(`Phone number '${phone}' must be E.164.`);
  return phone;
}

function phoneSummary(p) {
  return p ? {
    phoneNumberId: p.PhoneNumberId || null,
    e164PhoneNumber: p.E164PhoneNumber || null,
    country: p.Country || null,
    type: p.Type || null,
    productType: p.ProductType || null,
    status: p.Status || null,
    capabilities: p.Capabilities || null,
    associations: p.Associations || [],
    callingName: p.CallingName || null,
    callingNameStatus: p.CallingNameStatus || null,
    createdTimestamp: p.CreatedTimestamp?.toISOString?.() || p.CreatedTimestamp || null,
    updatedTimestamp: p.UpdatedTimestamp?.toISOString?.() || p.UpdatedTimestamp || null,
  } : null;
}

export async function searchAwsChimeAvailablePhoneNumbers({ areaCode, city, state, country="US", phoneNumberType="Local", maxResults=20, region } = {}) {
  const r = normalizeRegion(region);
  const input = {
    MaxResults: Math.max(1, Math.min(Number(maxResults) || 20, 500)),
    ...(areaCode ? { AreaCode: String(areaCode).trim() } : {}),
    ...(city ? { City: String(city).trim() } : {}),
    ...(state ? { State: String(state).trim() } : {}),
    ...(country ? { Country: String(country).trim().toUpperCase() } : {}),
    ...(phoneNumberType ? { PhoneNumberType: String(phoneNumberType) } : {}),
  };
  try {
    const x = await voiceClient(r).send(new SearchAvailablePhoneNumbersCommand(input));
    return { region:r, query:input, phoneNumbers:(x.E164PhoneNumbers || []).map(String) };
  } catch (e) { throw awsError(e); }
}

export async function listAwsChimePhoneNumbers({ region, maxResults=20, nextToken } = {}) {
  const r = normalizeRegion(region);
  try {
    const x = await voiceClient(r).send(new ListPhoneNumbersCommand({
      MaxResults: Math.max(1, Math.min(Number(maxResults) || 20, 99)),
      ...(nextToken ? { NextToken:String(nextToken) } : {}),
    }));
    return { region:r, phoneNumbers:(x.PhoneNumbers || []).map(phoneSummary), nextToken:x.NextToken || null };
  } catch (e) { throw awsError(e); }
}

export async function getAwsChimePhoneNumber({ phoneNumber, region } = {}) {
  const value = String(phoneNumber || "").trim();
  if (!value) throw new Error("phoneNumber is required.");
  const r = normalizeRegion(region);
  let id = value;
  if (value.startsWith("+")) {
    const inv = await listAwsChimePhoneNumbers({ region:r, maxResults:99 });
    const hit = inv.phoneNumbers.find(p => p.e164PhoneNumber === value);
    if (!hit?.phoneNumberId) throw new Error(`Phone number '${value}' was not found in this AWS account inventory.`);
    id = hit.phoneNumberId;
  }
  try {
    const x = await voiceClient(r).send(new GetPhoneNumberCommand({ PhoneNumberId:id }));
    return { region:r, phoneNumber:phoneSummary(x.PhoneNumber) };
  } catch (e) { throw awsError(e); }
}

function orderSummary(o) {
  return o ? {
    phoneNumberOrderId:o.PhoneNumberOrderId || null,
    productType:o.ProductType || null,
    status:o.Status || null,
    orderType:o.OrderType || null,
    orderedPhoneNumbers:(o.OrderedPhoneNumbers || []).map(p => ({
      e164PhoneNumber:p.E164PhoneNumber || null,
      status:p.Status || null,
    })),
    createdTimestamp:o.CreatedTimestamp?.toISOString?.() || o.CreatedTimestamp || null,
    updatedTimestamp:o.UpdatedTimestamp?.toISOString?.() || o.UpdatedTimestamp || null,
  } : null;
}

export async function listAwsChimePhoneNumberOrders({ region, maxResults=20, nextToken } = {}) {
  const r = normalizeRegion(region);
  try {
    const x = await voiceClient(r).send(new ListPhoneNumberOrdersCommand({
      MaxResults:Math.max(1, Math.min(Number(maxResults) || 20, 99)),
      ...(nextToken ? { NextToken:String(nextToken) } : {}),
    }));
    return { region:r, orders:(x.PhoneNumberOrders || []).map(orderSummary), nextToken:x.NextToken || null };
  } catch (e) { throw awsError(e); }
}

export async function getAwsChimePhoneNumberOrder({ orderId, region } = {}) {
  const id = String(orderId || "").trim();
  if (!id) throw new Error("orderId is required.");
  const r = normalizeRegion(region);
  try {
    const x = await voiceClient(r).send(new GetPhoneNumberOrderCommand({ PhoneNumberOrderId:id }));
    return { region:r, order:orderSummary(x.PhoneNumberOrder) };
  } catch (e) { throw awsError(e); }
}

export async function planAwsChimeOrderPhoneNumber({ actor, phoneNumber, region } = {}) {
  const phone = normalizePhoneNumber(phoneNumber);
  const r = normalizeRegion(region);
  const areaCode = phone.startsWith("+1") ? phone.slice(2,5) : undefined;
  const available = await searchAwsChimeAvailablePhoneNumbers({ areaCode, country: phone.startsWith("+1") ? "US" : undefined, maxResults:99, region:r });
  if (!available.phoneNumbers.includes(phone)) throw new Error(`Phone number '${phone}' is not currently returned by AWS as available.`);
  const changeId=`aws-chime-${randomUUID()}`, expiresAt=new Date(Date.now()+PLAN_TTL_MS);
  const confirmation=`ORDER AWS CHIME NUMBER ${phone}`;
  plans.set(changeId, {
    changeId, actor:String(actor || "unknown"), operation:"CreatePhoneNumberOrder",
    expiresAt, used:false, confirmation, region:r,
    request:{ ProductType:"VoiceConnector", E164PhoneNumbers:[phone] }
  });
  return {
    changeId, operation:"CreatePhoneNumberOrder", expiresAt:expiresAt.toISOString(), phoneNumber:phone, region:r,
    request:{ ProductType:"VoiceConnector", E164PhoneNumbers:[phone] },
    requiredConfirmation:confirmation, changesAws:false
  };
}

export async function planAwsChimeAssignPhoneNumber({ actor, phoneNumber, voiceConnectorId, region } = {}) {
  const phone = normalizePhoneNumber(phoneNumber);
  const vc = String(voiceConnectorId || "").trim();
  if (!vc) throw new Error("voiceConnectorId is required.");
  const r = normalizeRegion(region);
  const phoneInfo = await getAwsChimePhoneNumber({ phoneNumber:phone, region:r });
  const connector = await getAwsChimeVoiceConnector({ voiceConnectorId:vc, region:r });
  if ((phoneInfo.phoneNumber?.associations || []).length) {
    throw new Error(`Phone number '${phone}' already has an AWS association. Force reassignment is disabled.`);
  }
  const changeId=`aws-chime-${randomUUID()}`, expiresAt=new Date(Date.now()+PLAN_TTL_MS);
  const confirmation=`ASSIGN ${phone} TO AWS CHIME CONNECTOR ${vc}`;
  plans.set(changeId, {
    changeId, actor:String(actor || "unknown"), operation:"AssociatePhoneNumbersWithVoiceConnector",
    expiresAt, used:false, confirmation, region:r,
    request:{ VoiceConnectorId:vc, E164PhoneNumbers:[phone], ForceAssociate:false },
    targetConnectorName:connector.voiceConnector?.name || null
  });
  return {
    changeId, operation:"AssociatePhoneNumbersWithVoiceConnector", expiresAt:expiresAt.toISOString(),
    phoneNumber:phone, voiceConnectorId:vc, voiceConnectorName:connector.voiceConnector?.name || null,
    region:r, forceAssociate:false, requiredConfirmation:confirmation, changesAws:false
  };
}


function normalizeStringList(values, field) {
  if (values === undefined || values === null) return undefined;
  if (!Array.isArray(values)) throw new Error(`${field} must be an array.`);
  return values.map((v) => String(v).trim()).filter(Boolean);
}

function normalizeOriginationRoutes(routes) {
  if (routes === undefined || routes === null) return undefined;
  if (!Array.isArray(routes) || !routes.length) throw new Error("routes must be a non-empty array.");
  return routes.map((route, index) => {
    const host = String(route?.host || "").trim();
    if (!host) throw new Error(`routes[${index}].host is required.`);
    const port = Number(route?.port ?? 5060);
    const priority = Number(route?.priority ?? 1);
    const weight = Number(route?.weight ?? 1);
    const protocol = String(route?.protocol || "TCP").trim().toUpperCase();
    if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error(`routes[${index}].port must be 1-65535.`);
    if (!Number.isInteger(priority) || priority < 1 || priority > 100) throw new Error(`routes[${index}].priority must be 1-100.`);
    if (!Number.isInteger(weight) || weight < 1 || weight > 100) throw new Error(`routes[${index}].weight must be 1-100.`);
    if (!["TCP","UDP"].includes(protocol)) throw new Error(`routes[${index}].protocol must be TCP or UDP.`);
    return { Host:host, Port:port, Priority:priority, Protocol:protocol, Weight:weight };
  });
}

export async function planAwsChimeSetTerminationCredentials({ actor, voiceConnectorId, username, password, region } = {}) {
  const vc = String(voiceConnectorId || "").trim();
  const user = String(username || "").trim();
  const secret = String(password || "");
  if (!vc) throw new Error("voiceConnectorId is required.");
  if (!user) throw new Error("username is required.");
  if (!secret) throw new Error("password is required.");
  if (secret.length < 8) throw new Error("password must be at least 8 characters.");
  if (secret.length > 256) throw new Error("password is too long.");
  const r = normalizeRegion(region);
  await getAwsChimeVoiceConnector({ voiceConnectorId: vc, region: r });

  const changeId=`aws-chime-${randomUUID()}`, expiresAt=new Date(Date.now()+PLAN_TTL_MS);
  const confirmation=`SET AWS CHIME CREDENTIAL ${user} ON ${vc}`;
  plans.set(changeId,{
    changeId,actor:String(actor||"unknown"),operation:"PutVoiceConnectorTerminationCredentials",
    expiresAt,used:false,confirmation,region:r,
    request:{VoiceConnectorId:vc,Credentials:[{Username:user,Password:secret}]},
    summary:{voiceConnectorId:vc,username:user,password:"[REDACTED]"}
  });
  return {
    changeId,operation:"PutVoiceConnectorTerminationCredentials",expiresAt:expiresAt.toISOString(),
    region:r,voiceConnectorId:vc,username:user,password:"[REDACTED]",
    requiredConfirmation:confirmation,changesAws:false
  };
}

export async function planAwsChimeUpdateTermination({
  actor, voiceConnectorId, callingRegions, cidrAllowedList, cpsLimit, defaultPhoneNumber, disabled, region
} = {}) {
  const vc = String(voiceConnectorId || "").trim();
  if (!vc) throw new Error("voiceConnectorId is required.");
  const r = normalizeRegion(region);
  await getAwsChimeVoiceConnector({ voiceConnectorId: vc, region: r });

  const termination = {};
  const regions = normalizeStringList(callingRegions, "callingRegions");
  const cidrs = normalizeStringList(cidrAllowedList, "cidrAllowedList");
  if (regions) termination.CallingRegions = regions;
  if (cidrs) termination.CidrAllowedList = cidrs;
  if (cpsLimit !== undefined) {
    const cps = Number(cpsLimit);
    if (!Number.isInteger(cps) || cps < 1 || cps > 100) throw new Error("cpsLimit must be an integer from 1 through 100.");
    termination.CpsLimit = cps;
  }
  if (defaultPhoneNumber) termination.DefaultPhoneNumber = normalizePhoneNumber(defaultPhoneNumber);
  if (disabled !== undefined) termination.Disabled = Boolean(disabled);
  if (!Object.keys(termination).length) throw new Error("At least one termination field is required.");

  const changeId=`aws-chime-${randomUUID()}`, expiresAt=new Date(Date.now()+PLAN_TTL_MS);
  const confirmation=`UPDATE AWS CHIME TERMINATION ${vc}`;
  plans.set(changeId,{
    changeId,actor:String(actor||"unknown"),operation:"PutVoiceConnectorTermination",
    expiresAt,used:false,confirmation,region:r,
    request:{VoiceConnectorId:vc,Termination:termination},
    summary:{voiceConnectorId:vc,termination}
  });
  return {
    changeId,operation:"PutVoiceConnectorTermination",expiresAt:expiresAt.toISOString(),
    region:r,voiceConnectorId:vc,termination,requiredConfirmation:confirmation,changesAws:false
  };
}

export async function planAwsChimeUpdateOrigination({ actor, voiceConnectorId, disabled, routes, region } = {}) {
  const vc = String(voiceConnectorId || "").trim();
  if (!vc) throw new Error("voiceConnectorId is required.");
  const r = normalizeRegion(region);
  await getAwsChimeVoiceConnector({ voiceConnectorId: vc, region: r });

  const origination = {};
  if (disabled !== undefined) origination.Disabled = Boolean(disabled);
  const normalizedRoutes = normalizeOriginationRoutes(routes);
  if (normalizedRoutes) origination.Routes = normalizedRoutes;
  if (!Object.keys(origination).length) throw new Error("At least one origination field is required.");

  const changeId=`aws-chime-${randomUUID()}`, expiresAt=new Date(Date.now()+PLAN_TTL_MS);
  const confirmation=`UPDATE AWS CHIME ORIGINATION ${vc}`;
  plans.set(changeId,{
    changeId,actor:String(actor||"unknown"),operation:"PutVoiceConnectorOrigination",
    expiresAt,used:false,confirmation,region:r,
    request:{VoiceConnectorId:vc,Origination:origination},
    summary:{voiceConnectorId:vc,origination}
  });
  return {
    changeId,operation:"PutVoiceConnectorOrigination",expiresAt:expiresAt.toISOString(),
    region:r,voiceConnectorId:vc,origination,requiredConfirmation:confirmation,changesAws:false
  };
}

export async function planAwsChimeCreateVoiceConnector({actor,name,deploymentCountry,region,requireEncryption=true,networkType="IPV4_ONLY"}={}) {
  const a=String(actor||"unknown"), n=String(name||"").trim(); if(!n) throw new Error("name is required."); if(n.length>256) throw new Error("name exceeds 256 characters.");
  const cc=normalizeCountry(deploymentCountry);
  let awsRegion;
  if(region) {
    awsRegion=normalizeRegion(region);
    const available=await listAwsChimeAvailableRegions({region:awsRegion});
    if(!available.regions.includes(awsRegion)) throw new Error(`AWS region '${awsRegion}' is not currently available for Voice Connectors.`);
  } else {
    awsRegion=(await recommendAwsChimeRegion({country:cc})).recommendedRegion;
  }
  if(!["IPV4_ONLY","DUAL_STACK"].includes(networkType)) throw new Error("networkType must be IPV4_ONLY or DUAL_STACK.");
  const changeId=`aws-chime-${randomUUID()}`, expiresAt=new Date(Date.now()+PLAN_TTL_MS);
  const confirmation=`CREATE AWS CHIME CONNECTOR ${n} IN ${awsRegion}`;
  plans.set(changeId,{changeId,actor:a,operation:"CreateVoiceConnector",expiresAt,used:false,confirmation,
    request:{Name:n,AwsRegion:awsRegion,RequireEncryption:Boolean(requireEncryption),NetworkType:networkType},deploymentCountry:cc});
  return {changeId,operation:"CreateVoiceConnector",expiresAt:expiresAt.toISOString(),deploymentCountry:cc,awsRegion,
    request:{Name:n,AwsRegion:awsRegion,RequireEncryption:Boolean(requireEncryption),NetworkType:networkType},
    requiredConfirmation:confirmation,changesAws:false,
    guidance:"Review this plan. Apply only with aws_chime_apply_change and the exact requiredConfirmation before expiry."};
}
export async function applyAwsChimeChange({actor,changeId,confirmation}={}) {
  const id=String(changeId||"").trim(), p=plans.get(id); if(!p) throw new Error("Unknown or expired AWS Chime change plan.");
  if(p.used) throw new Error("This AWS Chime change plan has already been used.");
  if(Date.now()>p.expiresAt.getTime()){plans.delete(id);throw new Error("This AWS Chime change plan has expired.");}
  if(String(actor||"unknown")!==p.actor) throw new Error("This AWS Chime change plan belongs to a different authenticated actor.");
  if(String(confirmation||"")!==p.confirmation) throw new Error(`Confirmation mismatch. Required exact confirmation: ${p.confirmation}`);
  p.used=true;
  try {
    if (p.operation === "CreateVoiceConnector") {
      const x=await voiceClient(p.request.AwsRegion).send(new CreateVoiceConnectorCommand(p.request));
      plans.delete(id);
      return {changeId:id,operation:p.operation,region:p.request.AwsRegion,deploymentCountry:p.deploymentCountry,voiceConnector:connectorSummary(x.VoiceConnector,p.request.AwsRegion)};
    }
    if (p.operation === "CreatePhoneNumberOrder") {
      const x=await voiceClient(p.region).send(new CreatePhoneNumberOrderCommand(p.request));
      plans.delete(id);
      return {changeId:id,operation:p.operation,region:p.region,order:orderSummary(x.PhoneNumberOrder)};
    }
    if (p.operation === "AssociatePhoneNumbersWithVoiceConnector") {
      const x=await voiceClient(p.region).send(new AssociatePhoneNumbersWithVoiceConnectorCommand(p.request));
      plans.delete(id);
      return {changeId:id,operation:p.operation,region:p.region,phoneNumberErrors:x.PhoneNumberErrors || []};
    }

    if (p.operation === "PutVoiceConnectorTerminationCredentials") {
      await voiceClient(p.region).send(new PutVoiceConnectorTerminationCredentialsCommand(p.request));
      plans.delete(id);
      return {
        changeId:id, operation:p.operation, region:p.region,
        voiceConnectorId:p.request.VoiceConnectorId,
        username:p.request.Credentials?.[0]?.Username || null,
        password:"[REDACTED]"
      };
    }
    if (p.operation === "PutVoiceConnectorTermination") {
      const x = await voiceClient(p.region).send(new PutVoiceConnectorTerminationCommand(p.request));
      plans.delete(id);
      return {
        changeId:id, operation:p.operation, region:p.region,
        voiceConnectorId:p.request.VoiceConnectorId,
        termination:x.Termination || p.request.Termination
      };
    }
    if (p.operation === "PutVoiceConnectorOrigination") {
      const x = await voiceClient(p.region).send(new PutVoiceConnectorOriginationCommand(p.request));
      plans.delete(id);
      return {
        changeId:id, operation:p.operation, region:p.region,
        voiceConnectorId:p.request.VoiceConnectorId,
        origination:x.Origination || p.request.Origination
      };
    }
    throw new Error(`Unsupported AWS Chime plan operation '${p.operation}'.`);
  } catch(e){plans.delete(id);throw awsError(e);}
}

# Vodia MCP Phase 3.5.2 — 3CX Users Mapping + Dependency Guard

## Fixes

The 3CX analyzer emits account records under `users`. Phase 3.5.1 recognized the
overall JSON shape but counted only `extensions`, causing a false result of
0 extensions with 71 phones.

Phase 3.5.2:
- recognizes both `extensions` and `users`;
- uses non-empty `extensions` first, otherwise `users`;
- reports `sourceShape.extensionSourceKey`;
- blocks migration readiness if account-dependent objects exist but zero users/extensions parse;
- improves installer health checking with a retry loop.

## Expected fixture result

The sanitized fixture should now report approximately:
- 41 extensions/users
- 71 phones
- 3 ring groups
- 1 queue
- 6 IVRs
- 2 trunks
- 2 gateways
- 7 outbound rules
- 4 groups
- 15 park orbits
- 1 fax
- 1 conference
- 9 extensions/users without email

## Retest

Ask:

> Prepare the 3CX migration from `3cx-test-fixture-sanitized-normalized.json`.
> Target tenant is `vodiatech.audiomercy.com`. Skip trunks for first pass.
> Do not create anything yet.

It should ask for the missing-email policy before declaring the migration ready.

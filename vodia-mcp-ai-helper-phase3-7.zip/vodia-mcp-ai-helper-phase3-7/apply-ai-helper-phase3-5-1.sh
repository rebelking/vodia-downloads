#!/usr/bin/env bash
set -Eeuo pipefail

APP_DIR="/opt/vodia-mcp"
BACKUP="/var/backups/vodia-mcp-ai-helper-phase3-5-1-$(date +%Y%m%d-%H%M%S)"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

[[ ${EUID} -eq 0 ]] || { echo "Run: sudo bash apply-ai-helper-phase3-5-1.sh"; exit 1; }
[[ -f "$APP_DIR/index.js" ]] || { echo "Missing $APP_DIR/index.js"; exit 1; }
[[ -f "$APP_DIR/workflow-helper.js" ]] || { echo "Phase 3.5 must be installed first."; exit 1; }

echo "[1/6] Backup..."
mkdir -p "$BACKUP"
cp -a "$APP_DIR/index.js" "$BACKUP/index.js"
cp -a "$APP_DIR/workflow-helper.js" "$BACKUP/workflow-helper.js"

echo "[2/6] Install Phase 3.5.1..."
install -m 0644 "$HERE/index.js" "$APP_DIR/index.js"
install -m 0644 "$HERE/workflow-helper.js" "$APP_DIR/workflow-helper.js"

echo "[3/6] Syntax..."
node --check "$APP_DIR/index.js"
node --check "$APP_DIR/workflow-helper.js"

echo "[4/6] Check migration schema detector..."
grep -q 'find3cxConfigObject' "$APP_DIR/index.js" || {
  echo "Missing 3CX schema detector."
  exit 1
}

echo "[5/6] Restart..."
systemctl restart vodia-mcp
systemctl is-active --quiet vodia-mcp

echo "[6/6] Health..."
curl -fsS http://127.0.0.1:3100/health >/dev/null

echo "Complete. Backup: $BACKUP"
echo
echo "Phase 3.5.1 fixes:"
echo "  - discovers nested analyzer configuration objects instead of assuming one wrapper key"
echo "  - reports detected JSON config path and keys"
echo "  - blocks truly empty/unrecognized migration payloads instead of silently returning zero inventory"

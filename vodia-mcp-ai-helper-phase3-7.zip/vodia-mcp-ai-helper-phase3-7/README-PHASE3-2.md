# Vodia MCP Phase 3.2 — Amazon Chime credentials, termination, and origination

Adds guarded Chime write planning for:

- `aws_chime_plan_set_termination_credentials`
- `aws_chime_plan_update_termination`
- `aws_chime_plan_update_origination`

All changes still execute only through the existing `aws_chime_apply_change` gate.

## Security

The SIP password is accepted only by the plan call, kept inside the short-lived in-memory plan, never returned in clear text, and audit output receives `[REDACTED]`.

## IAM

Merge `aws-chime-phase3-2-policy.json` into `VodiaMCPChimeRolePolicy`.

New actions:
- `chime:PutVoiceConnectorTerminationCredentials`
- `chime:PutVoiceConnectorTermination`
- `chime:PutVoiceConnectorOrigination`

## Test

Ask the AI:

`Set up Amazon Chime for vodiatech.audiomercy.com. Check the connector, credentials, termination, origination, phone number, and Vodia trunk. Do not apply anything until every prerequisite is ready.`

If a credential password must be replaced, the AI should create a guarded credential plan instead of stopping because AWS previously lacked a password-write capability.

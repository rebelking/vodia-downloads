#!/usr/bin/env bash
set -Eeuo pipefail

APP_DIR="/opt/vodia-mcp"
BACKUP="/var/backups/vodia-mcp-ai-helper-phase3-4-1-$(date +%Y%m%d-%H%M%S)"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

[[ ${EUID} -eq 0 ]] || { echo "Run: sudo bash apply-ai-helper-phase3-4-1.sh"; exit 1; }
[[ -f "$APP_DIR/index.js" ]] || { echo "Missing $APP_DIR/index.js"; exit 1; }
[[ -f "$APP_DIR/admin.js" ]] || { echo "Missing $APP_DIR/admin.js"; exit 1; }
[[ -f "$APP_DIR/workflow-helper.js" ]] || { echo "Phase 3.x must be installed first."; exit 1; }

echo "[1/6] Backup..."
mkdir -p "$BACKUP"
cp -a "$APP_DIR/index.js" "$BACKUP/index.js"
cp -a "$APP_DIR/workflow-helper.js" "$BACKUP/workflow-helper.js"
cp -a "$APP_DIR/admin.js" "$BACKUP/admin.js"

echo "[2/6] Verify authoritative dial-plan tool exists in admin.js..."
grep -q 'registerTool("plan_create_dial_plan"' "$APP_DIR/admin.js" || {
  echo "Existing authoritative plan_create_dial_plan was not found in admin.js."
  exit 1
}
grep -q 'registerTool("plan_update_dial_plan"' "$APP_DIR/admin.js" || {
  echo "Existing authoritative plan_update_dial_plan was not found in admin.js."
  exit 1
}

echo "[3/6] Install Phase 3.4.1..."
install -m 0644 "$HERE/index.js" "$APP_DIR/index.js"
install -m 0644 "$HERE/workflow-helper.js" "$APP_DIR/workflow-helper.js"

echo "[4/6] Syntax + duplicate-registration checks..."
node --check "$APP_DIR/index.js"
node --check "$APP_DIR/workflow-helper.js"
COUNT_INDEX="$(grep -c '"plan_create_dial_plan"' "$APP_DIR/index.js" || true)"
if [[ "$COUNT_INDEX" -ne 0 ]]; then
  echo "Refusing restart: index.js still registers/references duplicate plan_create_dial_plan tool name ($COUNT_INDEX match(es))."
  exit 1
fi

echo "[5/6] Restart..."
systemctl restart vodia-mcp
systemctl is-active --quiet vodia-mcp

echo "[6/6] Health..."
curl -fsS http://127.0.0.1:3100/health >/dev/null

echo "Complete. Backup: $BACKUP"
echo
echo "Phase 3.4.1:"
echo "  - removes duplicate plan_create_dial_plan registration from index.js"
echo "  - keeps admin.js as the single authoritative dial-plan planner"
echo "  - guided AI uses create -> apply -> update rules -> apply -> verify"

#!/usr/bin/env bash
set -Eeuo pipefail
APP=/opt/vodia-mcp; HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACK="/var/backups/vodia-mcp-ai-helper-phase3-7-$(date +%Y%m%d-%H%M%S)"
[[ $EUID -eq 0 ]] || { echo "Run with sudo"; exit 1; }
[[ -f /root/analyze-3cx-backup.py ]] || { echo "Missing /root/analyze-3cx-backup.py"; exit 1; }
echo "[1/7] Backup..."; mkdir -p "$BACK"; cp -a "$APP/index.js" "$BACK/index.js"
echo "[2/7] Install..."; install -m 0644 "$HERE/index.js" "$APP/index.js"; install -m 0755 "$HERE/stage-3cx-backup.sh" "$APP/stage-3cx-backup.sh"
echo "[3/7] Directories..."; install -d -m 0750 /var/lib/vodia-mcp/3cx-raw-imports /var/lib/vodia-mcp/imports
echo "[4/7] Syntax..."; node --check "$APP/index.js"; bash -n "$APP/stage-3cx-backup.sh"
echo "[5/7] Verify..."; grep -q '"pbx_ai_ingest_3cx_backup"' "$APP/index.js"; grep -q '"pbx_ai_prepare_3cx_tenant_conversion"' "$APP/index.js"
echo "[6/7] Restart..."; systemctl restart vodia-mcp
echo "[7/7] Health..."
for i in {1..15}; do systemctl is-active --quiet vodia-mcp && curl -fsS http://127.0.0.1:3100/health >/dev/null && { echo "Complete. Backup: $BACK"; exit 0; }; sleep 1; done
systemctl status vodia-mcp --no-pager -l || true; journalctl -u vodia-mcp -n 80 --no-pager -l || true; exit 1

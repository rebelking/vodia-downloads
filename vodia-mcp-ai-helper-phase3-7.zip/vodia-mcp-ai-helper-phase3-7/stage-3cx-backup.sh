#!/usr/bin/env bash
set -Eeuo pipefail
SRC="${1:-}"; RAW="/var/lib/vodia-mcp/3cx-raw-imports"
[[ -f "$SRC" ]] || { echo "Usage: sudo bash stage-3cx-backup.sh /path/file.zip"; exit 1; }
case "$SRC" in *.zip|*.ZIP) ;; *) echo "Input must be .zip"; exit 1;; esac
install -d -m 0750 "$RAW"
install -m 0640 "$SRC" "$RAW/$(basename "$SRC")"
echo "Staged: $RAW/$(basename "$SRC")"

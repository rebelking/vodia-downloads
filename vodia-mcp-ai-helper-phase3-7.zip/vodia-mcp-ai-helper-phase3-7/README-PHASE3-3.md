# Vodia MCP Phase 3.3 — Guided Administrator Workflows

Adds:

- `pbx_ai_prepare_guided_workflow`

The purpose is simple: administrators describe what they want in normal language. The MCP discovers what it can from the PBX and asks only for essential information it cannot safely infer.

## Standard behavior

`HUMAN INTENT → DISCOVER → ASK ONLY WHAT IS MISSING → RECOMMEND → PLAN → APPROVAL → APPLY → VERIFY → REPORT`

The guided preparation tool is read-only. It never makes changes.

## Extension workflow

For a new extension, the normal human inputs are:

- tenant/domain
- first name
- last name
- extension number
- email
- MAC address (optional unless a desk phone must be provisioned immediately)

The MCP automatically checks the visible tenant list, the tenant-wide account namespace for number conflicts, and current extension state. It should not ask for low-level PBX fields that can be defaulted safely.

## Dial-plan workflow

The normal questions are:

- tenant
- what the dial plan should accomplish
- what users should dial
- which trunk/provider to use only when the MCP cannot safely choose

Before asking about a trunk, the MCP reads current trunks and dial plans and can recommend an obvious single choice.

## Other guided workflows

Definitions are included for:

- SIP trunks
- DID routing
- queues
- IVR/auto attendant
- phone provisioning
- voicemail
- Amazon Chime

## Safety

Phase 3.3 does not bypass any write gate. It prepares context only. Existing guarded plan/apply tools remain authoritative.

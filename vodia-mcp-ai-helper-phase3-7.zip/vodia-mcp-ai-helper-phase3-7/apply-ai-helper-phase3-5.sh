#!/usr/bin/env bash
set -Eeuo pipefail

APP_DIR="/opt/vodia-mcp"
IMPORT_DIR="${VODIA_3CX_IMPORT_DIR:-/var/lib/vodia-mcp/imports}"
BACKUP="/var/backups/vodia-mcp-ai-helper-phase3-5-$(date +%Y%m%d-%H%M%S)"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

[[ ${EUID} -eq 0 ]] || { echo "Run: sudo bash apply-ai-helper-phase3-5.sh"; exit 1; }
[[ -f "$APP_DIR/index.js" ]] || { echo "Missing $APP_DIR/index.js"; exit 1; }
[[ -f "$APP_DIR/workflow-helper.js" ]] || { echo "Phase 3.x must be installed first."; exit 1; }

echo "[1/6] Backup..."
mkdir -p "$BACKUP"
cp -a "$APP_DIR/index.js" "$BACKUP/index.js"
cp -a "$APP_DIR/workflow-helper.js" "$BACKUP/workflow-helper.js"

echo "[2/6] Install Phase 3.5..."
install -m 0644 "$HERE/index.js" "$APP_DIR/index.js"
install -m 0644 "$HERE/workflow-helper.js" "$APP_DIR/workflow-helper.js"
install -m 0755 "$HERE/prepare-3cx-import.sh" "$APP_DIR/prepare-3cx-import.sh"
install -d -o vodiamcp -g vodiamcp -m 0750 "$IMPORT_DIR"

echo "[3/6] Syntax..."
node --check "$APP_DIR/index.js"
node --check "$APP_DIR/workflow-helper.js"
bash -n "$APP_DIR/prepare-3cx-import.sh"

echo "[4/6] Duplicate tool sanity..."
for tool in plan_create_tenant apply_tenant_change pbx_ai_prepare_3cx_migration; do
  count="$(grep -c "\"$tool\"" "$APP_DIR/index.js" || true)"
  [[ "$count" -ge 1 ]] || { echo "Missing tool $tool"; exit 1; }
done

echo "[5/6] Restart..."
systemctl restart vodia-mcp
systemctl is-active --quiet vodia-mcp

echo "[6/6] Health..."
curl -fsS http://127.0.0.1:3100/health >/dev/null

echo "Complete. Backup: $BACKUP"
echo
echo "New Phase 3.5 tools:"
echo "  pbx_ai_prepare_3cx_migration"
echo "  plan_create_tenant"
echo "  apply_tenant_change"
echo
echo "3CX import directory: $IMPORT_DIR"
echo "Helper: $APP_DIR/prepare-3cx-import.sh"

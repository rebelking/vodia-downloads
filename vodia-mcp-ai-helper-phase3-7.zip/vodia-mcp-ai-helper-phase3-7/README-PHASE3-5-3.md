# Vodia MCP Phase 3.5.3 — Object-Level 3CX Migration Inventory

Phase 3.5.2 fixed `users -> extensions`. Phase 3.5.3 fixes the next migration blocker:
the AI previously had counts but not the actual source objects needed to build
reviewable Vodia plans.

## New tool

`pbx_ai_get_3cx_inventory`

Arguments:
- `filename`
- `category`
- `offset`
- `limit`

Categories:
- `users`
- `extensions`
- `phones`
- `ring_groups`
- `queues`
- `ivrs`
- `trunks`
- `gateways`
- `outbound_rules`
- `groups`
- `park_orbits`
- `fax_extensions`
- `conference_extensions`

The tool is read-only and paginated. It returns the real normalized source
objects, not invented values.

The analyzer already sanitizes credentials. Phase 3.5.3 additionally redacts
credential-looking fields before returning objects to the model.

## Expected AI behavior

1. Run `pbx_ai_prepare_3cx_migration`.
2. Resolve target tenant and migration decisions.
3. Retrieve actual source objects through `pbx_ai_get_3cx_inventory`.
4. Build dependency-aware Vodia plans from those exact objects.
5. Never plan a MAC, queue member, IVR destination, park orbit, fax account,
   conference account, or dial-plan rule from counts alone.
6. Keep every write behind the existing guarded approval path.

## Test

Ask Claude:

> Prepare the 3CX migration from `3cx-test-fixture-sanitized-normalized.json`.
> Target tenant is `vodiatech.audiomercy.com`.
> Skip trunks for the first pass.
> Create users without email for the 9 missing-email users.
> Retrieve the actual extension/user inventory and show me the first 10 objects.
> Do not create anything.

Then request the phone, ring-group, queue, IVR, outbound-rule, park-orbit,
fax, and conference inventories as needed.

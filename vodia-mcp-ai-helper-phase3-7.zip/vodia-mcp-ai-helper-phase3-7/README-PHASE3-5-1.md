# Vodia MCP Phase 3.5.1 — 3CX normalized JSON schema fix

Phase 3.5 correctly loaded the normalized JSON file but assumed the migration
arrays lived at `configuration`, `config`, or the JSON root. The test fixture
proved that the analyzer output can wrap the actual PBX configuration differently.

That caused a false all-zero inventory even though the analyzer had already
reported 41 extensions, 71 phones, ring groups, queues, IVRs, trunks, outbound
rules, and other migration objects.

## Fix

`pbx_ai_prepare_3cx_migration` now:

1. checks known wrapper names,
2. recursively scans nested JSON objects (bounded depth),
3. chooses the object containing the greatest number of known migration arrays,
4. reports the detected `configPath` and `availableKeys`,
5. refuses to treat a truly empty recognized payload as a normal `NEEDS_INPUT` result.

No migration writes are added in 3.5.1.

## Retest

After installing, run the exact same prompt against the same normalized file:

> Prepare the 3CX migration from `3cx-test-fixture-sanitized-normalized.json`. Do not create anything yet.

Expected inventory for the fixture should include approximately:

- 41 extensions
- 71 phones
- 3 ring groups
- 1 queue
- 6 IVRs
- 2 trunks/external lines
- 2 gateways
- 7 outbound rules
- 4 groups
- 15 park orbits
- 1 fax extension
- 1 conference extension

It should also ask how to handle the 9 extensions without email and how to
handle trunks/gateways.

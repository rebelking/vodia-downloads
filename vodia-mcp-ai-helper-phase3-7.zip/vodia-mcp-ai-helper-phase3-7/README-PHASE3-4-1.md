# Vodia MCP Phase 3.4.1 — Dial-plan duplicate registration fix

## Why this patch exists

Phase 3.4 registered `plan_create_dial_plan` in `index.js`, but the installed Vodia MCP already registers the same tool in `admin.js`.

The MCP SDK rejects duplicate tool names during session initialization, causing `/mcp-admin` to return HTTP 500.

## Fix

Phase 3.4.1 removes the duplicate tool registration from `index.js`.

`admin.js` remains the single authoritative owner of:
- `plan_create_dial_plan`
- `plan_update_dial_plan`
- `apply_vodia_change`

The AI helper still uses the workflow learned from the HAR/API:

1. Discover existing dial plans and trunks.
2. Ask only essential human questions.
3. `plan_create_dial_plan`
4. Explicit approval.
5. `apply_vodia_change` and capture the new dial-plan ID.
6. `plan_update_dial_plan` with the desired route/rules.
7. Explicit approval.
8. `apply_vodia_change`
9. Read back and verify.

This keeps the existing MCP safety architecture intact and avoids a second private plan store.

## After installation

Verify the service and initialization:

```bash
sudo systemctl status vodia-mcp --no-pager -l
curl -fsS http://127.0.0.1:3100/health ; echo
sudo journalctl -u vodia-mcp -n 50 --no-pager -l
```

The journal must no longer contain `Tool plan_create_dial_plan is already registered` after the new restart.

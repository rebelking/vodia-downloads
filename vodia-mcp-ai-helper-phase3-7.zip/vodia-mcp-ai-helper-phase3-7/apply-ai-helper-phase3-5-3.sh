#!/usr/bin/env bash
set -Eeuo pipefail
APP_DIR="/opt/vodia-mcp"
BACKUP="/var/backups/vodia-mcp-ai-helper-phase3-5-3-$(date +%Y%m%d-%H%M%S)"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

[[ ${EUID} -eq 0 ]] || { echo "Run: sudo bash apply-ai-helper-phase3-5-3.sh"; exit 1; }
[[ -f "$APP_DIR/index.js" ]] || { echo "Missing $APP_DIR/index.js"; exit 1; }

echo "[1/6] Backup..."
mkdir -p "$BACKUP"
cp -a "$APP_DIR/index.js" "$BACKUP/index.js"
[[ -f "$APP_DIR/workflow-helper.js" ]] && cp -a "$APP_DIR/workflow-helper.js" "$BACKUP/workflow-helper.js"

echo "[2/6] Install Phase 3.5.3..."
install -m 0644 "$HERE/index.js" "$APP_DIR/index.js"

echo "[3/6] Syntax..."
node --check "$APP_DIR/index.js"

echo "[4/6] Verify inventory tool..."
grep -q '"pbx_ai_get_3cx_inventory"' "$APP_DIR/index.js"
grep -q 'get3cxInventoryCategory' "$APP_DIR/index.js"

echo "[5/6] Restart..."
systemctl restart vodia-mcp

echo "[6/6] Wait for health..."
ok=0
for i in {1..15}; do
  if systemctl is-active --quiet vodia-mcp && curl -fsS http://127.0.0.1:3100/health >/dev/null 2>&1; then
    ok=1
    break
  fi
  sleep 1
done
[[ "$ok" -eq 1 ]] || {
  echo "Service did not become healthy."
  systemctl status vodia-mcp --no-pager -l || true
  journalctl -u vodia-mcp -n 50 --no-pager -l || true
  exit 1
}

echo "Complete. Backup: $BACKUP"
echo
echo "New read-only migration inventory tool:"
echo "  pbx_ai_get_3cx_inventory"

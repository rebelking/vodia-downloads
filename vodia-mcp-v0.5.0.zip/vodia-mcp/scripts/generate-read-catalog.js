#!/usr/bin/env node

import { mkdir, readFile, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import YAML from "yaml";

const OFFICIAL_SPEC_URL = "https://doc.vodia.com/openapi/vodia-rest-api.yaml";
const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const outputPath = resolve(projectRoot, "generated/read-catalog.json");

const ACTION_LIKE_GETS = [
  /^\/rest\/acd\/\{account\}\/email\//,
  /^\/rest\/hunt\/\{account\}\/email\//,
  /^\/rest\/system\/testemail$/,
  /^\/rest\/user\/\{account\}\/check-sync$/,
];

const BINARY_OR_OVERSIZED_GETS = [
  /\/wave\//,
  /^\/rest\/system\/pcap$/,
  /^\/rest\/user\/\{account\}\/message\/\{message_id\}$/,
  /^\/rest\/account\/\{account\}\/alias\/\{id\}$/,
];

function resolveRef(document, value) {
  if (!value?.$ref?.startsWith("#/")) return value;
  return value.$ref
    .slice(2)
    .split("/")
    .map((part) => part.replace(/~1/g, "/").replace(/~0/g, "~"))
    .reduce((current, key) => current?.[key], document);
}

function classify(path, operation) {
  if (ACTION_LIKE_GETS.some((rule) => rule.test(path))) {
    return {
      callable: false,
      reason: "The OpenAPI operation uses GET but performs an external action.",
    };
  }

  if (BINARY_OR_OVERSIZED_GETS.some((rule) => rule.test(path))) {
    return {
      callable: false,
      reason: "Binary or potentially oversized content is not returned through the JSON MCP reader.",
    };
  }

  const summary = String(operation.summary || "");
  if (/^send\b|^trigger\b/i.test(summary)) {
    return {
      callable: false,
      reason: "The operation description indicates that it performs an action.",
    };
  }

  return { callable: true, reason: null };
}

async function loadSpec() {
  const fileFlagIndex = process.argv.indexOf("--spec-file");
  if (fileFlagIndex !== -1) {
    const requestedPath = process.argv[fileFlagIndex + 1];
    if (!requestedPath) throw new Error("--spec-file requires a path");
    return readFile(resolve(requestedPath), "utf8");
  }

  const response = await fetch(OFFICIAL_SPEC_URL, {
    headers: { Accept: "application/yaml, text/yaml, text/plain" },
    signal: AbortSignal.timeout(30_000),
  });
  if (!response.ok) {
    throw new Error(`Unable to fetch Vodia OpenAPI specification: HTTP ${response.status}`);
  }
  return response.text();
}

const source = await loadSpec();
const document = YAML.parse(source);
const operations = [];

for (const [path, pathItem] of Object.entries(document.paths || {})) {
  const operation = pathItem?.get;
  if (!operation) continue;

  const parameters = [...(pathItem.parameters || []), ...(operation.parameters || [])]
    .map((parameter) => resolveRef(document, parameter))
    .filter(Boolean)
    .map((parameter) => ({
      name: parameter.name,
      in: parameter.in,
      required: Boolean(parameter.required),
      description: parameter.description || null,
      type: parameter.schema?.type || "string",
      enum: parameter.schema?.enum || null,
      example: parameter.example ?? null,
    }));

  const classification = classify(path, operation);
  operations.push({
    operationId: operation.operationId || `get_${path.replace(/[^a-z0-9]+/gi, "_")}`,
    method: "GET",
    path,
    summary: operation.summary || `Read ${path}`,
    description: operation.description || null,
    tags: operation.tags || [],
    parameters,
    callable: classification.callable,
    blockedReason: classification.reason,
  });
}

operations.sort((a, b) => a.operationId.localeCompare(b.operationId));

const result = {
  generatedAt: new Date().toISOString(),
  source: OFFICIAL_SPEC_URL,
  openapiVersion: document.openapi || null,
  vodiaApiVersion: document.info?.version || null,
  totalGetOperations: operations.length,
  callableOperations: operations.filter((operation) => operation.callable).length,
  blockedOperations: operations.filter((operation) => !operation.callable).length,
  operations,
};

await mkdir(dirname(outputPath), { recursive: true });
await writeFile(outputPath, `${JSON.stringify(result, null, 2)}\n`, "utf8");
console.log(
  `Generated ${result.totalGetOperations} GET operations ` +
    `(${result.callableOperations} callable, ${result.blockedOperations} blocked) ` +
    `for Vodia API ${result.vodiaApiVersion}.`
);

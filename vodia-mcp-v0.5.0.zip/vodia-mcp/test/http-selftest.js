import http from "node:http";
import { spawn } from "node:child_process";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StreamableHTTPClientTransport } from "@modelcontextprotocol/sdk/client/streamableHttp.js";

const mockPbx = http.createServer((request, response) => {
  response.setHeader("content-type", "application/json");
  if (request.url === "/rest/system/status") {
    return response.end(JSON.stringify({ status: "ok", password: "must-redact" }));
  }
  if (request.url === "/rest/system/domains") {
    return response.end(JSON.stringify([{ name: "remote.example.com" }]));
  }
  response.statusCode = 404;
  response.end(JSON.stringify({ error: request.url }));
});

await new Promise((resolve) => mockPbx.listen(0, "127.0.0.1", resolve));
const pbxPort = mockPbx.address().port;
const httpPort = 32000 + Math.floor(Math.random() * 1000);
const child = spawn(process.execPath, ["http.js"], {
  cwd: process.cwd(),
  env: {
    ...process.env,
    VODIA_URL: `http://127.0.0.1:${pbxPort}`,
    VODIA_USER: "mcp-api",
    VODIA_PASS: "test-pass",
    MCP_BEARER_TOKEN: "test-mcp-token",
    ADMIN_TOKEN: "test-admin-token",
    PORT: String(httpPort),
  },
  stdio: ["ignore", "pipe", "pipe"],
});

let startupLog = "";
child.stdout.on("data", (chunk) => { startupLog += chunk.toString(); });
child.stderr.on("data", (chunk) => { startupLog += chunk.toString(); });

for (let attempt = 0; attempt < 60; attempt += 1) {
  if (startupLog.includes("HTTP server listening")) break;
  if (child.exitCode !== null) throw new Error(`HTTP server exited early: ${startupLog}`);
  await new Promise((resolve) => setTimeout(resolve, 50));
}

const baseUrl = `http://127.0.0.1:${httpPort}`;
const unauthorized = await fetch(`${baseUrl}/api/status`);
const dashboard = await fetch(`${baseUrl}/admin/`);
const adminStatus = await fetch(`${baseUrl}/api/status`, {
  headers: { Authorization: "Bearer test-admin-token" },
}).then((response) => response.json());

const transport = new StreamableHTTPClientTransport(new URL(`${baseUrl}/mcp`), {
  requestInit: { headers: { Authorization: "Bearer test-mcp-token" } },
});
const client = new Client({ name: "vodia-http-selftest", version: "1.0.0" });

try {
  await client.connect(transport);
  const tools = await client.listTools();
  const domains = await client.callTool({ name: "list_domains", arguments: {} });
  const result = {
    unauthorizedAdminBlocked: unauthorized.status === 401,
    dashboardServed: dashboard.ok && (await dashboard.text()).includes("Vodia MCP Control Center"),
    adminPbxTestWorked: adminStatus.ok === true && adminStatus.pbx?.password === "[REDACTED]",
    streamableHttpConnected: tools.tools.length >= 15,
    bearerProtectedToolWorked: domains.structuredContent?.data?.[0]?.name === "remote.example.com",
  };
  console.log(JSON.stringify(result, null, 2));
  if (Object.values(result).some((value) => value !== true)) process.exitCode = 1;
} finally {
  await client.close().catch(() => {});
  child.kill("SIGTERM");
  await new Promise((resolve) => child.once("exit", resolve));
  await new Promise((resolve) => mockPbx.close(resolve));
}

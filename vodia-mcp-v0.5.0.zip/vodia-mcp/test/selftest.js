import http from "node:http";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StdioClientTransport } from "@modelcontextprotocol/sdk/client/stdio.js";

const expectedAuthorization = `Basic ${Buffer.from("mcp-api:test-pass").toString("base64")}`;
let badAuthorization = false;

const mockPbx = http.createServer((request, response) => {
  if (request.headers.authorization !== expectedAuthorization) badAuthorization = true;
  response.setHeader("content-type", "application/json");

  if (request.url === "/rest/system/domains") {
    return response.end(JSON.stringify([{ name: "test.example.com" }]));
  }
  if (request.url?.startsWith("/rest/acd/333%40test.example.com/stat")) {
    return response.end(JSON.stringify({ answered: 8, abandoned: 2 }));
  }
  if (request.url === "/rest/system/config") {
    return response.end(
      JSON.stringify({ name: "lab", api_secret: "hidden", nested: { password: "hidden" } })
    );
  }

  response.statusCode = 404;
  return response.end(JSON.stringify({ error: request.url }));
});

await new Promise((resolve) => mockPbx.listen(0, "127.0.0.1", resolve));
const { port } = mockPbx.address();

const transport = new StdioClientTransport({
  command: process.execPath,
  args: ["index.js"],
  cwd: process.cwd(),
  env: {
    ...process.env,
    VODIA_URL: `http://127.0.0.1:${port}`,
    VODIA_USER: "mcp-api",
    VODIA_PASS: "test-pass",
  },
  stderr: "pipe",
});

const client = new Client({ name: "vodia-mcp-selftest", version: "1.0.0" });

try {
  await client.connect(transport);
  const tools = await client.listTools();
  const domains = await client.callTool({ name: "list_domains", arguments: {} });
  const queue = await client.callTool({
    name: "get_queue_stats",
    arguments: { account: "333@test.example.com", date: "2026-08-01", days: 7 },
  });
  const config = await client.callTool({
    name: "read_vodia_resource",
    arguments: { operation_id: "get_rest_system_config" },
  });
  const search = await client.callTool({
    name: "find_read_capabilities",
    arguments: { query: "queue statistics", limit: 10 },
  });
  const blocked = await client.callTool({
    name: "read_vodia_resource",
    arguments: { operation_id: "get_rest_system_testemail" },
  });

  const result = {
    basicAuthCorrect: !badAuthorization,
    allToolsReadOnly: tools.tools.every((tool) => tool.annotations?.readOnlyHint === true),
    noDestructiveTools: tools.tools.every((tool) => tool.annotations?.destructiveHint !== true),
    domainReadWorked: domains.structuredContent?.data?.[0]?.name === "test.example.com",
    queueReadWorked: queue.structuredContent?.data?.answered === 8,
    secretsRedacted:
      config.structuredContent?.data?.api_secret === "[REDACTED]" &&
      config.structuredContent?.data?.nested?.password === "[REDACTED]",
    catalogSearchWorked: search.structuredContent?.data?.length > 0,
    actionLikeGetBlocked: blocked.isError === true,
  };

  console.log(JSON.stringify(result, null, 2));
  if (Object.values(result).some((value) => value !== true)) process.exitCode = 1;
} finally {
  await client.close();
  await new Promise((resolve) => mockPbx.close(resolve));
}

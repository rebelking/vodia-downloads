#!/usr/bin/env node

/**
 * Vodia PBX MCP Server — read-only v0.5
 *
 * Exposes the official Vodia v70 OpenAPI GET surface through:
 *   1. Focused, high-value PBX tools for routine support work.
 *   2. A searchable read capability catalog.
 *   3. A universal GET reader restricted to that generated allowlist.
 *
 * No POST, PUT, PATCH or DELETE tool is registered in this build.
 */

import { readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { pathToFileURL } from "node:url";
import { fileURLToPath } from "node:url";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";

const projectRoot = dirname(fileURLToPath(import.meta.url));
export const catalog = JSON.parse(
  readFileSync(resolve(projectRoot, "generated/read-catalog.json"), "utf8")
);

const PBX_URL = (process.env.VODIA_URL || "").replace(/\/+$/, "");
const PBX_USER = process.env.VODIA_USER || "";
const PBX_PASS = process.env.VODIA_PASS || "";
const REQUEST_TIMEOUT_MS = readPositiveInteger("VODIA_TIMEOUT_MS", 30_000, 1_000, 120_000);
const RESPONSE_LIMIT_BYTES = readPositiveInteger(
  "VODIA_RESPONSE_LIMIT_BYTES",
  2_000_000,
  10_000,
  10_000_000
);

if (/^true$/i.test(process.env.VODIA_INSECURE || "")) {
  process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
  console.error("[vodia-mcp] WARNING: TLS certificate verification is disabled (lab use only).");
}

if (!PBX_URL || !PBX_USER || !PBX_PASS) {
  console.error("[vodia-mcp] VODIA_URL, VODIA_USER and VODIA_PASS are required.");
  process.exit(1);
}

const operationsById = new Map(
  catalog.operations.map((operation) => [operation.operationId, operation])
);

const parameterValueSchema = z.union([z.string(), z.number(), z.boolean()]);
const parameterMapSchema = z.record(z.string(), parameterValueSchema);
const toolOutputSchema = {
  data: z.any(),
  meta: z.record(z.string(), z.any()),
};

const SENSITIVE_KEY = /(?:^|_)(?:pass(?:word)?|secret|token|credential|authorization|session|cookie|pin|private_key|api_key|oauth)(?:$|_)/i;

function readPositiveInteger(name, fallback, minimum, maximum) {
  const raw = Number(process.env[name] || fallback);
  if (!Number.isInteger(raw) || raw < minimum || raw > maximum) {
    console.error(
      `[vodia-mcp] ${name} must be an integer from ${minimum} through ${maximum}.`
    );
    process.exit(1);
  }
  return raw;
}

function redactSensitive(value, depth = 0) {
  if (depth > 30) return "[MAX_DEPTH]";
  if (Array.isArray(value)) return value.map((item) => redactSensitive(item, depth + 1));
  if (!value || typeof value !== "object") return value;

  const output = {};
  for (const [key, item] of Object.entries(value)) {
    output[key] = SENSITIVE_KEY.test(key)
      ? "[REDACTED]"
      : redactSensitive(item, depth + 1);
  }
  return output;
}

function audit(tool, details = {}) {
  const cleanDetails = redactSensitive(details);
  recentActivity.unshift({
    timestamp: new Date().toISOString(),
    tool,
    details: cleanDetails,
  });
  recentActivity.splice(100);
  console.error(
    `[vodia-mcp][${new Date().toISOString()}][read] ${tool} ${JSON.stringify(cleanDetails)}`
  );
}

const recentActivity = [];

export function getRecentActivity(limit = 25) {
  return recentActivity.slice(0, Math.max(1, Math.min(Number(limit) || 25, 100)));
}

function success(data, meta, message) {
  return {
    structuredContent: { data, meta },
    content: [{ type: "text", text: message }],
  };
}

function failure(error) {
  return {
    content: [{ type: "text", text: `Vodia read failed: ${error.message || error}` }],
    isError: true,
  };
}

async function readLimitedBody(response) {
  const declaredLength = Number(response.headers.get("content-length") || 0);
  if (declaredLength > RESPONSE_LIMIT_BYTES) {
    throw new Error(
      `Response is ${declaredLength} bytes; limit is ${RESPONSE_LIMIT_BYTES} bytes. Narrow the query.`
    );
  }

  if (!response.body) return "";
  const reader = response.body.getReader();
  const chunks = [];
  let total = 0;

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    total += value.byteLength;
    if (total > RESPONSE_LIMIT_BYTES) {
      await reader.cancel();
      throw new Error(
        `Response exceeded ${RESPONSE_LIMIT_BYTES} bytes. Narrow the query or page size.`
      );
    }
    chunks.push(value);
  }

  const joined = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) {
    joined.set(chunk, offset);
    offset += chunk.byteLength;
  }
  return new TextDecoder().decode(joined);
}

function buildRequest(operation, pathParams = {}, queryParams = {}) {
  if (!operation) throw new Error("Unknown Vodia read operation.");
  if (operation.method !== "GET") throw new Error("Only GET operations are available.");
  if (!operation.callable) {
    throw new Error(
      `Operation '${operation.operationId}' is blocked: ${operation.blockedReason}`
    );
  }

  const requiredPathParameters = [...operation.path.matchAll(/\{([^}]+)\}/g)].map(
    (match) => match[1]
  );
  const suppliedPathParameters = Object.keys(pathParams);
  const unknownPathParameters = suppliedPathParameters.filter(
    (name) => !requiredPathParameters.includes(name)
  );
  if (unknownPathParameters.length) {
    throw new Error(`Unknown path parameter(s): ${unknownPathParameters.join(", ")}`);
  }

  let path = operation.path;
  for (const name of requiredPathParameters) {
    const value = pathParams[name];
    if (value === undefined || value === null || String(value).trim() === "") {
      throw new Error(`Missing required path parameter '${name}'.`);
    }
    path = path.replace(`{${name}}`, encodeURIComponent(String(value)));
  }

  const allowedQueryParameters = new Set(
    operation.parameters
      .filter((parameter) => parameter.in === "query")
      .map((parameter) => parameter.name)
  );
  const unknownQueryParameters = Object.keys(queryParams).filter(
    (name) => !allowedQueryParameters.has(name)
  );
  if (unknownQueryParameters.length) {
    throw new Error(
      `Unsupported query parameter(s) for ${operation.operationId}: ${unknownQueryParameters.join(", ")}`
    );
  }

  const url = new URL(`${PBX_URL}${path}`);
  for (const [name, value] of Object.entries(queryParams)) {
    if (value !== undefined && value !== null && String(value) !== "") {
      url.searchParams.set(name, String(value));
    }
  }

  return { url, path };
}

export async function callOperation(operationId, { pathParams = {}, queryParams = {} } = {}) {
  const operation = operationsById.get(operationId);
  const { url, path } = buildRequest(operation, pathParams, queryParams);
  const authorization = Buffer.from(`${PBX_USER}:${PBX_PASS}`, "utf8").toString("base64");

  const response = await fetch(url, {
    method: "GET",
    headers: {
      Accept: "application/json, text/plain;q=0.9",
      Authorization: `Basic ${authorization}`,
      "User-Agent": "vodia-mcp-readonly/0.5.0",
    },
    signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
  });

  const body = await readLimitedBody(response);
  if (!response.ok) {
    throw new Error(
      `Vodia API GET ${path} returned HTTP ${response.status}: ${body.slice(0, 400)}`
    );
  }

  const contentType = response.headers.get("content-type") || "";
  let data;
  if (/json/i.test(contentType)) {
    try {
      data = body ? JSON.parse(body) : {};
    } catch {
      throw new Error(`Vodia returned invalid JSON for ${operationId}.`);
    }
  } else {
    data = { text: body };
  }

  return {
    data: redactSensitive(data),
    meta: {
      operationId,
      method: "GET",
      path: operation.path,
      summary: operation.summary,
      vodiaApiVersion: catalog.vodiaApiVersion,
      redactionApplied: true,
    },
  };
}

export function createVodiaServer() {
const server = new McpServer(
  { name: "vodia-pbx-readonly", version: "0.5.0" },
  {
    instructions:
      "This connector is strictly read-only. Use focused status and analytics tools first. " +
      "Use find_read_capabilities before read_vodia_resource for less common Vodia data. " +
      "Never claim that a read changed PBX configuration. Sensitive fields are redacted.",
  }
);

function registerPbXReadTool(name, definition, operationId, mapArguments) {
  server.registerTool(
    name,
    {
      title: definition.title,
      description: definition.description,
      inputSchema: definition.inputSchema,
      outputSchema: toolOutputSchema,
      annotations: {
        readOnlyHint: true,
        destructiveHint: false,
        openWorldHint: false,
      },
    },
    async (args) => {
      audit(name, args);
      try {
        const result = await callOperation(operationId, mapArguments(args || {}));
        return success(
          result.data,
          result.meta,
          `${definition.title} completed using read-only Vodia data.`
        );
      } catch (error) {
        return failure(error);
      }
    }
  );
}

registerPbXReadTool(
  "get_system_status",
  {
    title: "Get PBX system status",
    description: "Check Vodia PBX health, version and current system status.",
    inputSchema: {},
  },
  "get_rest_system_status",
  () => ({})
);

registerPbXReadTool(
  "list_domains",
  {
    title: "List Vodia tenants",
    description: "List all tenant domains visible to the configured PBX API account.",
    inputSchema: {},
  },
  "get_rest_system_domains",
  () => ({})
);

registerPbXReadTool(
  "list_extensions",
  {
    title: "List tenant extensions",
    description: "List extension accounts in a Vodia tenant or retrieve one extension by account number.",
    inputSchema: {
      domain: z.string().min(1),
      account: z.string().min(1).optional(),
    },
  },
  "get_rest_domain_domain_extensions_3",
  ({ domain, account }) => ({
    pathParams: { domain },
    queryParams: account ? { account } : {},
  })
);

registerPbXReadTool(
  "list_registrations",
  {
    title: "List SIP and push registrations",
    description: "Show registered phones, apps and push registrations for a Vodia tenant.",
    inputSchema: { domain: z.string().min(1) },
  },
  "get_rest_domain_domain_registrations",
  ({ domain }) => ({ pathParams: { domain } })
);

registerPbXReadTool(
  "list_trunks",
  {
    title: "List tenant trunks",
    description: "List SIP trunks configured for a Vodia tenant.",
    inputSchema: { domain: z.string().min(1) },
  },
  "get_rest_domain_domain_domain_trunks",
  ({ domain }) => ({ pathParams: { domain } })
);

registerPbXReadTool(
  "list_dialplans",
  {
    title: "List tenant dial plans",
    description: "List dial plans configured for a Vodia tenant.",
    inputSchema: { domain: z.string().min(1) },
  },
  "get_rest_domain_domain_dialplans",
  ({ domain }) => ({ pathParams: { domain } })
);

registerPbXReadTool(
  "get_tenant_cdrs",
  {
    title: "Get tenant CDRs",
    description: "Get a paginated set of tenant call detail records for troubleshooting or charting.",
    inputSchema: {
      domain: z.string().min(1),
      page: z.number().int().min(1).default(1),
      size: z.number().int().min(1).max(500).default(100),
    },
  },
  "get_rest_domain_domain_cdrs_1",
  ({ domain, page, size }) => ({
    pathParams: { domain },
    queryParams: { page, size },
  })
);

registerPbXReadTool(
  "get_tenant_stats",
  {
    title: "Get tenant call statistics",
    description: "Get tenant call or quality statistics, including MOS data when supported by the PBX.",
    inputSchema: {
      domain: z.string().min(1),
      type: z.string().min(1).optional(),
    },
  },
  "get_rest_domain_domain_stats_6",
  ({ domain, type }) => ({
    pathParams: { domain },
    queryParams: type ? { type } : {},
  })
);

registerPbXReadTool(
  "get_trunk_stats",
  {
    title: "Get trunk statistics",
    description: "Get call or quality statistics for one or all tenant trunks.",
    inputSchema: {
      domain: z.string().min(1),
      trunk: z.string().min(1).optional(),
      type: z.string().min(1).optional(),
    },
  },
  "get_rest_domain_domain_trunk_stats_1",
  ({ domain, trunk, type }) => ({
    pathParams: { domain },
    queryParams: {
      ...(trunk ? { trunk } : {}),
      ...(type ? { type } : {}),
    },
  })
);

registerPbXReadTool(
  "get_live_queue_status",
  {
    title: "Get live call queue status",
    description: "Get current Vodia call queue state for a tenant.",
    inputSchema: { domain: z.string().min(1) },
  },
  "get_rest_domain_domain_status_acds",
  ({ domain }) => ({ pathParams: { domain } })
);

registerPbXReadTool(
  "get_queue_stats",
  {
    title: "Get call queue statistics",
    description: "Get statistics for a call queue and timeframe; useful for queue charts.",
    inputSchema: {
      account: z.string().min(1).describe("Queue account, usually queue@tenant-domain"),
      date: z.string().min(1).optional(),
      days: z.number().int().min(1).max(366).optional(),
    },
  },
  "get_rest_acd_account_stat",
  ({ account, date, days }) => ({
    pathParams: { account },
    queryParams: {
      ...(date ? { date } : {}),
      ...(days ? { days } : {}),
    },
  })
);

registerPbXReadTool(
  "get_queue_cdrs",
  {
    title: "Get call queue CDRs",
    description: "Get paginated call records for a Vodia call queue for analysis and charting.",
    inputSchema: {
      account: z.string().min(1).describe("Queue account, usually queue@tenant-domain"),
      page: z.number().int().min(1).default(1),
      size: z.number().int().min(1).max(500).default(100),
    },
  },
  "get_rest_acd_account_cdr_1",
  ({ account, page, size }) => ({
    pathParams: { account },
    queryParams: { page, size },
  })
);

server.registerTool(
  "find_read_capabilities",
  {
    title: "Find Vodia read capabilities",
    description:
      "Search the official Vodia GET capability catalog before using the universal reader.",
    inputSchema: {
      query: z.string().optional(),
      tag: z.string().optional(),
      include_blocked: z.boolean().default(false),
      limit: z.number().int().min(1).max(100).default(25),
    },
    outputSchema: toolOutputSchema,
    annotations: {
      readOnlyHint: true,
      destructiveHint: false,
      openWorldHint: false,
    },
  },
  async ({ query, tag, include_blocked, limit }) => {
    audit("find_read_capabilities", { query, tag, include_blocked, limit });
    const needles = String(query || "")
      .trim()
      .toLowerCase()
      .split(/\s+/)
      .filter(Boolean);
    const tagNeedle = String(tag || "").trim().toLowerCase();
    const matches = catalog.operations
      .filter((operation) => include_blocked || operation.callable)
      .filter((operation) => {
        if (!needles.length) return true;
        const searchable = [
          operation.operationId,
          operation.path,
          operation.summary,
          ...(operation.tags || []),
        ]
          .join(" ")
          .toLowerCase();
        return needles.every((needle) => searchable.includes(needle));
      })
      .filter((operation) => {
        if (!tagNeedle) return true;
        return (operation.tags || []).some((item) => item.toLowerCase().includes(tagNeedle));
      })
      .slice(0, limit)
      .map((operation) => ({
        operationId: operation.operationId,
        path: operation.path,
        summary: operation.summary,
        tags: operation.tags,
        parameters: operation.parameters,
        callable: operation.callable,
        blockedReason: operation.blockedReason,
      }));

    return success(
      matches,
      {
        totalGetOperations: catalog.totalGetOperations,
        callableOperations: catalog.callableOperations,
        returned: matches.length,
        vodiaApiVersion: catalog.vodiaApiVersion,
      },
      `Found ${matches.length} matching Vodia read capabilities.`
    );
  }
);

server.registerTool(
  "read_vodia_resource",
  {
    title: "Read any allowlisted Vodia resource",
    description:
      "Call an official Vodia GET operation by operation ID. First use find_read_capabilities to obtain the operation ID and valid parameters.",
    inputSchema: {
      operation_id: z.string().min(1),
      path_params: parameterMapSchema.optional(),
      query_params: parameterMapSchema.optional(),
    },
    outputSchema: toolOutputSchema,
    annotations: {
      readOnlyHint: true,
      destructiveHint: false,
      openWorldHint: false,
    },
  },
  async ({ operation_id, path_params, query_params }) => {
    audit("read_vodia_resource", { operation_id, path_params, query_params });
    try {
      const result = await callOperation(operation_id, {
        pathParams: path_params || {},
        queryParams: query_params || {},
      });
      return success(
        result.data,
        result.meta,
        `Read '${operation_id}' from Vodia without changing PBX state.`
      );
    } catch (error) {
      return failure(error);
    }
  }
);

server.registerTool(
  "get_connector_info",
  {
    title: "Get Vodia connector information",
    description: "Show connector version, API catalog coverage and enforced safety limits.",
    inputSchema: {},
    outputSchema: toolOutputSchema,
    annotations: {
      readOnlyHint: true,
      destructiveHint: false,
      openWorldHint: false,
    },
  },
  async () =>
    success(
      {
        connectorVersion: "0.5.0",
        mode: "strict-read-only",
        vodiaApiVersion: catalog.vodiaApiVersion,
        totalGetOperations: catalog.totalGetOperations,
        callableOperations: catalog.callableOperations,
        blockedOperations: catalog.blockedOperations,
        responseLimitBytes: RESPONSE_LIMIT_BYTES,
        redactionApplied: true,
      },
      { source: catalog.source },
      "Returned Vodia connector coverage and safety information."
    )
);

return server;
}

export function getRuntimeInfo() {
  return {
    connectorVersion: "0.5.0",
    mode: "strict-read-only",
    pbxUrl: PBX_URL,
    apiUser: PBX_USER,
    vodiaApiVersion: catalog.vodiaApiVersion,
    totalGetOperations: catalog.totalGetOperations,
    callableOperations: catalog.callableOperations,
    blockedOperations: catalog.blockedOperations,
    responseLimitBytes: RESPONSE_LIMIT_BYTES,
  };
}

async function startStdio() {
  const server = createVodiaServer();
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error(
    `[vodia-mcp] connected read-only. PBX=${PBX_URL} ` +
      `VodiaAPI=${catalog.vodiaApiVersion} GET=${catalog.callableOperations}/${catalog.totalGetOperations}`
  );
}

const invokedPath = process.argv[1] ? pathToFileURL(resolve(process.argv[1])).href : "";
if (invokedPath === import.meta.url) {
  await startStdio();
}

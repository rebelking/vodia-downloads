import copy


def _flow(value):
    result = copy.deepcopy(value) if isinstance(value, dict) else {}
    result.setdefault("steps", [])
    result.setdefault("account_specs", [])
    return result


def _append_account(flow, account_type, number, name, settings, branch=None):
    result = _flow(flow)
    account = {
        "account_type": account_type,
        "number": str(number).strip(),
        "name": str(name).strip(),
        "settings": settings,
        "mode": "plan_only",
    }
    result["account_specs"].append(copy.deepcopy(account))
    step = {
        "type": account_type,
        "number": account["number"],
        "name": account["name"],
        **copy.deepcopy(settings),
    }
    if branch is not None:
        step["branch"] = branch
    result["steps"].append(step)
    return result


class VodiaParkOrbit:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "call_flow": ("VODIA_FLOW",),
                "orbit_number": ("STRING", {"default": "7000"}),
                "orbit_name": ("STRING", {"default": "Main Park Orbit"}),
                "recall_destination": ("STRING", {"default": "200"}),
                "timeout_seconds": (
                    "INT",
                    {"default": 120, "min": 5, "max": 3600, "step": 5},
                ),
            }
        }

    RETURN_TYPES = ("VODIA_FLOW",)
    RETURN_NAMES = ("call_flow",)
    FUNCTION = "route"
    CATEGORY = "Vodia PBX / Call Flow"

    def route(
        self,
        call_flow,
        orbit_number,
        orbit_name,
        recall_destination,
        timeout_seconds,
    ):
        result = _append_account(
            call_flow,
            "park_orbit",
            orbit_number,
            orbit_name,
            {
                "recall_destination": recall_destination.strip(),
                "timeout_seconds": timeout_seconds,
            },
        )
        return (result,)


class VodiaServiceFlag:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "call_flow": ("VODIA_FLOW",),
                "service_flag_number": ("STRING", {"default": "4000"}),
                "flag_name": ("STRING", {"default": "Business Hours Flag"}),
                "control_mode": (["automatic", "force_active", "force_inactive"],),
                "schedule_note": (
                    "STRING",
                    {"default": "Mon-Fri 09:00-17:00", "multiline": False},
                ),
            }
        }

    RETURN_TYPES = ("VODIA_FLOW", "VODIA_FLOW")
    RETURN_NAMES = ("active", "inactive")
    FUNCTION = "branch"
    CATEGORY = "Vodia PBX / Call Flow"

    def branch(
        self,
        call_flow,
        service_flag_number,
        flag_name,
        control_mode,
        schedule_note,
    ):
        settings = {
            "control_mode": control_mode,
            "schedule_note": schedule_note.strip(),
        }
        active = _append_account(
            call_flow,
            "service_flag",
            service_flag_number,
            flag_name,
            settings,
            branch="active",
        )
        inactive = _append_account(
            call_flow,
            "service_flag",
            service_flag_number,
            flag_name,
            settings,
            branch="inactive",
        )
        return (active, inactive)


class VodiaVoiceAgent:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "call_flow": ("VODIA_FLOW",),
                "voice_agent_number": ("STRING", {"default": "8000"}),
                "agent_name": ("STRING", {"default": "Reception Voice Agent"}),
                "instructions": (
                    "STRING",
                    {
                        "default": "Greet the caller and determine where the call should go.",
                        "multiline": True,
                    },
                ),
                "transfer_destination": ("STRING", {"default": "200"}),
                "fallback_destination": ("STRING", {"default": "82009"}),
            }
        }

    RETURN_TYPES = ("VODIA_FLOW", "VODIA_FLOW")
    RETURN_NAMES = ("transfer", "fallback")
    FUNCTION = "route"
    CATEGORY = "Vodia PBX / Call Flow"

    def route(
        self,
        call_flow,
        voice_agent_number,
        agent_name,
        instructions,
        transfer_destination,
        fallback_destination,
    ):
        settings = {
            "instructions_note": instructions.strip(),
            "transfer_destination": transfer_destination.strip(),
            "fallback_destination": fallback_destination.strip(),
        }
        transfer = _append_account(
            call_flow,
            "voice_agent",
            voice_agent_number,
            agent_name,
            settings,
            branch="transfer",
        )
        fallback = _append_account(
            call_flow,
            "voice_agent",
            voice_agent_number,
            agent_name,
            settings,
            branch="fallback",
        )
        return (transfer, fallback)


class VodiaCallingCard:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "call_flow": ("VODIA_FLOW",),
                "calling_card_number": ("STRING", {"default": "9000"}),
                "card_name": ("STRING", {"default": "Calling Card"}),
                "dial_plan": ("STRING", {"default": "1"}),
                "outbound_caller_id": ("STRING", {"default": ""}),
                "max_call_seconds": (
                    "INT",
                    {"default": 3600, "min": 60, "max": 86400, "step": 60},
                ),
                "credential_env": (
                    "STRING",
                    {
                        "default": "VODIA_CALLING_CARD_SECRET",
                        "multiline": False,
                    },
                ),
            }
        }

    RETURN_TYPES = ("VODIA_FLOW",)
    RETURN_NAMES = ("call_flow",)
    FUNCTION = "route"
    CATEGORY = "Vodia PBX / Call Flow"

    def route(
        self,
        call_flow,
        calling_card_number,
        card_name,
        dial_plan,
        outbound_caller_id,
        max_call_seconds,
        credential_env,
    ):
        result = _append_account(
            call_flow,
            "calling_card",
            calling_card_number,
            card_name,
            {
                "dial_plan": dial_plan.strip(),
                "outbound_caller_id": outbound_caller_id.strip(),
                "max_call_seconds": max_call_seconds,
                "credential_env": credential_env.strip(),
            },
        )
        return (result,)


NODE_CLASS_MAPPINGS = {
    "VodiaParkOrbit": VodiaParkOrbit,
    "VodiaServiceFlag": VodiaServiceFlag,
    "VodiaVoiceAgent": VodiaVoiceAgent,
    "VodiaCallingCard": VodiaCallingCard,
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "VodiaParkOrbit": "Vodia Park Orbit",
    "VodiaServiceFlag": "Vodia Service Flag",
    "VodiaVoiceAgent": "Vodia Voice Agent",
    "VodiaCallingCard": "Vodia Calling Card",
}

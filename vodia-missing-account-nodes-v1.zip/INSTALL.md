# Vodia Missing Account Nodes v1

Adds only the account types found in the live inventory that did not already
have dedicated nodes:

- Vodia Park Orbit
- Vodia Service Flag
- Vodia Voice Agent
- Vodia Calling Card

These nodes produce call-flow/account specifications only. They do not call the
Vodia REST API and cannot change the PBX.

## Install

Copy `additional_account_nodes.py` to
`~/ComfyUI/custom_nodes/ComfyUI-VodiaPBX/`.

Add to `__init__.py`:

```python
from .additional_account_nodes import NODE_CLASS_MAPPINGS as ADDITIONAL_NODES
from .additional_account_nodes import NODE_DISPLAY_NAME_MAPPINGS as ADDITIONAL_NAMES
```

Add `**ADDITIONAL_NODES,` to `NODE_CLASS_MAPPINGS` and
`**ADDITIONAL_NAMES,` to `NODE_DISPLAY_NAME_MAPPINGS`.

Then compile:

```bash
cd ~/ComfyUI
source .venv/bin/activate
python -m py_compile \
  custom_nodes/ComfyUI-VodiaPBX/additional_account_nodes.py \
  custom_nodes/ComfyUI-VodiaPBX/__init__.py
```

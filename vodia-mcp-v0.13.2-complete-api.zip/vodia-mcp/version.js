export const CONNECTOR_VERSION = "0.13.2";

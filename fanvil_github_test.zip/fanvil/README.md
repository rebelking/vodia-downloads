# Fanvil V62G – Peninsula Tokyo test files

| File | Use | Format |
|---|---|---|
| `peninsula_bootlogo.jpg` | Boot logo → `<AutoBootLogoUrl>` | JPG, 240×320 (320×240 rotated 90° clockwise) |
| `peninsula_bg.bmp` | Wallpaper → `<AutoEtcUrl>` | BMP, 24-bit, 320×240 |
| `etc.tar.gz` | Same wallpaper, bundled → `<AutoEtcUrl>` | tar.gz containing `peninsula_bg.bmp` |

Repo must be **public**. Use the raw links:

```xml
<ap>
    <AutoBootLogoUrl>https://raw.githubusercontent.com/<user>/<repo>/main/fanvil/peninsula_bootlogo.jpg</AutoBootLogoUrl>
    <AutoEtcUrl>https://raw.githubusercontent.com/<user>/<repo>/main/fanvil/peninsula_bg.bmp</AutoEtcUrl>
</ap>
<background>
    <UserMainBackground>peninsula_bg.bmp</UserMainBackground>
</background>
```

Use either `peninsula_bg.bmp` or `etc.tar.gz` in `<AutoEtcUrl>`, not both.

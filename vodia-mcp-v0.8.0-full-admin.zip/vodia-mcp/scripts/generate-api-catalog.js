#!/usr/bin/env node

import { mkdir, readFile, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import YAML from "yaml";

const OFFICIAL_SPEC_URL = "https://doc.vodia.com/openapi/vodia-rest-api.yaml";
const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const outputPath = resolve(projectRoot, "generated/api-catalog.json");
const METHODS = new Set(["get", "post", "put", "patch", "delete"]);

const NEVER_CALL = [
  /^\/rest\/system\/syncrpc$/,
  /^\/rest\/domain\/\{domain\}\/syncrpc$/,
  /^\/rest\/system\/http(?:\/|$)/,
  /^\/rest\/system\/textedit$/,
  /^\/rest\/system\/pagedefault\/\{filename\}$/,
];

const BINARY_READS = [
  /\/wave\//,
  /^\/rest\/system\/pcap$/,
  /^\/rest\/user\/\{account\}\/message\/\{message_id\}$/,
  /^\/rest\/account\/\{account\}\/alias\/\{id\}$/,
  /^\/rest\/domain\/\{domain\}\/account\/\{ext\}\/image$/,
];

const EXTERNAL_ACTION_GETS = [
  /^\/rest\/acd\/\{account\}\/email\//,
  /^\/rest\/hunt\/\{account\}\/email\//,
  /^\/rest\/system\/testemail$/,
  /^\/rest\/user\/\{account\}\/check-sync$/,
];

// These operations can change authentication, connector reachability, PBX
// software, licensing, system-wide executable content, or entire tenants.
// They remain catalogued, but require the separate break-glass policy switch.
const CRITICAL_WRITES = [
  /^\/rest\/system\/2nd$/,
  /^\/rest\/system\/access$/,
  /^\/rest\/system\/administrators$/,
  /^\/rest\/system\/billing$/,
  /^\/rest\/system\/certs$/,
  /^\/rest\/system\/config$/,
  /^\/rest\/system\/license$/,
  /^\/rest\/system\/login$/,
  /^\/rest\/system\/script$/,
  /^\/rest\/system\/session$/,
  /^\/rest\/system\/swupdate$/,
  /^\/rest\/system\/wave\/audio\//,
  /^\/rest\/system\/domains\/\{domain_primary_dns\}$/,
];

function resolveRef(document, value) {
  if (!value?.$ref?.startsWith("#/")) return value;
  return value.$ref
    .slice(2)
    .split("/")
    .map((part) => part.replace(/~1/g, "/").replace(/~0/g, "~"))
    .reduce((current, key) => current?.[key], document);
}

function classify(path, method, operation) {
  if (NEVER_CALL.some((rule) => rule.test(path))) {
    return { callable: false, risk: "blocked", reason: "Arbitrary, synchronization, or private server operation." };
  }
  if (method === "get" && BINARY_READS.some((rule) => rule.test(path))) {
    return { callable: false, risk: "specialized", reason: "Binary content requires a dedicated size-limited tool." };
  }
  if (method === "get" && EXTERNAL_ACTION_GETS.some((rule) => rule.test(path))) {
    return { callable: false, risk: "external-action", reason: "GET operation performs an external action." };
  }
  if (method === "get") return { callable: true, risk: "read", adminTier: "read", reason: null };

  const critical = CRITICAL_WRITES.some((rule) => rule.test(path));
  if (method === "delete") {
    return { callable: true, risk: "destructive", adminTier: critical ? "critical" : "destructive", reason: null };
  }

  const text = `${operation.summary || ""} ${operation.description || ""}`.toLowerCase();
  const elevated = /send|call control|upload|software|restart|reboot|token|password|certificate|fax|sms|email/.test(text);
  return {
    callable: true,
    risk: critical ? "elevated" : elevated ? "elevated" : "write",
    adminTier: critical ? "critical" : elevated ? "elevated" : "standard",
    reason: null,
  };
}

async function loadSpec() {
  const fileFlagIndex = process.argv.indexOf("--spec-file");
  if (fileFlagIndex !== -1) {
    const requestedPath = process.argv[fileFlagIndex + 1];
    if (!requestedPath) throw new Error("--spec-file requires a path");
    return readFile(resolve(requestedPath), "utf8");
  }
  const response = await fetch(OFFICIAL_SPEC_URL, {
    headers: { Accept: "application/yaml, text/yaml, text/plain" },
    signal: AbortSignal.timeout(30_000),
  });
  if (!response.ok) throw new Error(`Unable to fetch Vodia OpenAPI specification: HTTP ${response.status}`);
  return response.text();
}

const document = YAML.parse(await loadSpec());
const operations = [];
for (const [path, pathItem] of Object.entries(document.paths || {})) {
  for (const [method, operation] of Object.entries(pathItem || {})) {
    if (!METHODS.has(method) || !operation) continue;
    const parameters = [...(pathItem.parameters || []), ...(operation.parameters || [])]
      .map((parameter) => resolveRef(document, parameter))
      .filter(Boolean)
      .map((parameter) => ({
        name: parameter.name,
        in: parameter.in,
        required: Boolean(parameter.required),
        description: parameter.description || null,
        type: parameter.schema?.type || "string",
        enum: parameter.schema?.enum || null,
        example: parameter.example ?? null,
      }));
    const classification = classify(path, method, operation);
    operations.push({
      operationId: operation.operationId || `${method}_${path.replace(/[^a-z0-9]+/gi, "_")}`,
      method: method.toUpperCase(),
      path,
      summary: operation.summary || `${method.toUpperCase()} ${path}`,
      description: operation.description || null,
      tags: operation.tags || [],
      parameters,
      requestBody: Boolean(operation.requestBody),
      callable: classification.callable,
      risk: classification.risk,
      adminTier: classification.adminTier || (classification.risk === "blocked" ? "blocked" : "specialized"),
      blockedReason: classification.reason,
    });
  }
}
operations.sort((a, b) => a.operationId.localeCompare(b.operationId));
const counts = Object.fromEntries([...METHODS].map((method) => [method.toUpperCase(), operations.filter((o) => o.method === method.toUpperCase()).length]));
const result = {
  generatedAt: new Date().toISOString(),
  source: OFFICIAL_SPEC_URL,
  openapiVersion: document.openapi || null,
  vodiaApiVersion: document.info?.version || null,
  totalOperations: operations.length,
  counts,
  operations,
};
await mkdir(dirname(outputPath), { recursive: true });
await writeFile(outputPath, `${JSON.stringify(result, null, 2)}\n`, "utf8");
console.log(`Generated ${result.totalOperations} operations for Vodia API ${result.vodiaApiVersion}: ${JSON.stringify(counts)}`);

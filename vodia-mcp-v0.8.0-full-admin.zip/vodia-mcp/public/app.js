const $ = (selector) => document.querySelector(selector);
let token = sessionStorage.getItem("vodiaAdminToken") || "";
let operations = [];

async function api(path) {
  const response = await fetch(path, { headers: { Authorization: `Bearer ${token}` } });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.error || `HTTP ${response.status}`);
  return body;
}

function setStatus(ok, text) {
  const pill = $("#statusPill");
  pill.className = `pill ${ok === null ? "neutral" : ok ? "good" : "bad"}`;
  pill.innerHTML = `<span></span>${text}`;
}

function renderTools(filter = "") {
  const needle = filter.trim().toLowerCase();
  const rows = operations.filter((op) => !needle || JSON.stringify(op).toLowerCase().includes(needle));
  $("#toolRows").innerHTML = rows.slice(0, 250).map((op) => `
    <tr><td><code>${escapeHtml(op.operationId)}</code></td><td>${escapeHtml(op.summary || "")}</td>
    <td><code>${escapeHtml(op.path)}</code></td><td><span class="badge ${op.callable ? "" : "blocked"}">${op.callable ? "Callable" : "Blocked"}</span></td></tr>`).join("");
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>'"]/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" })[char]);
}

async function refresh() {
  setStatus(null, "Testing PBX…");
  const [status, capabilities, activity] = await Promise.all([
    api("/api/status").catch((error) => ({ ok: false, error: error.message })),
    api("/api/capabilities"),
    api("/api/activity?limit=30"),
  ]);
  operations = capabilities.operations;
  $("#callableCount").textContent = capabilities.callable;
  $("#blockedCount").textContent = capabilities.blocked;
  $("#connectorVersion").textContent = status.runtime?.connectorVersion || "0.8.0";
  $("#apiVersion").textContent = `Vodia API ${capabilities.version}`;
  $("#pbxState").textContent = status.ok ? "Online" : "Failed";
  $("#pbxLatency").textContent = status.latencyMs ? `${status.latencyMs} ms` : (status.error || "No response");
  setStatus(status.ok, status.ok ? "PBX connected" : "PBX unavailable");
  const runtime = status.runtime || {};
  $("#connectionDetails").innerHTML = `
    <dt>PBX URL</dt><dd>${escapeHtml(runtime.pbxUrl || "Unavailable")}</dd>
    <dt>API user</dt><dd>${escapeHtml(runtime.apiUser || "Unavailable")}</dd>
    <dt>Security</dt><dd>${escapeHtml(status.runtime?.mode || "strict-read-only")} · sensitive fields redacted</dd>`;
  $("#pbxPreview").textContent = status.ok ? JSON.stringify(status.pbx, null, 2) : (status.error || "Connection failed");
  $("#mcpUrl").textContent = `${location.origin}/mcp`;
  renderTools($("#toolSearch").value);
  $("#activity").innerHTML = activity.activity.length ? activity.activity.map((item) => `
    <div class="activity-item"><time>${escapeHtml(new Date(item.timestamp).toLocaleString())}</time><strong>${escapeHtml(item.tool)}</strong><code>${escapeHtml(JSON.stringify(item.details))}</code></div>`).join("") : '<p class="muted">No tool calls recorded since startup.</p>';
}

async function openDashboard() {
  $("#loginError").textContent = "";
  try {
    await api("/api/capabilities");
    sessionStorage.setItem("vodiaAdminToken", token);
    $("#loginPanel").classList.add("hidden");
    $("#dashboard").classList.remove("hidden");
    await refresh();
  } catch (error) {
    $("#loginError").textContent = error.message;
    setStatus(false, "Access denied");
  }
}

$("#loginForm").addEventListener("submit", (event) => { event.preventDefault(); token = $("#token").value; openDashboard(); });
$("#refreshButton").addEventListener("click", refresh);
$("#logoutButton").addEventListener("click", () => { sessionStorage.removeItem("vodiaAdminToken"); location.reload(); });
$("#toolSearch").addEventListener("input", (event) => renderTools(event.target.value));
$("#copyUrl").addEventListener("click", async () => { await navigator.clipboard.writeText($("#mcpUrl").textContent); $("#copyUrl").textContent = "Copied"; setTimeout(() => $("#copyUrl").textContent = "Copy", 1200); });
if (token) openDashboard();

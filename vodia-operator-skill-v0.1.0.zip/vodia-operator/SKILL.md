---
name: vodia-operator
description: Operate and troubleshoot Vodia PBX tenants through the vodia_test_admin MCP connector from short natural-language or voice requests. Use for registrations, devices, provisioning, reboot, buttons, DIDs, extensions, calls, queues, trunks, CDRs, and Vodia REST catalog operations.
---

# Vodia Operator

Translate plain-language PBX requests into verified Vodia MCP workflows. Do not require the user to know tool names, REST paths, operation IDs, or payload schemas.

## Defaults

- Use the `vodia_test_admin` connector.
- Use `vodiatech.audiomercy.com` when the user does not specify a tenant.
- Treat the live connector tool surface and schemas as authoritative.
- Keep voice-friendly answers concise. Show technical IDs only when requested or needed to explain a blocker.
- Never claim an action succeeded without verifying the resulting PBX state.

## Route the request

- For common status, registration, device, reboot, provisioning, button, DID, or phone-provisioning requests, read [references/command-map.md](references/command-map.md).
- For an unmatched request, a specific API operation, or complete catalog discovery, read [references/catalog-routing.md](references/catalog-routing.md).
- Read both references only when a common workflow must fall back to a generic catalog operation.

## Non-negotiable invariants

1. Use `list_registrations` for current live registrations. Registration history is a timeline, not current inventory.
2. If an extension has multiple active devices, never select the newest automatically. Require a unique model or MAC before a device-specific action.
3. Normalize MAC addresses by removing separators for MCP calls, while displaying a readable form to the user.
4. Reads may run immediately. Anything that changes PBX state follows resolve, inspect, plan, review, explicit approval, apply, and verify.
5. Never call `apply_vodia_change` before explicit approval of the displayed plan. Approval applies only to that plan ID, exact target, effect, and confirmation.
6. Treat action-like GET operations as writes.
7. Respect tenant scope and all blocked, destructive, and critical-operation policies.
8. High-level MCP tools are not Vodia catalog operation IDs. Check the connector tool surface before claiming one is unavailable.
9. Never invent a tenant, extension, user, device, MAC, operation, payload, plan, or result.

## Interpret authorization

- “Show,” “list,” “check,” “find,” and “read” authorize reads only.
- “Prepare” and “plan” authorize plan creation only.
- “Reboot,” “provision,” “assign,” “set,” “create,” “update,” “clear,” and “delete” authorize target resolution and planning, but never bypass the MCP approval gate.
- If a plan expires or target state changes, create a new plan. Never reuse a plan.

## Report changes

Before approval, report the action, tenant, exact target, current state, proposed effect, interruption or risk, plan ID, and required confirmation. End with `Status: awaiting approval`.

After applying, report the exact target, verification result, recovery or re-registration delay, and audit reference when available.

## Handle failures

- Name the exact blocker: missing tool, connector authentication, tenant scope, schema validation, policy, stale plan, or PBX rejection.
- If a preferred high-level tool is absent, use the verified catalog fallback when available.
- Do not weaken safety controls to work around a blocker.

# Complete Vodia API catalog routing

Use this reference when no common high-level mapping fits, when the user names an API operation, or when catalog coverage is being audited.

## Baseline, not a permanent assumption

Connector 0.13.2 reported Vodia API 70.3 with 301 catalog operations:

- GET: 202
- POST: 63
- PUT: 3
- PATCH: 0
- DELETE: 33

The live connector is authoritative. Catalogued does not mean callable; policy, tenant scope, schema support, and risk classification may block execution.

## Discover and select

1. Call `find_api_capabilities` with several relevant domain terms.
2. Inspect plausible matches with `inspect_vodia_operation`.
3. Select using the live description, method, path, parameter schema, scope, effect, and policy classification.
4. If candidates cause materially different effects, ask one short clarification question.
5. Do not expose operation IDs unless the user asks for technical details or troubleshooting requires them.

## Execute safely

- Genuine read: use `read_vodia_api`.
- Verified binary read: use `read_vodia_binary`.
- POST, PUT, DELETE, or action-like GET: use `plan_vodia_change`.
- Before approval, show target, effect, important inputs, redacted payload, risk, plan ID, and exact confirmation.
- After explicit approval, use `apply_vodia_change`, then verify with an independent read.
- If an operation exists but policy blocks it, state that it is catalogued but not executable and name the blocking policy.
- Never claim all 301 operations are callable merely because they are discoverable.

## Action-like GET warning

Some Vodia GET operations change state. Reboot, provisioning synchronization, history reset, and similar actions must never run through the generic read path. Classify by effect, not only by HTTP verb.

Known examples include:

- `get_rest_domain_domain_check_sync_mac`: provisioning or reboot behavior depending on parameters.
- `get_rest_domain_domain_generated_reset`: clear provisioning history.

Prefer the corresponding high-level planners when exposed.

## DELETE

1. Never delete from an ambiguous natural-language request.
2. Resolve the exact tenant and object.
3. Inspect dependencies including registrations, active calls, DIDs, voicemail, buttons, and provisioning.
4. Require destructive policy to be enabled and require exact destructive confirmation.
5. Prefer a disposable test object for end-to-end validation.
6. Verify absence afterward and report the audit result.

## Unsupported or uncertain operations

Do not infer payloads from endpoint names alone. If the schema or effect is incomplete, stop after inspection and explain what verified evidence is missing. Browser-captured requests may teach a missing workflow only through the connector's supervised-learning process; never silently create a learned write operation.

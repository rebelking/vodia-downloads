# Common Vodia command map

Use this reference for normal operator requests. Resolve natural language to the preferred high-level MCP tool, then follow the safety rules in `SKILL.md`.

## Read commands

| User intent | Preferred tool and behavior |
| --- | --- |
| `status` | `get_system_status`; report PBX, connector version, mode, and health. |
| `tenants` | `list_tenants`; make no changes. |
| `registrations EXTENSION` | `list_registrations`; return every current contact, model, transport, address, port, and MAC. |
| `registration history EXTENSION` | `get_extension_registration_history`; label results as historical events. |
| `provisioning history EXTENSION or MAC` | Resolve the device when needed, then use `get_mac_provisioning_history`. |
| `buttons EXTENSION` | `get_extension_buttons`; summarize configured keys and omit long unassigned ranges unless requested. |
| `DIDs` or `unassigned DIDs` | `list_tenant_dids`; show assignment, ANI, and trunk details when present. |
| `extension EXTENSION` | Combine verified reads for identity, live registrations, provisioned devices, buttons, and DID assignments. |

## Resolve devices

1. Call `list_registrations` for the extension.
2. Match vendor and model case-insensitively. Accept aliases such as `T57W`, `T73U`, `V64`, and `VVX400`.
3. Accept MACs with colons, hyphens, or no separators.
4. If more than one device remains, list the candidates and ask one short clarification question.
5. If a requested model uniquely matches, show the selected model and MAC before planning an action.

Validation example for extension 2035:

| Device | Normalized MAC |
| --- | --- |
| Yealink SIP-T57W | `805EC03C36F6` |
| Yealink SIP-T73U | `44DBD28A06D2` |
| Grandstream GXW4216 | `000B82A039D7` |

`reboot 2035 T57W` targets only `805EC03C36F6`.

## Reboot

For `reboot EXTENSION MODEL-or-MAC`:

1. Resolve the exact device from current registrations.
2. Check available live-call state. If the target appears active on a call, warn and stop unless the user explicitly directs otherwise.
3. Call `plan_trigger_mac_reboot`.
4. Display tenant, extension, user, vendor, model, MAC, and interruption risk.
5. Stop for explicit approval.
6. After approval, call `apply_vodia_change` using the plan's exact confirmation.
7. Verify provisioning history and registration recovery.
8. Never reboot another device registered to the same extension.

## Provisioning actions

- `provision EXTENSION MODEL-or-MAC`: resolve the device, call `plan_trigger_mac_provisioning`, wait for approval, apply, then verify history.
- `clear provisioning history EXTENSION-or-MAC`: resolve the device, call `plan_clear_mac_provisioning_history`, wait for approval, apply, then verify.
- Do not silently convert provisioning into a reboot.
- Pairing and cloud/RPS provisioning require a verified high-level tool or verified live schema. Never guess a UI payload.

## Buttons

For `set button EXTENSION KEY TYPE PARAMETER [LABEL]`:

1. Read the complete current profile with `get_extension_buttons`.
2. Preserve every key not explicitly changed.
3. Validate key number, type, parameter, label, and duplicates.
4. Use `plan_set_extension_buttons`.
5. Show a concise before-and-after difference and wait for approval.
6. Apply and read the profile again to verify.

## DIDs

For `assign DID DID EXTENSION`:

1. Read current DID assignments with `list_tenant_dids`.
2. Detect existing ownership and destination conflicts.
3. Use `plan_assign_did`.
4. Show the old and proposed destination and wait for approval.
5. Apply and read the DID assignment again to verify.

## Phone provisioning

For `provision phone EXTENSION MAC VENDOR MODEL`:

1. Use a verified high-level phone-provisioning planner when exposed.
2. Otherwise inspect and plan `post_rest_system_prov_phones` through the generic catalog workflow.
3. Normalize the MAC and redact secrets.
4. Fanvil manual provisioning does not require a serial ID.
5. Yealink requires a serial or pairing value only when the verified schema or workflow requires it.
6. Show the exact target and redacted payload, wait for approval, apply, and verify.

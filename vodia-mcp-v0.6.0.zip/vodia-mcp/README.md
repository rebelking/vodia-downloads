# Vodia PBX MCP — strict read-only connector

Version 0.6 expands the focused support tools, adds optional tenant-domain
allowlisting and persistent JSONL audit logging, strengthens secret redaction,
and blocks additional action-capable or privileged GET endpoints. Streamable
HTTP, Caddy HTTPS, the protected dashboard, and local STDIO mode remain available.

This MCP server exposes the Vodia PBX REST API to an MCP client without registering any write operation.

## Coverage

- Generated from Vodia's official OpenAPI specification.
- 200 documented GET operations in Vodia API 70.3.
- 180 JSON/text read operations are callable.
- 20 GET endpoints are intentionally blocked because they send email, execute RPC or outbound HTTP, expose privileged material, or return binary/oversized content.
- Common support and analytics operations are available as focused MCP tools.
- Less common reads are available through a searchable allowlist and the universal read tool.

The connector recursively redacts snake_case and camelCase password, secret,
token, credential, authorization, session, cookie, PIN, private-key, API-key,
access-key, JWT, CSRF and OAuth fields before returning structured data.

## Requirements

- Node.js 18 or newer.
- Vodia PBX 70 or newer for full catalog compatibility.
- A dedicated Vodia administrator with API access enabled.
- HTTPS with a valid certificate.

Version 69 systems may support a subset of the endpoints. Unsupported calls return the PBX HTTP error without falling back to a write or undocumented endpoint.

## Install

```bash
npm ci
npm run check
```

## Recommended EC2 installation (Caddy + GUI)

Create a DNS record for the MCP hostname pointing to the Ubuntu EC2 public IP.
Allow inbound TCP 80 and 443 in the AWS Security Group. Then download and run
the installer:

```bash
wget https://raw.githubusercontent.com/rebelking/vodia-downloads/main/install-vodia-mcp.sh
sudo bash install-vodia-mcp.sh
```

The installer prompts for the public hostname and Vodia API credentials. It
installs Node.js when needed, installs Caddy from its official package source,
downloads the release, creates a locked-down systemd service, obtains HTTPS,
and prints separate admin and MCP bearer tokens.

After installation:

- Admin GUI: `https://your-mcp-domain/admin/`
- MCP endpoint: `https://your-mcp-domain/mcp`
- Health check: `https://your-mcp-domain/health`

The GUI tests the PBX connection, shows catalog coverage, searches all read
capabilities, and displays recent read-only activity. It never displays the PBX
password or MCP bearer token.

Useful server commands:

```bash
sudo systemctl status vodia-mcp caddy
sudo journalctl -u vodia-mcp -n 100 --no-pager
sudo cat /root/vodia-mcp-credentials.txt
```

Connect another Codex client to the shared endpoint. Set the token in that
user's shell, then add this block to `~/.codex/config.toml`:

```bash
export VODIA_MCP_TOKEN="token-printed-by-the-installer"
```

```toml
[mcp_servers.vodia]
url = "https://your-mcp-domain/mcp"
bearer_token_env_var = "VODIA_MCP_TOKEN"
default_tools_approval_mode = "auto"
tool_timeout_sec = 60
```

Restart Codex and run `codex mcp list`, or type `/mcp` inside Codex.

Configure the MCP client using `codex_config.example.toml` or `claude_desktop_config.example.json`. Keep real credentials outside source control.

## Environment variables

| Variable | Required | Purpose |
|---|---:|---|
| `VODIA_URL` | Yes | PBX base URL, for example `https://pbx.example.com` |
| `VODIA_USER` | Yes | Dedicated API username |
| `VODIA_PASS` | Yes | API password |
| `VODIA_TIMEOUT_MS` | No | Request timeout, default 30,000 ms |
| `VODIA_RESPONSE_LIMIT_BYTES` | No | Maximum response size, default 2,000,000 bytes |
| `VODIA_INSECURE` | No | Disable TLS validation only when set to `true`; lab use only |
| `VODIA_ALLOWED_DOMAINS` | No | Comma-separated tenant allowlist; blocks other tenants and most system-wide reads |
| `VODIA_AUDIT_LOG` | No | Append-only JSONL audit destination; installer uses `/var/log/vodia-mcp/audit.jsonl` |

The official Vodia API specification documents Basic authentication. Each MCP request sends the API account through the `Authorization` header directly to the configured PBX.

## High-value tools

- `get_system_status`
- `get_system_license`
- `get_system_stats`
- `get_system_audit_log`
- `list_domains`
- `list_extensions`
- `list_accounts`
- `list_queues`
- `list_ring_groups`
- `list_auto_attendants`
- `list_conferences`
- `list_service_flags`
- `list_registrations`
- `list_trunks`
- `list_dialplans`
- `get_live_extension_status`
- `get_tenant_cdrs`
- `get_tenant_audit_log`
- `get_tenant_stats`
- `get_trunk_stats`
- `get_live_queue_status`
- `get_live_ring_group_status`
- `get_live_conference_status`
- `get_queue_stats`
- `get_queue_cdrs`
- `get_extension_call_history`
- `get_extension_registration_history`
- `get_voicemail_metadata` (metadata only; audio is blocked)

## Full read catalog

Use `find_read_capabilities` to search the generated GET catalog. Then call `read_vodia_resource` with the returned `operationId`, path parameters and supported query parameters.

`read_vodia_resource` cannot accept a raw URL or arbitrary REST path. It can call only generated, allowlisted GET operations.

Regenerate the catalog after Vodia publishes a new API specification:

```bash
npm run generate:catalog
```

Review catalog changes before deploying them.

## Graphs and analysis

MCP tools return structured JSON so ChatGPT or Codex can create tables and charts from:

- Calls by hour, day, tenant, extension or trunk
- Answered versus missed calls
- Queue answered, abandoned and wait-time statistics
- Registration counts by tenant or device type
- MOS and call-quality statistics
- Trunk usage and failures

For small reports, the client can chart returned CDR pages directly. For months of CDR history or multi-PBX reporting, stream Vodia CDRs into a reporting database and expose server-side aggregation tools instead of sending thousands of raw records through MCP.

## Phase-one safety guarantees

- No POST, PUT, PATCH or DELETE tools.
- Action-like, synchronous-RPC, outbound-HTTP-proxy and privileged GET endpoints are blocked.
- Binary audio, voicemail and PCAP endpoints are blocked.
- Optional tenant restrictions deny cross-tenant and most system-wide operations.
- Unknown operations and parameters are rejected.
- Response size and request time limits are enforced.
- Sensitive snake_case and camelCase keys are redacted recursively.
- Tool calls are written to stderr and optionally to append-only JSONL without credentials.

OAuth 2.1 is not bundled in v0.6. The HTTP endpoint supports one or more bearer
tokens; deploy it behind an OAuth-aware gateway before treating it as per-user
authorization. Per-user identity, token-to-tenant claims, and OAuth consent are
planned as a separate authentication release so they are not simulated with a
shared secret.

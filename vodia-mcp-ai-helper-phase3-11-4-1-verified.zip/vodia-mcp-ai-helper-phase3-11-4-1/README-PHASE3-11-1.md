# Phase 3.11.1 — Live Vodia model-catalog resolution

Do NOT install the earlier Phase 3.11 first. Phase 3.11.1 is cumulative.

## New behavior

Device model resolution is no longer hard-coded around Yealink T46/T48.

For **any vendor**:

1. If the source model is exact and supported, use it.
2. If the source model is incomplete (for example `T48`, `T46`, or a future
   partial model family), query the LIVE Vodia read/API catalog for current
   device/model candidates.
3. If exactly one compatible model is found, resolve automatically.
4. If multiple compatible versions are found, return those actual Vodia models
   to the administrator and let the admin choose.
5. Store the selected override for identical source model strings during the
   migration session.
6. If no compatible live model exists, defer the device as unsupported.
7. Never guess a model that the live Vodia catalog did not return.

Missing serials remain non-blocking: write the validated `#` placeholder for an
otherwise-supported device and flag `SERIAL_PLACEHOLDER_USED`.

Device exceptions never block independent PBX migration stages.

## Example

Source:
`Yealink T48`

Live Vodia candidates:
`T48G`, `T48S`, `T48U`

Wizard:
> 3CX only identifies these devices as Yealink T48. Which Vodia model should be
> used? T48G / T48S / T48U. Apply this selection to all matching T48 devices?

The same mechanism applies to future incomplete Fanvil, Snom, Poly, Grandstream,
or other device model strings.

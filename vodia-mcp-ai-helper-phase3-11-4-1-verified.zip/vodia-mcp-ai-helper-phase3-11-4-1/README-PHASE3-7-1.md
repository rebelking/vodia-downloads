# Vodia MCP Phase 3.7.1 — shebang/safe-install hotfix

Phase 3.7 inserted the `node:child_process` import before the Node shebang, making
the installed `index.js` invalid:

```text
/opt/vodia-mcp/index.js:2
#!/usr/bin/env node
^
SyntaxError: Invalid or unexpected token
```

The running service survived only because the Phase 3.7 installer failed its
syntax check before restarting systemd. However, the broken file had already
been copied into `/opt/vodia-mcp/index.js`, so a later service restart would fail.

Phase 3.7.1:
- restores `#!/usr/bin/env node` as the first line;
- keeps `spawnSync` import immediately after the shebang;
- validates the candidate before touching the live file;
- backs up the live file;
- automatically rolls back if post-install validation, restart, or health check fails;
- preserves the Phase 3.7 raw ZIP ingestion tool and staging helper.

After installation, stage the sample if needed:

```bash
sudo bash /opt/vodia-mcp/stage-3cx-backup.sh /tmp/3cx-test-fixture-sanitized.zip
```

Then test in Claude:

> Ingest `3cx-test-fixture-sanitized.zip` and prepare it for conversion into a new Vodia tenant. Do not create anything yet. Ask only essential questions.

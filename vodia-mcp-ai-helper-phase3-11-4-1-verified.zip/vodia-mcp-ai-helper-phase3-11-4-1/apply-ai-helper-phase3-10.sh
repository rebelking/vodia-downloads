#!/usr/bin/env bash
set -Eeuo pipefail

APP="/opt/vodia-mcp"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LIVE="$APP/index.js"
CANDIDATE="$HERE/index.js"
BACK="/var/backups/vodia-mcp-ai-helper-phase3-10-$(date +%Y%m%d-%H%M%S)"

[[ ${EUID} -eq 0 ]] || { echo "Run with sudo/root."; exit 1; }
[[ -f "$LIVE" && -f "$CANDIDATE" ]] || { echo "Missing index.js"; exit 1; }

echo "[1/9] Preflight candidate syntax..."
node --check "$CANDIDATE"
head -n 1 "$CANDIDATE" | grep -qx '#!/usr/bin/env node'

echo "[2/9] Verify raw ZIP dependencies..."
grep -q 'import \* as fs from "node:fs";' "$CANDIDATE"
grep -q 'import \* as path from "node:path";' "$CANDIDATE"
grep -q '"pbx_ai_ingest_3cx_backup"' "$CANDIDATE"

echo "[3/9] Verify tenant endpoint hotfix..."
grep -q 'path: "/rest/system/domains"' "$CANDIDATE"
if grep -q 'path: "/rest/system/domain",' "$CANDIDATE"; then
  echo "ERROR: obsolete singular tenant-create endpoint still present."
  exit 1
fi

echo "[4/9] Backup live installation..."
mkdir -p "$BACK"
cp -a "$LIVE" "$BACK/index.js"

rollback() {
  rc=$?
  if [[ $rc -ne 0 ]]; then
    echo "ERROR: Phase 3.10 failed. Restoring previous index.js..."
    cp -a "$BACK/index.js" "$LIVE" || true
    systemctl restart vodia-mcp || true
  fi
  exit $rc
}
trap rollback EXIT

echo "[5/9] Install..."
install -m 0644 "$CANDIDATE" "$LIVE"

echo "[6/9] Validate installed file..."
node --check "$LIVE"

echo "[7/9] Restart..."
systemctl restart vodia-mcp

echo "[8/9] Wait for health..."
ok=0
for i in {1..20}; do
  if systemctl is-active --quiet vodia-mcp && curl -fsS http://127.0.0.1:3100/health >/dev/null 2>&1; then
    ok=1
    break
  fi
  sleep 1
done
[[ "$ok" -eq 1 ]] || {
  systemctl status vodia-mcp --no-pager -l || true
  journalctl -u vodia-mcp -n 80 --no-pager -l || true
  false
}

echo "[9/9] Verify live markers..."
grep -n 'pbx_ai_ingest_3cx_backup' "$LIVE" | head
grep -n 'pbx_ai_prepare_3cx_autopilot' "$LIVE" | head
grep -n 'path: "/rest/system/domains"' "$LIVE" | head

trap - EXIT
echo "Complete. Backup: $BACK"
echo "Phase 3.10 fixes raw ZIP path/fs ReferenceErrors and tenant POST endpoint."

#!/usr/bin/env bash
set -Eeuo pipefail
APP=/opt/vodia-mcp
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LIVE="$APP/index.js"
CANDIDATE="$HERE/index.js"
BACK="/var/backups/vodia-mcp-ai-helper-phase3-11-3-$(date +%Y%m%d-%H%M%S)"
[[ ${EUID} -eq 0 ]] || { echo "Run with sudo/root."; exit 1; }
echo "[1/8] Preflight..."
node --check "$CANDIDATE"
grep -q devicesFoundInSourceBackup "$CANDIDATE"
grep -q collect3cxModelEvidence "$CANDIDATE"
grep -q canonicalizeVodiaDeviceModel "$CANDIDATE"
echo "[2/8] Backup..."
mkdir -p "$BACK"; cp -a "$LIVE" "$BACK/index.js"
rollback(){ rc=$?; if [[ $rc -ne 0 ]]; then echo "ERROR: rolling back"; cp -a "$BACK/index.js" "$LIVE" || true; systemctl restart vodia-mcp || true; fi; exit $rc; }; trap rollback EXIT
echo "[3/8] Install..."; install -m 0644 "$CANDIDATE" "$LIVE"
echo "[4/8] Syntax..."; node --check "$LIVE"
echo "[5/8] Restart..."; systemctl restart vodia-mcp
echo "[6/8] Health..."
ok=0; for i in {1..20}; do if systemctl is-active --quiet vodia-mcp && curl -fsS http://127.0.0.1:3100/health >/dev/null 2>&1; then ok=1; break; fi; sleep 1; done; [[ $ok -eq 1 ]]
echo "[7/8] Verify..."; grep -n pbx_ai_resolve_device_model "$LIVE" | head; grep -n devicesFoundInSourceBackup "$LIVE" | head; grep -n collect3cxModelEvidence "$LIVE" | head
echo "[8/8] Complete."; trap - EXIT; echo "Backup: $BACK"; echo "Phase 3.11.3 installed."

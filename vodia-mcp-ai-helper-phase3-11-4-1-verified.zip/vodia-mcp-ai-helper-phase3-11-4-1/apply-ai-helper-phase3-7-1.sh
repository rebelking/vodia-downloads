#!/usr/bin/env bash
set -Eeuo pipefail

APP="/opt/vodia-mcp"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACK="/var/backups/vodia-mcp-ai-helper-phase3-7-1-$(date +%Y%m%d-%H%M%S)"
LIVE="$APP/index.js"
CANDIDATE="$HERE/index.js"

[[ ${EUID} -eq 0 ]] || { echo "Run with sudo/root."; exit 1; }
[[ -f "$LIVE" ]] || { echo "Missing $LIVE"; exit 1; }
[[ -f "$CANDIDATE" ]] || { echo "Missing candidate index.js"; exit 1; }
[[ -f /root/analyze-3cx-backup.py ]] || { echo "Missing /root/analyze-3cx-backup.py"; exit 1; }

echo "[1/8] Preflight candidate syntax BEFORE changing live files..."
node --check "$CANDIDATE"

echo "[2/8] Verify candidate shebang/import ordering..."
head -n 1 "$CANDIDATE" | grep -qx '#!/usr/bin/env node'
grep -q 'import { spawnSync } from "node:child_process";' "$CANDIDATE"
grep -q '"pbx_ai_ingest_3cx_backup"' "$CANDIDATE"
grep -q '"pbx_ai_prepare_3cx_tenant_conversion"' "$CANDIDATE"

echo "[3/8] Backup live installation..."
mkdir -p "$BACK"
cp -a "$LIVE" "$BACK/index.js"
[[ -f "$APP/stage-3cx-backup.sh" ]] && cp -a "$APP/stage-3cx-backup.sh" "$BACK/stage-3cx-backup.sh"

rollback() {
  rc=$?
  if [[ $rc -ne 0 ]]; then
    echo "ERROR: Phase 3.7.1 failed. Restoring previous index.js..."
    cp -a "$BACK/index.js" "$LIVE" || true
    systemctl restart vodia-mcp || true
  fi
  exit $rc
}
trap rollback EXIT

echo "[4/8] Install Phase 3.7.1..."
install -m 0644 "$CANDIDATE" "$LIVE"
install -m 0755 "$HERE/stage-3cx-backup.sh" "$APP/stage-3cx-backup.sh"
install -d -m 0750 /var/lib/vodia-mcp/3cx-raw-imports /var/lib/vodia-mcp/imports

echo "[5/8] Validate installed file..."
node --check "$LIVE"
head -n 1 "$LIVE" | grep -qx '#!/usr/bin/env node'

echo "[6/8] Restart..."
systemctl restart vodia-mcp

echo "[7/8] Wait for health..."
ok=0
for i in {1..20}; do
  if systemctl is-active --quiet vodia-mcp && curl -fsS http://127.0.0.1:3100/health >/dev/null 2>&1; then
    ok=1
    break
  fi
  sleep 1
done
[[ "$ok" -eq 1 ]] || {
  systemctl status vodia-mcp --no-pager -l || true
  journalctl -u vodia-mcp -n 80 --no-pager -l || true
  false
}

echo "[8/8] Verify tool markers..."
grep -n 'pbx_ai_ingest_3cx_backup' "$LIVE" | head
grep -n 'pbx_ai_prepare_3cx_tenant_conversion' "$LIVE" | head

trap - EXIT
echo "Complete. Backup: $BACK"
echo "Phase 3.7.1 is healthy."

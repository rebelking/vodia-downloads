# Vodia MCP Phase 3.8 — One-shot object-level 3CX conversion planner

Phase 3.8 removes the need for the AI/customer to manually retrieve twelve inventory
categories one at a time.

## New tool

`pbx_ai_build_3cx_conversion_plan`

Given the normalized 3CX file and the small set of migration decisions, it:
- loads every required source category automatically;
- includes exact object-level source values, not counts only;
- builds a dependency-ordered conversion manifest;
- translates obvious 3CX-native constructs such as HOL and QCB into Vodia-native concepts;
- skips obvious 3CX internal/default/favorites groups instead of asking needless questions;
- separates safe migration work from production-cutover blockers;
- never creates or changes PBX objects.

## Customer-facing direction

The intended flow is now:

`ZIP → ingest → ask ~2–4 essentials → build complete conversion plan → approval → guarded apply → verify`

The customer should not be asked whether the AI should fetch categories one by one.

## Test

After the raw ZIP has been ingested:

> Build the complete conversion plan for the normalized 3CX file into a NEW tenant.
> Create missing-email users without email, skip trunks first pass, review duplicate
> devices. Do not create anything.

The tool should return one complete plan with concrete source objects and stage status.

# Phase 3.11.3

- Ignore source IP/provisioning interface for migration eligibility.
- Group by exact source vendor + source model.
- Report exact quantity found in the uploaded 3CX backup, MACs and extensions.
- Inspect 3CX model/template/firmware/user-agent/provisioning fields for variant clues.
- Evidence can recommend but never silently choose among multiple live Vodia variants.
- Canonical Vodia provisioning names are returned (T46G/T46S/T46U), not firmware parameter keys.
- Missing serial uses `#` and continues.

#!/usr/bin/env python3
from pathlib import Path
import re, sys

p = Path(sys.argv[1] if len(sys.argv) > 1 else "/opt/vodia-mcp/admin.js")
text = p.read_text()

patterns = [
    r'z\.string\(\)\.min\(6\)\.regex\(/\^\[A-Za-z0-9\._-\]\+\$/\)',
    r'z\.string\(\)\.min\(6\)\.regex\(/\^\[A-Za-z0-9\.\_-\]\+\$/\)',
]

replacement = 'z.string().refine(v => v === "#" || (/^[A-Za-z0-9._-]+$/.test(v) && v.length >= 6), "Serial must be # or at least 6 characters using A-Z, a-z, 0-9, dot, underscore, or hyphen")'

matches = []
for pat in patterns:
    found = list(re.finditer(pat, text))
    if found:
        matches = found
        selected = pat
        break

if len(matches) != 1:
    raise SystemExit(f"Expected exactly one plan_provision_mac serial schema match; found {len(matches)}. admin.js left unchanged.")

new_text, count = re.subn(selected, replacement, text, count=1)
if count != 1:
    raise SystemExit("Serial schema patch failed. admin.js left unchanged.")

p.write_text(new_text)
print("Patched plan_provision_mac serial schema: exact '#' placeholder is now accepted.")

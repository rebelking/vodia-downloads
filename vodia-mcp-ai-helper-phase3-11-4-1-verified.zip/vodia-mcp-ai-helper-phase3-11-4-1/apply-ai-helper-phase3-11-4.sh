#!/usr/bin/env bash
set -Eeuo pipefail

APP="/opt/vodia-mcp"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LIVE_INDEX="$APP/index.js"
LIVE_ADMIN="$APP/admin.js"
CANDIDATE_INDEX="$HERE/index.js"
PATCH_ADMIN="$HERE/patch-admin-phase3-11-4.py"
BACK="/var/backups/vodia-mcp-ai-helper-phase3-11-4-$(date +%Y%m%d-%H%M%S)"

[[ ${EUID} -eq 0 ]] || { echo "Run with sudo/root."; exit 1; }

echo "[1/9] Preflight..."
[[ -f "$LIVE_INDEX" && -f "$LIVE_ADMIN" ]]
node --check "$CANDIDATE_INDEX"
python3 -m py_compile "$PATCH_ADMIN"
grep -q 'deriveVendorFromModel' "$CANDIDATE_INDEX"
grep -q 'button_templates' "$CANDIDATE_INDEX"
grep -q 'target_tenant' "$CANDIDATE_INDEX"

# Verify the currently installed admin.js has exactly one serial schema we know how to patch.
python3 - "$LIVE_ADMIN" <<'PY'
from pathlib import Path
import re, sys
text=Path(sys.argv[1]).read_text()
patterns=[
 r'z\.string\(\)\.min\(6\)\.regex\(/\^\[A-Za-z0-9\._-\]\+\$/\)',
 r'z\.string\(\)\.min\(6\)\.regex\(/\^\[A-Za-z0-9\.\_-\]\+\$/\)',
]
n=max(sum(1 for _ in re.finditer(p,text)) for p in patterns)
if n != 1:
    raise SystemExit(f"Preflight failed: expected one serial schema in admin.js, found {n}. Nothing changed.")
PY

echo "[2/9] Backup..."
mkdir -p "$BACK"
cp -a "$LIVE_INDEX" "$BACK/index.js"
cp -a "$LIVE_ADMIN" "$BACK/admin.js"

rollback() {
  rc=$?
  if [[ $rc -ne 0 ]]; then
    echo "ERROR: rolling back Phase 3.11.4..."
    cp -a "$BACK/index.js" "$LIVE_INDEX" || true
    cp -a "$BACK/admin.js" "$LIVE_ADMIN" || true
    systemctl restart vodia-mcp || true
  fi
  exit "$rc"
}
trap rollback EXIT

echo "[3/9] Install index.js..."
install -m 0644 "$CANDIDATE_INDEX" "$LIVE_INDEX"

echo "[4/9] Patch admin.js serial placeholder validation..."
python3 "$PATCH_ADMIN" "$LIVE_ADMIN"

echo "[5/9] Syntax..."
node --check "$LIVE_INDEX"
node --check "$LIVE_ADMIN"

echo "[6/9] Restart..."
systemctl restart vodia-mcp

echo "[7/9] Health..."
ok=0
for i in {1..20}; do
  if systemctl is-active --quiet vodia-mcp && curl -fsS http://127.0.0.1:3100/health >/dev/null 2>&1; then
    ok=1; break
  fi
  sleep 1
done
[[ "$ok" -eq 1 ]]

echo "[8/9] Verify..."
grep -n 'deriveVendorFromModel' "$LIVE_INDEX" | head
grep -n 'target_tenant' "$LIVE_INDEX" | head
grep -n 'Serial must be # or at least 6 characters' "$LIVE_ADMIN" | head

echo "[9/9] Complete."
trap - EXIT
echo "Backup: $BACK"
echo "Phase 3.11.4 installed."

# Phase 3.11.4.1

Hotfix for Phase 3.11.4 preflight against the verified live Vodia MCP 0.14.7
`plan_provision_mac` schema.

- Matches the actual serial schema from the running server.
- Allows exact `#` as the missing-serial migration placeholder.
- Retains Phase 3.11.4 model-catalog, vendor-derivation, canonical-model,
  interface-neutrality, and evidence-engine changes.
- Backs up index.js and admin.js and rolls back automatically on failure.

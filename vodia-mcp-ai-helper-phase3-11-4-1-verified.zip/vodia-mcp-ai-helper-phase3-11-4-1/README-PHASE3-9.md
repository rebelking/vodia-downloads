# Vodia MCP Phase 3.9 — 3CX Migration Autopilot

This phase is intentionally about reducing friction.

## New tool

`pbx_ai_prepare_3cx_autopilot`

The customer supplies:
- the normalized 3CX source file;
- the new Vodia tenant domain.

The tool applies safe defaults automatically:
- missing email -> create without email;
- trunks/gateways -> defer first pass;
- duplicate devices -> review, do not silently discard;
- 3CX internal/default/favorites groups -> skip;
- HOL -> Vodia service flag/timeframe concept;
- QCB -> Vodia queue callback concept;
- unsupported/ambiguous legacy phones -> defer and flag;
- dial plan -> defer while trunks are deferred;
- emergency routing -> production blocker until explicitly configured/tested.

It distinguishes:
- safe migration work that can proceed;
- review items that should be visible but do not need to block the first pass;
- production-cutover blockers that must remain unresolved until explicitly configured.

The desired customer interaction is now:

1. Upload/stage 3CX backup.
2. Analyze.
3. Provide new tenant domain.
4. Review one migration summary.
5. Approve with one exact phrase.
6. Staged guarded execution is the next execution-layer step.

This phase does not itself auto-apply writes; it creates the single-approval package
without inventing unsupported low-level API behavior.

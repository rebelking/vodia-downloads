#!/usr/bin/env python3
from pathlib import Path
import sys

p = Path(sys.argv[1] if len(sys.argv) > 1 else "/opt/vodia-mcp/admin.js")
text = p.read_text()

old_schema = '''serial_number: z.string().trim().min(6).max(128).regex(/^[A-Za-z0-9._-]+$/).optional()
        .describe("Full Yealink serial number. Required when vendor is Yealink; do not submit only the legacy last-five-digit handset challenge."),'''

new_schema = '''serial_number: z.string().trim().max(128)
        .refine(v => v === "#" || (/^[A-Za-z0-9._-]+$/.test(v) && v.length >= 6), "Serial must be # or at least 6 characters using A-Z, a-z, 0-9, dot, underscore, or hyphen")
        .optional()
        .describe("Full Yealink serial number, or exact # as the migration placeholder when the source backup has no serial. Required when vendor is Yealink."),'''

if old_schema in text:
    text = text.replace(old_schema, new_schema, 1)
elif "Serial must be # or at least 6 characters" not in text:
    raise SystemExit("Expected live plan_provision_mac serial schema was not found. admin.js left unchanged.")

old_missing = '''if (isYealink && !serial_number) {
        throw new Error("The full Yealink serial number is required for Vodia RPS API V2 provisioning. Ask for the complete serial number, not only the last five digits.");
      }'''
new_missing = '''if (isYealink && !serial_number) {
        throw new Error("A Yealink serial number is required. During 3CX migration, use exact # only when the source backup has no serial and the administrator accepts the placeholder.");
      }'''
if old_missing in text:
    text = text.replace(old_missing, new_missing, 1)

p.write_text(text)
print("Patched plan_provision_mac for exact # migration-placeholder support.")

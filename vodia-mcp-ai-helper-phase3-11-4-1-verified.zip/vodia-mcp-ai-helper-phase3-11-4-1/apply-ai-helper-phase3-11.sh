#!/usr/bin/env bash
set -Eeuo pipefail
APP=/opt/vodia-mcp
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LIVE="$APP/index.js"; CANDIDATE="$HERE/index.js"
BACK="/var/backups/vodia-mcp-ai-helper-phase3-11-$(date +%Y%m%d-%H%M%S)"
[[ $EUID -eq 0 ]] || { echo 'Run with sudo/root'; exit 1; }
node --check "$CANDIDATE"
grep -q '"pbx_ai_prepare_3cx_device_migration"' "$CANDIDATE"
mkdir -p "$BACK"; cp -a "$LIVE" "$BACK/index.js"
rollback(){ rc=$?; if [[ $rc -ne 0 ]]; then cp -a "$BACK/index.js" "$LIVE" || true; systemctl restart vodia-mcp || true; fi; exit $rc; }
trap rollback EXIT
install -m 0644 "$CANDIDATE" "$LIVE"
node --check "$LIVE"
systemctl restart vodia-mcp
for i in {1..20}; do
  if systemctl is-active --quiet vodia-mcp && curl -fsS http://127.0.0.1:3100/health >/dev/null 2>&1; then ok=1; break; fi
  sleep 1
done
[[ ${ok:-0} -eq 1 ]]
grep -n 'pbx_ai_prepare_3cx_device_migration' "$LIVE" | head
trap - EXIT
echo "Complete. Backup: $BACK"

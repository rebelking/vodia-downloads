# Phase 3.11 — Non-blocking device migration

Adds `pbx_ai_prepare_3cx_device_migration`.

Rules:
- supported device + serial present → ready to migrate;
- supported device + serial missing → use `#` as validated serial placeholder and continue;
- ambiguous Yealink family such as bare `T46` → admin chooses exact Vodia model (T46G/T46S/T46U), optionally once for all matches;
- unsupported model → defer and report;
- legacy/duplicate device → defer for admin review;
- device exceptions do not stop tenant/users/ring-groups/queue/IVR/etc migration.

Statuses are surfaced in an administrator action report. Overall migration may finish as `COMPLETED_WITH_ACTIONS_REQUIRED` rather than fail.

This phase is read-only for device provisioning: it prepares classification and admin decisions but does not create MAC records.

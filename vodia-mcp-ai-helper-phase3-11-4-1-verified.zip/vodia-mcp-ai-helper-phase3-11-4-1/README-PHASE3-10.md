# Vodia MCP Phase 3.10 — ingestion + tenant-creation hotfix

This release fixes the two defects found by the first autopilot execution test.

## Fix 1 — raw ZIP ingestion `path is not defined`

Phase 3.7+ used `path.basename`, `path.resolve`, `path.sep`, `path.join`, and
`fs.statSync`/`fs.mkdirSync`, while the module only imported named helpers.

Phase 3.10 adds namespace imports:

```js
import * as fs from "node:fs";
import * as path from "node:path";
```

This keeps the existing named imports intact and makes raw ZIP ingestion runnable.

## Fix 2 — tenant creation HTTP 404

The guarded tenant apply path was posting to:

`POST /rest/system/domain`

The live Vodia 70.6.beta server returned HTTP 404. The live API catalog exposes
tenant creation at:

`POST /rest/system/domains`

Phase 3.10 changes the guarded tenant creation call to the plural endpoint while
keeping the existing preflight and post-write verification through:

`GET /rest/system/domains`

The request body remains the DNS-name array already used by the connector:
`["newtenant.example.com"]`.

## Approval clarification

The autopilot approval phrase represents customer approval to begin the staged
migration workflow. Existing low-level write tools still retain their own exact
confirmation checks. Phase 3.10 does not weaken those guards or pretend one phrase
bypasses validated per-operation controls.

## Retest order

1. Install Phase 3.10.
2. Verify health.
3. Re-run raw ZIP ingestion.
4. Prepare autopilot package.
5. Plan tenant creation.
6. Apply tenant creation using its exact guarded confirmation.
7. Verify the new tenant appears in `GET /rest/system/domains`.
8. Only then move to extension import.

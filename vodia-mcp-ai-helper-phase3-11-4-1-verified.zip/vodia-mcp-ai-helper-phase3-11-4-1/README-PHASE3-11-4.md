# Phase 3.11.4

Fixes the confirmed Phase 3.11.3 device-migration blockers while retaining the
good 3.11.3 behavior.

## Changes

- Uses Vodia's tenant button-template provisioning catalog when `target_tenant`
  (or resolver `domain`) is provided.
- Keeps system parameters only as a supplemental firmware-family source.
- Derives a missing vendor only from an unambiguous source-model prefix.
- Allows the exact `#` placeholder in `plan_provision_mac`; normal serials still
  require at least six characters from the existing safe character set.
- Keeps canonical model names such as `T46G`, not firmware parameter keys.
- Keeps source IP/interface out of device eligibility.
- Keeps source counts, MACs, extensions, grouped admin selection, and evidence.
- Records family-level evidence (for example `yealinkT4x_DEFAULT_COPY`) without
  claiming it identifies G/S/U.

## Fixture regression target

For the 71-device sanitized fixture, once run with:

`target_tenant=allisonmackenzie-migration.tryvodia.com`

the mathematically consistent target is:

- `READY_TO_MIGRATE`: 37
- `DEFERRED_AMBIGUOUS_MODEL`: 31
- `DEFERRED_UNSUPPORTED`: 3
- `DEFERRED_LEGACY`: 0

37 + 31 + 3 = 71. The earlier report's suggested 35-ready target conflicts with
its own requirement to eliminate the two interface-based legacy deferrals.

No phone is provisioned by the preparation tool.

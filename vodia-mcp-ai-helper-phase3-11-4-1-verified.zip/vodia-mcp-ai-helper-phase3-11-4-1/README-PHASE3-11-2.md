# Phase 3.11.2 — Explicit live device model resolver

This package is cumulative over Phase 3.11.1.

## New MCP tool

`pbx_ai_resolve_device_model`

Given a vendor and incomplete source model (for example `Yealink T46` or
`Yealink T48`), the MCP queries the live Vodia device/model catalog and returns
only compatible live Vodia candidates.

- one candidate → `AUTO_SELECT`
- multiple candidates → `ADMIN_SELECT_MODEL`
- no candidate → defer unsupported
- never invent a model

The resolver is vendor-neutral and applies to future incomplete Yealink, Fanvil,
Snom, Poly, Grandstream, or other model families.

## Grouped admin choice

`pbx_ai_prepare_3cx_device_migration` groups identical ambiguous source model
strings. Instead of asking 30 times for `Yealink T46`, it returns one group with:

- source vendor/model
- number of affected devices
- affected extensions
- actual live Vodia candidate models
- `ADMIN_SELECT_MODEL`
- `applySelectionToAllMatchingSourceModels: true`

Missing serials remain non-blocking:
supported phone + no serial → `serial_number = "#"` and
`SERIAL_PLACEHOLDER_USED`.

Device exceptions never block independent PBX migration stages.

## Recheck hardening

Candidate matching is manufacturer-scoped. If the 3CX source says `Yealink`,
the resolver will not offer a Fanvil/Snom/Poly model simply because its model
token happens to resemble `T46` or `T48`.

import {
  listAwsChimePhoneNumbers,
  listAwsChimeVoiceConnectors,
  recommendAwsChimeRegion,
} from "./aws-chime.js";

const WORKFLOWS = {
  amazon_chime: {
    id: "amazon_chime",
    title: "Amazon Chime tenant connection",
    examples: [
      "Set up Amazon Chime for this tenant",
      "Create a Chime connection for customer.example.com",
      "Get this tenant a local number on Chime",
    ],
    policy: "Discover → recommend → choices → plan → explicit approval → apply → verify → audit",
    defaultRecommendations: {
      region: "automatic from deployment country, validated against AWS",
      encryption: "TLS/SRTP",
      networkType: "IPV4_ONLY",
      forcePhoneNumberReassignment: false,
    },
    toolFamilies: [
      "aws_chime_*",
      "Vodia trunk/DID/dial-plan read tools",
      "Vodia guarded plan/apply tools",
    ],
    verify: [
      "Voice Connector exists",
      "phone number order/assignment is complete when requested",
      "Vodia trunk points at the AWS-generated Voice Connector hostname",
      "DID routing is correct",
      "test call or observable SIP state confirms the path",
    ],
  },
  sip_trunk: {
    id: "sip_trunk",
    title: "SIP trunk setup or change",
    examples: ["Set up Telnyx for this tenant", "Create a SIP trunk", "Change this carrier trunk"],
    policy: "Read existing trunks/provider context → recommend settings → guarded Vodia plan/apply → verify",
    toolFamilies: ["find_read_capabilities", "read_vodia_resource", "inspect_vodia_operation", "Vodia trunk planners", "apply_vodia_change"],
    verify: ["trunk exists/enabled", "routing references correct trunk", "inbound/outbound test result"],
  },
  extension: {
    id: "extension",
    title: "Extension/user administration",
    examples: ["Create extension 205 for John", "Update extension 3005", "Disable this user"],
    policy: "Check tenant and number conflicts → recommend defaults → guarded plan/apply → verify",
    toolFamilies: ["extension/account reads", "account planners", "apply_vodia_change"],
    verify: ["account exists with intended settings", "registration/provisioning state where applicable"],
  },
  phone: {
    id: "phone",
    title: "Phone provisioning",
    examples: ["Provision this Yealink", "Assign this MAC to extension 205", "Why did this phone stop provisioning?"],
    policy: "Discover vendor/model/MAC/tenant → inspect existing assignment → plan → approve → apply → verify registration",
    toolFamilies: ["MAC/device reads", "vendor/model discovery", "MAC provisioning planners", "registration reads"],
    verify: ["MAC assigned", "provisioning generated", "device registered"],
  },
  did: {
    id: "did",
    title: "DID and phone-number routing",
    examples: ["Send this DID to extension 205", "Assign this number to the queue", "Find DID conflicts"],
    policy: "Read DID inventory/conflicts → propose destination → guarded plan/apply → verify",
    toolFamilies: ["DID reads", "DID assignment planners", "dial-plan/routing reads"],
    verify: ["DID uniquely assigned", "inbound route reaches intended target"],
  },
  dial_plan: {
    id: "dial_plan",
    title: "Dial plan and routing",
    examples: ["Route 9 plus number through Chime", "Create an outbound rule", "Change international routing"],
    policy: "Inspect existing rules/trunks → detect overlap → guarded plan/apply → verify",
    toolFamilies: ["dial-plan reads", "dial-plan planners", "trunk reads"],
    verify: ["rule order and pattern are correct", "expected trunk is selected"],
  },
  queue: {
    id: "queue",
    title: "ACD/queue operations",
    examples: ["Create a support queue", "Add these agents", "Why are calls abandoning?"],
    policy: "Inspect queue/agents/live state/stats → recommend → plan/apply when changing → verify",
    toolFamilies: ["ACD reads", "queue stats", "agent state", "generic guarded admin operations"],
    verify: ["agents and algorithm match intent", "live/queue stats show expected behavior"],
  },
  ivr: {
    id: "ivr",
    title: "IVR/auto attendant",
    examples: ["Create a main menu", "Change option 2 to support", "Route after-hours differently"],
    policy: "Read existing IVR/routing/audio → propose menu → guarded change → verify",
    toolFamilies: ["resource discovery", "generic Vodia reads", "guarded admin operations"],
    verify: ["menu destinations resolve", "audio/routing behavior matches plan"],
  },
  voicemail: {
    id: "voicemail",
    title: "Voicemail",
    examples: ["Configure voicemail for 205", "Why is voicemail not taking calls?"],
    policy: "Read account/forwarding/voicemail state → recommend → guarded change → verify",
    toolFamilies: ["account reads", "resource discovery", "guarded admin operations"],
    verify: ["voicemail settings and forwarding path are correct"],
  },
  troubleshoot_call: {
    id: "troubleshoot_call",
    title: "Call/SIP/audio troubleshooting",
    examples: ["Why did this call fail?", "Find one-way audio", "Why did this call get 408?"],
    policy: "Read-only diagnosis first; correlate CDR, live state, SIP/PCAP, trunk, routing and registrations before proposing a fix",
    toolFamilies: ["CDR reads", "live-call reads", "PCAP/SIP diagnostics", "trunk stats", "registration reads"],
    verify: ["root cause is evidence-backed", "post-fix test no longer reproduces issue"],
  },
  troubleshoot_registration: {
    id: "troubleshoot_registration",
    title: "Registration troubleshooting",
    examples: ["Why is extension 3005 offline?", "Which phones are not registered?"],
    policy: "Read registration/account/provisioning state first; make no changes until cause is identified",
    toolFamilies: ["registration reads", "extension reads", "provisioning reads", "system/network diagnostics"],
    verify: ["device registers and remains stable"],
  },
  cdr: {
    id: "cdr",
    title: "CDR and reporting",
    examples: ["Show abandoned calls", "How many calls connected?", "Report outbound attempts"],
    policy: "Read-only analytics by default",
    toolFamilies: ["CDR reads", "tenant stats", "queue stats"],
    verify: ["filters and definitions are stated with the report"],
  },
  system_health: {
    id: "system_health",
    title: "PBX system health",
    examples: ["Check CPU RAM and disk", "Is the PBX healthy?", "Check license and update state"],
    policy: "Read system status/stats first; privileged remediation requires guarded plan/apply",
    toolFamilies: ["system status", "system stats", "license/update reads", "audit"],
    verify: ["health indicators return to expected range after remediation"],
  },
  maintenance: {
    id: "maintenance",
    title: "Backup/upgrade/maintenance",
    examples: ["Is this PBX safe to upgrade?", "Prepare an upgrade", "Check backup readiness"],
    policy: "Inventory/version/health/backup checks first; high-impact changes require explicit approval and post-change verification",
    toolFamilies: ["system/version reads", "health reads", "critical guarded operations"],
    verify: ["service health, version, registrations, trunks and test calls after change"],
  },
  certificates: {
    id: "certificates",
    title: "DNS/certificate troubleshooting",
    examples: ["Why isn't the certificate renewing?", "Check this tenant DNS", "Validate HTTPS readiness"],
    policy: "Read/validate before any DNS or system change",
    toolFamilies: ["system/domain reads", "logs", "external diagnostics when available"],
    verify: ["DNS resolves correctly", "certificate is valid and served"],
  },
  general: {
    id: "general",
    title: "General PBX administration",
    examples: ["Help me configure this tenant", "Check this PBX"],
    policy: "Discover context first → choose a specific workflow → read before write",
    toolFamilies: ["find_read_capabilities", "read_vodia_resource", "inspect_vodia_operation"],
    verify: ["select a more specific workflow before applying changes"],
  },
};

function classify(request, provider) {
  const text = `${request || ""} ${provider || ""}`.toLowerCase();
  if (/\b(chime|amazon chime|aws voice|voice connector)\b/.test(text)) return "amazon_chime";
  if (/\b(one[- ]way audio|no audio|sip|408|486|487|call fail|failed call|dropped call|rtp|pcap)\b/.test(text)) return "troubleshoot_call";
  if (/\b(register|registration|offline phone|not registered)\b/.test(text)) return "troubleshoot_registration";
  if (/\b(sip trunk|trunk|telnyx|bandwidth|skyetel|flowroute|carrier)\b/.test(text)) return "sip_trunk";
  if (/\b(extension|account|user)\b/.test(text)) return "extension";
  if (/\b(phone|yealink|snom|fanvil|poly|grandstream|mac|provision)\b/.test(text)) return "phone";
  if (/\b(did|phone number|number route|inbound number)\b/.test(text)) return "did";
  if (/\b(dial plan|outbound rule|route calls|routing rule)\b/.test(text)) return "dial_plan";
  if (/\b(queue|acd|agent|abandon)\b/.test(text)) return "queue";
  if (/\b(ivr|auto attendant|menu)\b/.test(text)) return "ivr";
  if (/\b(voicemail|mailbox)\b/.test(text)) return "voicemail";
  if (/\b(cdr|call report|call history|analytics)\b/.test(text)) return "cdr";
  if (/\b(cpu|memory|ram|disk|system health|license)\b/.test(text)) return "system_health";
  if (/\b(upgrade|backup|maintenance|reboot)\b/.test(text)) return "maintenance";
  if (/\b(certificate|cert|dns|acme|https)\b/.test(text)) return "certificates";
  return "general";
}

function basePrepared(workflow, input) {
  const missingInputs = [];
  const choices = [];
  if (["amazon_chime", "sip_trunk", "extension", "phone", "did", "dial_plan", "queue", "ivr", "voicemail"].includes(workflow.id) && !input.tenant) {
    missingInputs.push({ field: "tenant", reason: "Target tenant/domain is needed before configuration changes can be planned." });
  }
  return {
    workflow,
    request: input.request,
    tenant: input.tenant || null,
    provider: input.provider || null,
    safety: {
      readsMayRunAutomatically: true,
      writesRequirePlanAndExplicitApproval: true,
      destructiveOrCriticalChangesNeedStrongerConfirmation: true,
      verifyAfterApply: true,
      auditExpected: true,
    },
    missingInputs,
    choices,
    workflowStatus: missingInputs.length ? "BLOCKED" : "READY_FOR_DISCOVERY",
    blockers: missingInputs.map((item) => ({
      type: "missing_input",
      field: item.field,
      reason: item.reason,
    })),
    canPlanWrites: false,
    canApplyWrites: false,
    nextAction: missingInputs.length ? "Collect the missing information, then prepare again." : "Continue with workflow discovery and planning.",
    changesMade: false,
  };
}


const GUIDED_WORKFLOW_FIELDS = {
  extension: {
    humanGoal: "Create or update a user extension with the fewest administrator questions possible.",
    essential: [
      { key:"tenant", label:"Tenant/domain", required:true, discoverable:true },
      { key:"first_name", label:"First name", required:true, discoverable:false },
      { key:"last_name", label:"Last name", required:true, discoverable:false },
      { key:"extension", label:"Extension number", required:true, discoverable:false },
      { key:"email", label:"Email address", required:true, discoverable:false },
      { key:"mac_address", label:"Phone MAC address", required:false, discoverable:false,
        note:"Optional. Ask only when a desk phone should be provisioned now." },
    ],
    automaticChecks: [
      "Confirm tenant exists and is permitted.",
      "Check the requested number across all tenant account types, not only extensions.",
      "Check whether the email is already used when the PBX exposes that data.",
      "If a MAC is supplied, check existing device/MAC assignments before planning provisioning.",
      "Inspect tenant/current extension defaults when available instead of asking the administrator for low-level PBX fields.",
    ],
    defaults: [
      "Use safe tenant defaults for unspecified extension settings.",
      "Do not invent a MAC, email, extension number, name, or tenant.",
      "Do not ask for SIP/API fields that the MCP can derive or default safely.",
    ],
    verify: [
      "Extension exists with intended name and email.",
      "No account-number conflict was introduced.",
      "If MAC supplied: device assignment/provisioning is present.",
      "If a device is expected online: verify registration after apply.",
    ],
  },
  dial_plan: {
    humanGoal: "Build a dial plan from business intent rather than API fields.",
    essential: [
      { key:"tenant", label:"Tenant/domain", required:true, discoverable:true },
      { key:"purpose", label:"What should this dial plan accomplish?", required:true, discoverable:false,
        examples:["normal outbound US calling","international calling","emergency calling","custom prefix routing"] },
      { key:"dialing_pattern", label:"What should users dial?", required:true, discoverable:false,
        examples:["10 digits","1 + 10 digits","9 + number","both 10 and 11 digits"] },
      { key:"trunk", label:"Which trunk/provider should carry the calls?", required:false, discoverable:true,
        note:"Discover existing trunks and recommend one; ask only if there is more than one sensible choice." },
    ],
    automaticChecks: [
      "List existing dial plans and detect overlap/conflicts.",
      "List available trunks and their current state.",
      "Prefer an already-working trunk that fits the administrator's stated purpose.",
      "Inspect existing tenant numbering conventions before recommending patterns.",
    ],
    defaults: [
      "Do not ask for regex/API fields if a normal human description can be translated safely.",
      "Recommend the least surprising dialing pattern based on existing tenant behavior.",
    ],
    verify: [
      "New rule ordering does not shadow existing rules unexpectedly.",
      "The intended dialed patterns select the intended trunk.",
      "A test call or read-only route check confirms expected behavior when available.",
    ],
  },
  sip_trunk: {
    humanGoal: "Create a SIP trunk by asking for provider/business facts and deriving technical defaults.",
    essential: [
      { key:"tenant", label:"Tenant/domain", required:true, discoverable:true },
      { key:"provider", label:"Provider", required:true, discoverable:false },
      { key:"credentials", label:"Provider credentials", required:false, discoverable:false,
        note:"Ask only if the provider requires credentials and they cannot be obtained through an integrated provider workflow." },
    ],
    automaticChecks: [
      "List existing trunks to prevent duplicates.",
      "Use provider-specific defaults/templates when known.",
      "Prefer TLS/SRTP where the provider/integration supports it.",
      "Check routing dependencies before presenting the plan as ready.",
    ],
    verify:["Trunk exists","Required auth/settings match provider","Inbound/outbound path is testable"],
  },
  did: {
    humanGoal: "Route a DID using only the number and business destination.",
    essential: [
      { key:"tenant", label:"Tenant/domain", required:true, discoverable:true },
      { key:"did", label:"Phone number/DID", required:true, discoverable:false },
      { key:"destination", label:"Destination", required:true, discoverable:false,
        examples:["extension 2012","queue 333","auto attendant 500"] },
    ],
    automaticChecks:[
      "Check whether the DID is already assigned.",
      "Validate that the destination account exists.",
      "Detect conflicting inbound routes.",
    ],
    verify:["DID uniquely maps to intended destination","Inbound route resolves correctly"],
  },
  queue: {
    humanGoal: "Create a queue using a queue number/name and the people who should answer it.",
    essential: [
      { key:"tenant", label:"Tenant/domain", required:true, discoverable:true },
      { key:"queue_number", label:"Queue number", required:true, discoverable:false },
      { key:"queue_name", label:"Queue name", required:true, discoverable:false },
      { key:"agents", label:"Agent extensions", required:true, discoverable:false },
    ],
    automaticChecks:[
      "Check account-number conflicts.",
      "Validate every agent extension exists.",
      "Inspect existing queue defaults/algorithms and recommend a safe default.",
    ],
    verify:["Queue exists","Agents are assigned","Queue status is readable"],
  },
  ivr: {
    humanGoal: "Create an auto attendant from a menu description.",
    essential: [
      { key:"tenant", label:"Tenant/domain", required:true, discoverable:true },
      { key:"ivr_number", label:"Auto-attendant number", required:true, discoverable:false },
      { key:"ivr_name", label:"Auto-attendant name", required:true, discoverable:false },
      { key:"menu_options", label:"Menu choices and destinations", required:true, discoverable:false },
    ],
    automaticChecks:[
      "Check account-number conflicts.",
      "Validate destinations.",
      "Inspect existing tenant routing/audio conventions.",
    ],
    verify:["Menu exists","All destinations resolve","Routing matches requested menu"],
  },
  phone: {
    humanGoal: "Provision a phone with only a MAC and extension when possible.",
    essential: [
      { key:"tenant", label:"Tenant/domain", required:true, discoverable:true },
      { key:"extension", label:"Extension number", required:true, discoverable:false },
      { key:"mac_address", label:"Phone MAC address", required:true, discoverable:false },
    ],
    automaticChecks:[
      "Validate extension exists.",
      "Check MAC conflict/ownership.",
      "Detect vendor/model when the PBX/device database can do so.",
    ],
    verify:["MAC is assigned","Provisioning exists","Phone registers when reachable"],
  },
  voicemail: {
    humanGoal: "Configure voicemail without exposing low-level account fields.",
    essential: [
      { key:"tenant", label:"Tenant/domain", required:true, discoverable:true },
      { key:"extension", label:"Extension number", required:true, discoverable:false },
      { key:"purpose", label:"What should voicemail do?", required:false, discoverable:false },
    ],
    automaticChecks:["Validate extension exists","Read current forwarding/voicemail settings first"],
    verify:["Voicemail/forwarding behavior matches requested intent"],
  },
  amazon_chime: {
    humanGoal: "Build an end-to-end Chime connection while hiding AWS implementation details.",
    essential: [
      { key:"tenant", label:"Tenant/domain", required:true, discoverable:true },
      { key:"country", label:"Deployment country", required:true, discoverable:false },
      { key:"area_code", label:"Area code", required:false, discoverable:false,
        note:"Ask only if the administrator wants a new local number." },
      { key:"destination", label:"Inbound destination", required:false, discoverable:false },
    ],
    automaticChecks:[
      "Discover/recommend AWS region.",
      "Check Voice Connectors, credentials, termination, origination, inventory and number assignment.",
      "Check matching Vodia trunk and routing.",
    ],
    verify:[
      "AWS connector and required settings exist.",
      "Phone number is assigned when requested.",
      "Vodia trunk and DID route match AWS.",
      "Inbound/outbound path can be tested.",
    ],
  },
};

export function getGuidedWorkflowDefinition(workflowId) {
  const id = String(workflowId || "").trim();
  const specific = GUIDED_WORKFLOW_FIELDS[id] || null;
  if (specific) return specific;
  return {
    humanGoal: "Complete the administrator's request while asking only for information that cannot be discovered safely.",
    essential: [{ key:"tenant", label:"Tenant/domain", required:false, discoverable:true }],
    automaticChecks:["Read current PBX state before proposing changes."],
    defaults:["Use safe existing tenant defaults when possible."],
    verify:["Verify the requested outcome after apply."],
  };
}

export function buildGuidedInputState(workflowId, input = {}, discovery = {}) {
  const definition = getGuidedWorkflowDefinition(workflowId);
  const details = input.details && typeof input.details === "object" ? input.details : {};
  const combined = { ...details, ...input };

  const questions = [];
  const resolved = {};
  for (const field of definition.essential) {
    let value = combined[field.key];

    if ((value === undefined || value === null || value === "") && field.key === "tenant") {
      value = discovery.resolvedTenant || input.tenant || null;
    }
    if ((value === undefined || value === null || value === "") && field.key === "trunk") {
      value = discovery.recommendedTrunk || null;
    }

    if (value !== undefined && value !== null && value !== "") {
      resolved[field.key] = value;
    } else if (field.required) {
      questions.push({
        field: field.key,
        question: `What is the ${field.label.toLowerCase()}?`,
        examples: field.examples || undefined,
        note: field.note || undefined,
      });
    } else if (!field.discoverable && field.note) {
      questions.push({
        field: field.key,
        question: `Do you want to provide ${field.label.toLowerCase()}?`,
        optional: true,
        note: field.note,
      });
    }
  }

  return {
    definition,
    resolved,
    questions,
    readyForPlanning: questions.filter((q) => !q.optional).length === 0,
  };
}

export function getAiWorkflowCatalog() {
  return {
    schemaVersion: 1,
    principle: "The AI interprets intent; the MCP supplies deterministic discovery, recommendations, guarded plans, execution, verification goals and audit boundaries.",
    interactionPattern: ["DISCOVER", "RECOMMEND", "CHOICES", "PLAN", "APPROVAL", "APPLY", "VERIFY", "REPORT"],
    workflows: Object.values(WORKFLOWS),
  };
}

export async function prepareAiWorkflow(input = {}) {
  const request = String(input.request || "").trim();
  if (!request) throw new Error("request is required.");
  const id = classify(request, input.provider);
  const workflow = WORKFLOWS[id] || WORKFLOWS.general;
  const result = basePrepared(workflow, { ...input, request });

  if (id !== "amazon_chime") return result;

  const country = String(input.country || "").trim();
  if (!country) {
    result.missingInputs.push({
      field: "country",
      reason: "Deployment country is used to recommend and validate the AWS Voice Connector region.",
    });
  }

  let regionInfo = null;
  if (country) {
    regionInfo = await recommendAwsChimeRegion({ country, region: input.region });
  }

  const connectors = await listAwsChimeVoiceConnectors({ region: regionInfo?.recommendedRegion || input.region, maxResults: 99 });
  const matching = input.tenant
    ? connectors.voiceConnectors.filter((c) => String(c.name || "").toLowerCase() === String(input.tenant).toLowerCase())
    : [];

  const inventory = await listAwsChimePhoneNumbers({ region: regionInfo?.recommendedRegion || input.region, maxResults: 99 });

  result.discovery = {
    awsConnected: true,
    recommendedRegion: regionInfo?.recommendedRegion || null,
    countryCode: regionInfo?.countryCode || null,
    availableVoiceConnectorCount: connectors.voiceConnectors.length,
    matchingVoiceConnectors: matching,
    phoneNumberInventory: inventory.phoneNumbers,
  };

  result.recommendations = {
    region: regionInfo?.recommendedRegion || "automatic after country is known",
    encryption: "TLS/SRTP",
    networkType: "IPV4_ONLY",
    connectorStrategy: matching.length === 1 ? "reuse-existing" : matching.length > 1 ? "choose-existing" : "create-new",
    numberStrategy: inventory.phoneNumbers.length ? "ask: existing inventory vs search new vs no number yet" : "ask: search new vs no number yet",
    forcePhoneNumberReassignment: false,
  };

  result.choices = [
    {
      id: "connector",
      question: "Voice Connector",
      options: matching.length
        ? [
            { value: "reuse-existing", label: `Reuse matching connector ${matching[0]?.name || ""}`, recommended: matching.length === 1 },
            { value: "create-new", label: "Create a new Voice Connector", recommended: false },
          ]
        : [{ value: "create-new", label: "Create a new Voice Connector", recommended: true }],
    },
    {
      id: "phone_number",
      question: "Phone number",
      options: [
        ...(inventory.phoneNumbers.length ? [{ value: "use-existing", label: "Use an existing AWS phone number", recommended: false }] : []),
        { value: "search-new", label: "Search for a new local number", recommended: true },
        { value: "none", label: "Configure SIP only; no number yet", recommended: false },
      ],
    },
    {
      id: "security",
      question: "Security",
      options: [
        { value: "tls-srtp", label: "TLS/SRTP", recommended: true },
        { value: "standard-sip", label: "Standard SIP", recommended: false },
      ],
    },
    {
      id: "region",
      question: "AWS region",
      options: [
        { value: regionInfo?.recommendedRegion || "automatic", label: `Automatic${regionInfo?.recommendedRegion ? ` (${regionInfo.recommendedRegion})` : ""}`, recommended: true },
        { value: "manual", label: "Choose manually", recommended: false },
      ],
    },
  ];

  if (input.areaCode) {
    result.preferences = { areaCode: String(input.areaCode) };
  }

  const blockers = [];
  if (result.missingInputs.length) {
    blockers.push(...result.missingInputs.map((item) => ({
      type: "missing_input",
      field: item.field,
      reason: item.reason,
    })));
  }

  // A matching connector is not mandatory because the workflow can create one,
  // but AWS connectivity and live inventory discovery must succeed before we
  // present any write plan as ready.
  if (!result.discovery?.awsConnected) {
    blockers.push({
      type: "dependency",
      dependency: "AWS",
      reason: "Amazon Chime/AWS discovery is not available.",
    });
  }

  result.blockers = blockers;
  result.workflowStatus = blockers.length ? "BLOCKED" : "READY_FOR_CHOICES";
  result.canPlanWrites = blockers.length === 0;
  result.canApplyWrites = false;
  result.applyGate = {
    policy: "Never apply AWS or Vodia changes from this preparation step.",
    requirement: "After choices are selected, create guarded plans. Only a later explicit approval may apply them.",
  };

  result.nextAction = blockers.length
    ? "Resolve the blockers first. Do not create or apply AWS or Vodia write plans while the workflow is BLOCKED."
    : "Present the choices to the administrator. After choices are selected, create guarded AWS and Vodia plans. If any later prerequisite fails, mark the workflow BLOCKED and do not present partial plans as ready for approval.";

  return result;
}

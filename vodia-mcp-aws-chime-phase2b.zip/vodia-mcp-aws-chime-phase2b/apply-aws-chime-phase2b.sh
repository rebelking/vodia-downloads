#!/usr/bin/env bash
set -Eeuo pipefail
APP_DIR="/opt/vodia-mcp"
BACKUP="/var/backups/vodia-mcp-aws-phase2b-$(date +%Y%m%d-%H%M%S)"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
[[ ${EUID} -eq 0 ]] || { echo "Run: sudo bash apply-aws-chime-phase2b.sh"; exit 1; }
mkdir -p "$BACKUP"
cp -a "$APP_DIR/index.js" "$BACKUP/index.js"
cp -a "$APP_DIR/aws-chime.js" "$BACKUP/aws-chime.js"
cd "$APP_DIR"
npm install --save @aws-sdk/client-chime-sdk-voice @aws-sdk/client-sts
install -m 0644 "$HERE/index.js" "$APP_DIR/index.js"
install -m 0644 "$HERE/aws-chime.js" "$APP_DIR/aws-chime.js"
node --check "$APP_DIR/index.js"
node --check "$APP_DIR/aws-chime.js"
systemctl restart vodia-mcp
systemctl is-active --quiet vodia-mcp
echo "Phase 2B installed. Backup: $BACKUP"

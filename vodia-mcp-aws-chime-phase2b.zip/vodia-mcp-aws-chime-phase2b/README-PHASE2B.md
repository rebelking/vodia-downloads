# Amazon Chime SDK Voice Phase 2B — Phone Number Management

Adds read-only tools:
- aws_chime_search_available_phone_numbers
- aws_chime_list_phone_numbers
- aws_chime_get_phone_number
- aws_chime_list_phone_number_orders
- aws_chime_get_phone_number_order

Adds guarded plans:
- aws_chime_plan_order_phone_number
- aws_chime_plan_assign_phone_number

The existing aws_chime_apply_change now supports:
- CreatePhoneNumberOrder
- AssociatePhoneNumbersWithVoiceConnector

Safety:
- Orders require an expiring plan + exact confirmation.
- Assignments require an expiring plan + exact confirmation.
- ForceAssociate is always false.
- Already-associated numbers are rejected instead of moved.

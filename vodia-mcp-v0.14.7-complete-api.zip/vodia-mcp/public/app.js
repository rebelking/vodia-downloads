const $ = (selector) => document.querySelector(selector);
let token = sessionStorage.getItem("vodiaAdminToken") || "";
let operations = [];
let users = [];
let selectedUserId = "";

async function api(path, options = {}) {
  const headers = { Authorization: `Bearer ${token}`, ...(options.headers || {}) };
  if (options.body && typeof options.body !== "string") {
    headers["Content-Type"] = "application/json";
    options.body = JSON.stringify(options.body);
  }
  const response = await fetch(path, { ...options, headers });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.error || `HTTP ${response.status}`);
  return body;
}

function setStatus(ok, text) {
  const pill = $("#statusPill");
  pill.className = `pill ${ok === null ? "neutral" : ok ? "good" : "bad"}`;
  pill.innerHTML = `<span></span>${text}`;
}

function renderTools(filter = "") {
  const needle = filter.trim().toLowerCase();
  const rows = operations.filter((op) => !needle || JSON.stringify(op).toLowerCase().includes(needle));
  $("#toolRows").innerHTML = rows.slice(0, 250).map((op) => `
    <tr><td><code>${escapeHtml(op.operationId)}</code></td><td>${escapeHtml(op.summary || "")}</td>
    <td><code>${escapeHtml(op.path)}</code></td><td><span class="badge ${op.callable ? "" : "blocked"}">${op.callable ? "Callable" : "Blocked"}</span></td></tr>`).join("");
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>'"]/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" })[char]);
}

function renderUsers() {
  $("#userRows").innerHTML = users.length ? users.map((user) => `
    <tr data-user-id="${escapeHtml(user.id)}"><td><strong>${escapeHtml(user.display_name)}</strong><br><small>${escapeHtml(user.email)}</small></td>
    <td><select class="role-select"><option value="viewer" ${user.role === "viewer" ? "selected" : ""}>Viewer</option><option value="approver" ${user.role === "approver" ? "selected" : ""}>Approver</option><option value="admin" ${user.role === "admin" ? "selected" : ""}>Administrator</option></select></td>
    <td><span class="badge ${user.status === "active" ? "" : "blocked"}">${escapeHtml(user.status)}</span></td>
    <td>${user.last_login_at ? escapeHtml(new Date(user.last_login_at * 1000).toLocaleString()) : "Never"}</td>
    <td class="actions"><button class="small manage-user">Access</button><button class="small secondary reset-password">Reset password</button><button class="small secondary toggle-user">${user.status === "active" ? "Disable" : "Enable"}</button></td></tr>`).join("") : '<tr><td colspan="5" class="muted">No OAuth users. Create the first account above.</td></tr>';
}

async function refreshUsers() {
  const result = await api("/api/auth/users").catch(() => ({ users: [] }));
  users = result.users || [];
  renderUsers();
}

async function showAccess(userId) {
  selectedUserId = userId;
  const user = users.find((item) => item.id === userId);
  const result = await api(`/api/auth/users/${encodeURIComponent(userId)}/apps`);
  $("#selectedUserName").textContent = `${user?.display_name || "User"} — connected apps and PATs`;
  const appRows = (result.apps || []).map((app) => `<div class="access-row"><span><strong>${escapeHtml(app.client_name)}</strong><small>OAuth · ${app.active ? "active" : "revoked"}</small></span>${app.active ? `<button class="small secondary revoke-app" data-client-id="${escapeHtml(app.client_id)}">Revoke</button>` : ""}</div>`);
  const patRows = (result.pats || []).map((pat) => `<div class="access-row"><span><strong>${escapeHtml(pat.name)}</strong><small>PAT · ${escapeHtml(pat.scopes.join(" "))} · ${pat.active ? "active" : "revoked"}</small></span>${pat.active ? `<button class="small secondary revoke-pat" data-client-id="${escapeHtml(pat.client_id)}">Revoke</button>` : ""}</div>`);
  $("#connectedApps").innerHTML = [...appRows, ...patRows].join("") || '<p class="muted">No connected apps or personal access tokens.</p>';
  $("#patScope").querySelector('option[value="mcp:read,mcp:admin"]').disabled = user?.role !== "admin";
  $("#patScope").querySelector('option[value="mcp:read,mcp:approve"]').disabled = !["admin", "approver"].includes(user?.role);
  $("#patScope").value = "mcp:read";
  $("#patOutput").classList.add("hidden");
  $("#userAccessPanel").classList.remove("hidden");
}

async function refresh() {
  setStatus(null, "Testing PBX…");
  const [status, capabilities, activity, userResult] = await Promise.all([
    api("/api/status").catch((error) => ({ ok: false, error: error.message })),
    api("/api/capabilities"),
    api("/api/activity?limit=30"),
    api("/api/auth/users").catch(() => ({ users: [] })),
  ]);
  operations = capabilities.operations;
  users = userResult.users || [];
  $("#callableCount").textContent = capabilities.callable;
  $("#blockedCount").textContent = capabilities.blocked;
  $("#connectorVersion").textContent = status.runtime?.connectorVersion || "unknown";
  $("#apiVersion").textContent = `Vodia API ${capabilities.version}`;
  $("#pbxState").textContent = status.ok ? "Online" : "Failed";
  $("#pbxLatency").textContent = status.latencyMs ? `${status.latencyMs} ms` : (status.error || "No response");
  setStatus(status.ok, status.ok ? "PBX connected" : "PBX unavailable");
  const runtime = status.runtime || {};
  $("#connectionDetails").innerHTML = `
    <dt>PBX URL</dt><dd>${escapeHtml(runtime.pbxUrl || "Unavailable")}</dd>
    <dt>API user</dt><dd>${escapeHtml(runtime.apiUser || "Unavailable")}</dd>
    <dt>Security</dt><dd>${escapeHtml(status.runtime?.mode || "strict-read-only")} · sensitive fields redacted</dd>`;
  $("#pbxPreview").textContent = status.ok ? JSON.stringify(status.pbx, null, 2) : (status.error || "Connection failed");
  $("#mcpUrl").textContent = `${location.origin}/mcp`;
  renderTools($("#toolSearch").value);
  renderUsers();
  $("#activity").innerHTML = activity.activity.length ? activity.activity.map((item) => `
    <div class="activity-item"><time>${escapeHtml(new Date(item.timestamp).toLocaleString())}</time><strong>${escapeHtml(item.tool)}</strong><span>${escapeHtml(item.details?.user || item.details?.actor || "system")}<small>${escapeHtml(item.details?.client || "server")}</small></span><code>${escapeHtml(JSON.stringify(item.details))}</code></div>`).join("") : '<p class="muted">No tool calls recorded since startup.</p>';
}

async function openDashboard() {
  $("#loginError").textContent = "";
  try {
    await api("/api/capabilities");
    sessionStorage.setItem("vodiaAdminToken", token);
    $("#loginPanel").classList.add("hidden");
    $("#dashboard").classList.remove("hidden");
    await refresh();
  } catch (error) {
    $("#loginError").textContent = error.message;
    setStatus(false, "Access denied");
  }
}

$("#loginForm").addEventListener("submit", (event) => { event.preventDefault(); token = $("#token").value; openDashboard(); });
$("#refreshButton").addEventListener("click", refresh);
$("#logoutButton").addEventListener("click", () => { sessionStorage.removeItem("vodiaAdminToken"); location.reload(); });
$("#toolSearch").addEventListener("input", (event) => renderTools(event.target.value));
$("#copyUrl").addEventListener("click", async () => { await navigator.clipboard.writeText($("#mcpUrl").textContent); $("#copyUrl").textContent = "Copied"; setTimeout(() => $("#copyUrl").textContent = "Copy", 1200); });
$("#createUserForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  $("#userError").textContent = "";
  try {
    await api("/api/auth/users", { method: "POST", body: { email: $("#newUserEmail").value, display_name: $("#newUserName").value, password: $("#newUserPassword").value, role: $("#newUserRole").value } });
    event.target.reset();
    await refreshUsers();
  } catch (error) { $("#userError").textContent = error.message; }
});
$("#userRows").addEventListener("click", async (event) => {
  const row = event.target.closest("tr[data-user-id]");
  if (!row) return;
  const userId = row.dataset.userId;
  const user = users.find((item) => item.id === userId);
  try {
    if (event.target.classList.contains("manage-user")) await showAccess(userId);
    if (event.target.classList.contains("toggle-user")) {
      await api(`/api/auth/users/${encodeURIComponent(userId)}/status`, { method: "POST", body: { status: user.status === "active" ? "disabled" : "active" } });
      await refreshUsers();
    }
    if (event.target.classList.contains("reset-password")) {
      const password = prompt(`Enter a new password for ${user.email} (12+ characters):`);
      if (password) await api(`/api/auth/users/${encodeURIComponent(userId)}/password`, { method: "POST", body: { password } });
    }
  } catch (error) { $("#userError").textContent = error.message; }
});
$("#userRows").addEventListener("change", async (event) => {
  if (!event.target.classList.contains("role-select")) return;
  const userId = event.target.closest("tr[data-user-id]").dataset.userId;
  try {
    await api(`/api/auth/users/${encodeURIComponent(userId)}/role`, { method: "POST", body: { role: event.target.value } });
    await refreshUsers();
  } catch (error) { $("#userError").textContent = error.message; await refreshUsers(); }
});
$("#closeAccessPanel").addEventListener("click", () => $("#userAccessPanel").classList.add("hidden"));
$("#createPatForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  try {
    const result = await api(`/api/auth/users/${encodeURIComponent(selectedUserId)}/pats`, { method: "POST", body: { name: $("#patName").value, scopes: $("#patScope").value.split(",") } });
    $("#patOutput").textContent = `Copy this token now; it will not be shown again:\n\n${result.pat.token}`;
    $("#patOutput").classList.remove("hidden");
    $("#patName").value = "";
    await showAccess(selectedUserId);
    $("#patOutput").textContent = `Copy this token now; it will not be shown again:\n\n${result.pat.token}`;
    $("#patOutput").classList.remove("hidden");
  } catch (error) { $("#userError").textContent = error.message; }
});
$("#connectedApps").addEventListener("click", async (event) => {
  const clientId = event.target.dataset.clientId;
  if (!clientId) return;
  const kind = event.target.classList.contains("revoke-pat") ? "pats" : "apps";
  await api(`/api/auth/users/${encodeURIComponent(selectedUserId)}/${kind}/${encodeURIComponent(clientId)}/revoke`, { method: "POST" });
  await showAccess(selectedUserId);
});
if (token) openDashboard();

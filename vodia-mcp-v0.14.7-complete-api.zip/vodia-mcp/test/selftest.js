import http from "node:http";
import { readFile, unlink } from "node:fs/promises";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StdioClientTransport } from "@modelcontextprotocol/sdk/client/stdio.js";

const expectedAuthorization = `Basic ${Buffer.from("mcp-api:test-pass").toString("base64")}`;
let badAuthorization = false;
const auditPath = `/tmp/vodia-mcp-selftest-${process.pid}.jsonl`;

const mockPbx = http.createServer((request, response) => {
  if (request.headers.authorization !== expectedAuthorization) badAuthorization = true;
  response.setHeader("content-type", "application/json");

  if (request.url === "/rest/system/domains") {
    return response.end(JSON.stringify([{ name: "test.example.com" }]));
  }
  if (request.url?.startsWith("/rest/acd/333%40test.example.com/stat")) {
    return response.end(JSON.stringify({ answered: 8, abandoned: 2 }));
  }
  if (request.url === "/rest/domain/test.example.com/orbits?page=1&size=100") {
    return response.end(JSON.stringify([
      { name: "800", display: "Park 1", calls: [] },
      { name: "801", display: "Park 2", calls: [{ id: "call-1", caller: "18005550101" }] },
    ]));
  }
  if (request.url === "/rest/user/2009%40test.example.com/orbits") {
    return response.end(JSON.stringify([
      { name: "800", display: "Park 1", calls: [] },
      { name: "801", display: "Park 2", calls: [{ id: "call-1" }] },
    ]));
  }
  if (request.url === "/rest/domain/test.example.com/config") {
    return response.end(
      JSON.stringify({
        name: "lab",
        api_secret: "hidden",
        apiSecret: "hidden-camel",
        nested: { password: "hidden", accessToken: "hidden-token" },
      })
    );
  }

  response.statusCode = 404;
  return response.end(JSON.stringify({ error: request.url }));
});

await new Promise((resolve) => mockPbx.listen(0, "127.0.0.1", resolve));
const { port } = mockPbx.address();

const transport = new StdioClientTransport({
  command: process.execPath,
  args: ["index.js"],
  cwd: process.cwd(),
  env: {
    ...process.env,
    VODIA_URL: `http://127.0.0.1:${port}`,
    VODIA_USER: "mcp-api",
    VODIA_PASS: "test-pass",
    VODIA_ALLOWED_DOMAINS: "test.example.com",
    VODIA_AUDIT_LOG: auditPath,
  },
  stderr: "pipe",
});

const client = new Client({ name: "vodia-mcp-selftest", version: "1.0.0" });

try {
  await client.connect(transport);
  const tools = await client.listTools();
  const domains = await client.callTool({ name: "list_domains", arguments: {} });
  const queue = await client.callTool({
    name: "get_queue_stats",
    arguments: { account: "333@test.example.com", date: "2026-08-01", days: 7 },
  });
  const tenantOrbits = await client.callTool({
    name: "list_park_orbits",
    arguments: { domain: "test.example.com" },
  });
  const userOrbits = await client.callTool({
    name: "get_live_park_status",
    arguments: { account: "2009@test.example.com" },
  });
  const config = await client.callTool({
    name: "read_vodia_resource",
    arguments: {
      operation_id: "get_rest_domain_domain_config",
      path_params: { domain: "test.example.com" },
    },
  });
  const search = await client.callTool({
    name: "find_read_capabilities",
    arguments: { query: "queue statistics", limit: 10 },
  });
  const blocked = await client.callTool({
    name: "read_vodia_resource",
    arguments: { operation_id: "get_rest_system_syncrpc" },
  });
  const outsideTenant = await client.callTool({
    name: "list_extensions",
    arguments: { domain: "outside.example.com" },
  });
  const systemWideBlocked = await client.callTool({
    name: "read_vodia_resource",
    arguments: { operation_id: "get_rest_system_config" },
  });
  await client.callTool({
    name: "read_vodia_resource",
    arguments: {
      operation_id: "get_rest_system_status",
      query_params: { token: "must-not-appear" },
    },
  });
  const auditText = await readFile(auditPath, "utf8");

  const result = {
    basicAuthCorrect: !badAuthorization,
    allToolsReadOnly: tools.tools.every((tool) => tool.annotations?.readOnlyHint === true),
    noDestructiveTools: tools.tools.every((tool) => tool.annotations?.destructiveHint !== true),
    domainReadWorked: domains.structuredContent?.data?.[0]?.domain === "test.example.com",
    domainReadJsonMirroredInContent:
      domains.content?.some?.((block) => block.type === "text" && block.text.includes('"test.example.com"')) === true,
    queueReadWorked: queue.structuredContent?.data?.answered === 8,
    tenantParkOrbitsWorked:
      tenantOrbits.structuredContent?.data?.length === 2 &&
      tenantOrbits.structuredContent?.data?.[0]?.number === "800" &&
      tenantOrbits.structuredContent?.data?.[0]?.occupied === false &&
      tenantOrbits.structuredContent?.data?.[1]?.occupied === true,
    userParkStatusWorked:
      userOrbits.structuredContent?.data?.length === 2 &&
      userOrbits.structuredContent?.data?.[1]?.occupied === true,
    secretsRedacted:
      config.structuredContent?.data?.api_secret === "[REDACTED]" &&
      config.structuredContent?.data?.apiSecret === "[REDACTED]" &&
      config.structuredContent?.data?.nested?.password === "[REDACTED]" &&
      config.structuredContent?.data?.nested?.accessToken === "[REDACTED]",
    catalogSearchWorked: search.structuredContent?.data?.length > 0,
    actionLikeGetBlocked: blocked.isError === true,
    outsideTenantBlocked: outsideTenant.isError === true,
    systemWideReadBlockedInTenantMode: systemWideBlocked.isError === true,
    expandedToolsPresent: [
      "get_system_license",
      "list_queues",
      "list_ring_groups",
      "get_tenant_audit_log",
      "get_voicemail_metadata",
      "list_park_orbits",
      "get_live_park_status",
    ].every((name) => tools.tools.some((tool) => tool.name === name)),
    persistentAuditRedacted: !auditText.includes("must-not-appear") && auditText.includes("[REDACTED]"),
  };

  console.log(JSON.stringify(result, null, 2));
  if (Object.values(result).some((value) => value !== true)) process.exitCode = 1;
} finally {
  await client.close();
  await new Promise((resolve) => mockPbx.close(resolve));
  await unlink(auditPath).catch(() => {});
}

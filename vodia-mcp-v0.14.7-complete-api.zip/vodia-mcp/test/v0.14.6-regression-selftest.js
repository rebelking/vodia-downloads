import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { CONNECTOR_VERSION } from "../version.js";
import { apiCatalog } from "../admin.js";

const root = dirname(dirname(fileURLToPath(import.meta.url)));
assert.equal(CONNECTOR_VERSION, "0.14.6");
const op = apiCatalog.operations.find((item) => item.operationId === "post_rest_domain_domain_domain_trunks");
assert.ok(op, "domain_trunks POST operation must exist");
assert.equal(op.method, "POST");
assert.equal(op.path, "/rest/domain/{domain}/domain_trunks");
assert.equal(op.evidence?.verified, true);
const source = readFileSync(resolve(root, "admin.js"), "utf8");
for (const required of ["list_predefined_trunks", "get_predefined_trunk_requirements", "plan_create_predefined_trunk", "sip.pstnhub.microsoft.com", "What FQDN should the Microsoft Teams trunk use?", "Amazon Chime", "voiceconnector.chime.aws", "What is the Amazon Chime Voice Connector hostname?"]) {
  assert.ok(source.includes(required), `admin.js must contain ${required}`);
}
console.log(JSON.stringify({
  connectorVersion: CONNECTOR_VERSION,
  verifiedCreateOperation: true,
  predefinedToolsPresent: true,
  microsoftTeamsTemplatePresent: true,
  amazonChimeTemplatePresent: true,
  missingInputQuestionPresent: true,
}, null, 2));

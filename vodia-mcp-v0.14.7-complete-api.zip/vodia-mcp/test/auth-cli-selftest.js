import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { mkdtempSync, readFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { AuthService } from "../auth.js";

const directory = mkdtempSync(join(tmpdir(), "vodia-auth-cli-"));
const dbPath = join(directory, "auth.db");
const cli = new URL("../auth-cli.js", import.meta.url).pathname;
const wrapper = readFileSync(new URL("../scripts/vodia-mcp-auth", import.meta.url), "utf8");
const baseEnv = { ...process.env, DB_PATH: dbPath, VODIA_BOOTSTRAP_PASSWORD: "correct horse battery staple" };

const created = spawnSync(process.execPath, [cli, "create-admin", "--email", "admin@example.test", "--name", "Admin"], { env: baseEnv, encoding: "utf8" });
assert.equal(created.status, 0, created.stderr);

const duplicate = spawnSync(process.execPath, [cli, "create-admin", "--email", "admin@example.test", "--name", "Admin"], { env: baseEnv, encoding: "utf8" });
assert.equal(duplicate.status, 1);
assert.match(duplicate.stderr, /User with email admin@example\.test already exists \(id:/);
assert.doesNotMatch(duplicate.stderr, /UNIQUE constraint failed/i);

const auth = new AuthService({
  enabled: false, publicBase: "", dbPath, sessionSecret: "", accessTtl: 3600,
  refreshTtl: 2592000, codeTtl: 120, sessionTtl: 43200, allowLoopback: true,
  allowedRedirects: new Set(), legacyEnabled: true, trustProxy: true,
});
const user = auth.listUsers()[0];
for (let attempt = 0; attempt < 5; attempt += 1) auth.authenticate(user.email, "wrong password");
auth.close();

const unlocked = spawnSync(process.execPath, [cli, "unlock-user", "--user-id", user.id], { env: baseEnv, encoding: "utf8" });
assert.equal(unlocked.status, 0, unlocked.stderr);
assert.equal(JSON.parse(unlocked.stdout).locked_until, null);
assert.equal(JSON.parse(unlocked.stdout).failed_login_count, 0);

const envWithoutDb = { ...process.env };
delete envWithoutDb.DB_PATH;
const missingDb = spawnSync(process.execPath, [cli, "list-users"], { env: envWithoutDb, encoding: "utf8" });
assert.equal(missingDb.status, 1);
assert.match(missingDb.stderr, /DB_PATH is not set/);

assert.match(wrapper, /source "\$ENV_FILE"/);
assert.match(wrapper, /setpriv --reuid=vodiamcp --regid=vodiamcp --init-groups/);
assert.match(wrapper, /read -r -s -p/);
assert.match(wrapper, /--disable-warning=ExperimentalWarning/);

console.log(JSON.stringify({
  duplicateUserErrorFriendly: true,
  unlockUserCommandWorked: true,
  missingDbPathFailsLoudly: true,
  rootSafeWrapperPresent: true,
  passwordPromptHidden: true,
  sqliteExperimentalWarningSuppressedOnlyInWrapper: true,
}, null, 2));

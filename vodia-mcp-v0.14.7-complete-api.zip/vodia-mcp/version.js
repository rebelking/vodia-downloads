export const CONNECTOR_VERSION = "0.14.7";

# Vodia MCP v0.14.0 Phase 0 Reconnaissance

Baseline inspected: verified `vodia-mcp-v0.13.2-complete-api.zip`.

## Runtime and framework

- Language/runtime: JavaScript ES modules on Node.js 18+ in v0.13.2; the installer normally installs Node.js 22.
- HTTP framework: Express 5.2.1.
- MCP SDK: `@modelcontextprotocol/sdk` exactly 1.30.0 in the lockfile.
- Transport: stateless Streamable HTTP using `StreamableHTTPServerTransport` with no session ID generator.
- MCP routes: `POST /mcp`, `POST /mcp-admin`, and `POST /mcp-approver`.

## Authentication

`http.js` reads static bearer tokens from environment variables and compares them in constant time:

- `/mcp`: `MCP_BEARER_TOKEN(S)`
- `/mcp-admin`: `MCP_ADMIN_BEARER_TOKEN(S)`
- `/mcp-approver`: `MCP_APPROVER_BEARER_TOKEN(S)`
- Dashboard JSON APIs: `ADMIN_TOKEN`

The existing 401 responses do not advertise OAuth protected-resource metadata.

## Authorization and policy context

`handleMcp` selects an `accessMode` solely from the endpoint and supplies an actor string to `createVodiaServer`:

- `read` → `read-user`
- `admin` → `MCP_ADMIN_ACTOR`, default `system-admin`
- `approver` → `MCP_APPROVER_ACTOR`, default `human-approver`

The actor string is passed to admin and learning tools. Change plans are stored in an in-memory `Map`, bound to that actor string, expire after a configured TTL, and are single-use. The write policy is controlled by admin profile, tenant allowlist, per-operation allow/block lists, and elevated/destructive/critical switches.

OAuth must preserve endpoint separation while replacing the shared actor string with an authenticated user context. OAuth scopes must not elevate a user beyond both their role and the endpoint they called.

## Persistence and audit

- Audit: in-memory last 100 events plus append-only JSONL at `VODIA_AUDIT_LOG` when configured.
- Supervised learning: atomic JSON file at `VODIA_LEARNING_STORE`.
- Pending change plans: memory only; plans disappear on restart.
- Authentication database: none in v0.13.2.

The v0.14.0 authentication database will be separate SQLite state under `/var/lib/vodia-mcp/auth.db`. Existing audit and learning files must remain intact during upgrade.

## HTTP routing and dashboard

- `/admin` is static content served before the root redirect.
- Only exact `GET /` redirects to `/admin/`; it does not swallow other paths.
- `/api/*` dashboard endpoints use the separate admin bearer token.
- OAuth discovery, registration, authorization, token, revocation, login, and consent routes can be mounted before the final 404 without conflicting with the root redirect.

## TLS and proxy

- The Node service listens on `127.0.0.1:3100` over HTTP.
- Caddy terminates public TLS and reverse-proxies to Node.
- Express currently trusts only loopback proxies, which matches local Caddy. v0.14.0 must derive published URLs only from `PUBLIC_BASE_URL`, never the incoming Host header.

## SDK OAuth support verified

SDK 1.30.0 includes `mcpAuthRouter`, `requireBearerAuth`, the `OAuthServerProvider` interface, dynamic registration, PKCE validation, OAuth metadata, protected-resource metadata, token handling, revocation handling, and default rate limiting. Production persistence, login, consent, user management, refresh-token reuse handling, and redirect allowlisting remain application responsibilities.

## Conflicts resolved from the original brief

1. v0.13.2 is not globally read-only. `/mcp` is read-only, while `/mcp-admin` exposes policy-controlled plans and apply operations and `/mcp-approver` exposes learning approval.
2. `mcp:read` alone cannot support the requested reboot workflow. v0.14.0 needs role-limited scopes for read, plan/apply, learning approval, and user administration.
3. OAuth must work on all three existing MCP endpoints without removing static-token migration support.
4. OAuth login/consent is not approval to change the PBX. The existing plan/confirm/apply gate remains mandatory.
5. The installed SDK metadata helper advertises public and secret-based client authentication. Vodia will accept only public dynamically registered clients and validate this in the client store.

## Implementation direction

- Use the installed SDK router and bearer middleware interfaces where compatible.
- Use opaque random access, refresh, session, PAT, and authorization-code values; store SHA-256 hashes only.
- Use SQLite through Node's built-in `node:sqlite`, making Node.js 22.13+ the v0.14.0 minimum.
- Use bcrypt through a maintained pure-JavaScript package unless a supported Argon2 deployment is selected.
- Keep legacy static bearer tokens behind `LEGACY_STATIC_TOKEN_ENABLED` during migration.
- Bind plans and audits to immutable user IDs plus human-readable identity and client information.


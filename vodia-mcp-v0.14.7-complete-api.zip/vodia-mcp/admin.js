import { createHash, randomUUID } from "node:crypto";
import { readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { z } from "zod";
import { parseSipFromPcap, summarizeSipDialog } from "./pcap.js";
import { CONNECTOR_VERSION } from "./version.js";
import {
  approveLearnedOperation,
  disableLearnedOperation,
  getLearnedOperation,
  learnedRuntimeInfo,
  listLearnedOperations,
  loadApprovedLearnedCatalog,
  materializeLearnedRequest,
  proposeLearnedOperation,
  recordReadTest,
} from "./learned.js";

const projectRoot = dirname(fileURLToPath(import.meta.url));
export const apiCatalog = JSON.parse(readFileSync(resolve(projectRoot, "generated/api-catalog.json"), "utf8"));
const verifiedPortalOperations = [
  {
    operationId: "get_rest_domain_domain_check_sync_mac",
    method: "GET",
    path: "/rest/domain/{domain}/check-sync",
    summary: "Trigger provisioning or reboot for one provisioned MAC",
    description: "Verified from the Vodia 70.5 tenant MAC portal. reboot=false triggers provisioning; reboot=true triggers a phone reboot/resync.",
    tags: ["Tenant - Provisioning"],
    parameters: [
      { name: "domain", in: "path", required: true, description: "Tenant domain.", type: "string", enum: null, example: "pbx.example.com" },
      { name: "mac", in: "query", required: true, description: "Twelve-character phone MAC address.", type: "string", enum: null, example: "0004F2C785BE" },
      { name: "reboot", in: "query", required: true, description: "false triggers provisioning; true triggers reboot/resync.", type: "boolean", enum: [false, true], example: false },
    ],
    requestBody: null,
    responses: { "200": { description: "Boolean action result.", contentTypes: ["application/json"] } },
    callable: true,
    risk: "elevated",
    adminTier: "elevated",
    blockedReason: "GET operation performs an external device action and must use plan/apply.",
    evidence: { source: "Vodia 70.5 tenant MAC portal capture", verified: true },
  },
  {
    operationId: "get_rest_domain_domain_generated_reset",
    method: "GET",
    path: "/rest/domain/{domain}/generated",
    summary: "Clear provisioning history for one MAC",
    description: "Verified from the Vodia 70.5 tenant MAC portal. reset=1 clears the selected device's provisioning history.",
    tags: ["Tenant - Provisioning"],
    parameters: [
      { name: "domain", in: "path", required: true, description: "Tenant domain.", type: "string", enum: null, example: "pbx.example.com" },
      { name: "mac", in: "query", required: true, description: "Twelve-character phone MAC address.", type: "string", enum: null, example: "0004F2C785BE" },
      { name: "reset", in: "query", required: true, description: "Must be 1.", type: "integer", enum: [1], example: 1 },
    ],
    requestBody: null,
    responses: { "200": { description: "Boolean action result.", contentTypes: ["application/json"] } },
    callable: true,
    risk: "elevated",
    adminTier: "elevated",
    blockedReason: "GET operation clears provisioning history and must use plan/apply.",
    evidence: { source: "Vodia 70.5 tenant MAC portal capture", verified: true },
  },
];
for (const operation of verifiedPortalOperations) {
  if (!apiCatalog.operations.some((candidate) => candidate.operationId === operation.operationId)) {
    apiCatalog.operations.push(operation);
    apiCatalog.totalOperations += 1;
    apiCatalog.counts.GET = (apiCatalog.counts.GET || 0) + 1;
  }
}
// Portal capture verified that this POST has two modes: with ?trunk=<id> it
// enables/disables an existing trunk; without the query parameter and with a full
// trunk body it creates a new tenant trunk and returns its numeric id.
const domainTrunksPost = apiCatalog.operations.find((operation) => operation.operationId === "post_rest_domain_domain_domain_trunks");
if (domainTrunksPost) {
  domainTrunksPost.summary = "Create, enable, or disable a tenant SIP trunk";
  domainTrunksPost.description = "Verified from the Vodia tenant portal: POST without a trunk query parameter creates a new trunk from the supplied JSON body and returns its numeric id; POST with ?trunk=<id> and {dis:\"true|false\"} enables or disables an existing trunk.";
  domainTrunksPost.evidence = { source: "Vodia 70.6.beta tenant portal HAR, 2026-09-11", verified: true };
}
const operationsById = new Map(apiCatalog.operations.map((operation) => [operation.operationId, operation]));
for (const operation of loadApprovedLearnedCatalog()) operationsById.set(operation.operationId, operation);
const PBX_URL = String(process.env.VODIA_URL || "").replace(/\/+$/, "");
const PBX_USER = String(process.env.VODIA_USER || "");
const PBX_PASS = String(process.env.VODIA_PASS || "");
const PLAN_TTL_MS = Math.max(60_000, Math.min(Number(process.env.VODIA_CHANGE_PLAN_TTL_MS || 300_000), 900_000));
const PCAP_LIMIT_BYTES = Math.max(100_000, Math.min(Number(process.env.VODIA_PCAP_LIMIT_BYTES || 20_000_000), 100_000_000));
const DESTRUCTIVE_ENABLED = /^true$/i.test(process.env.VODIA_ENABLE_DESTRUCTIVE || "");
const ELEVATED_ENABLED = /^true$/i.test(process.env.VODIA_ENABLE_ELEVATED_WRITES || "");
const CRITICAL_ENABLED = /^true$/i.test(process.env.VODIA_ENABLE_CRITICAL_WRITES || "");
const ADMIN_PROFILE = ["diagnostic", "operator", "full"].includes(String(process.env.VODIA_ADMIN_PROFILE || "operator").toLowerCase())
  ? String(process.env.VODIA_ADMIN_PROFILE || "operator").toLowerCase()
  : "operator";
const MAX_WRITE_BODY_BYTES = Math.max(4_096, Math.min(Number(process.env.VODIA_MAX_WRITE_BODY_BYTES || 262_144), 1_048_576));
const ALLOWED_DOMAINS = new Set(String(process.env.VODIA_ALLOWED_DOMAINS || "").split(",").map((v) => v.trim().toLowerCase()).filter(Boolean));
const ALLOWED_WRITE_OPERATIONS = new Set(String(process.env.VODIA_ALLOWED_WRITE_OPERATIONS || "").split(",").map((v) => v.trim()).filter(Boolean));
const BLOCKED_WRITE_OPERATIONS = new Set(String(process.env.VODIA_BLOCKED_WRITE_OPERATIONS || "").split(",").map((v) => v.trim()).filter(Boolean));
const plans = new Map();

const MICROSOFT_TEAMS_ALLOWED_ADDRESSES = "13.107.64.0/18 52.112.0.0/14 52.122.0.0/15 52.238.119.141/32 52.244.160.207/32 2603:1027::/48 2603:1037::/48 2603:1047::/48 2603:1057::/48 2603:1063::/39 2620:1ec:6::/48 2620:1ec:40::/42";

const PREDEFINED_TRUNK_TEMPLATES = new Map([
  ["microsoft_teams", {
    id: "microsoft_teams",
    label: "Microsoft Teams",
    aliases: ["microsoft teams", "teams", "ms teams", "msteams"],
    verified: true,
    evidence: "Vodia 70.6.beta tenant portal HAR captured 2026-09-11",
    requiredInputs: [
      { field: "fqdn", label: "PBX/SBC FQDN", question: "What FQDN should the Microsoft Teams trunk use? Example: pbx.example.com" },
    ],
    optionalInputs: [
      { field: "name", label: "Trunk name", default: "Microsoft Teams" },
    ],
    build({ fqdn, name }) {
      return {
        dial_extension: "!",
        name: name || "Microsoft Teams",
        reg_display: name || "Microsoft Teams",
        reg_pass: "",
        reg_user: "teams",
        dids: [],
        type: "options",
        outbound_proxy: "sip:sip.pstnhub.microsoft.com",
        reg_registrar: fqdn,
        reg_account: "teams",
        ani_regular: "from-trunk:teams-from from",
        hru: "{request-uri}",
        ht: "{to}",
        hf: "{from}",
        hpr: "{privacy-id}",
        glob: "plus",
        aadr: MICROSOFT_TEAMS_ALLOWED_ADDRESSES,
        country_code: "1",
        ice: "savpl",
        concurrent_registration: "true",
        keep_alive: "60",
        request_timeout: "10",
        anonymous: "[from] anonymous",
        contact_hdr: `sip:teams@${fqdn}:{x-pre-server-port};transport=tls`,
        other_headers: `Contact: <sip:teams@${fqdn}:{x-pre-server-port};transport=tls>\r\nX-MS-SBC: Vodia-PBX/{version}`,
        user_defined_hdr: "X-MS-SBC: Vodia-PBX/{version}",
        ignore_18x_sdp: "true",
        teams: "true",
      };
    },
  }],
  ["amazon_chime", {
    id: "amazon_chime",
    label: "Amazon Chime",
    aliases: ["amazon chime", "chime", "amazon voice connector", "aws chime"],
    verified: true,
    evidence: "Vodia 70.6.beta tenant portal HAR captured 2026-09-11",
    requiredInputs: [
      { field: "voice_connector_host", label: "Voice Connector hostname", question: "What is the Amazon Chime Voice Connector hostname? Example: abc123.voiceconnector.chime.aws" },
      { field: "sip_username", label: "SIP username", question: "What SIP username/account should the Amazon Chime trunk use?" },
      { field: "sip_password", label: "SIP password", question: "What SIP password should the Amazon Chime trunk use?" },
    ],
    optionalInputs: [
      { field: "name", label: "Trunk name", default: "Amazon Chime" },
      { field: "did", label: "DID", default: "" },
      { field: "allowed_addresses", label: "Allowed signaling addresses", default: "3.80.16.0/23 99.77.253.0/24" },
    ],
    build({ voice_connector_host, sip_username, sip_password, did, allowed_addresses, name }) {
      const host = voice_connector_host;
      return {
        dial_extension: "!",
        name: name || "Amazon Chime",
        reg_registrar: host,
        reg_pass: sip_password,
        reg_user: sip_username,
        dids: did ? [did] : [],
        type: "options",
        country_code: "1",
        glob: "plus",
        hf: "{from}",
        hru: "{request-uri}",
        ht: "{to}",
        outbound_proxy: `sip:${host};transport=tls`,
        reg_account: sip_username,
        aadr: allowed_addresses || "3.80.16.0/23 99.77.253.0/24",
      };
    },
  }],
]);
const PRIVATE_AUDIT_FIELD = /(?:email|e_?mail|phone|mobile|cell|ani|did|mac|hash|digest|password|secret|token|authorization|cookie|session|pin|serial|private.?key|api.?key|credential)/i;
const PRIVATE_AUDIT_VALUE = /(?:^[0-9A-F]{12}$|^[0-9A-F]{16,}$|^\+?\d{7,15}$|^[^\s@]+@[^\s@]+\.[^\s@]+$)/i;

function privacySafeAuditValue(field, value, depth = 0) {
  if (PRIVATE_AUDIT_FIELD.test(field)) return "[REDACTED]";
  if (value == null || typeof value === "boolean" || typeof value === "number") return value;
  if (typeof value === "string") return PRIVATE_AUDIT_VALUE.test(value.trim()) ? "[REDACTED]" : value.slice(0, 256);
  if (depth >= 4) return "[REDACTED-COMPLEX]";
  if (Array.isArray(value)) return value.slice(0, 25).map((item) => privacySafeAuditValue(field, item, depth + 1));
  if (typeof value === "object") {
    return Object.fromEntries(Object.entries(value).slice(0, 50).map(([key, child]) => [key, privacySafeAuditValue(key, child, depth + 1)]));
  }
  return String(value).slice(0, 256);
}

function changedFieldsForAudit(plan) {
  const rawBefore = plan.preimage?.available ? plan.preimage.data : null;
  const before = Array.isArray(rawBefore) ? rawBefore[0] : rawBefore;
  return Object.fromEntries(Object.entries(plan.body || {}).map(([field, after]) => [field, {
    before: privacySafeAuditValue(field, before && typeof before === "object" ? before[field] ?? null : null),
    after: privacySafeAuditValue(field, after),
  }]));
}

const PROFILE_LEVEL = { diagnostic: 0, operator: 1, full: 2 };

function confirmationFor(operation, pathParams = {}) {
  const critical = operation.adminTier === "critical";
  const destructive = operation.risk === "destructive";
  const verb = critical && destructive ? "DELETE-CRITICAL" : critical ? "APPLY-CRITICAL" : destructive ? "DELETE" : "APPLY";
  const target = tenantFrom(pathParams) || "SYSTEM";
  return `${verb} ${operation.operationId} ON ${target}`;
}

function operationPolicy(operation, { safeWrapper = false } = {}) {
  if (!operation?.callable) return { allowed: false, reason: operation?.blockedReason || "Operation is not callable." };
  if (BLOCKED_WRITE_OPERATIONS.has(operation.operationId)) return { allowed: false, reason: "Operation is denied by VODIA_BLOCKED_WRITE_OPERATIONS." };
  if (ALLOWED_WRITE_OPERATIONS.size && !ALLOWED_WRITE_OPERATIONS.has(operation.operationId)) {
    return { allowed: false, reason: "Operation is outside VODIA_ALLOWED_WRITE_OPERATIONS." };
  }
  if (safeWrapper) return { allowed: true, policy: "dedicated-safe-wrapper" };

  if (operation.adminTier === "critical") {
    if (PROFILE_LEVEL[ADMIN_PROFILE] < PROFILE_LEVEL.full) return { allowed: false, reason: "Critical changes require VODIA_ADMIN_PROFILE=full." };
    if (!CRITICAL_ENABLED) return { allowed: false, reason: "Critical changes require the separate VODIA_ENABLE_CRITICAL_WRITES=true break-glass switch." };
    if (operation.risk === "destructive" && !DESTRUCTIVE_ENABLED) return { allowed: false, reason: "Critical DELETE operations also require VODIA_ENABLE_DESTRUCTIVE=true." };
    return { allowed: true, policy: "break-glass-critical" };
  }
  if (operation.risk === "destructive") {
    if (PROFILE_LEVEL[ADMIN_PROFILE] < PROFILE_LEVEL.full) return { allowed: false, reason: "DELETE operations require VODIA_ADMIN_PROFILE=full." };
    if (!DESTRUCTIVE_ENABLED) return { allowed: false, reason: "DELETE operations require VODIA_ENABLE_DESTRUCTIVE=true." };
    return { allowed: true, policy: "destructive" };
  }
  if (operation.risk === "elevated") {
    if (PROFILE_LEVEL[ADMIN_PROFILE] < PROFILE_LEVEL.full && !ELEVATED_ENABLED) {
      return { allowed: false, reason: "Elevated writes require VODIA_ADMIN_PROFILE=full." };
    }
    return { allowed: true, policy: "full-admin" };
  }
  if (PROFILE_LEVEL[ADMIN_PROFILE] < PROFILE_LEVEL.operator) {
    return { allowed: false, reason: "Configuration writes require VODIA_ADMIN_PROFILE=operator or full." };
  }
  return { allowed: true, policy: "operator" };
}

function validateWriteBody(body) {
  const encoded = JSON.stringify(body ?? {});
  if (Buffer.byteLength(encoded, "utf8") > MAX_WRITE_BODY_BYTES) throw new Error(`Write body exceeds ${MAX_WRITE_BODY_BYTES} bytes.`);
  let nodes = 0;
  const visit = (value, depth = 0) => {
    if (depth > 20) throw new Error("Write body nesting exceeds 20 levels.");
    nodes += 1;
    if (nodes > 20_000) throw new Error("Write body is too complex.");
    if (!value || typeof value !== "object") return;
    for (const [key, child] of Object.entries(value)) {
      if (["__proto__", "prototype", "constructor"].includes(key)) throw new Error(`Unsafe write-body key '${key}'.`);
      visit(child, depth + 1);
    }
  };
  visit(body);
}

function authorization() {
  return `Basic ${Buffer.from(`${PBX_USER}:${PBX_PASS}`, "utf8").toString("base64")}`;
}

function tenantFrom(args = {}) {
  if (args.domain) return String(args.domain).toLowerCase();
  for (const key of ["account", "user", "queue"]) {
    const value = String(args[key] || "");
    if (value.includes("@")) return value.slice(value.lastIndexOf("@") + 1).toLowerCase();
  }
  return null;
}

function enforceTenant(args) {
  const tenant = tenantFrom(args);
  if (ALLOWED_DOMAINS.size && (!tenant || !ALLOWED_DOMAINS.has(tenant))) {
    throw new Error(tenant ? `Tenant '${tenant}' is outside VODIA_ALLOWED_DOMAINS.` : "A tenant-scoped operation is required in restricted mode.");
  }
  return tenant;
}

function buildUrl(operation, pathParams = {}, queryParams = {}) {
  let path = operation.path;
  const required = [...path.matchAll(/\{([^}]+)\}/g)].map((match) => match[1]);
  for (const name of required) {
    const value = pathParams[name];
    if (value === undefined || value === null || String(value).trim() === "") throw new Error(`Missing required path parameter '${name}'.`);
    path = path.replace(`{${name}}`, encodeURIComponent(String(value)));
  }
  const unknown = Object.keys(pathParams).filter((name) => !required.includes(name));
  if (unknown.length) throw new Error(`Unknown path parameter(s): ${unknown.join(", ")}`);
  const allowedQuery = new Set(operation.parameters.filter((p) => p.in === "query").map((p) => p.name));
  const unknownQuery = Object.keys(queryParams).filter((name) => !allowedQuery.has(name));
  if (unknownQuery.length) throw new Error(`Unsupported query parameter(s): ${unknownQuery.join(", ")}`);
  const missingQuery = operation.parameters
    .filter((parameter) => parameter.in === "query" && parameter.required)
    .map((parameter) => parameter.name)
    .filter((name) => queryParams[name] === undefined || queryParams[name] === null || String(queryParams[name]).trim() === "");
  if (missingQuery.length) throw new Error(`Missing required query parameter(s): ${missingQuery.join(", ")}`);
  enforceTenant(pathParams);
  const url = new URL(`${PBX_URL}${path}`);
  for (const [key, value] of Object.entries(queryParams)) if (value !== undefined && value !== null && value !== "") url.searchParams.set(key, String(value));
  return { url, path };
}

async function limitedBuffer(response, limit = PCAP_LIMIT_BYTES) {
  const declared = Number(response.headers.get("content-length") || 0);
  if (declared > limit) throw new Error(`Response is ${declared} bytes; limit is ${limit}.`);
  const buffer = Buffer.from(await response.arrayBuffer());
  if (buffer.length > limit) throw new Error(`Response exceeded ${limit} bytes.`);
  return buffer;
}

export async function retrieveCallPcap({ domain, callId, callOperation }) {
  enforceTenant({ domain });
  const cdr = await callOperation("get_rest_domain_domain_cdr", {
    pathParams: { domain },
    queryParams: { id: callId },
  });
  const rows = Array.isArray(cdr.data) ? cdr.data : [cdr.data];
  if (!rows.length || !rows.some(Boolean)) throw new Error("Call ID was not found in the requested tenant.");
  const pcapOperation = operationsById.get("get_rest_system_pcap");
  const { url } = buildUrl(pcapOperation, {}, { id: callId });
  const response = await fetch(url, {
    headers: {
      Accept: "application/vnd.tcpdump.pcap, application/octet-stream",
      Authorization: authorization(),
      "User-Agent": `vodia-mcp-admin/${CONNECTOR_VERSION}`,
    },
    signal: AbortSignal.timeout(30_000),
  });
  if (!response.ok) throw new Error(`No retained PCAP is available for this call (HTTP ${response.status}).`);
  const buffer = await limitedBuffer(response);
  return { buffer, cdr: rows };
}

async function rawRequest(operation, { pathParams = {}, queryParams = {}, body } = {}) {
  validateWriteBody(body);
  const { url, path } = buildUrl(operation, pathParams, queryParams);
  const response = await fetch(url, {
    method: operation.method,
    headers: {
      Accept: "application/json, text/plain;q=0.9",
      Authorization: authorization(),
      "Content-Type": "application/json",
      "User-Agent": `vodia-mcp-admin/${CONNECTOR_VERSION}`,
    },
    body: operation.method === "GET" || body === undefined ? undefined : JSON.stringify(body),
    signal: AbortSignal.timeout(30_000),
  });
  const text = (await response.text()).slice(0, 2_000_000);
  if (!response.ok) throw new Error(`Vodia API ${operation.method} ${path} returned HTTP ${response.status}: ${text.slice(0, 400)}`);
  let data = {};
  if (text) {
    try { data = JSON.parse(text); } catch { data = { text }; }
  }
  return { data, status: response.status, path };
}

async function rawBinaryRequest(operation, { pathParams = {}, queryParams = {}, limitBytes = 1_000_000 } = {}) {
  const { url, path } = buildUrl(operation, pathParams, queryParams);
  const response = await fetch(url, {
    method: "GET",
    headers: {
      Accept: "application/octet-stream, audio/*, image/*, application/vnd.tcpdump.pcap",
      Authorization: authorization(),
      "User-Agent": `vodia-mcp-admin/${CONNECTOR_VERSION}`,
    },
    signal: AbortSignal.timeout(30_000),
  });
  if (!response.ok) throw new Error(`Vodia API GET ${path} returned HTTP ${response.status}.`);
  const buffer = await limitedBuffer(response, limitBytes);
  return {
    bytes: buffer.length,
    contentType: response.headers.get("content-type") || "application/octet-stream",
    base64: buffer.toString("base64"),
  };
}

async function preimageFor(operation, pathParams, queryParams, callOperation) {
  const reader = apiCatalog.operations.find((candidate) => candidate.method === "GET" && candidate.risk === "read" && candidate.path === operation.path && candidate.callable);
  if (!reader) return { available: false, data: null };
  const allowed = new Set(reader.parameters.filter((p) => p.in === "query").map((p) => p.name));
  const safeQuery = Object.fromEntries(Object.entries(queryParams || {}).filter(([name]) => allowed.has(name)));
  try {
    const result = await callOperation(reader.operationId, { pathParams, queryParams: safeQuery });
    return { available: true, operationId: reader.operationId, data: result.data };
  } catch (error) {
    return { available: false, error: error.message || String(error), data: null };
  }
}

function activeCallRows(data) {
  if (Array.isArray(data)) return data;
  if (Array.isArray(data?.calls)) return data.calls;
  return data && typeof data === "object" ? [data] : [];
}

function activeCallId(call) {
  return String(call?.id ?? call?.call_id ?? call?.callId ?? "");
}

function extensionNumber(record) {
  const alias = Array.isArray(record?.alias) ? record.alias[0] : record?.alias;
  return String(record?.name ?? record?.account ?? record?.extension ?? record?.ext ?? alias ?? "").trim();
}

function normalizeLiveCall(call, account) {
  return {
    account,
    callId: activeCallId(call),
    legId: String(call?.leg_id ?? call?.legId ?? call?.id ?? ""),
    state: call?.state ?? call?.status ?? null,
    held: Boolean(call?.held ?? /hold/i.test(String(call?.state ?? call?.status ?? ""))),
    caller: call?.from ?? call?.caller ?? call?.calling ?? null,
    callee: call?.to ?? call?.callee ?? call?.called ?? call?.remote_party ?? call?.remoteParty ?? null,
    direction: call?.direction ?? call?.dir ?? null,
    durationSeconds: call?.duration ?? call?.duration_seconds ?? call?.durationSeconds ?? null,
    raw: call,
  };
}

function catalogText(value) {
  if (typeof value === "string" || typeof value === "number") return String(value).trim();
  if (!value || typeof value !== "object") return "";
  return String(value.model ?? value.name ?? value.value ?? value.id ?? "").trim();
}

function normalizePhoneCatalog(data) {
  const rows = Array.isArray(data)
    ? data
    : Array.isArray(data?.catalog)
      ? data.catalog
      : Array.isArray(data?.vendors)
        ? data.vendors
        : [];
  return rows.map((row) => {
    const vendor = catalogText(row?.vendor ?? row?.name ?? row?.value);
    const primary = Array.isArray(row?.model) ? row.model : Array.isArray(row?.models) ? row.models : [];
    const bases = Array.isArray(row?.dect?.base) ? row.dect.base : [];
    const handsets = Array.isArray(row?.dect?.handset) ? row.dect.handset : [];
    const models = [...new Set([...primary, ...bases, ...handsets].map(catalogText).filter(Boolean))];
    return {
      vendor,
      models,
      ...(bases.length || handsets.length ? {
        dect: {
          bases: [...new Set(bases.map(catalogText).filter(Boolean))],
          handsets: [...new Set(handsets.map(catalogText).filter(Boolean))],
        },
      } : {}),
    };
  }).filter((row) => row.vendor);
}

async function supportedPhoneCatalog(callOperation, domain) {
  const result = await callOperation("get_rest_domain_domain_button_templates", {
    pathParams: { domain },
    queryParams: { id: "all" },
  });
  const catalog = normalizePhoneCatalog(result.data);
  if (!catalog.length) throw new Error(`The PBX returned no supported phone vendor/model catalog for '${domain}'.`);
  return catalog;
}

function canonicalPhone(catalog, requestedVendor, requestedModel) {
  const vendor = catalog.find((item) => item.vendor.toLowerCase() === String(requestedVendor).trim().toLowerCase());
  if (!vendor) {
    throw new Error(`Unsupported phone vendor '${requestedVendor}'. Call list_supported_phone_models to retrieve the PBX catalog.`);
  }
  const model = vendor.models.find((item) => item.toLowerCase() === String(requestedModel).trim().toLowerCase());
  if (!model) {
    throw new Error(`Model '${requestedModel}' is not supported for vendor '${vendor.vendor}'. Supported models: ${vendor.models.join(", ") || "none returned"}.`);
  }
  return { vendor: vendor.vendor, model };
}

function normalizeMac(value) {
  const mac = String(value || "").replace(/[^0-9a-f]/gi, "").toUpperCase();
  if (!/^[0-9A-F]{12}$/.test(mac)) throw new Error("MAC address must contain exactly 12 hexadecimal characters.");
  return mac;
}

async function requireProvisionedMac(callOperation, domain, mac) {
  const current = await callOperation("get_rest_domain_domain_macs_1", {
    pathParams: { domain },
    queryParams: { adr: mac },
  });
  const rows = Array.isArray(current.data) ? current.data : [current.data];
  const entry = rows.find((row) => {
    try { return normalizeMac(row?.mac ?? row?.address ?? "") === mac; } catch { return false; }
  });
  if (!entry) throw new Error(`MAC '${mac}' is not provisioned in tenant '${domain}'.`);
  return { entry, data: current.data };
}

function predefinedTrunkTemplate(provider) {
  const wanted = String(provider || "").trim().toLowerCase();
  for (const template of PREDEFINED_TRUNK_TEMPLATES.values()) {
    if (template.id === wanted || template.label.toLowerCase() === wanted || template.aliases.includes(wanted)) return template;
  }
  throw new Error(`Unknown predefined trunk '${provider}'. Call list_predefined_trunks to see verified templates.`);
}

function normalizeFqdn(value) {
  const fqdn = String(value || "").trim().replace(/\.$/, "").toLowerCase();
  if (!fqdn) return "";
  if (fqdn.length > 253 || fqdn.includes("://") || fqdn.includes("/") || !/^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(fqdn)) {
    throw new Error("FQDN must be a hostname such as pbx.example.com, without http://, https://, a port, or a path.");
  }
  return fqdn;
}

function normalizeDid(value) {
  const did = String(value || "").trim();
  if (!did) return "";
  if (!/^\+?[0-9]{7,15}$/.test(did)) throw new Error("DID must contain 7 to 15 digits and may begin with +.");
  return did;
}

function predefinedInputs({ fqdn, voice_connector_host, sip_username, sip_password, did, allowed_addresses, name }) {
  const normalizedFqdn = fqdn ? normalizeFqdn(fqdn) : "";
  const normalizedVoiceHost = voice_connector_host ? normalizeFqdn(voice_connector_host) : "";
  return {
    fqdn: normalizedFqdn,
    voice_connector_host: normalizedVoiceHost,
    sip_username: String(sip_username || "").trim(),
    sip_password: String(sip_password || ""),
    did: did ? normalizeDid(did) : "",
    allowed_addresses: String(allowed_addresses || "").trim(),
    name: String(name || "").trim(),
  };
}

function publicPredefinedTemplate(template) {
  return {
    id: template.id,
    label: template.label,
    aliases: template.aliases,
    verified: template.verified,
    evidence: template.evidence,
    requiredInputs: template.requiredInputs,
    optionalInputs: template.optionalInputs,
  };
}

function stateHash(value) {
  return createHash("sha256").update(JSON.stringify(value)).digest("hex");
}

function accountParts(account) {
  const value = String(account || "").trim();
  const separator = value.lastIndexOf("@");
  if (separator <= 0 || separator === value.length - 1) {
    throw new Error("Account must use extension@tenant-domain form.");
  }
  return { account: value, extension: value.slice(0, separator), domain: value.slice(separator + 1).toLowerCase() };
}

function buttonProfileForMac(data, mac) {
  const rows = Array.isArray(data) ? data : [data];
  const profile = rows.find((row) => {
    try { return normalizeMac(row?.address ?? row?.mac ?? "") === mac; } catch { return false; }
  });
  if (!profile) return null;
  let configuration = profile.buttons ?? profile.configuration ?? null;
  if (typeof configuration === "string") {
    try { configuration = JSON.parse(configuration); } catch { configuration = null; }
  }
  return { profile, configuration: configuration && typeof configuration === "object" ? configuration : null };
}

function normalizeButton(button, index) {
  return {
    number: String(button.number),
    name: String(button.name ?? ""),
    mode: String(button.mode ?? "1"),
    type: String(button.type),
    sort: Number.isInteger(button.sort) ? button.sort : index + 1,
    group: Number.isInteger(button.group) ? button.group : 1,
    identity: String(button.identity ?? ""),
    parameter: String(button.parameter ?? ""),
    label: String(button.label ?? ""),
    fixed: Boolean(button.fixed),
    pickup: String(button.pickup ?? ""),
  };
}

function didRows(data) {
  if (Array.isArray(data)) return data;
  if (Array.isArray(data?.numbers)) return data.numbers;
  return [];
}

async function findActiveCall(callOperation, account, callId) {
  const result = await callOperation("get_rest_user_account_calls", {
    pathParams: { account },
  });
  const call = activeCallRows(result.data).find((candidate) => activeCallId(candidate) === String(callId));
  return { call: call || null, calls: activeCallRows(result.data) };
}

function planHash(plan) {
  return createHash("sha256").update(JSON.stringify({ operationId: plan.operationId, pathParams: plan.pathParams, queryParams: plan.queryParams, body: plan.body })).digest("hex");
}

async function makePlan({
  operationId,
  pathParams = {},
  queryParams = {},
  body = {},
  reason,
  actor,
  callOperation,
  safeWrapper = false,
  preimageOverride,
  precondition,
  confirmationRequired,
  ttlMs,
}) {
  for (const [id, existing] of plans) if (Date.parse(existing.expiresAt) <= Date.now()) plans.delete(id);
  if (plans.size >= 1000) throw new Error("Too many pending change plans; wait for existing plans to expire.");
  const operation = operationsById.get(operationId);
  if (!operation) throw new Error(`Unknown operation '${operationId}'.`);
  if (operation.method === "GET" && operation.risk === "read") throw new Error("Use the read tools for GET operations.");
  if (!operation.callable) throw new Error(`Operation is blocked: ${operation.blockedReason}`);
  const policy = operationPolicy(operation, { safeWrapper });
  if (!policy.allowed) throw new Error(`Operation is blocked by administrator policy: ${policy.reason}`);
  validateWriteBody(body);
  const tenant = enforceTenant(pathParams);
  const preimage = preimageOverride === undefined
    ? await preimageFor(operation, pathParams, queryParams, callOperation)
    : preimageOverride;
  const changeId = randomUUID();
  const plan = {
    changeId,
    actor,
    operationId,
    method: operation.method,
    path: operation.path,
    risk: operation.risk,
    adminTier: operation.adminTier,
    policy: policy.policy,
    confirmationRequired: confirmationRequired || confirmationFor(operation, pathParams),
    tenant,
    pathParams,
    queryParams,
    body,
    reason,
    preimage,
    precondition: precondition || null,
    createdAt: new Date().toISOString(),
    expiresAt: new Date(Date.now() + Math.max(30_000, Math.min(ttlMs || PLAN_TTL_MS, PLAN_TTL_MS))).toISOString(),
  };
  plan.requestHash = planHash(plan);
  plans.set(changeId, plan);
  return plan;
}

function publicPlan(plan, redactSensitive) {
  return redactSensitive({
    changeId: plan.changeId,
    operationId: plan.operationId,
    method: plan.method,
    path: plan.path,
    risk: plan.risk,
    adminTier: plan.adminTier,
    policy: plan.policy,
    tenant: plan.tenant,
    request: { pathParams: plan.pathParams, queryParams: plan.queryParams, body: plan.body },
    preimage: plan.preimage,
    precondition: plan.precondition,
    reason: plan.reason,
    requestHash: plan.requestHash,
    expiresAt: plan.expiresAt,
    confirmationRequired: plan.confirmationRequired,
  });
}

export function registerAdminTools(server, { audit, success, failure, redactSensitive, callOperation, actor = "system-admin" }) {
  const parameterValue = z.union([z.string().max(4096), z.number(), z.boolean()]);
  const parameterMap = z.record(z.string(), parameterValue);
  const outputSchema = { data: z.any(), meta: z.record(z.string(), z.any()) };
  const writeAnnotations = { readOnlyHint: false, destructiveHint: true, openWorldHint: false };

  server.registerTool("read_vodia_api", {
    title: "Read any documented Vodia JSON API operation",
    description: "Call any catalogued, non-action GET operation by operation ID with strict path/query validation, tenant enforcement, response limits, auditing and secret redaction.",
    inputSchema: { operation_id: z.string().min(1), path_params: parameterMap.optional(), query_params: parameterMap.optional() },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ operation_id, path_params, query_params }) => {
    audit("read_vodia_api", { actor, operation_id, path_params, query_params });
    try {
      const operation = operationsById.get(operation_id);
      if (!operation) throw new Error(`Unknown operation '${operation_id}'.`);
      if (operation.method !== "GET" || operation.risk !== "read" || !operation.callable) {
        throw new Error("This operation is not a direct JSON read. Use plan_vodia_change for action-like GETs or read_vodia_binary for binary GETs.");
      }
      const result = await rawRequest(operation, { pathParams: path_params || {}, queryParams: query_params || {} });
      return success(redactSensitive(result.data), { operationId: operation.operationId, method: operation.method, path: operation.path, status: result.status }, `Read '${operation.operationId}' without changing PBX state.`);
    } catch (error) { return failure(error); }
  });

  server.registerTool("read_vodia_binary", {
    title: "Read a documented Vodia binary resource",
    description: "Retrieve a catalogued binary GET resource such as audio, an image, voicemail media, or PCAP as bounded base64 data. Use only when the binary payload is required.",
    inputSchema: {
      operation_id: z.string().min(1),
      path_params: parameterMap.optional(),
      query_params: parameterMap.optional(),
      max_bytes: z.number().int().min(1_024).max(5_000_000).default(1_000_000),
    },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ operation_id, path_params, query_params, max_bytes }) => {
    audit("read_vodia_binary", { actor, operation_id, path_params, query_params, max_bytes });
    try {
      const operation = operationsById.get(operation_id);
      const binary = operation?.method === "GET" && operation?.risk === "specialized" && /Binary content/i.test(operation?.blockedReason || "");
      if (!binary) throw new Error("The selected operation is not a catalogued binary GET resource.");
      const result = await rawBinaryRequest(operation, { pathParams: path_params || {}, queryParams: query_params || {}, limitBytes: max_bytes });
      return success(result, { operationId: operation.operationId, path: operation.path, encoding: "base64" }, `Retrieved ${result.bytes} bytes from '${operation.operationId}'.`);
    } catch (error) { return failure(error); }
  });

  server.registerTool("inspect_vodia_operation", {
    title: "Inspect one documented Vodia API operation",
    description: "Return the imported method, path, parameters, request schema/example, response types, risk classification and current connector policy for one operation ID.",
    inputSchema: { operation_id: z.string().min(1) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ operation_id }) => {
    audit("inspect_vodia_operation", { actor, operation_id });
    try {
      const operation = operationsById.get(operation_id);
      if (!operation) throw new Error(`Unknown operation '${operation_id}'.`);
      const policy = operation.method === "GET" && operation.risk === "read"
        ? { allowed: true, policy: "read" }
        : operationPolicy(operation);
      return success({ ...operation, policy }, { catalogVersion: apiCatalog.vodiaApiVersion }, `Inspected '${operation_id}'.`);
    } catch (error) { return failure(error); }
  });

  server.registerTool("list_supported_phone_models", {
    title: "List PBX-supported phone vendors and models",
    description: "Fetch the live vendor/model provisioning catalog used by the Vodia tenant GUI. Use this before provisioning a MAC address; do not guess vendor or model strings.",
    inputSchema: {
      domain: z.string().min(1),
      vendor: z.string().min(1).max(128).optional().describe("Optional vendor filter, case-insensitive, for example Polycom, snom, Fanvil, or Yealink."),
    },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ domain, vendor }) => {
    audit("list_supported_phone_models", { actor, domain, vendor });
    try {
      enforceTenant({ domain });
      const catalog = await supportedPhoneCatalog(callOperation, domain);
      const filtered = vendor
        ? catalog.filter((item) => item.vendor.toLowerCase() === vendor.trim().toLowerCase())
        : catalog;
      if (vendor && !filtered.length) throw new Error(`Vendor '${vendor}' was not found in the live PBX provisioning catalog.`);
      return success(filtered, {
        domain,
        vendorCount: filtered.length,
        modelCount: filtered.reduce((total, item) => total + item.models.length, 0),
        sourceOperationId: "get_rest_domain_domain_button_templates",
      }, "Returned the live vendor/model catalog used by the Vodia provisioning GUI.");
    } catch (error) { return failure(error); }
  });

  server.registerTool("find_extension_across_tenants", {
    title: "Find an extension across all tenants",
    description: "System-administrator inventory search across every visible Vodia tenant.",
    inputSchema: { extension: z.string().min(1).optional(), max_tenants: z.number().int().min(1).max(500).default(100) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ extension, max_tenants }) => {
    audit("find_extension_across_tenants", { actor, extension, max_tenants });
    try {
      const domainsResult = await callOperation("get_rest_system_domains");
      const domains = (Array.isArray(domainsResult.data) ? domainsResult.data : []).map((item) => item.domain || item.name || item.primary || item.primary_dns).filter(Boolean).slice(0, max_tenants);
      const matches = [];
      const errors = [];
      for (const domain of domains) {
        try {
          const result = await callOperation("get_rest_domain_domain_extensions_3", { pathParams: { domain }, queryParams: extension ? { account: extension } : {} });
          const records = Array.isArray(result.data) ? result.data : result.data ? [result.data] : [];
          if (records.length) matches.push({ domain, records });
        } catch (error) { errors.push({ domain, error: error.message || String(error) }); }
      }
      return success(redactSensitive({ matches, errors }), { tenantsChecked: domains.length, tenantsMatched: matches.length }, `Checked ${domains.length} tenants and found matches in ${matches.length}.`);
    } catch (error) { return failure(error); }
  });

  server.registerTool("troubleshoot_dropped_call", {
    title: "Collect dropped-call evidence",
    description: "Collect the tenant CDR, logs, call-quality statistics, trunk statistics, and optional extension evidence for one call.",
    inputSchema: { domain: z.string().min(1), call_id: z.string().min(1).max(256), extension: z.string().min(1).optional() },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ domain, call_id, extension }) => {
    audit("troubleshoot_dropped_call", { actor, domain, call_id, extension });
    enforceTenant({ domain });
    const evidence = {};
    const errors = {};
    const collect = async (name, operationId, args) => {
      try { evidence[name] = (await callOperation(operationId, args)).data; }
      catch (error) { errors[name] = error.message || String(error); }
    };
    await Promise.all([
      collect("cdr", "get_rest_domain_domain_cdr", { pathParams: { domain }, queryParams: { id: call_id } }),
      collect("tenantLog", "get_rest_domain_domain_log", { pathParams: { domain } }),
      collect("tenantStats", "get_rest_domain_domain_stats_6", { pathParams: { domain } }),
      collect("trunkStats", "get_rest_domain_domain_trunk_stats_1", { pathParams: { domain } }),
      ...(extension ? [
        collect("registrationHistory", "get_rest_user_account_reghist", { pathParams: { account: `${extension}@${domain}` } }),
        collect("extensionSyslog", "get_rest_user_account_syslog", { pathParams: { account: `${extension}@${domain}` } }),
      ] : []),
    ]);
    return success(redactSensitive({ evidence, errors }), { domain, callId: call_id, sourcesCollected: Object.keys(evidence), unavailableSources: Object.keys(errors) }, "Collected available dropped-call evidence. Use get_call_sip_trace separately when the CDR indicates a retained PCAP.");
  });

  server.registerTool("find_api_capabilities", {
    title: "Find Vodia API capabilities",
    description: "Search the full official Vodia API catalog, including reads and policy-gated writes.",
    inputSchema: { query: z.string().optional(), method: z.enum(["GET", "POST", "PUT", "PATCH", "DELETE"]).optional(), include_blocked: z.boolean().default(false), limit: z.number().int().min(1).max(100).default(25) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ query, method, include_blocked, limit }) => {
    const words = String(query || "").toLowerCase().split(/\s+/).filter(Boolean);
    const data = apiCatalog.operations.filter((op) => (!method || op.method === method) && (include_blocked || op.callable)).filter((op) => {
      const haystack = `${op.operationId} ${op.path} ${op.summary} ${(op.tags || []).join(" ")}`.toLowerCase();
      return words.every((word) => haystack.includes(word));
    }).slice(0, limit).map((operation) => {
      const policy = operation.method === "GET" && operation.risk === "read"
        ? { allowed: true, policy: "read" }
        : operationPolicy(operation);
      const { operationId, method: opMethod, path, summary, risk, adminTier, callable, blockedReason, parameters } = operation;
      return { operationId, method: opMethod, path, summary, risk, adminTier, callable, blockedReason, policy, parameters };
    });
    return success(data, { totalOperations: apiCatalog.totalOperations, counts: apiCatalog.counts }, `Found ${data.length} Vodia API capabilities.`);
  });

  server.registerTool("list_learned_operations", {
    title: "List supervised learned operations",
    description: "List proposed, approved, or disabled operation definitions in the persistent MCP learning store. This does not contact or change the PBX.",
    inputSchema: { status: z.enum(["proposed", "approved", "disabled"]).optional() },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ status }) => {
    audit("list_learned_operations", { actor, status });
    try {
      const data = listLearnedOperations({ status });
      return success(data, { returned: data.length, learning: learnedRuntimeInfo() }, `Returned ${data.length} supervised learned operations.`);
    } catch (error) { return failure(error); }
  });

  server.registerTool("inspect_learned_operation", {
    title: "Inspect a supervised learned operation",
    description: "Inspect one learned operation, its evidence, approval state, parameters, and redacted body template.",
    inputSchema: { operation_id: z.string().min(1).max(160) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ operation_id }) => {
    audit("inspect_learned_operation", { actor, operation_id });
    try {
      const data = listLearnedOperations().find((item) => item.id === operation_id || item.operationId === operation_id);
      if (!data) throw new Error(`Learned operation '${operation_id}' was not found.`);
      return success(data, { learning: learnedRuntimeInfo() }, "Returned the learned operation without executing it.");
    } catch (error) { return failure(error); }
  });

  server.registerTool("propose_learned_operation", {
    title: "Propose a supervised Vodia operation",
    description: "Store a proposed Vodia REST operation learned from reviewed portal evidence. This never executes the request and cannot teach DELETE, destructive, arbitrary-URL, or system-write operations.",
    inputSchema: {
      name: z.string().min(3).max(120),
      description: z.string().min(3).max(500),
      method: z.enum(["GET", "POST", "PUT", "PATCH"]),
      path: z.string().min(6).max(500).describe("Relative /rest/... path only; use braces for path parameters, for example /rest/domain/{domain}/feature."),
      path_parameters: z.array(z.string().min(1).max(64)).default([]),
      query_parameters: z.array(z.string().min(1).max(64)).default([]),
      input_parameters: z.array(z.string().min(1).max(64)).default([]).describe("Runtime values used by exact {{parameter}} placeholders in body_template."),
      body_template: z.record(z.string(), z.any()).default({}),
      pbx_version: z.string().min(1).max(64),
      evidence_source: z.string().min(3).max(120).describe("Where the request was observed, for example Vodia admin portal Network log."),
      evidence_note: z.string().min(3).max(1000).describe("What GUI action was observed and the response/result. Do not paste credentials, cookies, tokens, serials, or passwords."),
    },
    outputSchema,
    annotations: { readOnlyHint: false, destructiveHint: false, openWorldHint: false },
  }, async (input) => {
    audit("propose_learned_operation_attempt", { actor, name: input.name, method: input.method, path: input.path, pbx_version: input.pbx_version, evidence_source: input.evidence_source });
    try {
      const data = proposeLearnedOperation(input, actor);
      audit("learned_operation_proposed", { actor, operation_id: data.operationId, method: data.method, path: data.path });
      return success(data, { approvalRequired: true, executed: false }, "Lesson stored as proposed. No PBX request was sent; an administrator must review and approve it.");
    } catch (error) { return failure(error, "learning"); }
  });

  server.registerTool("test_learned_read", {
    title: "Test a proposed learned read",
    description: "Execute one proposed or approved GET lesson with strict tenant, parameter, URL and response controls. Write lessons cannot be tested through this tool.",
    inputSchema: { operation_id: z.string().min(1).max(160), path_params: parameterMap.optional(), query_params: parameterMap.optional() },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ operation_id, path_params, query_params }) => {
    audit("test_learned_read", { actor, operation_id, path_params, query_params });
    try {
      const learned = getLearnedOperation(operation_id);
      if (learned.method !== "GET") throw new Error("Only learned GET operations can be tested directly. Learned writes must be approved and then planned.");
      const materialized = materializeLearnedRequest(operation_id, { pathParams: path_params || {}, queryParams: query_params || {} }, { requireApproved: false });
      const result = await rawRequest(materialized.catalog, materialized.request);
      recordReadTest(operation_id, actor, { success: true, status: result.status });
      return success(redactSensitive(result.data), { operationId: learned.operationId, status: result.status, proposalStatus: learned.status }, "Tested the learned read without changing PBX state.");
    } catch (error) {
      recordReadTest(operation_id, actor, { success: false });
      return failure(error);
    }
  });

  server.registerTool("run_learned_read", {
    title: "Run an approved learned read",
    description: "Run an approved learned GET operation using its stored path and parameter contract.",
    inputSchema: { operation_id: z.string().min(1).max(160), path_params: parameterMap.optional(), query_params: parameterMap.optional() },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ operation_id, path_params, query_params }) => {
    audit("run_learned_read", { actor, operation_id, path_params, query_params });
    try {
      const materialized = materializeLearnedRequest(operation_id, { pathParams: path_params || {}, queryParams: query_params || {} });
      if (materialized.operation.method !== "GET") throw new Error("Use plan_learned_write for an approved learned write.");
      const result = await rawRequest(materialized.catalog, materialized.request);
      return success(redactSensitive(result.data), { operationId: materialized.operation.operationId, status: result.status }, "Ran the approved learned read without changing PBX state.");
    } catch (error) { return failure(error); }
  });

  server.registerTool("plan_learned_write", {
    title: "Plan an approved learned write",
    description: "Materialize and plan an approved learned POST, PUT, or PATCH operation. This tool never writes to the PBX; apply_vodia_change and its exact confirmation are still required.",
    inputSchema: { operation_id: z.string().min(1).max(160), path_params: parameterMap.optional(), query_params: parameterMap.optional(), inputs: parameterMap.optional(), reason: z.string().min(3).max(500) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ operation_id, path_params, query_params, inputs, reason }) => {
    audit("plan_learned_write", { actor, operation_id, path_params, query_params, inputs, reason });
    try {
      const materialized = materializeLearnedRequest(operation_id, { pathParams: path_params || {}, queryParams: query_params || {}, inputs: inputs || {} });
      if (materialized.operation.method === "GET") throw new Error("Use run_learned_read for an approved learned GET operation.");
      const plan = await makePlan({
        operationId: materialized.operation.operationId,
        ...materialized.request,
        reason,
        actor,
        callOperation,
        preimageOverride: { available: false, data: null, reason: "No reviewed preimage reader is paired with this learned operation." },
      });
      return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt, learned: true }, "Learned write planned. Review the immutable request and use the exact confirmation shown to apply it.");
    } catch (error) { return failure(error, "plan"); }
  });

  server.registerTool("disable_learned_operation", {
    title: "Disable a learned operation",
    description: "Immediately disable a learned operation without deleting its evidence or audit history. This does not contact the PBX.",
    inputSchema: { operation_id: z.string().min(1).max(160), reason: z.string().min(3).max(500) },
    outputSchema,
    annotations: { readOnlyHint: false, destructiveHint: false, openWorldHint: false },
  }, async ({ operation_id, reason }) => {
    audit("disable_learned_operation", { actor, operation_id, reason });
    try {
      const data = disableLearnedOperation(operation_id, actor, reason);
      operationsById.delete(data.operationId);
      return success(data, { disabled: true }, "Learned operation disabled; its evidence and audit history were retained.");
    } catch (error) { return failure(error, "learning"); }
  });

  server.registerTool("plan_vodia_change", {
    title: "Plan a Vodia PBX change",
    description: "Validate and preview a policy-allowed Vodia API write. This tool does not change PBX state.",
    inputSchema: { operation_id: z.string().min(1), path_params: parameterMap.optional(), query_params: parameterMap.optional(), body: z.record(z.string(), z.any()).default({}), reason: z.string().min(3).max(500) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ operation_id, path_params, query_params, body, reason }) => {
    audit("plan_vodia_change", { actor, operation_id, path_params, query_params, body, reason });
    try {
      const plan = await makePlan({ operationId: operation_id, pathParams: path_params || {}, queryParams: query_params || {}, body, reason, actor, callOperation });
      return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt }, "Change planned. Review the exact request and preimage before applying it.");
    } catch (error) { return failure(error, "plan"); }
  });

  async function planActiveCallAction({ account, callId, body, reason, action, confirmation }) {
    const current = await findActiveCall(callOperation, account, callId);
    if (!current.call) throw new Error(`Active call '${callId}' was not found for '${account}'.`);
    return makePlan({
      operationId: "post_rest_user_account_calls",
      pathParams: { account },
      body,
      reason,
      actor,
      callOperation,
      preimageOverride: {
        available: true,
        operationId: "get_rest_user_account_calls",
        data: current.call,
      },
      precondition: {
        type: "active-call-exists",
        account,
        callId: String(callId),
        action,
      },
      confirmationRequired: confirmation,
      ttlMs: 60_000,
    });
  }

  server.registerTool("plan_hangup_call", {
    title: "Plan active-call hangup",
    description: "Plan hanging up one currently active call. The plan expires quickly and validates the stable call id again before applying.",
    inputSchema: { account: z.string().min(3).describe("Account in extension@tenant-domain form"), call_id: z.string().min(1).max(256), reason: z.string().min(3).max(500) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ account, call_id, reason }) => {
    audit("plan_hangup_call", { actor, account, call_id, reason });
    try {
      const plan = await planActiveCallAction({ account, callId: call_id, body: { hangup: call_id }, reason, action: "hangup", confirmation: `HANGUP ${call_id}` });
      return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt }, "Active-call hangup planned. Verify both parties and use the exact confirmation shown.");
    } catch (error) { return failure(error, "plan"); }
  });

  server.registerTool("plan_reject_call", {
    title: "Plan alerting-call rejection",
    description: "Plan rejecting one currently alerting call by stable call id.",
    inputSchema: { account: z.string().min(3).describe("Account in extension@tenant-domain form"), call_id: z.string().min(1).max(256), reason: z.string().min(3).max(500) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ account, call_id, reason }) => {
    audit("plan_reject_call", { actor, account, call_id, reason });
    try {
      const plan = await planActiveCallAction({ account, callId: call_id, body: { reject: call_id }, reason, action: "reject", confirmation: `REJECT ${call_id}` });
      return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt }, "Alerting-call rejection planned.");
    } catch (error) { return failure(error, "plan"); }
  });

  server.registerTool("plan_transfer_call", {
    title: "Plan blind call transfer",
    description: "Plan transferring one active call to a destination number after revalidating its stable call id.",
    inputSchema: { account: z.string().min(3).describe("Account in extension@tenant-domain form"), call_id: z.string().min(1).max(256), destination: z.string().min(1).max(128), reason: z.string().min(3).max(500) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ account, call_id, destination, reason }) => {
    audit("plan_transfer_call", { actor, account, call_id, destination, reason });
    try {
      const plan = await planActiveCallAction({ account, callId: call_id, body: { transfer: call_id, number: destination }, reason, action: "transfer", confirmation: `TRANSFER ${call_id} TO ${destination}` });
      return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt }, "Blind transfer planned. Verify the destination and exact confirmation.");
    } catch (error) { return failure(error, "plan"); }
  });

  for (const definition of [
    { name: "plan_hold_call", title: "Plan call hold", key: "remote-hold", action: "hold", verb: "HOLD" },
    { name: "plan_resume_call", title: "Plan call resume", key: "remote-resume", action: "resume", verb: "RESUME" },
    { name: "plan_answer_call", title: "Plan remote call answer", key: "remote-answer", action: "answer", verb: "ANSWER" },
  ]) {
    server.registerTool(definition.name, {
      title: definition.title,
      description: `${definition.title} for one active call after revalidating its stable call id.`,
      inputSchema: { account: z.string().min(3).describe("Account in extension@tenant-domain form"), call_id: z.string().min(1).max(256), reason: z.string().min(3).max(500) },
      outputSchema,
      annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
    }, async ({ account, call_id, reason }) => {
      audit(definition.name, { actor, account, call_id, reason });
      try {
        const plan = await planActiveCallAction({ account, callId: call_id, body: { [definition.key]: call_id }, reason, action: definition.action, confirmation: `${definition.verb} ${call_id}` });
        return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt }, `${definition.title} prepared.`);
      } catch (error) { return failure(error, "plan"); }
    });
  }

  const accountTypes = ["extensions", "attendants", "conferences", "hunts", "acds", "orbits", "hoots", "srvflags", "ivrnodes", "callingcards", "colines"];
  const nonEmptyChanges = z.record(z.string(), z.any()).refine((value) => Object.keys(value).length > 0, "At least one field must be supplied.");

  server.registerTool("plan_create_account", {
    title: "Plan account creation",
    description: "Plan creation of one or more extensions, auto attendants, conferences, hunt groups, queues, service flags, IVR nodes, calling cards, park orbits, paging accounts, or CO lines.",
    inputSchema: { domain: z.string().min(1), type: z.enum(accountTypes), accounts: z.string().min(1).max(512), reason: z.string().min(3).max(500) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ domain, type, accounts, reason }) => {
    audit("plan_create_account", { actor, domain, type, accounts, reason });
    try {
      if (!/^[A-Za-z0-9*#._/-]+$/.test(accounts)) throw new Error("Account identifiers contain unsupported characters.");
      const body = type === "extensions" ? { type, account_ext: accounts } : { type, account: accounts };
      const plan = await makePlan({ operationId: "post_rest_domain_domain_addacc", pathParams: { domain }, body, reason, actor, callOperation });
      return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt }, "Account creation planned. Review the account type and every requested identifier.");
    } catch (error) { return failure(error, "plan"); }
  });

  server.registerTool("plan_update_account", {
    title: "Plan account configuration update",
    description: "Plan an extension or other account update. Use this for names, permissions, redirection, mailbox, device, and supported account settings.",
    inputSchema: { domain: z.string().min(1), account: z.string().min(1).max(128), changes: nonEmptyChanges, reason: z.string().min(3).max(500) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ domain, account, changes, reason }) => {
    audit("plan_update_account", { actor, domain, account, changes, reason });
    try {
      const plan = await makePlan({ operationId: "post_rest_domain_domain_user_settings_ext", pathParams: { domain, ext: account }, body: changes, reason, actor, callOperation });
      return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt }, "Account configuration update planned.");
    } catch (error) { return failure(error, "plan"); }
  });

  server.registerTool("plan_provision_mac", {
    title: "Plan MAC-address phone provisioning",
    description: "Plan creation or update of a tenant MAC provisioning entry. SIP transport, T.38 and refresh behavior are optional: new entries use Default/Default/Automatic, while existing entries preserve their current values when omitted. For Yealink devices, the full serial number remains required. Vendor and model are validated against the live PBX catalog.",
    inputSchema: {
      domain: z.string().min(1),
      mac: z.string().min(12).max(32).describe("Phone MAC address; separators are accepted and removed."),
      extension: z.string().min(1).max(128),
      vendor: z.string().min(1).max(128),
      model: z.string().min(1).max(128),
      name: z.string().max(128).optional(),
      sip_transport: z.enum(["Default", "TLS", "TCP", "UDP"]).optional().describe("Optional proposed SIP transport. New-entry default is Default; updates preserve the current value."),
      t38: z.enum(["Default", "On", "Off"]).optional().describe("Optional T.38 choice. New-entry default is Default; updates preserve the current value."),
      refresh_connection: z.enum(["Automatic", "No", "Yes"]).optional().describe("Optional refresh behavior. New-entry default is Automatic; updates preserve the current value."),
      serial_number: z.string().trim().min(6).max(128).regex(/^[A-Za-z0-9._-]+$/).optional()
        .describe("Full Yealink serial number. Required when vendor is Yealink; do not submit only the legacy last-five-digit handset challenge."),
      reason: z.string().min(3).max(500),
    },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ domain, mac, extension, vendor, model, name, sip_transport, t38, refresh_connection, serial_number, reason }) => {
    audit("plan_provision_mac", { actor, domain, mac, extension, vendor, model, name, sip_transport, t38, refresh_connection, reason });
    try {
      enforceTenant({ domain });
      const normalizedMac = normalizeMac(mac);
      const catalog = await supportedPhoneCatalog(callOperation, domain);
      const canonical = canonicalPhone(catalog, vendor, model);
      const isYealink = canonical.vendor.toLowerCase() === "yealink";
      if (isYealink && !serial_number) {
        throw new Error("The full Yealink serial number is required for Vodia RPS API V2 provisioning. Ask for the complete serial number, not only the last five digits.");
      }
      if (!isYealink && serial_number) {
        throw new Error("serial_number is only accepted for Yealink provisioning in this workflow.");
      }
      await callOperation("get_rest_domain_domain_user_settings_ext", {
        pathParams: { domain, ext: extension },
      });
      const current = await callOperation("get_rest_domain_domain_macs_1", {
        pathParams: { domain },
        queryParams: { adr: normalizedMac },
      });
      const existing = (Array.isArray(current.data) ? current.data : [current.data]).find((entry) => {
        try { return normalizeMac(entry?.mac ?? entry?.address ?? "") === normalizedMac; } catch { return false; }
      }) || null;
      const resolvedSipTransport = sip_transport ?? ({ tls: "TLS", tcp: "TCP", udp: "UDP" }[String(existing?.siptrans || "").toLowerCase()] || "Default");
      const resolvedT38 = t38 ?? ({ true: "On", false: "Off" }[String(existing?.prov_t38 || "").toLowerCase()] || "Default");
      const resolvedRefresh = refresh_connection ?? ({ true: "Yes", false: "No" }[String(existing?.refresh || "").toLowerCase()] || "Automatic");
      const body = {
        mac: normalizedMac,
        vendor: canonical.vendor,
        model: canonical.model,
        siptrans: { Default: "", TLS: "tls", TCP: "tcp", UDP: "udp" }[resolvedSipTransport],
        prov_t38: { Default: "", On: "true", Off: "false" }[resolvedT38],
        refresh: { Automatic: "", No: "false", Yes: "true" }[resolvedRefresh],
        name: name ?? existing?.name ?? "",
        extensions: extension,
        // Vodia PBX 69.5.16+ maps the Yealink RPS API V2 serial number to
        // the legacy wire-level `pin` field. Keep the MCP input unambiguous.
        pin: isYealink ? serial_number : existing?.pin ?? "",
      };
      const plan = await makePlan({
        operationId: "post_rest_domain_domain_macs",
        pathParams: { domain },
        body,
        reason,
        actor,
        callOperation,
        preimageOverride: { available: true, operationId: "get_rest_domain_domain_macs_1", data: current.data },
        precondition: { type: "mac-entry-state", domain, mac: normalizedMac, expectedHash: stateHash(current.data) },
      });
      return success(publicPlan(plan, redactSensitive), {
        expiresAt: plan.expiresAt,
        vendorSource: "live-pbx-catalog",
        normalizedMac,
        yealinkSerialRequired: isYealink,
        selections: { sipTransport: resolvedSipTransport, t38: resolvedT38, refreshConnection: resolvedRefresh },
        defaultsApplied: !existing ? {
          sipTransport: sip_transport === undefined,
          t38: t38 === undefined,
          refreshConnection: refresh_connection === undefined,
        } : undefined,
        existingValuesPreserved: Boolean(existing) ? {
          sipTransport: sip_transport === undefined,
          t38: t38 === undefined,
          refreshConnection: refresh_connection === undefined,
        } : undefined,
      }, isYealink
        ? "Yealink MAC provisioning planned. Vendor/model were validated and the full serial number was mapped to Vodia's redacted pin field for RPS API V2."
        : "MAC provisioning planned. Vendor and model were validated against the live PBX catalog.");
    } catch (error) { return failure(error, "plan"); }
  });

  server.registerTool("get_mac_provisioning_history", {
    title: "Get MAC provisioning history",
    description: "Read the generated provisioning-file history and pairing count for one provisioned tenant MAC. Embedded authentication headers are redacted.",
    inputSchema: {
      domain: z.string().min(1),
      mac: z.string().min(12).max(32),
    },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ domain, mac }) => {
    audit("get_mac_provisioning_history", { actor, domain, mac });
    try {
      enforceTenant({ domain });
      const normalizedMac = normalizeMac(mac);
      await requireProvisionedMac(callOperation, domain, normalizedMac);
      const result = await callOperation("get_rest_domain_domain_generated", {
        pathParams: { domain },
        queryParams: { mac: normalizedMac },
      });
      return success(redactSensitive(result.data), { domain, normalizedMac }, "MAC provisioning history retrieved with embedded credentials redacted.");
    } catch (error) { return failure(error); }
  });

  const deviceActionPlanner = ({ name, title, description, reboot, confirmation, message }) => {
    server.registerTool(name, {
      title,
      description,
      inputSchema: {
        domain: z.string().min(1),
        mac: z.string().min(12).max(32),
        reason: z.string().min(3).max(500),
      },
      outputSchema,
      annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
    }, async ({ domain, mac, reason }) => {
      audit(name, { actor, domain, mac, reason });
      try {
        enforceTenant({ domain });
        const normalizedMac = normalizeMac(mac);
        const current = await requireProvisionedMac(callOperation, domain, normalizedMac);
        const plan = await makePlan({
          operationId: "get_rest_domain_domain_check_sync_mac",
          pathParams: { domain },
          queryParams: { mac: normalizedMac, reboot },
          reason,
          actor,
          callOperation,
          safeWrapper: true,
          preimageOverride: { available: true, operationId: "get_rest_domain_domain_macs_1", data: current.data },
          precondition: { type: "mac-device-exists", domain, mac: normalizedMac },
          confirmationRequired: confirmation(normalizedMac, domain),
        });
        return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt, normalizedMac }, message);
      } catch (error) { return failure(error, "plan"); }
    });
  };

  deviceActionPlanner({
    name: "plan_trigger_mac_provisioning",
    title: "Plan provisioning trigger for one MAC",
    description: "Plan a Vodia CHECK-SYNC provisioning trigger for one validated tenant MAC. This does not reboot the device.",
    reboot: false,
    confirmation: (mac, domain) => `TRIGGER PROVISIONING FOR ${mac} ON ${domain}`,
    message: "MAC provisioning trigger planned. Review the tenant and device before applying.",
  });

  deviceActionPlanner({
    name: "plan_trigger_mac_reboot",
    title: "Plan reboot for one provisioned MAC",
    description: "Plan the verified Vodia tenant-MAC reboot/resync action for one validated device. Applying may interrupt active calls on that phone.",
    reboot: true,
    confirmation: (mac, domain) => `REBOOT MAC ${mac} ON ${domain}`,
    message: "MAC reboot planned. Confirm the phone is idle before applying.",
  });

  server.registerTool("plan_clear_mac_provisioning_history", {
    title: "Plan clearing one MAC provisioning history",
    description: "Plan clearing generated provisioning history for one validated tenant MAC. This does not remove the phone or extension.",
    inputSchema: {
      domain: z.string().min(1),
      mac: z.string().min(12).max(32),
      reason: z.string().min(3).max(500),
    },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: true, openWorldHint: false },
  }, async ({ domain, mac, reason }) => {
    audit("plan_clear_mac_provisioning_history", { actor, domain, mac, reason });
    try {
      enforceTenant({ domain });
      const normalizedMac = normalizeMac(mac);
      await requireProvisionedMac(callOperation, domain, normalizedMac);
      const history = await callOperation("get_rest_domain_domain_generated", {
        pathParams: { domain },
        queryParams: { mac: normalizedMac },
      });
      const plan = await makePlan({
        operationId: "get_rest_domain_domain_generated_reset",
        pathParams: { domain },
        queryParams: { mac: normalizedMac, reset: 1 },
        reason,
        actor,
        callOperation,
        safeWrapper: true,
        preimageOverride: { available: true, operationId: "get_rest_domain_domain_generated", data: history.data },
        precondition: { type: "mac-device-exists", domain, mac: normalizedMac },
        confirmationRequired: `CLEAR PROVISIONING HISTORY FOR ${normalizedMac} ON ${domain}`,
      });
      return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt, normalizedMac, historyCount: Number(history.data?.count || 0) }, "Provisioning-history clear planned. The phone and extension will remain configured.");
    } catch (error) { return failure(error, "plan"); }
  });

  const buttonTypes = ["local", "none", "private", "attendant", "hunt", "queue", "extension", "conference", "flag", "park", "ivrnode", "coline", "page", "speed", "intercom", "vm", "ldap", "dnd", "dtmf", "login", "redirect", "group", "cell", "url", "transfer", "hold", "mute", "redial", "record", "snom"];
  const buttonSchema = z.object({
    number: z.union([z.string().min(1).max(32), z.number().int().nonnegative()]),
    type: z.enum(buttonTypes),
    name: z.string().max(64).optional(),
    mode: z.union([z.string().max(32), z.number().int().nonnegative()]).optional(),
    sort: z.number().int().positive().optional(),
    group: z.number().int().positive().optional(),
    identity: z.string().max(128).optional(),
    parameter: z.string().max(256).optional(),
    label: z.string().max(256).optional(),
    fixed: z.boolean().optional(),
    pickup: z.string().max(128).optional(),
  });

  server.registerTool("get_extension_buttons", {
    title: "Get extension phone-button profiles",
    description: "Read the phone/button-profile response for one extension account. Some PBX builds return only profile containers; this tool reports whether detailed assignments are present.",
    inputSchema: { account: z.string().min(3).describe("Account in extension@tenant-domain form") },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ account }) => {
    audit("get_extension_buttons", { actor, account });
    try {
      accountParts(account);
      const result = await callOperation("get_rest_user_account_buttons", { pathParams: { account } });
      const detailedProfiles = (Array.isArray(result.data) ? result.data : [result.data]).filter((row) => row?.buttons || row?.configuration).length;
      return success(redactSensitive(result.data), { detailedProfiles, containerOnly: detailedProfiles === 0 }, "Phone-button profiles retrieved.");
    } catch (error) { return failure(error); }
  });

  server.registerTool("plan_set_extension_buttons", {
    title: "Plan complete extension phone-button configuration",
    description: "Plan a complete replacement of one phone's button/DSS-key configuration. Every slot that must remain configured must be supplied. This planner records the current profile and blocks stale application.",
    inputSchema: {
      account: z.string().min(3).describe("Account in extension@tenant-domain form"),
      mac: z.string().min(12).max(32),
      template: z.union([z.string().max(128), z.number().int().nonnegative()]).optional(),
      buttons: z.array(buttonSchema).max(256),
      modes: z.record(z.string(), z.array(z.string().max(64)).max(64)).optional(),
      replace_all: z.literal(true).describe("Must be true to acknowledge that POST replaces the complete phone-button profile."),
      reason: z.string().min(3).max(500),
    },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: true, openWorldHint: false },
  }, async ({ account, mac, template, buttons, modes, replace_all, reason }) => {
    audit("plan_set_extension_buttons", { actor, account, mac, template, buttonCount: buttons.length, replace_all, reason });
    try {
      const { domain } = accountParts(account);
      enforceTenant({ domain });
      const normalizedMac = normalizeMac(mac);
      const current = await callOperation("get_rest_user_account_buttons", { pathParams: { account } });
      const matched = buttonProfileForMac(current.data, normalizedMac);
      if (Array.isArray(current.data) && current.data.length && !matched) {
        throw new Error(`MAC '${normalizedMac}' is not present in the button profiles returned for '${account}'.`);
      }
      const resolvedModes = modes ?? matched?.configuration?.modes ?? {};
      const normalizedButtons = buttons.map(normalizeButton);
      const body = {
        mac: normalizedMac,
        template: String(template ?? matched?.profile?.template ?? "0"),
        buttons: JSON.stringify({ buttons: normalizedButtons, modes: resolvedModes }),
      };
      const plan = await makePlan({
        operationId: "post_rest_user_account_buttons",
        pathParams: { account },
        body,
        reason,
        actor,
        callOperation,
        preimageOverride: { available: true, operationId: "get_rest_user_account_buttons", data: current.data },
        precondition: { type: "button-profile-state", account, expectedHash: stateHash(current.data) },
        confirmationRequired: `REPLACE BUTTONS ${normalizedMac} ON ${account}`,
      });
      return success(publicPlan(plan, redactSensitive), {
        expiresAt: plan.expiresAt,
        normalizedMac,
        buttonCount: normalizedButtons.length,
        completeReplacement: true,
        previousDetailsAvailable: Boolean(matched?.configuration),
      }, "Complete phone-button replacement planned. Verify every slot before applying.");
    } catch (error) { return failure(error, "plan"); }
  });

  server.registerTool("list_tenant_dids", {
    title: "List tenant DID management entries",
    description: "Read the DID policy and DID assignments for one tenant.",
    inputSchema: { domain: z.string().min(1) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ domain }) => {
    audit("list_tenant_dids", { actor, domain });
    try {
      enforceTenant({ domain });
      const result = await callOperation("get_rest_domain_domain_did", { pathParams: { domain } });
      return success(redactSensitive(result.data), { didCount: didRows(result.data).length }, "Tenant DID entries retrieved.");
    } catch (error) { return failure(error); }
  });

  server.registerTool("plan_assign_did", {
    title: "Plan DID assignment to an extension",
    description: "Plan assigning a DID to one tenant extension using the documented Vodia DID endpoint. This does not invent unsupported DID inventory, trunk-edit, unassign or delete operations.",
    inputSchema: {
      domain: z.string().min(1),
      extension: z.string().min(1).max(128),
      did: z.string().trim().min(3).max(128),
      outbound: z.boolean().optional().default(false),
      reason: z.string().min(3).max(500),
    },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ domain, extension, did, outbound, reason }) => {
    audit("plan_assign_did", { actor, domain, extension, did, outbound, reason });
    try {
      enforceTenant({ domain });
      await callOperation("get_rest_domain_domain_user_settings_ext", { pathParams: { domain, ext: extension } });
      const current = await callOperation("get_rest_domain_domain_did", { pathParams: { domain } });
      const matches = didRows(current.data).filter((row) => String(row?.did || "") === did);
      const conflict = matches.find((row) => String(row?.user || row?.assign || "") && String(row?.user || row?.assign || "") !== extension);
      if (conflict) throw new Error(`DID '${did}' is already assigned to '${conflict.user || conflict.assign}'.`);
      const plan = await makePlan({
        operationId: "post_rest_domain_domain_did_2",
        pathParams: { domain },
        body: { cmd: "assign", assign: extension, did, outbound },
        reason,
        actor,
        callOperation,
        preimageOverride: { available: true, operationId: "get_rest_domain_domain_did", data: current.data },
        precondition: { type: "did-list-state", domain, expectedHash: stateHash(current.data) },
        confirmationRequired: `ASSIGN DID ${did} TO ${extension}@${domain}`,
      });
      return success(publicPlan(plan, redactSensitive), {
        expiresAt: plan.expiresAt,
        didAlreadyListed: matches.length > 0,
        outbound,
      }, "DID assignment planned. Review the number, target extension and outbound-caller-ID choice.");
    } catch (error) { return failure(error, "plan"); }
  });

  server.registerTool("list_predefined_trunks", {
    title: "List verified predefined SIP trunk templates",
    description: "List predefined trunk templates that were verified from real Vodia portal/API traffic, including the fields the assistant must collect before planning creation.",
    inputSchema: {},
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async () => {
    audit("list_predefined_trunks", { actor });
    try {
      const templates = [...PREDEFINED_TRUNK_TEMPLATES.values()].map(publicPredefinedTemplate);
      return success(templates, { templateCount: templates.length }, "Verified predefined SIP trunk templates retrieved.");
    } catch (error) { return failure(error); }
  });

  server.registerTool("get_predefined_trunk_requirements", {
    title: "Get predefined SIP trunk requirements",
    description: "Resolve a predefined trunk provider and report exactly which user-supplied fields are still required. The assistant should ask the returned questions instead of guessing missing values.",
    inputSchema: {
      provider: z.string().min(1).max(128),
      domain: z.string().min(1).max(253).optional(),
      fqdn: z.string().max(253).optional(),
      voice_connector_host: z.string().max(253).optional(),
      sip_username: z.string().max(128).optional(),
      sip_password: z.string().max(256).optional(),
      did: z.string().max(32).optional(),
      allowed_addresses: z.string().max(2048).optional(),
      name: z.string().min(1).max(128).optional(),
    },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ provider, domain, fqdn, voice_connector_host, sip_username, sip_password, did, allowed_addresses, name }) => {
    audit("get_predefined_trunk_requirements", { actor, provider, domain, fqdn, voice_connector_host, sip_username, sip_password, did, allowed_addresses, name });
    try {
      const template = predefinedTrunkTemplate(provider);
      if (domain) enforceTenant({ domain });
      const supplied = predefinedInputs({ fqdn, voice_connector_host, sip_username, sip_password, did, allowed_addresses, name });
      const missing = template.requiredInputs.filter((field) => !supplied[field.field]).map((field) => ({ field: field.field, question: field.question }));
      return success({ template: publicPredefinedTemplate(template), supplied, missing, readyToPlan: missing.length === 0 }, { missingCount: missing.length }, missing.length ? "More information is required before the predefined trunk can be planned." : "All required predefined-trunk inputs are present.");
    } catch (error) { return failure(error); }
  });

  server.registerTool("plan_create_predefined_trunk", {
    title: "Plan predefined SIP trunk creation",
    description: "Plan creation of a verified predefined SIP trunk. If a required value such as the Microsoft Teams FQDN is missing, no change plan is created; the tool returns the exact question the assistant must ask the user.",
    inputSchema: {
      domain: z.string().min(1).max(253),
      provider: z.string().min(1).max(128),
      fqdn: z.string().max(253).optional(),
      voice_connector_host: z.string().max(253).optional(),
      sip_username: z.string().max(128).optional(),
      sip_password: z.string().max(256).optional(),
      did: z.string().max(32).optional(),
      allowed_addresses: z.string().max(2048).optional(),
      name: z.string().min(1).max(128).optional(),
      reason: z.string().min(3).max(500).default("Create predefined SIP trunk"),
    },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ domain, provider, fqdn, voice_connector_host, sip_username, sip_password, did, allowed_addresses, name, reason }) => {
    audit("plan_create_predefined_trunk", { actor, domain, provider, fqdn, voice_connector_host, sip_username, sip_password, did, allowed_addresses, name, reason });
    try {
      enforceTenant({ domain });
      const template = predefinedTrunkTemplate(provider);
      const supplied = predefinedInputs({ fqdn, voice_connector_host, sip_username, sip_password, did, allowed_addresses, name });
      const missing = template.requiredInputs.filter((field) => !supplied[field.field]).map((field) => ({ field: field.field, question: field.question }));
      if (missing.length) {
        return success({ needsInput: true, template: publicPredefinedTemplate(template), missing, readyToPlan: false }, { missingCount: missing.length }, "Required predefined-trunk information is missing. Ask the user the returned question(s); do not guess.");
      }
      const current = await callOperation("get_rest_domain_domain_domain_trunks", { pathParams: { domain } });
      const rows = Array.isArray(current.data) ? current.data : [];
      const finalName = name || template.label;
      if (rows.some((row) => String(row?.name || "").trim().toLowerCase() === finalName.trim().toLowerCase())) {
        throw new Error(`A SIP trunk named '${finalName}' already exists in '${domain}'. Choose another name or update the existing trunk.`);
      }
      const body = template.build({ ...supplied, name: finalName });
      const plan = await makePlan({
        operationId: "post_rest_domain_domain_domain_trunks",
        pathParams: { domain },
        queryParams: {},
        body,
        reason,
        actor,
        callOperation,
        preimageOverride: { available: true, operationId: "get_rest_domain_domain_domain_trunks", data: current.data },
        confirmationRequired: `CREATE ${template.label.toUpperCase()} TRUNK ${finalName} ON ${domain}`,
      });
      return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt, provider: template.id, verifiedTemplate: true }, "Predefined SIP trunk creation planned. Review the exact request, then explicitly approve before apply_vodia_change.");
    } catch (error) { return failure(error, "plan"); }
  });

  server.registerTool("plan_update_sip_trunk", {
    title: "Plan SIP trunk update",
    description: "Plan changes to an existing SIP trunk, including its name, registrar, proxy, transport, authentication, codecs, routing, headers, failover, PCAP, and other supported fields.",
    inputSchema: { domain: z.string().min(1), trunk_id: z.union([z.string().min(1).max(128), z.number().int().nonnegative()]), changes: nonEmptyChanges, reason: z.string().min(3).max(500) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ domain, trunk_id, changes, reason }) => {
    audit("plan_update_sip_trunk", { actor, domain, trunk_id, changes, reason });
    try {
      const plan = await makePlan({ operationId: "post_rest_domain_domain_edit_trunk_trunk_id", pathParams: { domain, trunk_id }, body: changes, reason, actor, callOperation });
      return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt }, "SIP trunk update planned. Authentication fields remain redacted in the preview and audit log.");
    } catch (error) { return failure(error, "plan"); }
  });

  server.registerTool("plan_set_sip_trunk_enabled", {
    title: "Plan SIP trunk enable or disable",
    description: "Plan enabling or disabling an existing tenant SIP trunk.",
    inputSchema: { domain: z.string().min(1), trunk_id: z.union([z.string().min(1).max(128), z.number().int().nonnegative()]), enabled: z.boolean(), reason: z.string().min(3).max(500) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ domain, trunk_id, enabled, reason }) => {
    audit("plan_set_sip_trunk_enabled", { actor, domain, trunk_id, enabled, reason });
    try {
      const plan = await makePlan({ operationId: "post_rest_domain_domain_domain_trunks", pathParams: { domain }, queryParams: { trunk: trunk_id }, body: { dis: enabled ? "false" : "true" }, reason, actor, callOperation });
      return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt }, `SIP trunk ${enabled ? "enable" : "disable"} change planned.`);
    } catch (error) { return failure(error, "plan"); }
  });

  server.registerTool("plan_create_dial_plan", {
    title: "Plan dial-plan creation",
    description: "Plan creation of a new empty tenant dial plan. Configure its ordered rules afterward with plan_update_dial_plan.",
    inputSchema: { domain: z.string().min(1), name: z.string().min(1).max(128), reason: z.string().min(3).max(500) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ domain, name, reason }) => {
    audit("plan_create_dial_plan", { actor, domain, name, reason });
    try {
      const current = await callOperation("get_rest_domain_domain_dialplans", { pathParams: { domain } });
      const rows = Array.isArray(current.data) ? current.data : [];
      if (rows.some((row) => String(row?.name || "").toLowerCase() === name.toLowerCase())) {
        throw new Error(`A dial plan named '${name}' already exists in '${domain}'.`);
      }
      const plan = await makePlan({ operationId: "post_rest_domain_domain_dialplans", pathParams: { domain }, body: { name }, reason, actor, callOperation });
      return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt }, "Dial-plan creation planned. The resulting plan will be empty until rules are configured.");
    } catch (error) { return failure(error, "plan"); }
  });

  server.registerTool("plan_update_dial_plan", {
    title: "Plan dial-plan update",
    description: "Plan an update to the selected tenant dial plan, including its ordered routing rules.",
    inputSchema: { domain: z.string().min(1), dialplan_id: z.union([z.string().min(1).max(128), z.number().int().nonnegative()]), changes: nonEmptyChanges, reason: z.string().min(3).max(500) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ domain, dialplan_id, changes, reason }) => {
    audit("plan_update_dial_plan", { actor, domain, dialplan_id, changes, reason });
    try {
      const plan = await makePlan({ operationId: "post_rest_domain_domain_edit_dialplan", pathParams: { domain }, queryParams: { dialplan: dialplan_id }, body: changes, reason, actor, callOperation });
      return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt }, "Dial-plan update planned. Review rule order, patterns, replacements, and trunk assignments.");
    } catch (error) { return failure(error, "plan"); }
  });

  server.registerTool("plan_delete_dial_plan", {
    title: "Plan dial-plan deletion",
    description: "Plan permanent deletion of an unused tenant dial plan. Destructive writes must be explicitly enabled.",
    inputSchema: { domain: z.string().min(1), dialplan_id: z.union([z.string().min(1).max(128), z.number().int().nonnegative()]), reason: z.string().min(3).max(500) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: true, openWorldHint: false },
  }, async ({ domain, dialplan_id, reason }) => {
    audit("plan_delete_dial_plan", { actor, domain, dialplan_id, reason });
    try {
      const plan = await makePlan({ operationId: "delete_rest_domain_domain_dialplans", pathParams: { domain }, queryParams: { id: dialplan_id }, reason, actor, callOperation });
      return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt }, "Dial-plan deletion planned. Vodia will reject deletion if the dial plan is still in use.");
    } catch (error) { return failure(error, "plan"); }
  });

  server.registerTool("plan_update_tenant_settings", {
    title: "Plan tenant settings update",
    description: "Plan a supported tenant-level configuration update.",
    inputSchema: { domain: z.string().min(1), changes: nonEmptyChanges, reason: z.string().min(3).max(500) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ domain, changes, reason }) => {
    audit("plan_update_tenant_settings", { actor, domain, changes, reason });
    try {
      const plan = await makePlan({ operationId: "post_rest_domain_domain_settings", pathParams: { domain }, body: changes, reason, actor, callOperation });
      return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt }, "Tenant settings update planned.");
    } catch (error) { return failure(error, "plan"); }
  });

  server.registerTool("plan_delete_account", {
    title: "Plan account deletion",
    description: "Plan permanent deletion of one tenant account. Requires the destructive policy switch and DELETE confirmation.",
    inputSchema: { domain: z.string().min(1), account: z.string().min(1).max(128), reason: z.string().min(3).max(500) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: true, openWorldHint: false },
  }, async ({ domain, account, reason }) => {
    audit("plan_delete_account", { actor, domain, account, reason });
    try {
      const plan = await makePlan({ operationId: "delete_rest_domain_domain_addacc_ext", pathParams: { domain, ext: account }, body: {}, reason, actor, callOperation });
      return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt }, "Account deletion planned. This action is permanent.");
    } catch (error) { return failure(error, "plan"); }
  });

  server.registerTool("plan_delete_sip_trunk", {
    title: "Plan SIP trunk deletion",
    description: "Plan permanent deletion of one tenant SIP trunk. Requires the destructive policy switch and DELETE confirmation.",
    inputSchema: { domain: z.string().min(1), trunk_id: z.union([z.string().min(1).max(128), z.number().int().nonnegative()]), reason: z.string().min(3).max(500) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: true, openWorldHint: false },
  }, async ({ domain, trunk_id, reason }) => {
    audit("plan_delete_sip_trunk", { actor, domain, trunk_id, reason });
    try {
      const plan = await makePlan({ operationId: "delete_rest_domain_domain_domain_trunks", pathParams: { domain }, queryParams: { trunk: trunk_id }, body: {}, reason, actor, callOperation });
      return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt }, "SIP trunk deletion planned. This action is permanent.");
    } catch (error) { return failure(error, "plan"); }
  });

  server.registerTool("apply_vodia_change", {
    title: "Apply an approved Vodia PBX change",
    description: "Apply an unexpired change plan after explicit confirmation. The body cannot be altered after planning.",
    inputSchema: { change_id: z.string().uuid(), confirmation: z.string().min(1).max(512) },
    outputSchema,
    annotations: writeAnnotations,
  }, async ({ change_id, confirmation }) => {
    const plan = plans.get(change_id);
    audit("apply_vodia_change", { actor, change_id, operation_id: plan?.operationId, reason: plan?.reason });
    try {
      if (!plan) throw new Error("Unknown or already-used change plan.");
      if (Date.parse(plan.expiresAt) <= Date.now()) { plans.delete(change_id); throw new Error("Change plan expired; create a new plan."); }
      if (plan.actor !== actor) throw new Error("Change plan belongs to a different administrator.");
      if (confirmation !== plan.confirmationRequired) throw new Error(`This plan requires confirmation exactly ${plan.confirmationRequired}.`);
      const operation = operationsById.get(plan.operationId);
      if (plan.precondition?.type === "active-call-exists") {
        const current = await findActiveCall(callOperation, plan.precondition.account, plan.precondition.callId);
        if (!current.call) {
          throw new Error(`Active call '${plan.precondition.callId}' no longer exists. Nothing was written; create a new plan from current call state.`);
        }
      } else if (plan.precondition?.type === "mac-entry-state") {
        const current = await callOperation("get_rest_domain_domain_macs_1", {
          pathParams: { domain: plan.precondition.domain },
          queryParams: { adr: plan.precondition.mac },
        });
        if (stateHash(current.data) !== plan.precondition.expectedHash) {
          throw new Error(`MAC provisioning entry '${plan.precondition.mac}' changed after the plan was created. Nothing was written; create and review a new plan.`);
        }
      } else if (plan.precondition?.type === "mac-device-exists") {
        await requireProvisionedMac(callOperation, plan.precondition.domain, plan.precondition.mac);
      } else if (plan.precondition?.type === "button-profile-state") {
        const current = await callOperation("get_rest_user_account_buttons", {
          pathParams: { account: plan.precondition.account },
        });
        if (stateHash(current.data) !== plan.precondition.expectedHash) {
          throw new Error(`Button profile for '${plan.precondition.account}' changed after the plan was created. Nothing was written; create and review a new plan.`);
        }
      } else if (plan.precondition?.type === "did-list-state") {
        const current = await callOperation("get_rest_domain_domain_did", {
          pathParams: { domain: plan.precondition.domain },
        });
        if (stateHash(current.data) !== plan.precondition.expectedHash) {
          throw new Error(`DID list for '${plan.precondition.domain}' changed after the plan was created. Nothing was written; create and review a new plan.`);
        }
      } else if (plan.preimage?.available) {
        const current = await preimageFor(operation, plan.pathParams, plan.queryParams, callOperation);
        if (!current.available || createHash("sha256").update(JSON.stringify(current.data)).digest("hex") !== createHash("sha256").update(JSON.stringify(plan.preimage.data)).digest("hex")) {
          throw new Error("PBX state changed after the plan was created. Nothing was written; create and review a new plan.");
        }
      }
      const result = await rawRequest(operation, plan);
      if (plan.autoRestoreSeconds && plan.preimage?.available && plan.preimage.data && typeof plan.preimage.data === "object") {
        const source = Array.isArray(plan.preimage.data) ? plan.preimage.data[0] : plan.preimage.data;
        const restoreBody = Object.fromEntries(Object.keys(plan.body).filter((key) => Object.hasOwn(source || {}, key)).map((key) => [key, source[key]]));
        if (Object.keys(restoreBody).length) {
          const timer = setTimeout(async () => {
            try {
              await rawRequest(operation, { pathParams: plan.pathParams, queryParams: plan.queryParams, body: restoreBody });
              audit("temporary_change_restored", { actor: plan.actor, operation_id: plan.operationId, tenant: plan.tenant, reason: plan.reason });
            } catch (error) {
              audit("temporary_change_restore_failed", { actor: plan.actor, operation_id: plan.operationId, error: error.message || String(error) });
            }
          }, plan.autoRestoreSeconds * 1000);
          timer.unref();
        }
      }
      plans.delete(change_id);
      const verification = plan.precondition?.type === "active-call-exists"
        ? await findActiveCall(callOperation, plan.precondition.account, plan.precondition.callId)
          .then(({ call }) => ({ available: true, operationId: "get_rest_user_account_calls", callStillPresent: Boolean(call), data: call }))
          .catch((error) => ({ available: false, error: error.message || String(error), data: null }))
        : plan.precondition?.type === "mac-entry-state"
          ? await callOperation("get_rest_domain_domain_macs_1", {
            pathParams: { domain: plan.precondition.domain },
            queryParams: { adr: plan.precondition.mac },
          }).then((current) => ({ available: true, operationId: "get_rest_domain_domain_macs_1", data: current.data }))
            .catch((error) => ({ available: false, error: error.message || String(error), data: null }))
        : plan.precondition?.type === "mac-device-exists"
          ? await callOperation("get_rest_domain_domain_generated", {
            pathParams: { domain: plan.precondition.domain },
            queryParams: { mac: plan.precondition.mac },
          }).then((current) => ({ available: true, operationId: "get_rest_domain_domain_generated", data: current.data }))
            .catch((error) => ({ available: false, error: error.message || String(error), data: null }))
        : plan.precondition?.type === "button-profile-state"
          ? await callOperation("get_rest_user_account_buttons", {
            pathParams: { account: plan.precondition.account },
          }).then((current) => ({ available: true, operationId: "get_rest_user_account_buttons", data: current.data }))
            .catch((error) => ({ available: false, error: error.message || String(error), data: null }))
        : plan.precondition?.type === "did-list-state"
          ? await callOperation("get_rest_domain_domain_did", {
            pathParams: { domain: plan.precondition.domain },
          }).then((current) => ({ available: true, operationId: "get_rest_domain_domain_did", data: current.data }))
            .catch((error) => ({ available: false, error: error.message || String(error), data: null }))
        : await preimageFor(operation, plan.pathParams, plan.queryParams, callOperation);
      const data = redactSensitive({ operationId: plan.operationId, status: result.status, tenant: plan.tenant, reason: plan.reason, result: result.data, verification });
      audit("vodia_change_applied", {
        operationId: plan.operationId,
        status: result.status,
        tenant: plan.tenant,
        change_id,
        changed_fields: changedFieldsForAudit(plan),
      });
      return success(data, { requestHash: plan.requestHash }, "Approved Vodia change applied and verification read attempted.");
    } catch (error) { return failure(error, "write"); }
  });

  server.registerTool("plan_extension_pcap", {
    title: "Plan extension PCAP change",
    description: "Plan enabling or disabling packet capture for one extension. Applying requires a separate explicit confirmation.",
    inputSchema: { domain: z.string().min(1), extension: z.string().min(1), enabled: z.boolean(), reason: z.string().min(3).max(500) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ domain, extension, enabled, reason }) => {
    audit("plan_extension_pcap", { actor, domain, extension, enabled, reason });
    try {
      const plan = await makePlan({ operationId: "post_rest_domain_domain_user_settings_ext", pathParams: { domain, ext: extension }, body: { pcap: enabled ? "true" : "" }, reason, actor, callOperation, safeWrapper: true });
      return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt }, `PCAP ${enabled ? "enable" : "disable"} change planned for the extension.`);
    } catch (error) { return failure(error, "plan"); }
  });

  server.registerTool("plan_trunk_pcap", {
    title: "Plan trunk PCAP change",
    description: "Plan enabling or disabling packet capture for one SIP trunk. Applying requires a separate explicit confirmation.",
    inputSchema: { domain: z.string().min(1), trunk_id: z.union([z.string().min(1), z.number().int().nonnegative()]), enabled: z.boolean(), reason: z.string().min(3).max(500) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ domain, trunk_id, enabled, reason }) => {
    audit("plan_trunk_pcap", { actor, domain, trunk_id, enabled, reason });
    try {
      const plan = await makePlan({ operationId: "post_rest_domain_domain_edit_trunk_trunk_id", pathParams: { domain, trunk_id }, body: { pcap: enabled ? "true" : "" }, reason, actor, callOperation, safeWrapper: true });
      return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt }, `PCAP ${enabled ? "enable" : "disable"} change planned for the trunk.`);
    } catch (error) { return failure(error, "plan"); }
  });

  server.registerTool("plan_sip_trace_logging", {
    title: "Plan temporary SIP trace logging",
    description: "Plan a short-lived PBX SIP dialog trace. Applying requires confirmation; logging automatically restores afterward.",
    inputSchema: { duration_seconds: z.number().int().min(60).max(3600).default(600), sip_level: z.number().int().min(7).max(9).default(9), media_level: z.number().int().min(0).max(9).default(7), include_register: z.boolean().default(false), include_subscribe_notify: z.boolean().default(false), watch_ip: z.string().optional(), reason: z.string().min(3).max(500) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ duration_seconds, sip_level, media_level, include_register, include_subscribe_notify, watch_ip, reason }) => {
    audit("plan_sip_trace_logging", { actor, duration_seconds, sip_level, media_level, include_register, include_subscribe_notify, watch_ip, reason });
    try {
      const body = { log_duration: String(duration_seconds), log_event_sip: String(sip_level), log_event_media: String(media_level), log_sip_dialog: "true", log_sip_register: String(include_register), log_sip_subnot: String(include_subscribe_notify), ...(watch_ip ? { log_sip_watchlist: watch_ip } : {}) };
      const plan = await makePlan({ operationId: "post_rest_system_config", body, reason, actor, callOperation, safeWrapper: true });
      plan.autoRestoreSeconds = duration_seconds;
      return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt, autoRestoreSeconds: duration_seconds }, "Temporary SIP logging change planned.");
    } catch (error) { return failure(error, "plan"); }
  });

  server.registerTool("get_call_sip_trace", {
    title: "Get a call SIP trace",
    description: "Validate a call against its tenant, retrieve its size-limited PCAP, and return a redacted chronological SIP dialog.",
    inputSchema: { domain: z.string().min(1), call_id: z.string().min(1).max(256), include_sdp: z.boolean().default(false), include_raw_messages: z.boolean().default(false) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ domain, call_id, include_sdp, include_raw_messages }) => {
    audit("get_call_sip_trace", { actor, domain, call_id, include_sdp, include_raw_messages });
    try {
      const { buffer } = await retrieveCallPcap({ domain, callId: call_id, callOperation });
      const messages = parseSipFromPcap(buffer, { includeSdp: include_sdp });
      if (!messages.length) throw new Error("PCAP was retrieved but contained no recognizable SIP messages.");
      const safeMessages = messages.map((message) => include_raw_messages ? message : { timestamp: message.timestamp, startLine: message.startLine, callId: message.callId, cseq: message.cseq, reason: message.reason, userAgent: message.userAgent });
      return success(redactSensitive({ summary: summarizeSipDialog(messages), messages: safeMessages }), { domain, callId: call_id, pcapBytes: buffer.length, redactionApplied: true }, `Retrieved and parsed ${messages.length} SIP messages.`);
    } catch (error) { return failure(error); }
  });
}

export function registerLearningApprovalTools(server, { audit, success, failure, actor = "human-approver" }) {
  const outputSchema = { data: z.any(), meta: z.record(z.string(), z.any()) };

  server.registerTool("list_learning_proposals", {
    title: "List MCP learning proposals",
    description: "List proposed learned operations for independent human review. This does not contact the PBX.",
    inputSchema: {},
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async () => {
    audit("list_learning_proposals", { actor });
    try {
      const data = listLearnedOperations({ status: "proposed" });
      return success(data, { returned: data.length, learning: learnedRuntimeInfo() }, `Returned ${data.length} pending learning proposals.`);
    } catch (error) { return failure(error); }
  });

  server.registerTool("inspect_learning_proposal", {
    title: "Inspect an MCP learning proposal",
    description: "Inspect one proposal and its redacted template and evidence before approval.",
    inputSchema: { operation_id: z.string().min(1).max(160) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ operation_id }) => {
    audit("inspect_learning_proposal", { actor, operation_id });
    try {
      const data = listLearnedOperations().find((item) => item.id === operation_id || item.operationId === operation_id);
      if (!data) throw new Error(`Learned operation '${operation_id}' was not found.`);
      return success(data, { executable: false }, "Returned the learning proposal without executing it.");
    } catch (error) { return failure(error); }
  });

  server.registerTool("approve_learned_operation", {
    title: "Approve an MCP learning proposal",
    description: "Approve one reviewed, non-destructive proposal. Approval does not execute the operation or apply a PBX change.",
    inputSchema: { operation_id: z.string().min(1).max(160), confirmation: z.string().min(1).max(256) },
    outputSchema,
    annotations: { readOnlyHint: false, destructiveHint: false, openWorldHint: false },
  }, async ({ operation_id, confirmation }) => {
    audit("approve_learned_operation", { actor, operation_id });
    try {
      const proposal = getLearnedOperation(operation_id);
      const required = `APPROVE LEARNING ${proposal.operationId}`;
      if (confirmation !== required) throw new Error(`Approval requires confirmation exactly ${required}.`);
      const data = approveLearnedOperation(operation_id, actor);
      const catalog = loadApprovedLearnedCatalog().find((item) => item.operationId === data.operationId);
      if (!catalog) throw new Error("Approved operation could not be loaded into the runtime catalog.");
      operationsById.set(catalog.operationId, catalog);
      audit("learned_operation_approved", { actor, operation_id: data.operationId, method: data.method, path: data.path });
      return success(data, { executed: false, confirmationRequiredForUse: data.method === "GET" ? null : `APPLY ${data.operationId} ON <tenant>` }, "Learning proposal approved. No PBX request was sent.");
    } catch (error) { return failure(error, "learning approval"); }
  });
}

export function getAdminRuntimeInfo() {
  const writes = apiCatalog.operations.filter((operation) => (operation.method !== "GET" || operation.risk === "elevated") && operation.callable);
  const binaryReads = apiCatalog.operations.filter((operation) => operation.method === "GET" && operation.risk === "specialized" && /Binary content/i.test(operation.blockedReason || ""));
  const privateBlocked = apiCatalog.operations.filter((operation) => !operation.callable && !binaryReads.includes(operation));
  return {
    apiVersion: apiCatalog.vodiaApiVersion,
    totalOperations: apiCatalog.totalOperations,
    counts: apiCatalog.counts,
    adminProfile: ADMIN_PROFILE,
    standardWritesAllowed: PROFILE_LEVEL[ADMIN_PROFILE] >= PROFILE_LEVEL.operator,
    elevatedWritesAllowed: PROFILE_LEVEL[ADMIN_PROFILE] >= PROFILE_LEVEL.full || ELEVATED_ENABLED,
    destructiveEnabled: DESTRUCTIVE_ENABLED,
    criticalWritesEnabled: CRITICAL_ENABLED,
    allowedWriteOperationCount: writes.filter((operation) => operationPolicy(operation).allowed).length,
    deniedWriteOperationCount: writes.filter((operation) => !operationPolicy(operation).allowed).length,
    directCallableOperationCount: apiCatalog.operations.filter((operation) => operation.callable).length,
    boundedBinaryReadOperationCount: binaryReads.length,
    intentionallyUnavailableOperationCount: privateBlocked.length,
    totalExposedOperationCount: apiCatalog.operations.filter((operation) => operation.callable).length + binaryReads.length,
    explicitWriteAllowlistEnabled: ALLOWED_WRITE_OPERATIONS.size > 0,
    explicitWriteDenylistCount: BLOCKED_WRITE_OPERATIONS.size,
    maxWriteBodyBytes: MAX_WRITE_BODY_BYTES,
    planTtlMs: PLAN_TTL_MS,
    pcapLimitBytes: PCAP_LIMIT_BYTES,
    learning: learnedRuntimeInfo(),
  };
}

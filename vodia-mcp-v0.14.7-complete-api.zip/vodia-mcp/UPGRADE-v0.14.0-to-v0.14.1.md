# Upgrade Vodia MCP 0.14.0 to 0.14.1

This focused upgrade fixes OAuth Dynamic Client Registration, scope handling,
apply-log privacy, authentication CLI usability, and the single-administrator
learning workflow. It preserves the v0.14.0 OAuth database and existing client
grants.

## Before upgrading

Take an EC2 snapshot and confirm that the installed version is `0.14.0`:

```bash
curl -fsS http://127.0.0.1:3100/health
node -p "require('/opt/vodia-mcp/package.json').version"
```

## Upgrade

After the v0.14.1 ZIP, checksum, and upgrade script are present in the GitHub
download repository:

```bash
cd /tmp
wget -O upgrade-vodia-mcp-v0.14.1.sh \
  https://raw.githubusercontent.com/rebelking/vodia-downloads/main/upgrade-vodia-mcp-v0.14.1.sh
sudo bash upgrade-vodia-mcp-v0.14.1.sh
```

The script verifies the checksum, installs and tests a replacement directory,
backs up the environment, service unit, and authentication database, switches
the application, installs `/usr/local/bin/vodia-mcp-auth`, and runs the health
check. It retains the v0.14.0 application directory for rollback.

## Verify

```bash
curl -fsS http://127.0.0.1:3100/health
node -p "require('/opt/vodia-mcp/package.json').version"
sudo systemctl --no-pager --full status vodia-mcp
sudo vodia-mcp-auth list-users
```

Health and package output must report `0.14.1`.

Test DCR without specifying an authentication method:

```bash
curl -i https://mcp-test.tryvodia.com/register \
  -H 'Content-Type: application/json' \
  --data '{"client_name":"v0.14.1 smoke test","redirect_uris":["https://claude.ai/api/mcp/auth_callback"],"grant_types":["authorization_code","refresh_token"],"response_types":["code"]}'
```

Expected: `201` with `token_endpoint_auth_method` set to
`client_secret_post`, plus a generated secret displayed once.

Confirm the read endpoint challenge advertises its scope:

```bash
curl -i -X POST https://mcp-test.tryvodia.com/mcp
```

Expected: `401` and a `WWW-Authenticate` header containing
`scope="mcp:read"`.

## Authentication CLI examples

```bash
sudo vodia-mcp-auth list-users
sudo vodia-mcp-auth unlock-user --user-id USER_ID
sudo vodia-mcp-auth reset-password --user-id USER_ID
```

The password-reset command prompts without echoing the password and revokes the
user's current grants.

## Rollback note

The upgrade output prints the previous application directory and backup file
paths. v0.14.1 does not require an authentication schema change, so the existing
v0.14.0 database remains compatible. Preserve the printed database backup until
public OAuth testing is complete.

#!/usr/bin/env node

import { AuthService, readAuthConfig } from "./auth.js";

function argument(name, fallback = "") {
  const index = process.argv.indexOf(`--${name}`);
  return index >= 0 ? String(process.argv[index + 1] || "") : fallback;
}

function passwordFromEnvironment() {
  const variable = argument("password-env", "VODIA_BOOTSTRAP_PASSWORD");
  const value = process.env[variable] || "";
  if (!value) throw new Error(`Set ${variable} to the password, then run this command again.`);
  return value;
}

function output(value) {
  process.stdout.write(`${JSON.stringify(value, null, 2)}\n`);
}

const command = process.argv[2];
if (!process.env.DB_PATH) {
  process.stderr.write("Authentication command failed: DB_PATH is not set. Use /usr/local/bin/vodia-mcp-auth on an installed server.\n");
  process.exit(1);
}
const service = new AuthService(readAuthConfig());

try {
  switch (command) {
    case "create-admin":
    case "create-user": {
      const role = command === "create-admin" ? "admin" : argument("role", "viewer");
      output(service.createUser({
        email: argument("email"),
        displayName: argument("name"),
        password: passwordFromEnvironment(),
        role,
      }));
      break;
    }
    case "list-users":
      output(service.listUsers());
      break;
    case "reset-password":
      output(service.resetPassword(argument("user-id"), passwordFromEnvironment()));
      break;
    case "set-role":
      output(service.setUserRole(argument("user-id"), argument("role")));
      break;
    case "enable-user":
      output(service.setUserStatus(argument("user-id"), "active"));
      break;
    case "disable-user":
      output(service.setUserStatus(argument("user-id"), "disabled"));
      break;
    case "unlock-user":
      output(service.unlockUser(argument("user-id")));
      break;
    case "create-pat": {
      const scopes = argument("scopes", "mcp:read").split(",").map((value) => value.trim()).filter(Boolean);
      output(service.createPat(argument("user-id"), argument("name"), scopes));
      break;
    }
    default:
      process.stderr.write("Usage:\n  vodia-mcp-auth create-admin --email EMAIL --name NAME\n  vodia-mcp-auth create-user --email EMAIL --name NAME --role viewer|admin|approver\n  vodia-mcp-auth list-users\n  vodia-mcp-auth reset-password --user-id ID\n  vodia-mcp-auth set-role --user-id ID --role viewer|admin|approver\n  vodia-mcp-auth enable-user|disable-user|unlock-user --user-id ID\n  vodia-mcp-auth create-pat --user-id ID --name NAME --scopes mcp:read,mcp:admin\n");
      process.exitCode = 2;
  }
} catch (error) {
  process.stderr.write(`Authentication command failed: ${error.message || error}\n`);
  process.exitCode = 1;
} finally {
  service.close();
}

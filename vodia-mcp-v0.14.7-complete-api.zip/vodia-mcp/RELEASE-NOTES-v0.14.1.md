# Vodia MCP 0.14.1

Vodia MCP 0.14.1 is a focused OAuth, privacy, and operator-usability maintenance
release for v0.14.0. It retains the 301-operation Vodia 70.3 catalog and all
existing provisioning, button, DID, Park Orbit, live-call, diagnostic, guarded
write, and supervised-learning capabilities.

## Fixed

### Dynamic Client Registration

- `POST /register` without `token_endpoint_auth_method` now returns `201`
  instead of an internal-server error.
- Both `none` and `client_secret_post` are supported and advertised.
- Generated client secrets are returned once and stored only as SHA-256 hashes.
- Client secrets are verified before the SDK token handler runs.
- Unsupported client authentication metadata returns `400
  invalid_client_metadata`.
- Disallowed callback URLs return `400 invalid_redirect_uri`.
- Unexpected registration failures log a server-side stack without logging the
  registration body or secret.
- OAuth request auditing records the original URL path rather than the nested
  router's `/` path.

### OAuth scopes and endpoint binding

- Scope grants are now the intersection of requested scopes, role maximums, and
  resource scopes.
- `invalid_scope` is returned only when that intersection is empty.
- MCP `401` challenges include the endpoint's required `scope` value.
- OAuth tokens remain bound to the exact `/mcp`, `/mcp-admin`, or
  `/mcp-approver` resource that issued them.
- `/mcp` remains strictly read-only.

### Audit privacy

- `vodia_change_applied` no longer sends the complete Vodia response or
  verification object to journald or JSONL audit storage.
- Apply events now contain only user, operation ID, HTTP status, tenant, change
  ID, and changed fields with privacy-filtered before/after values.
- Email addresses, phone/DID values, MAC addresses, credentials, serial/PIN
  values, and long hash-like values are redacted from those field changes.

### Authentication CLI

- Added `/usr/local/bin/vodia-mcp-auth`.
- The wrapper must run as root, loads `/etc/vodia-mcp.env`, drops privileges to
  `vodiamcp` with `setpriv`, and runs `auth-cli.js` against the configured DB.
- Password prompts are hidden and passwords are never placed in command-line
  arguments.
- The wrapper suppresses only Node's `ExperimentalWarning` for `node:sqlite`.
- Duplicate email errors now identify the existing user cleanly instead of
  displaying a raw SQLite constraint error.
- Added `unlock-user --user-id ID`.
- Direct CLI use now fails loudly when `DB_PATH` is unset.

### Single-administrator workflow

- A single authenticated administrator can propose, inspect, and approve a
  supervised-learning operation on `/mcp-admin`.
- The approval-only `/mcp-approver` endpoint remains for compatibility, but a
  separate human approver is not required in this release.
- Approval still does not execute a PBX request. Learned writes still require a
  separate immutable plan and exact apply confirmation.

## Compatibility

- Existing OAuth clients, authorization data, users, and tokens remain in the
  same SQLite database.
- Legacy static tokens continue working while
  `LEGACY_STATIC_TOKEN_ENABLED=true`.
- Existing admin-token dashboard access remains unchanged.
- The upgrade backs up the authentication database before switching versions.
- No invitation flow, per-user tenant scope, MFA, SSO, or separate-approver
  requirement is added in v0.14.1.

## Verification

The release adds HTTP and unit coverage for omitted client authentication
metadata, `client_secret_post`, hashed secret persistence, invalid DCR metadata,
redirect rejection, original-path logging, scope intersection, scoped
challenges, token resource binding, duplicate users, account unlock, missing DB
configuration, the protected wrapper, apply-log privacy, and single-admin
approval. The complete existing regression suite remains required.

# Testing Vodia MCP 0.14.1

Run the packaged suite first:

```bash
cd /opt/vodia-mcp
npm run audit:prod
npm run check
npm test
```

Then verify the deployed service:

```bash
curl -fsS http://127.0.0.1:3100/health
sudo vodia-mcp-auth list-users
curl -i -X POST https://mcp-test.tryvodia.com/mcp
curl -fsS https://mcp-test.tryvodia.com/.well-known/oauth-authorization-server
```

Expected: v0.14.1 with OAuth enabled, a working user list, and a `401`
challenge containing both protected-resource metadata and `scope="mcp:read"`.

## Registration cases

Run each request against `/register`:

1. Omit `token_endpoint_auth_method`: expect `201`,
   `client_secret_post`, and a one-time generated secret.
2. Send `token_endpoint_auth_method: "none"`: expect `201` without a secret.
3. Send `client_secret_post`: expect `201` and a generated secret.
4. Send an unsupported method: expect `400 invalid_client_metadata`.
5. Send an unapproved redirect: expect `400 invalid_redirect_uri`.

Confirm `journalctl -u vodia-mcp` records `path:"/register"`, not `path:"/"`,
and never records a returned client secret.

## Administrator workflow

Connect an administrator to `/mcp-admin`, then confirm that they can:

1. Plan a harmless reversible setting change.
2. Apply it only with the exact confirmation returned by the plan.
3. Propose, inspect, and approve a non-destructive learned operation without
   switching to a separate identity.

Confirm `/mcp` lists no write or apply tools.

## Audit privacy

After the harmless test change:

```bash
sudo journalctl -u vodia-mcp --since '10 minutes ago' --no-pager | \
  grep vodia_change_applied
```

The line may contain operation ID, status, tenant, change ID, and
privacy-filtered changed fields. It must not contain the complete result,
verification object, email address, phone/DID value, MAC, PIN/serial, or hash.

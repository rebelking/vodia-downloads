# Authentication and Authorization Design — v0.14.1

## Endpoint and scope matrix

| MCP endpoint | Required scope | Minimum role | Capability |
| --- | --- | --- | --- |
| `/mcp` | `mcp:read` | Viewer | Strict allowlisted reads only |
| `/mcp-admin` | `mcp:admin` | Administrator | Reads, plans, guarded apply, and reviewed learning approval |
| `/mcp-approver` | `mcp:approve` | Approver or administrator | Optional compatibility approval endpoint |

The requested grant is intersected with the user's maximum role scopes and the
selected resource scopes. An empty intersection returns `invalid_scope`.
Tokens are bound to the exact resource URL that issued them.

## Dynamic clients

- Public clients use `token_endpoint_auth_method=none`.
- When the field is omitted, the MCP SDK generates a secret and the client is
  registered as `client_secret_post`.
- Generated secrets are returned once. SQLite stores only their SHA-256 hashes.
- Before token or revocation handling, the submitted secret is hashed and
  compared in constant time; the SDK receives only the stored hash marker.
- Every redirect must exactly match the configured allowlist or an enabled
  loopback `/callback` URI.

## Identity and safety

OAuth, PAT, and legacy identities continue to include user ID, role, client ID,
scopes, and authentication type in audit context. The same administrator may
plan and apply an operation and may approve a reviewed learning proposal.
Approval alone never calls the PBX. All existing plan expiry, ownership,
single-use, stale-state, destructive, critical-write, and exact-confirmation
controls remain mandatory.

## Deferred

Invitation links, self-service password reset, per-user tenant access, MFA,
SSO, and mandatory separation of duties are not part of v0.14.1.

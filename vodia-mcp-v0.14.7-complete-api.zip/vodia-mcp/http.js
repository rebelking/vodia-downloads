#!/usr/bin/env node

import { timingSafeEqual } from "node:crypto";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import express from "express";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import { mcpAuthRouter } from "@modelcontextprotocol/sdk/server/auth/router.js";
import {
  audit,
  callOperation,
  createVodiaServer,
  getRecentActivity,
  getRuntimeInfo,
} from "./index.js";
import { apiCatalog, retrieveCallPcap } from "./admin.js";
import { CONNECTOR_VERSION } from "./version.js";
import {
  AuthService,
  createMcpAuthMiddleware,
  legacyIdentity,
  protectedResourceMetadata,
  readAuthConfig,
} from "./auth.js";

const projectRoot = dirname(fileURLToPath(import.meta.url));
const port = Number(process.env.PORT || 3100);
const host = process.env.HOST || "127.0.0.1";
const adminToken = process.env.ADMIN_TOKEN || "";
const mcpTokens = (process.env.MCP_BEARER_TOKENS || process.env.MCP_BEARER_TOKEN || "")
  .split(",")
  .map((token) => token.trim())
  .filter(Boolean);
const adminMcpTokens = (process.env.MCP_ADMIN_BEARER_TOKENS || process.env.MCP_ADMIN_BEARER_TOKEN || "")
  .split(",")
  .map((token) => token.trim())
  .filter(Boolean);
const approverMcpTokens = (process.env.MCP_APPROVER_BEARER_TOKENS || process.env.MCP_APPROVER_BEARER_TOKEN || "")
  .split(",")
  .map((token) => token.trim())
  .filter(Boolean);
const adminActor = String(process.env.MCP_ADMIN_ACTOR || "system-admin").trim();
const approverActor = String(process.env.MCP_APPROVER_ACTOR || "human-approver").trim();
const authConfig = readAuthConfig();
const authService = authConfig.enabled ? new AuthService(authConfig) : null;
const authCleanupTimer = authService ? setInterval(() => authService.cleanup(), 60 * 60 * 1000) : null;
authCleanupTimer?.unref();

if (!adminToken || (!authService && mcpTokens.length === 0)) {
  console.error("[vodia-mcp] ADMIN_TOKEN and either OAuth configuration or MCP_BEARER_TOKEN(S) are required in HTTP mode.");
  process.exit(1);
}
if (!Number.isInteger(port) || port < 1 || port > 65535) {
  console.error("[vodia-mcp] PORT must be a valid TCP port.");
  process.exit(1);
}

const app = express();
app.disable("x-powered-by");
app.set("trust proxy", authConfig.trustProxy ? "loopback" : false);
app.use(express.json({ limit: "1mb" }));

function sameSecret(provided, expected) {
  const left = Buffer.from(String(provided || ""));
  const right = Buffer.from(String(expected || ""));
  return left.length === right.length && timingSafeEqual(left, right);
}

function bearer(req) {
  const value = req.get("authorization") || "";
  return value.startsWith("Bearer ") ? value.slice(7) : "";
}

function requireMcpAuth(req, res, next) {
  const supplied = bearer(req);
  if (!mcpTokens.some((token) => sameSecret(supplied, token))) {
    return res.status(401).json({ error: "Valid MCP bearer token required." });
  }
  next();
}

function requireAdminMcpAuth(req, res, next) {
  const supplied = bearer(req);
  if (!adminMcpTokens.some((token) => sameSecret(supplied, token))) {
    return res.status(401).json({ error: "Valid administrator MCP bearer token required." });
  }
  next();
}

function requireApproverMcpAuth(req, res, next) {
  const supplied = bearer(req);
  if (!approverMcpTokens.some((token) => sameSecret(supplied, token))) {
    return res.status(401).json({ error: "Valid learning-approver MCP bearer token required." });
  }
  next();
}

function requireAdmin(req, res, next) {
  if (!sameSecret(bearer(req), adminToken)) {
    return res.status(401).json({ error: "Valid administrator token required." });
  }
  next();
}

if (authService) {
  const publicBase = authConfig.publicBase;
  const issuerUrl = new URL(publicBase);
  const resources = [
    { path: "/mcp", scopes: ["mcp:read"] },
    { path: "/mcp-admin", scopes: ["mcp:read", "mcp:admin"] },
    { path: "/mcp-approver", scopes: ["mcp:read", "mcp:approve"] },
  ];
  const authorizationMetadata = {
    issuer: publicBase,
    authorization_endpoint: `${publicBase}/authorize`,
    token_endpoint: `${publicBase}/token`,
    registration_endpoint: `${publicBase}/register`,
    revocation_endpoint: `${publicBase}/revoke`,
    response_types_supported: ["code"],
    grant_types_supported: ["authorization_code", "refresh_token"],
    code_challenge_methods_supported: ["S256"],
    token_endpoint_auth_methods_supported: ["none", "client_secret_post"],
    scopes_supported: ["mcp:read", "mcp:admin", "mcp:approve"],
  };
  const oauthPaths = new Set(["/authorize", "/token", "/register", "/revoke", "/.well-known/oauth-authorization-server", "/.well-known/oauth-protected-resource", "/.well-known/oauth-protected-resource/mcp", "/.well-known/oauth-protected-resource/mcp-admin", "/.well-known/oauth-protected-resource/mcp-approver"]);
  app.use((req, res, next) => {
    if (!oauthPaths.has(req.path)) return next();
    const started = Date.now();
    res.on("finish", () => {
      audit("oauth_http_request", {
        method: req.method,
        path: String(req.originalUrl || req.path).split("?", 1)[0],
        status: res.statusCode,
        client_id: String(req.body?.client_id || req.query?.client_id || "") || null,
        latency_ms: Date.now() - started,
      });
    });
    next();
  });
  app.get("/.well-known/oauth-authorization-server", (_req, res) => res.json(authorizationMetadata));
  app.get("/.well-known/oauth-protected-resource", (_req, res) => res.json(protectedResourceMetadata(publicBase, "/mcp", ["mcp:read"])));
  for (const resource of resources) {
    app.get(`/.well-known/oauth-protected-resource${resource.path}`, (_req, res) => res.json(protectedResourceMetadata(publicBase, resource.path, resource.scopes)));
  }
  app.post("/token", express.urlencoded({ extended: false }), async (req, res, next) => {
    const clientId = String(req.body?.client_id || "");
    const normalized = clientId ? authService.normalizeClientCredentials(clientId, req.body?.client_secret) : null;
    if (clientId && !normalized) {
      res.setHeader("Cache-Control", "no-store");
      return res.status(401).json({ error: "invalid_client" });
    }
    if (normalized?.sdkSecret) req.body.client_secret = normalized.sdkSecret;
    next();
  });
  app.post("/revoke", express.urlencoded({ extended: false }), (req, _res, next) => {
    const clientId = String(req.body?.client_id || "");
    const normalized = clientId ? authService.normalizeClientCredentials(clientId, req.body?.client_secret) : null;
    if (normalized?.sdkSecret) req.body.client_secret = normalized.sdkSecret;
    next();
  });
  app.use(mcpAuthRouter({
    provider: authService,
    issuerUrl,
    resourceServerUrl: new URL(`${publicBase}/mcp`),
    scopesSupported: authorizationMetadata.scopes_supported,
    resourceName: "Vodia PBX MCP",
  }));
}

app.get("/health", (_req, res) => {
  res.json({ ok: true, service: "vodia-mcp", version: CONNECTOR_VERSION, mode: adminMcpTokens.length ? (approverMcpTokens.length ? "read-only+policy-controlled-full-admin+supervised-learning" : "read-only+policy-controlled-full-admin") : "strict-read-only", oauthEnabled: Boolean(authService) });
});

app.use("/admin", express.static(resolve(projectRoot, "public"), {
  extensions: ["html"],
  index: "index.html",
  maxAge: "5m",
}));
app.get("/", (_req, res) => res.redirect(302, "/admin/"));

app.get("/api/status", requireAdmin, async (_req, res) => {
  const started = Date.now();
  try {
    const result = await callOperation("get_rest_system_status");
    res.json({
      ok: true,
      latencyMs: Date.now() - started,
      runtime: getRuntimeInfo(),
      pbx: result.data,
    });
  } catch (error) {
    res.status(502).json({
      ok: false,
      latencyMs: Date.now() - started,
      runtime: getRuntimeInfo(),
      error: error.message || String(error),
    });
  }
});

app.get("/api/capabilities", requireAdmin, (_req, res) => {
  res.json({
    version: apiCatalog.vodiaApiVersion,
    total: apiCatalog.totalOperations,
    callable: apiCatalog.operations.filter((operation) => operation.callable).length,
    blocked: apiCatalog.operations.filter((operation) => !operation.callable).length,
    counts: apiCatalog.counts,
    operations: apiCatalog.operations.map(({ operationId, method, path, summary, tags, risk, adminTier, callable, blockedReason }) => ({
      operationId,
      method,
      path,
      summary,
      tags,
      risk,
      adminTier,
      callable,
      blockedReason,
    })),
  });
});

app.get("/api/activity", requireAdmin, (req, res) => {
  res.json({ activity: getRecentActivity(req.query.limit) });
});

function requireAuthFeature(_req, res, next) {
  if (!authService) return res.status(503).json({ error: "OAuth user management is not configured." });
  next();
}

app.get("/api/auth/users", requireAdmin, requireAuthFeature, (_req, res) => {
  res.json({ users: authService.listUsers() });
});

app.post("/api/auth/users", requireAdmin, requireAuthFeature, (req, res) => {
  try {
    const user = authService.createUser({ email: req.body?.email, displayName: req.body?.display_name, password: req.body?.password, role: req.body?.role });
    audit("oauth_user_created", { actor: adminActor, user_id: user.id, user: user.email, role: user.role });
    res.status(201).json({ user });
  } catch (error) {
    res.status(400).json({ error: error.message || String(error) });
  }
});

app.post("/api/auth/users/:id/status", requireAdmin, requireAuthFeature, (req, res) => {
  try {
    const user = authService.setUserStatus(req.params.id, String(req.body?.status || ""));
    audit("oauth_user_status_changed", { actor: adminActor, user_id: user.id, user: user.email, status: user.status });
    res.json({ user });
  } catch (error) {
    res.status(400).json({ error: error.message || String(error) });
  }
});

app.post("/api/auth/users/:id/role", requireAdmin, requireAuthFeature, (req, res) => {
  try {
    const user = authService.setUserRole(req.params.id, String(req.body?.role || ""));
    audit("oauth_user_role_changed", { actor: adminActor, user_id: user.id, user: user.email, role: user.role });
    res.json({ user });
  } catch (error) {
    res.status(400).json({ error: error.message || String(error) });
  }
});

app.post("/api/auth/users/:id/password", requireAdmin, requireAuthFeature, (req, res) => {
  try {
    const user = authService.resetPassword(req.params.id, req.body?.password);
    audit("oauth_user_password_reset", { actor: adminActor, user_id: user.id, user: user.email });
    res.json({ user });
  } catch (error) {
    res.status(400).json({ error: error.message || String(error) });
  }
});

app.get("/api/auth/users/:id/apps", requireAdmin, requireAuthFeature, (req, res) => {
  res.json({ apps: authService.listConnectedApps(req.params.id), pats: authService.listPats(req.params.id) });
});

app.post("/api/auth/users/:id/apps/:clientId/revoke", requireAdmin, requireAuthFeature, (req, res) => {
  authService.revokeClientGrant(req.params.id, req.params.clientId);
  audit("oauth_client_grant_revoked", { actor: adminActor, user_id: req.params.id, client_id: req.params.clientId });
  res.json({ ok: true });
});

app.post("/api/auth/users/:id/pats", requireAdmin, requireAuthFeature, (req, res) => {
  try {
    const scopes = Array.isArray(req.body?.scopes) ? req.body.scopes : ["mcp:read"];
    const pat = authService.createPat(req.params.id, req.body?.name, scopes);
    audit("personal_access_token_created", { actor: adminActor, user_id: req.params.id, name: pat.name, scopes: pat.scopes });
    res.status(201).json({ pat, warning: "Copy this token now. It will not be displayed again." });
  } catch (error) {
    res.status(400).json({ error: error.message || String(error) });
  }
});

app.post("/api/auth/users/:id/pats/:clientId/revoke", requireAdmin, requireAuthFeature, (req, res) => {
  authService.revokePat(req.params.id, req.params.clientId);
  audit("personal_access_token_revoked", { actor: adminActor, user_id: req.params.id, client_id: req.params.clientId });
  res.json({ ok: true });
});

app.get("/api/pcap/:callId", requireAdmin, async (req, res) => {
  try {
    const domain = String(req.query.domain || "").trim();
    const callId = String(req.params.callId || "").trim();
    if (!domain || !callId) return res.status(400).json({ error: "Both domain and callId are required." });
    audit("download_call_pcap", { actor: adminActor, domain, call_id: callId });
    const { buffer } = await retrieveCallPcap({ domain, callId, callOperation });
    const safeName = callId.replace(/[^A-Za-z0-9._-]+/g, "_").slice(0, 128) || "call";
    res.setHeader("Content-Type", "application/vnd.tcpdump.pcap");
    res.setHeader("Content-Disposition", `attachment; filename="${safeName}.pcap"`);
    res.setHeader("Cache-Control", "no-store");
    return res.send(buffer);
  } catch (error) {
    return res.status(404).json({ error: error.message || String(error) });
  }
});

async function handleMcp(req, res, accessMode) {
  const fallbackActor = accessMode === "admin" ? adminActor : accessMode === "approver" ? approverActor : "read-user";
  const identity = req.vodiaIdentity || legacyIdentity(accessMode, fallbackActor);
  const actor = identity.auth_type === "legacy" ? fallbackActor : `user:${identity.user_id}`;
  const toolResultLimitBytes = identity.auth_type === "oauth" ? authConfig.oauthToolResultLimit : undefined;
  const server = createVodiaServer({ accessMode, actor, identity, toolResultLimitBytes });
  const transport = new StreamableHTTPServerTransport({ sessionIdGenerator: undefined });
  let cleanedUp = false;
  const cleanup = async () => {
    if (cleanedUp) return;
    cleanedUp = true;
    await transport.close().catch(() => {});
    await server.close().catch(() => {});
  };
  res.on("close", cleanup);
  try {
    await server.connect(transport);
    await transport.handleRequest(req, res, req.body);
  } catch (error) {
    console.error("[vodia-mcp] HTTP request failed:", error);
    if (!res.headersSent) {
      res.status(500).json({
        jsonrpc: "2.0",
        error: { code: -32603, message: "Internal MCP server error" },
        id: null,
      });
    }
    await cleanup();
  }
}

const readAuth = authService ? createMcpAuthMiddleware({ service: authService, accessMode: "read", requiredScope: "mcp:read", resourceUrl: `${authConfig.publicBase}/mcp`, legacyTokens: mcpTokens, legacyActor: "read-user" }) : requireMcpAuth;
const adminAuth = authService ? createMcpAuthMiddleware({ service: authService, accessMode: "admin", requiredScope: "mcp:admin", resourceUrl: `${authConfig.publicBase}/mcp-admin`, legacyTokens: adminMcpTokens, legacyActor: adminActor }) : requireAdminMcpAuth;
const approverAuth = authService ? createMcpAuthMiddleware({ service: authService, accessMode: "approver", requiredScope: "mcp:approve", resourceUrl: `${authConfig.publicBase}/mcp-approver`, legacyTokens: approverMcpTokens, legacyActor: approverActor }) : requireApproverMcpAuth;

app.post("/mcp", readAuth, async (req, res) => handleMcp(req, res, "read"));
app.post("/mcp-admin", adminAuth, async (req, res) => handleMcp(req, res, "admin"));
app.post("/mcp-approver", approverAuth, async (req, res) => handleMcp(req, res, "approver"));

app.all("/mcp", readAuth, (_req, res) => {
  res.status(405).json({
    jsonrpc: "2.0",
    error: { code: -32000, message: "Method not allowed; use POST." },
    id: null,
  });
});

app.all("/mcp-admin", adminAuth, (_req, res) => {
  res.status(405).json({
    jsonrpc: "2.0",
    error: { code: -32000, message: "Method not allowed; use POST." },
    id: null,
  });
});

app.all("/mcp-approver", approverAuth, (_req, res) => {
  res.status(405).json({
    jsonrpc: "2.0",
    error: { code: -32000, message: "Method not allowed; use POST." },
    id: null,
  });
});

app.use((_req, res) => res.status(404).json({ error: "Not found" }));

const listener = app.listen(port, host, () => {
  console.log(`[vodia-mcp] HTTP server listening on http://${host}:${port}`);
});

for (const signal of ["SIGINT", "SIGTERM"]) {
  process.on(signal, () => listener.close(() => {
    if (authCleanupTimer) clearInterval(authCleanupTimer);
    authService?.close();
    process.exit(0);
  }));
}

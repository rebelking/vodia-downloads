# Authentication and Authorization Design — v0.14.0

## Endpoint and scope matrix

| MCP endpoint | Required scope | Minimum role | Existing tools preserved |
| --- | --- | --- | --- |
| `/mcp` | `mcp:read` | viewer | Strict allowlisted reads |
| `/mcp-admin` | `mcp:admin` | admin | Reads, plans, and guarded apply |
| `/mcp-approver` | `mcp:approve` | approver or admin | Supervised-learning approval |

`mcp:admin` is intentionally one coarse endpoint scope in v0.14.0 because v0.13.2 registers plans and apply tools on the same MCP endpoint. A future release may split tool registration into separate plan/apply endpoints or enforce per-tool scopes.

## Identity context

Every authenticated request produces:

```json
{
  "user_id": "immutable UUID or service identity",
  "email": "user@example.com",
  "display_name": "User Name",
  "role": "viewer|admin|approver",
  "client_id": "OAuth client ID or static client label",
  "client": "OAuth client name, PAT name, or legacy-token",
  "scopes": ["mcp:read"],
  "auth_type": "oauth|pat|legacy"
}
```

The stable plan owner is `user:<user_id>`. Audit entries also include the email, role, client ID/name, scopes, and authentication type after secret redaction.

## Authentication priority

1. OAuth access token
2. Personal access token
3. Endpoint-specific legacy static token when migration mode is enabled
4. OAuth 401 challenge

Tokens are accepted only from the `Authorization` header.

## Role grants

| Role | Maximum scopes |
| --- | --- |
| viewer | `mcp:read` |
| approver | `mcp:read mcp:approve` |
| admin | `mcp:read mcp:admin mcp:approve` |

The authorization screen grants only the intersection of requested scopes, the user's role, and the requested MCP resource.

## Compatibility

- Static tokens remain accepted while `LEGACY_STATIC_TOKEN_ENABLED=true`.
- The existing dashboard admin token remains available as a documented break-glass credential.
- Existing endpoint paths and Streamable HTTP transport remain unchanged.
- OAuth resource metadata is published for all three MCP resource paths.
- Existing write policy flags remain authoritative even for an OAuth administrator.


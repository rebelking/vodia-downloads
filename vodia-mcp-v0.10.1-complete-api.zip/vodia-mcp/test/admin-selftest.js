import { apiCatalog } from "../admin.js";
import { parseSipFromPcap, summarizeSipDialog } from "../pcap.js";
import { readFileSync } from "node:fs";

function pcap(messages) {
  const globalHeader = Buffer.alloc(24);
  globalHeader.writeUInt32LE(0xa1b2c3d4, 0);
  globalHeader.writeUInt16LE(2, 4);
  globalHeader.writeUInt16LE(4, 6);
  globalHeader.writeUInt32LE(65535, 16);
  globalHeader.writeUInt32LE(1, 20);
  const records = messages.map((message, index) => {
    const payload = Buffer.from(message, "latin1");
    const header = Buffer.alloc(16);
    header.writeUInt32LE(1_786_200_000 + index, 0);
    header.writeUInt32LE(1000 * index, 4);
    header.writeUInt32LE(payload.length, 8);
    header.writeUInt32LE(payload.length, 12);
    return Buffer.concat([header, payload]);
  });
  return Buffer.concat([globalHeader, ...records]);
}

const capture = pcap([
  "INVITE sip:2037@test.example.com SIP/2.0\r\nCall-ID: abc123\r\nCSeq: 1 INVITE\r\nAuthorization: Digest secret\r\nContent-Length: 0\r\n\r\n",
  "SIP/2.0 486 Busy Here\r\nCall-ID: abc123\r\nCSeq: 1 INVITE\r\nReason: Q.850;cause=17\r\nContent-Length: 0\r\n\r\n",
]);
const messages = parseSipFromPcap(capture, { includeSdp: false });
const summary = summarizeSipDialog(messages);
const installer = readFileSync(new URL("../install-vodia-mcp.sh", import.meta.url), "utf8");
const result = {
  fullCatalogPresent: apiCatalog.totalOperations === 299,
  catalogMethodCounts: apiCatalog.counts.GET === 200 && apiCatalog.counts.POST === 63 && apiCatalog.counts.PUT === 3 && apiCatalog.counts.DELETE === 33,
  broadCallableCoverage: apiCatalog.operations.filter((operation) => operation.callable).length === 283,
  accountLiveCallsCatalogued: apiCatalog.operations.some((operation) => operation.operationId === "get_rest_user_account_calls" && operation.callable),
  actionLikeGetsPolicyGated: apiCatalog.operations.filter((operation) => operation.method === "GET" && operation.risk === "elevated").length === 4,
  installerVersionCheckUsesDefinedDirectory: installer.includes("require('$APP_DIR/package.json').version") && !installer.includes("$INSTALL_DIR"),
  sipMessagesParsed: messages.length === 2,
  sipAuthorizationRedacted: messages[0].raw.includes("Authorization: [REDACTED]") && !messages[0].raw.includes("Digest secret"),
  sipFailureSummarized: summary.finalFailure?.code === 486 && summary.termination === "SIP failure response",
};
console.log(JSON.stringify(result, null, 2));
if (Object.values(result).some((value) => value !== true)) process.exitCode = 1;

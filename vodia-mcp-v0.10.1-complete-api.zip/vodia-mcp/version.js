export const CONNECTOR_VERSION = "0.10.1";

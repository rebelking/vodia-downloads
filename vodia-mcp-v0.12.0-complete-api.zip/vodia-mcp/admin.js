import { createHash, randomUUID } from "node:crypto";
import { readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { z } from "zod";
import { parseSipFromPcap, summarizeSipDialog } from "./pcap.js";
import { CONNECTOR_VERSION } from "./version.js";
import {
  approveLearnedOperation,
  disableLearnedOperation,
  getLearnedOperation,
  learnedRuntimeInfo,
  listLearnedOperations,
  loadApprovedLearnedCatalog,
  materializeLearnedRequest,
  proposeLearnedOperation,
  recordReadTest,
} from "./learned.js";

const projectRoot = dirname(fileURLToPath(import.meta.url));
export const apiCatalog = JSON.parse(readFileSync(resolve(projectRoot, "generated/api-catalog.json"), "utf8"));
const operationsById = new Map(apiCatalog.operations.map((operation) => [operation.operationId, operation]));
for (const operation of loadApprovedLearnedCatalog()) operationsById.set(operation.operationId, operation);
const PBX_URL = String(process.env.VODIA_URL || "").replace(/\/+$/, "");
const PBX_USER = String(process.env.VODIA_USER || "");
const PBX_PASS = String(process.env.VODIA_PASS || "");
const PLAN_TTL_MS = Math.max(60_000, Math.min(Number(process.env.VODIA_CHANGE_PLAN_TTL_MS || 300_000), 900_000));
const PCAP_LIMIT_BYTES = Math.max(100_000, Math.min(Number(process.env.VODIA_PCAP_LIMIT_BYTES || 20_000_000), 100_000_000));
const DESTRUCTIVE_ENABLED = /^true$/i.test(process.env.VODIA_ENABLE_DESTRUCTIVE || "");
const ELEVATED_ENABLED = /^true$/i.test(process.env.VODIA_ENABLE_ELEVATED_WRITES || "");
const CRITICAL_ENABLED = /^true$/i.test(process.env.VODIA_ENABLE_CRITICAL_WRITES || "");
const ADMIN_PROFILE = ["diagnostic", "operator", "full"].includes(String(process.env.VODIA_ADMIN_PROFILE || "operator").toLowerCase())
  ? String(process.env.VODIA_ADMIN_PROFILE || "operator").toLowerCase()
  : "operator";
const MAX_WRITE_BODY_BYTES = Math.max(4_096, Math.min(Number(process.env.VODIA_MAX_WRITE_BODY_BYTES || 262_144), 1_048_576));
const ALLOWED_DOMAINS = new Set(String(process.env.VODIA_ALLOWED_DOMAINS || "").split(",").map((v) => v.trim().toLowerCase()).filter(Boolean));
const ALLOWED_WRITE_OPERATIONS = new Set(String(process.env.VODIA_ALLOWED_WRITE_OPERATIONS || "").split(",").map((v) => v.trim()).filter(Boolean));
const BLOCKED_WRITE_OPERATIONS = new Set(String(process.env.VODIA_BLOCKED_WRITE_OPERATIONS || "").split(",").map((v) => v.trim()).filter(Boolean));
const plans = new Map();

const PROFILE_LEVEL = { diagnostic: 0, operator: 1, full: 2 };

function confirmationFor(operation, pathParams = {}) {
  const critical = operation.adminTier === "critical";
  const destructive = operation.risk === "destructive";
  const verb = critical && destructive ? "DELETE-CRITICAL" : critical ? "APPLY-CRITICAL" : destructive ? "DELETE" : "APPLY";
  const target = tenantFrom(pathParams) || "SYSTEM";
  return `${verb} ${operation.operationId} ON ${target}`;
}

function operationPolicy(operation, { safeWrapper = false } = {}) {
  if (!operation?.callable) return { allowed: false, reason: operation?.blockedReason || "Operation is not callable." };
  if (BLOCKED_WRITE_OPERATIONS.has(operation.operationId)) return { allowed: false, reason: "Operation is denied by VODIA_BLOCKED_WRITE_OPERATIONS." };
  if (ALLOWED_WRITE_OPERATIONS.size && !ALLOWED_WRITE_OPERATIONS.has(operation.operationId)) {
    return { allowed: false, reason: "Operation is outside VODIA_ALLOWED_WRITE_OPERATIONS." };
  }
  if (safeWrapper) return { allowed: true, policy: "dedicated-safe-wrapper" };

  if (operation.adminTier === "critical") {
    if (PROFILE_LEVEL[ADMIN_PROFILE] < PROFILE_LEVEL.full) return { allowed: false, reason: "Critical changes require VODIA_ADMIN_PROFILE=full." };
    if (!CRITICAL_ENABLED) return { allowed: false, reason: "Critical changes require the separate VODIA_ENABLE_CRITICAL_WRITES=true break-glass switch." };
    if (operation.risk === "destructive" && !DESTRUCTIVE_ENABLED) return { allowed: false, reason: "Critical DELETE operations also require VODIA_ENABLE_DESTRUCTIVE=true." };
    return { allowed: true, policy: "break-glass-critical" };
  }
  if (operation.risk === "destructive") {
    if (PROFILE_LEVEL[ADMIN_PROFILE] < PROFILE_LEVEL.full) return { allowed: false, reason: "DELETE operations require VODIA_ADMIN_PROFILE=full." };
    if (!DESTRUCTIVE_ENABLED) return { allowed: false, reason: "DELETE operations require VODIA_ENABLE_DESTRUCTIVE=true." };
    return { allowed: true, policy: "destructive" };
  }
  if (operation.risk === "elevated") {
    if (PROFILE_LEVEL[ADMIN_PROFILE] < PROFILE_LEVEL.full && !ELEVATED_ENABLED) {
      return { allowed: false, reason: "Elevated writes require VODIA_ADMIN_PROFILE=full." };
    }
    return { allowed: true, policy: "full-admin" };
  }
  if (PROFILE_LEVEL[ADMIN_PROFILE] < PROFILE_LEVEL.operator) {
    return { allowed: false, reason: "Configuration writes require VODIA_ADMIN_PROFILE=operator or full." };
  }
  return { allowed: true, policy: "operator" };
}

function validateWriteBody(body) {
  const encoded = JSON.stringify(body ?? {});
  if (Buffer.byteLength(encoded, "utf8") > MAX_WRITE_BODY_BYTES) throw new Error(`Write body exceeds ${MAX_WRITE_BODY_BYTES} bytes.`);
  let nodes = 0;
  const visit = (value, depth = 0) => {
    if (depth > 20) throw new Error("Write body nesting exceeds 20 levels.");
    nodes += 1;
    if (nodes > 20_000) throw new Error("Write body is too complex.");
    if (!value || typeof value !== "object") return;
    for (const [key, child] of Object.entries(value)) {
      if (["__proto__", "prototype", "constructor"].includes(key)) throw new Error(`Unsafe write-body key '${key}'.`);
      visit(child, depth + 1);
    }
  };
  visit(body);
}

function authorization() {
  return `Basic ${Buffer.from(`${PBX_USER}:${PBX_PASS}`, "utf8").toString("base64")}`;
}

function tenantFrom(args = {}) {
  if (args.domain) return String(args.domain).toLowerCase();
  for (const key of ["account", "user", "queue"]) {
    const value = String(args[key] || "");
    if (value.includes("@")) return value.slice(value.lastIndexOf("@") + 1).toLowerCase();
  }
  return null;
}

function enforceTenant(args) {
  const tenant = tenantFrom(args);
  if (ALLOWED_DOMAINS.size && (!tenant || !ALLOWED_DOMAINS.has(tenant))) {
    throw new Error(tenant ? `Tenant '${tenant}' is outside VODIA_ALLOWED_DOMAINS.` : "A tenant-scoped operation is required in restricted mode.");
  }
  return tenant;
}

function buildUrl(operation, pathParams = {}, queryParams = {}) {
  let path = operation.path;
  const required = [...path.matchAll(/\{([^}]+)\}/g)].map((match) => match[1]);
  for (const name of required) {
    const value = pathParams[name];
    if (value === undefined || value === null || String(value).trim() === "") throw new Error(`Missing required path parameter '${name}'.`);
    path = path.replace(`{${name}}`, encodeURIComponent(String(value)));
  }
  const unknown = Object.keys(pathParams).filter((name) => !required.includes(name));
  if (unknown.length) throw new Error(`Unknown path parameter(s): ${unknown.join(", ")}`);
  const allowedQuery = new Set(operation.parameters.filter((p) => p.in === "query").map((p) => p.name));
  const unknownQuery = Object.keys(queryParams).filter((name) => !allowedQuery.has(name));
  if (unknownQuery.length) throw new Error(`Unsupported query parameter(s): ${unknownQuery.join(", ")}`);
  const missingQuery = operation.parameters
    .filter((parameter) => parameter.in === "query" && parameter.required)
    .map((parameter) => parameter.name)
    .filter((name) => queryParams[name] === undefined || queryParams[name] === null || String(queryParams[name]).trim() === "");
  if (missingQuery.length) throw new Error(`Missing required query parameter(s): ${missingQuery.join(", ")}`);
  enforceTenant(pathParams);
  const url = new URL(`${PBX_URL}${path}`);
  for (const [key, value] of Object.entries(queryParams)) if (value !== undefined && value !== null && value !== "") url.searchParams.set(key, String(value));
  return { url, path };
}

async function limitedBuffer(response, limit = PCAP_LIMIT_BYTES) {
  const declared = Number(response.headers.get("content-length") || 0);
  if (declared > limit) throw new Error(`Response is ${declared} bytes; limit is ${limit}.`);
  const buffer = Buffer.from(await response.arrayBuffer());
  if (buffer.length > limit) throw new Error(`Response exceeded ${limit} bytes.`);
  return buffer;
}

export async function retrieveCallPcap({ domain, callId, callOperation }) {
  enforceTenant({ domain });
  const cdr = await callOperation("get_rest_domain_domain_cdr", {
    pathParams: { domain },
    queryParams: { id: callId },
  });
  const rows = Array.isArray(cdr.data) ? cdr.data : [cdr.data];
  if (!rows.length || !rows.some(Boolean)) throw new Error("Call ID was not found in the requested tenant.");
  const pcapOperation = operationsById.get("get_rest_system_pcap");
  const { url } = buildUrl(pcapOperation, {}, { id: callId });
  const response = await fetch(url, {
    headers: {
      Accept: "application/vnd.tcpdump.pcap, application/octet-stream",
      Authorization: authorization(),
      "User-Agent": `vodia-mcp-admin/${CONNECTOR_VERSION}`,
    },
    signal: AbortSignal.timeout(30_000),
  });
  if (!response.ok) throw new Error(`No retained PCAP is available for this call (HTTP ${response.status}).`);
  const buffer = await limitedBuffer(response);
  return { buffer, cdr: rows };
}

async function rawRequest(operation, { pathParams = {}, queryParams = {}, body } = {}) {
  validateWriteBody(body);
  const { url, path } = buildUrl(operation, pathParams, queryParams);
  const response = await fetch(url, {
    method: operation.method,
    headers: {
      Accept: "application/json, text/plain;q=0.9",
      Authorization: authorization(),
      "Content-Type": "application/json",
      "User-Agent": `vodia-mcp-admin/${CONNECTOR_VERSION}`,
    },
    body: operation.method === "GET" || body === undefined ? undefined : JSON.stringify(body),
    signal: AbortSignal.timeout(30_000),
  });
  const text = (await response.text()).slice(0, 2_000_000);
  if (!response.ok) throw new Error(`Vodia API ${operation.method} ${path} returned HTTP ${response.status}: ${text.slice(0, 400)}`);
  let data = {};
  if (text) {
    try { data = JSON.parse(text); } catch { data = { text }; }
  }
  return { data, status: response.status, path };
}

async function rawBinaryRequest(operation, { pathParams = {}, queryParams = {}, limitBytes = 1_000_000 } = {}) {
  const { url, path } = buildUrl(operation, pathParams, queryParams);
  const response = await fetch(url, {
    method: "GET",
    headers: {
      Accept: "application/octet-stream, audio/*, image/*, application/vnd.tcpdump.pcap",
      Authorization: authorization(),
      "User-Agent": `vodia-mcp-admin/${CONNECTOR_VERSION}`,
    },
    signal: AbortSignal.timeout(30_000),
  });
  if (!response.ok) throw new Error(`Vodia API GET ${path} returned HTTP ${response.status}.`);
  const buffer = await limitedBuffer(response, limitBytes);
  return {
    bytes: buffer.length,
    contentType: response.headers.get("content-type") || "application/octet-stream",
    base64: buffer.toString("base64"),
  };
}

async function preimageFor(operation, pathParams, queryParams, callOperation) {
  const reader = apiCatalog.operations.find((candidate) => candidate.method === "GET" && candidate.risk === "read" && candidate.path === operation.path && candidate.callable);
  if (!reader) return { available: false, data: null };
  const allowed = new Set(reader.parameters.filter((p) => p.in === "query").map((p) => p.name));
  const safeQuery = Object.fromEntries(Object.entries(queryParams || {}).filter(([name]) => allowed.has(name)));
  try {
    const result = await callOperation(reader.operationId, { pathParams, queryParams: safeQuery });
    return { available: true, operationId: reader.operationId, data: result.data };
  } catch (error) {
    return { available: false, error: error.message || String(error), data: null };
  }
}

function activeCallRows(data) {
  if (Array.isArray(data)) return data;
  if (Array.isArray(data?.calls)) return data.calls;
  return data && typeof data === "object" ? [data] : [];
}

function activeCallId(call) {
  return String(call?.id ?? call?.call_id ?? call?.callId ?? "");
}

function extensionNumber(record) {
  const alias = Array.isArray(record?.alias) ? record.alias[0] : record?.alias;
  return String(record?.name ?? record?.account ?? record?.extension ?? record?.ext ?? alias ?? "").trim();
}

function normalizeLiveCall(call, account) {
  return {
    account,
    callId: activeCallId(call),
    legId: String(call?.leg_id ?? call?.legId ?? call?.id ?? ""),
    state: call?.state ?? call?.status ?? null,
    held: Boolean(call?.held ?? /hold/i.test(String(call?.state ?? call?.status ?? ""))),
    caller: call?.from ?? call?.caller ?? call?.calling ?? null,
    callee: call?.to ?? call?.callee ?? call?.called ?? call?.remote_party ?? call?.remoteParty ?? null,
    direction: call?.direction ?? call?.dir ?? null,
    durationSeconds: call?.duration ?? call?.duration_seconds ?? call?.durationSeconds ?? null,
    raw: call,
  };
}

function catalogText(value) {
  if (typeof value === "string" || typeof value === "number") return String(value).trim();
  if (!value || typeof value !== "object") return "";
  return String(value.model ?? value.name ?? value.value ?? value.id ?? "").trim();
}

function normalizePhoneCatalog(data) {
  const rows = Array.isArray(data)
    ? data
    : Array.isArray(data?.catalog)
      ? data.catalog
      : Array.isArray(data?.vendors)
        ? data.vendors
        : [];
  return rows.map((row) => {
    const vendor = catalogText(row?.vendor ?? row?.name ?? row?.value);
    const primary = Array.isArray(row?.model) ? row.model : Array.isArray(row?.models) ? row.models : [];
    const bases = Array.isArray(row?.dect?.base) ? row.dect.base : [];
    const handsets = Array.isArray(row?.dect?.handset) ? row.dect.handset : [];
    const models = [...new Set([...primary, ...bases, ...handsets].map(catalogText).filter(Boolean))];
    return {
      vendor,
      models,
      ...(bases.length || handsets.length ? {
        dect: {
          bases: [...new Set(bases.map(catalogText).filter(Boolean))],
          handsets: [...new Set(handsets.map(catalogText).filter(Boolean))],
        },
      } : {}),
    };
  }).filter((row) => row.vendor);
}

async function supportedPhoneCatalog(callOperation, domain) {
  const result = await callOperation("get_rest_domain_domain_button_templates", {
    pathParams: { domain },
    queryParams: { id: "all" },
  });
  const catalog = normalizePhoneCatalog(result.data);
  if (!catalog.length) throw new Error(`The PBX returned no supported phone vendor/model catalog for '${domain}'.`);
  return catalog;
}

function canonicalPhone(catalog, requestedVendor, requestedModel) {
  const vendor = catalog.find((item) => item.vendor.toLowerCase() === String(requestedVendor).trim().toLowerCase());
  if (!vendor) {
    throw new Error(`Unsupported phone vendor '${requestedVendor}'. Call list_supported_phone_models to retrieve the PBX catalog.`);
  }
  const model = vendor.models.find((item) => item.toLowerCase() === String(requestedModel).trim().toLowerCase());
  if (!model) {
    throw new Error(`Model '${requestedModel}' is not supported for vendor '${vendor.vendor}'. Supported models: ${vendor.models.join(", ") || "none returned"}.`);
  }
  return { vendor: vendor.vendor, model };
}

function normalizeMac(value) {
  const mac = String(value || "").replace(/[^0-9a-f]/gi, "").toUpperCase();
  if (!/^[0-9A-F]{12}$/.test(mac)) throw new Error("MAC address must contain exactly 12 hexadecimal characters.");
  return mac;
}

function stateHash(value) {
  return createHash("sha256").update(JSON.stringify(value)).digest("hex");
}

async function findActiveCall(callOperation, account, callId) {
  const result = await callOperation("get_rest_user_account_calls", {
    pathParams: { account },
  });
  const call = activeCallRows(result.data).find((candidate) => activeCallId(candidate) === String(callId));
  return { call: call || null, calls: activeCallRows(result.data) };
}

function planHash(plan) {
  return createHash("sha256").update(JSON.stringify({ operationId: plan.operationId, pathParams: plan.pathParams, queryParams: plan.queryParams, body: plan.body })).digest("hex");
}

async function makePlan({
  operationId,
  pathParams = {},
  queryParams = {},
  body = {},
  reason,
  actor,
  callOperation,
  safeWrapper = false,
  preimageOverride,
  precondition,
  confirmationRequired,
  ttlMs,
}) {
  for (const [id, existing] of plans) if (Date.parse(existing.expiresAt) <= Date.now()) plans.delete(id);
  if (plans.size >= 1000) throw new Error("Too many pending change plans; wait for existing plans to expire.");
  const operation = operationsById.get(operationId);
  if (!operation) throw new Error(`Unknown operation '${operationId}'.`);
  if (operation.method === "GET" && operation.risk === "read") throw new Error("Use the read tools for GET operations.");
  if (!operation.callable) throw new Error(`Operation is blocked: ${operation.blockedReason}`);
  const policy = operationPolicy(operation, { safeWrapper });
  if (!policy.allowed) throw new Error(`Operation is blocked by administrator policy: ${policy.reason}`);
  validateWriteBody(body);
  const tenant = enforceTenant(pathParams);
  const preimage = preimageOverride === undefined
    ? await preimageFor(operation, pathParams, queryParams, callOperation)
    : preimageOverride;
  const changeId = randomUUID();
  const plan = {
    changeId,
    actor,
    operationId,
    method: operation.method,
    path: operation.path,
    risk: operation.risk,
    adminTier: operation.adminTier,
    policy: policy.policy,
    confirmationRequired: confirmationRequired || confirmationFor(operation, pathParams),
    tenant,
    pathParams,
    queryParams,
    body,
    reason,
    preimage,
    precondition: precondition || null,
    createdAt: new Date().toISOString(),
    expiresAt: new Date(Date.now() + Math.max(30_000, Math.min(ttlMs || PLAN_TTL_MS, PLAN_TTL_MS))).toISOString(),
  };
  plan.requestHash = planHash(plan);
  plans.set(changeId, plan);
  return plan;
}

function publicPlan(plan, redactSensitive) {
  return redactSensitive({
    changeId: plan.changeId,
    operationId: plan.operationId,
    method: plan.method,
    path: plan.path,
    risk: plan.risk,
    adminTier: plan.adminTier,
    policy: plan.policy,
    tenant: plan.tenant,
    request: { pathParams: plan.pathParams, queryParams: plan.queryParams, body: plan.body },
    preimage: plan.preimage,
    precondition: plan.precondition,
    reason: plan.reason,
    requestHash: plan.requestHash,
    expiresAt: plan.expiresAt,
    confirmationRequired: plan.confirmationRequired,
  });
}

export function registerAdminTools(server, { audit, success, failure, redactSensitive, callOperation, actor = "system-admin" }) {
  const parameterValue = z.union([z.string().max(4096), z.number(), z.boolean()]);
  const parameterMap = z.record(z.string(), parameterValue);
  const outputSchema = { data: z.any(), meta: z.record(z.string(), z.any()) };
  const writeAnnotations = { readOnlyHint: false, destructiveHint: true, openWorldHint: false };

  server.registerTool("read_vodia_api", {
    title: "Read any documented Vodia JSON API operation",
    description: "Call any catalogued, non-action GET operation by operation ID with strict path/query validation, tenant enforcement, response limits, auditing and secret redaction.",
    inputSchema: { operation_id: z.string().min(1), path_params: parameterMap.optional(), query_params: parameterMap.optional() },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ operation_id, path_params, query_params }) => {
    audit("read_vodia_api", { actor, operation_id, path_params, query_params });
    try {
      const operation = operationsById.get(operation_id);
      if (!operation) throw new Error(`Unknown operation '${operation_id}'.`);
      if (operation.method !== "GET" || operation.risk !== "read" || !operation.callable) {
        throw new Error("This operation is not a direct JSON read. Use plan_vodia_change for action-like GETs or read_vodia_binary for binary GETs.");
      }
      const result = await rawRequest(operation, { pathParams: path_params || {}, queryParams: query_params || {} });
      return success(redactSensitive(result.data), { operationId: operation.operationId, method: operation.method, path: operation.path, status: result.status }, `Read '${operation.operationId}' without changing PBX state.`);
    } catch (error) { return failure(error); }
  });

  server.registerTool("read_vodia_binary", {
    title: "Read a documented Vodia binary resource",
    description: "Retrieve a catalogued binary GET resource such as audio, an image, voicemail media, or PCAP as bounded base64 data. Use only when the binary payload is required.",
    inputSchema: {
      operation_id: z.string().min(1),
      path_params: parameterMap.optional(),
      query_params: parameterMap.optional(),
      max_bytes: z.number().int().min(1_024).max(5_000_000).default(1_000_000),
    },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ operation_id, path_params, query_params, max_bytes }) => {
    audit("read_vodia_binary", { actor, operation_id, path_params, query_params, max_bytes });
    try {
      const operation = operationsById.get(operation_id);
      const binary = operation?.method === "GET" && operation?.risk === "specialized" && /Binary content/i.test(operation?.blockedReason || "");
      if (!binary) throw new Error("The selected operation is not a catalogued binary GET resource.");
      const result = await rawBinaryRequest(operation, { pathParams: path_params || {}, queryParams: query_params || {}, limitBytes: max_bytes });
      return success(result, { operationId: operation.operationId, path: operation.path, encoding: "base64" }, `Retrieved ${result.bytes} bytes from '${operation.operationId}'.`);
    } catch (error) { return failure(error); }
  });

  server.registerTool("list_supported_phone_models", {
    title: "List PBX-supported phone vendors and models",
    description: "Fetch the live vendor/model provisioning catalog used by the Vodia tenant GUI. Use this before provisioning a MAC address; do not guess vendor or model strings.",
    inputSchema: {
      domain: z.string().min(1),
      vendor: z.string().min(1).max(128).optional().describe("Optional vendor filter, case-insensitive, for example Polycom, snom, Fanvil, or Yealink."),
    },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ domain, vendor }) => {
    audit("list_supported_phone_models", { actor, domain, vendor });
    try {
      enforceTenant({ domain });
      const catalog = await supportedPhoneCatalog(callOperation, domain);
      const filtered = vendor
        ? catalog.filter((item) => item.vendor.toLowerCase() === vendor.trim().toLowerCase())
        : catalog;
      if (vendor && !filtered.length) throw new Error(`Vendor '${vendor}' was not found in the live PBX provisioning catalog.`);
      return success(filtered, {
        domain,
        vendorCount: filtered.length,
        modelCount: filtered.reduce((total, item) => total + item.models.length, 0),
        sourceOperationId: "get_rest_domain_domain_button_templates",
      }, "Returned the live vendor/model catalog used by the Vodia provisioning GUI.");
    } catch (error) { return failure(error); }
  });

  server.registerTool("find_extension_across_tenants", {
    title: "Find an extension across all tenants",
    description: "System-administrator inventory search across every visible Vodia tenant.",
    inputSchema: { extension: z.string().min(1).optional(), max_tenants: z.number().int().min(1).max(500).default(100) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ extension, max_tenants }) => {
    audit("find_extension_across_tenants", { actor, extension, max_tenants });
    try {
      const domainsResult = await callOperation("get_rest_system_domains");
      const domains = (Array.isArray(domainsResult.data) ? domainsResult.data : []).map((item) => item.domain || item.name || item.primary || item.primary_dns).filter(Boolean).slice(0, max_tenants);
      const matches = [];
      const errors = [];
      for (const domain of domains) {
        try {
          const result = await callOperation("get_rest_domain_domain_extensions_3", { pathParams: { domain }, queryParams: extension ? { account: extension } : {} });
          const records = Array.isArray(result.data) ? result.data : result.data ? [result.data] : [];
          if (records.length) matches.push({ domain, records });
        } catch (error) { errors.push({ domain, error: error.message || String(error) }); }
      }
      return success(redactSensitive({ matches, errors }), { tenantsChecked: domains.length, tenantsMatched: matches.length }, `Checked ${domains.length} tenants and found matches in ${matches.length}.`);
    } catch (error) { return failure(error); }
  });

  server.registerTool("troubleshoot_dropped_call", {
    title: "Collect dropped-call evidence",
    description: "Collect the tenant CDR, logs, call-quality statistics, trunk statistics, and optional extension evidence for one call.",
    inputSchema: { domain: z.string().min(1), call_id: z.string().min(1).max(256), extension: z.string().min(1).optional() },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ domain, call_id, extension }) => {
    audit("troubleshoot_dropped_call", { actor, domain, call_id, extension });
    enforceTenant({ domain });
    const evidence = {};
    const errors = {};
    const collect = async (name, operationId, args) => {
      try { evidence[name] = (await callOperation(operationId, args)).data; }
      catch (error) { errors[name] = error.message || String(error); }
    };
    await Promise.all([
      collect("cdr", "get_rest_domain_domain_cdr", { pathParams: { domain }, queryParams: { id: call_id } }),
      collect("tenantLog", "get_rest_domain_domain_log", { pathParams: { domain } }),
      collect("tenantStats", "get_rest_domain_domain_stats_6", { pathParams: { domain } }),
      collect("trunkStats", "get_rest_domain_domain_trunk_stats_1", { pathParams: { domain } }),
      ...(extension ? [
        collect("registrationHistory", "get_rest_user_account_reghist", { pathParams: { account: `${extension}@${domain}` } }),
        collect("extensionSyslog", "get_rest_user_account_syslog", { pathParams: { account: `${extension}@${domain}` } }),
      ] : []),
    ]);
    return success(redactSensitive({ evidence, errors }), { domain, callId: call_id, sourcesCollected: Object.keys(evidence), unavailableSources: Object.keys(errors) }, "Collected available dropped-call evidence. Use get_call_sip_trace separately when the CDR indicates a retained PCAP.");
  });

  server.registerTool("find_api_capabilities", {
    title: "Find Vodia API capabilities",
    description: "Search the full official Vodia API catalog, including reads and policy-gated writes.",
    inputSchema: { query: z.string().optional(), method: z.enum(["GET", "POST", "PUT", "PATCH", "DELETE"]).optional(), include_blocked: z.boolean().default(false), limit: z.number().int().min(1).max(100).default(25) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ query, method, include_blocked, limit }) => {
    const words = String(query || "").toLowerCase().split(/\s+/).filter(Boolean);
    const data = apiCatalog.operations.filter((op) => (!method || op.method === method) && (include_blocked || op.callable)).filter((op) => {
      const haystack = `${op.operationId} ${op.path} ${op.summary} ${(op.tags || []).join(" ")}`.toLowerCase();
      return words.every((word) => haystack.includes(word));
    }).slice(0, limit).map((operation) => {
      const policy = operation.method === "GET" ? { allowed: true, policy: "read" } : operationPolicy(operation);
      const { operationId, method: opMethod, path, summary, risk, adminTier, callable, blockedReason, parameters } = operation;
      return { operationId, method: opMethod, path, summary, risk, adminTier, callable, blockedReason, policy, parameters };
    });
    return success(data, { totalOperations: apiCatalog.totalOperations, counts: apiCatalog.counts }, `Found ${data.length} Vodia API capabilities.`);
  });

  server.registerTool("list_learned_operations", {
    title: "List supervised learned operations",
    description: "List proposed, approved, or disabled operation definitions in the persistent MCP learning store. This does not contact or change the PBX.",
    inputSchema: { status: z.enum(["proposed", "approved", "disabled"]).optional() },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ status }) => {
    audit("list_learned_operations", { actor, status });
    try {
      const data = listLearnedOperations({ status });
      return success(data, { returned: data.length, learning: learnedRuntimeInfo() }, `Returned ${data.length} supervised learned operations.`);
    } catch (error) { return failure(error); }
  });

  server.registerTool("inspect_learned_operation", {
    title: "Inspect a supervised learned operation",
    description: "Inspect one learned operation, its evidence, approval state, parameters, and redacted body template.",
    inputSchema: { operation_id: z.string().min(1).max(160) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ operation_id }) => {
    audit("inspect_learned_operation", { actor, operation_id });
    try {
      const data = listLearnedOperations().find((item) => item.id === operation_id || item.operationId === operation_id);
      if (!data) throw new Error(`Learned operation '${operation_id}' was not found.`);
      return success(data, { learning: learnedRuntimeInfo() }, "Returned the learned operation without executing it.");
    } catch (error) { return failure(error); }
  });

  server.registerTool("propose_learned_operation", {
    title: "Propose a supervised Vodia operation",
    description: "Store a proposed Vodia REST operation learned from reviewed portal evidence. This never executes the request and cannot teach DELETE, destructive, arbitrary-URL, or system-write operations.",
    inputSchema: {
      name: z.string().min(3).max(120),
      description: z.string().min(3).max(500),
      method: z.enum(["GET", "POST", "PUT", "PATCH"]),
      path: z.string().min(6).max(500).describe("Relative /rest/... path only; use braces for path parameters, for example /rest/domain/{domain}/feature."),
      path_parameters: z.array(z.string().min(1).max(64)).default([]),
      query_parameters: z.array(z.string().min(1).max(64)).default([]),
      input_parameters: z.array(z.string().min(1).max(64)).default([]).describe("Runtime values used by exact {{parameter}} placeholders in body_template."),
      body_template: z.record(z.string(), z.any()).default({}),
      pbx_version: z.string().min(1).max(64),
      evidence_source: z.string().min(3).max(120).describe("Where the request was observed, for example Vodia admin portal Network log."),
      evidence_note: z.string().min(3).max(1000).describe("What GUI action was observed and the response/result. Do not paste credentials, cookies, tokens, serials, or passwords."),
    },
    outputSchema,
    annotations: { readOnlyHint: false, destructiveHint: false, openWorldHint: false },
  }, async (input) => {
    audit("propose_learned_operation_attempt", { actor, name: input.name, method: input.method, path: input.path, pbx_version: input.pbx_version, evidence_source: input.evidence_source });
    try {
      const data = proposeLearnedOperation(input, actor);
      audit("learned_operation_proposed", { actor, operation_id: data.operationId, method: data.method, path: data.path });
      return success(data, { approvalRequired: true, executed: false }, "Lesson stored as proposed. No PBX request was sent; a separate approver must review it.");
    } catch (error) { return failure(error, "learning"); }
  });

  server.registerTool("test_learned_read", {
    title: "Test a proposed learned read",
    description: "Execute one proposed or approved GET lesson with strict tenant, parameter, URL and response controls. Write lessons cannot be tested through this tool.",
    inputSchema: { operation_id: z.string().min(1).max(160), path_params: parameterMap.optional(), query_params: parameterMap.optional() },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ operation_id, path_params, query_params }) => {
    audit("test_learned_read", { actor, operation_id, path_params, query_params });
    try {
      const learned = getLearnedOperation(operation_id);
      if (learned.method !== "GET") throw new Error("Only learned GET operations can be tested directly. Learned writes must be approved and then planned.");
      const materialized = materializeLearnedRequest(operation_id, { pathParams: path_params || {}, queryParams: query_params || {} }, { requireApproved: false });
      const result = await rawRequest(materialized.catalog, materialized.request);
      recordReadTest(operation_id, actor, { success: true, status: result.status });
      return success(redactSensitive(result.data), { operationId: learned.operationId, status: result.status, proposalStatus: learned.status }, "Tested the learned read without changing PBX state.");
    } catch (error) {
      recordReadTest(operation_id, actor, { success: false });
      return failure(error);
    }
  });

  server.registerTool("run_learned_read", {
    title: "Run an approved learned read",
    description: "Run an approved learned GET operation using its stored path and parameter contract.",
    inputSchema: { operation_id: z.string().min(1).max(160), path_params: parameterMap.optional(), query_params: parameterMap.optional() },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ operation_id, path_params, query_params }) => {
    audit("run_learned_read", { actor, operation_id, path_params, query_params });
    try {
      const materialized = materializeLearnedRequest(operation_id, { pathParams: path_params || {}, queryParams: query_params || {} });
      if (materialized.operation.method !== "GET") throw new Error("Use plan_learned_write for an approved learned write.");
      const result = await rawRequest(materialized.catalog, materialized.request);
      return success(redactSensitive(result.data), { operationId: materialized.operation.operationId, status: result.status }, "Ran the approved learned read without changing PBX state.");
    } catch (error) { return failure(error); }
  });

  server.registerTool("plan_learned_write", {
    title: "Plan an approved learned write",
    description: "Materialize and plan an approved learned POST, PUT, or PATCH operation. This tool never writes to the PBX; apply_vodia_change and its exact confirmation are still required.",
    inputSchema: { operation_id: z.string().min(1).max(160), path_params: parameterMap.optional(), query_params: parameterMap.optional(), inputs: parameterMap.optional(), reason: z.string().min(3).max(500) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ operation_id, path_params, query_params, inputs, reason }) => {
    audit("plan_learned_write", { actor, operation_id, path_params, query_params, inputs, reason });
    try {
      const materialized = materializeLearnedRequest(operation_id, { pathParams: path_params || {}, queryParams: query_params || {}, inputs: inputs || {} });
      if (materialized.operation.method === "GET") throw new Error("Use run_learned_read for an approved learned GET operation.");
      const plan = await makePlan({
        operationId: materialized.operation.operationId,
        ...materialized.request,
        reason,
        actor,
        callOperation,
        preimageOverride: { available: false, data: null, reason: "No reviewed preimage reader is paired with this learned operation." },
      });
      return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt, learned: true }, "Learned write planned. Review the immutable request and use the exact confirmation shown to apply it.");
    } catch (error) { return failure(error, "plan"); }
  });

  server.registerTool("disable_learned_operation", {
    title: "Disable a learned operation",
    description: "Immediately disable a learned operation without deleting its evidence or audit history. This does not contact the PBX.",
    inputSchema: { operation_id: z.string().min(1).max(160), reason: z.string().min(3).max(500) },
    outputSchema,
    annotations: { readOnlyHint: false, destructiveHint: false, openWorldHint: false },
  }, async ({ operation_id, reason }) => {
    audit("disable_learned_operation", { actor, operation_id, reason });
    try {
      const data = disableLearnedOperation(operation_id, actor, reason);
      operationsById.delete(data.operationId);
      return success(data, { disabled: true }, "Learned operation disabled; its evidence and audit history were retained.");
    } catch (error) { return failure(error, "learning"); }
  });

  server.registerTool("plan_vodia_change", {
    title: "Plan a Vodia PBX change",
    description: "Validate and preview a policy-allowed Vodia API write. This tool does not change PBX state.",
    inputSchema: { operation_id: z.string().min(1), path_params: parameterMap.optional(), query_params: parameterMap.optional(), body: z.record(z.string(), z.any()).default({}), reason: z.string().min(3).max(500) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ operation_id, path_params, query_params, body, reason }) => {
    audit("plan_vodia_change", { actor, operation_id, path_params, query_params, body, reason });
    try {
      const plan = await makePlan({ operationId: operation_id, pathParams: path_params || {}, queryParams: query_params || {}, body, reason, actor, callOperation });
      return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt }, "Change planned. Review the exact request and preimage before applying it.");
    } catch (error) { return failure(error, "plan"); }
  });

  async function planActiveCallAction({ account, callId, body, reason, action, confirmation }) {
    const current = await findActiveCall(callOperation, account, callId);
    if (!current.call) throw new Error(`Active call '${callId}' was not found for '${account}'.`);
    return makePlan({
      operationId: "post_rest_user_account_calls",
      pathParams: { account },
      body,
      reason,
      actor,
      callOperation,
      preimageOverride: {
        available: true,
        operationId: "get_rest_user_account_calls",
        data: current.call,
      },
      precondition: {
        type: "active-call-exists",
        account,
        callId: String(callId),
        action,
      },
      confirmationRequired: confirmation,
      ttlMs: 60_000,
    });
  }

  server.registerTool("plan_hangup_call", {
    title: "Plan active-call hangup",
    description: "Plan hanging up one currently active call. The plan expires quickly and validates the stable call id again before applying.",
    inputSchema: { account: z.string().min(3).describe("Account in extension@tenant-domain form"), call_id: z.string().min(1).max(256), reason: z.string().min(3).max(500) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ account, call_id, reason }) => {
    audit("plan_hangup_call", { actor, account, call_id, reason });
    try {
      const plan = await planActiveCallAction({ account, callId: call_id, body: { hangup: call_id }, reason, action: "hangup", confirmation: `HANGUP ${call_id}` });
      return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt }, "Active-call hangup planned. Verify both parties and use the exact confirmation shown.");
    } catch (error) { return failure(error, "plan"); }
  });

  server.registerTool("plan_reject_call", {
    title: "Plan alerting-call rejection",
    description: "Plan rejecting one currently alerting call by stable call id.",
    inputSchema: { account: z.string().min(3).describe("Account in extension@tenant-domain form"), call_id: z.string().min(1).max(256), reason: z.string().min(3).max(500) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ account, call_id, reason }) => {
    audit("plan_reject_call", { actor, account, call_id, reason });
    try {
      const plan = await planActiveCallAction({ account, callId: call_id, body: { reject: call_id }, reason, action: "reject", confirmation: `REJECT ${call_id}` });
      return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt }, "Alerting-call rejection planned.");
    } catch (error) { return failure(error, "plan"); }
  });

  server.registerTool("plan_transfer_call", {
    title: "Plan blind call transfer",
    description: "Plan transferring one active call to a destination number after revalidating its stable call id.",
    inputSchema: { account: z.string().min(3).describe("Account in extension@tenant-domain form"), call_id: z.string().min(1).max(256), destination: z.string().min(1).max(128), reason: z.string().min(3).max(500) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ account, call_id, destination, reason }) => {
    audit("plan_transfer_call", { actor, account, call_id, destination, reason });
    try {
      const plan = await planActiveCallAction({ account, callId: call_id, body: { transfer: call_id, number: destination }, reason, action: "transfer", confirmation: `TRANSFER ${call_id} TO ${destination}` });
      return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt }, "Blind transfer planned. Verify the destination and exact confirmation.");
    } catch (error) { return failure(error, "plan"); }
  });

  for (const definition of [
    { name: "plan_hold_call", title: "Plan call hold", key: "remote-hold", action: "hold", verb: "HOLD" },
    { name: "plan_resume_call", title: "Plan call resume", key: "remote-resume", action: "resume", verb: "RESUME" },
    { name: "plan_answer_call", title: "Plan remote call answer", key: "remote-answer", action: "answer", verb: "ANSWER" },
  ]) {
    server.registerTool(definition.name, {
      title: definition.title,
      description: `${definition.title} for one active call after revalidating its stable call id.`,
      inputSchema: { account: z.string().min(3).describe("Account in extension@tenant-domain form"), call_id: z.string().min(1).max(256), reason: z.string().min(3).max(500) },
      outputSchema,
      annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
    }, async ({ account, call_id, reason }) => {
      audit(definition.name, { actor, account, call_id, reason });
      try {
        const plan = await planActiveCallAction({ account, callId: call_id, body: { [definition.key]: call_id }, reason, action: definition.action, confirmation: `${definition.verb} ${call_id}` });
        return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt }, `${definition.title} prepared.`);
      } catch (error) { return failure(error, "plan"); }
    });
  }

  const accountTypes = ["extensions", "attendants", "conferences", "hunts", "acds", "orbits", "hoots", "srvflags", "ivrnodes", "callingcards", "colines"];
  const nonEmptyChanges = z.record(z.string(), z.any()).refine((value) => Object.keys(value).length > 0, "At least one field must be supplied.");

  server.registerTool("plan_create_account", {
    title: "Plan account creation",
    description: "Plan creation of one or more extensions, auto attendants, conferences, hunt groups, queues, service flags, IVR nodes, calling cards, park orbits, paging accounts, or CO lines.",
    inputSchema: { domain: z.string().min(1), type: z.enum(accountTypes), accounts: z.string().min(1).max(512), reason: z.string().min(3).max(500) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ domain, type, accounts, reason }) => {
    audit("plan_create_account", { actor, domain, type, accounts, reason });
    try {
      if (!/^[A-Za-z0-9*#._/-]+$/.test(accounts)) throw new Error("Account identifiers contain unsupported characters.");
      const body = type === "extensions" ? { type, account_ext: accounts } : { type, account: accounts };
      const plan = await makePlan({ operationId: "post_rest_domain_domain_addacc", pathParams: { domain }, body, reason, actor, callOperation });
      return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt }, "Account creation planned. Review the account type and every requested identifier.");
    } catch (error) { return failure(error, "plan"); }
  });

  server.registerTool("plan_update_account", {
    title: "Plan account configuration update",
    description: "Plan an extension or other account update. Use this for names, permissions, redirection, mailbox, device, and supported account settings.",
    inputSchema: { domain: z.string().min(1), account: z.string().min(1).max(128), changes: nonEmptyChanges, reason: z.string().min(3).max(500) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ domain, account, changes, reason }) => {
    audit("plan_update_account", { actor, domain, account, changes, reason });
    try {
      const plan = await makePlan({ operationId: "post_rest_domain_domain_user_settings_ext", pathParams: { domain, ext: account }, body: changes, reason, actor, callOperation });
      return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt }, "Account configuration update planned.");
    } catch (error) { return failure(error, "plan"); }
  });

  server.registerTool("plan_provision_mac", {
    title: "Plan MAC-address phone provisioning",
    description: "Plan creation or update of a tenant MAC provisioning entry. MAC, extension, vendor, model, proposed SIP transport, T.38 mode and refresh-connection behavior are all mandatory. For Yealink devices, ask for the full device serial number and pass it through Vodia's wire-level pin field for RPS API V2; the last five digits alone are not sufficient. Never guess omitted values. Vendor and model are validated against the live PBX catalog before a plan is created.",
    inputSchema: {
      domain: z.string().min(1),
      mac: z.string().min(12).max(32).describe("Phone MAC address; separators are accepted and removed."),
      extension: z.string().min(1).max(128),
      vendor: z.string().min(1).max(128),
      model: z.string().min(1).max(128),
      name: z.string().max(128).optional(),
      sip_transport: z.enum(["Default", "TLS", "TCP", "UDP"]).describe("Required Proposed SIP transport protocol choice from the Vodia GUI."),
      t38: z.enum(["Default", "On", "Off"]).describe("Required Provision devices to use T.38 for FAX choice from the Vodia GUI."),
      refresh_connection: z.enum(["Automatic", "No", "Yes"]).describe("Required Device will refresh connection choice from the Vodia GUI."),
      serial_number: z.string().trim().min(6).max(128).regex(/^[A-Za-z0-9._-]+$/).optional()
        .describe("Full Yealink serial number. Required when vendor is Yealink; do not submit only the legacy last-five-digit handset challenge."),
      reason: z.string().min(3).max(500),
    },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ domain, mac, extension, vendor, model, name, sip_transport, t38, refresh_connection, serial_number, reason }) => {
    audit("plan_provision_mac", { actor, domain, mac, extension, vendor, model, name, sip_transport, t38, refresh_connection, reason });
    try {
      enforceTenant({ domain });
      const normalizedMac = normalizeMac(mac);
      const catalog = await supportedPhoneCatalog(callOperation, domain);
      const canonical = canonicalPhone(catalog, vendor, model);
      const isYealink = canonical.vendor.toLowerCase() === "yealink";
      if (isYealink && !serial_number) {
        throw new Error("The full Yealink serial number is required for Vodia RPS API V2 provisioning. Ask for the complete serial number, not only the last five digits.");
      }
      if (!isYealink && serial_number) {
        throw new Error("serial_number is only accepted for Yealink provisioning in this workflow.");
      }
      await callOperation("get_rest_domain_domain_user_settings_ext", {
        pathParams: { domain, ext: extension },
      });
      const current = await callOperation("get_rest_domain_domain_macs_1", {
        pathParams: { domain },
        queryParams: { adr: normalizedMac },
      });
      const body = {
        mac: normalizedMac,
        vendor: canonical.vendor,
        model: canonical.model,
        siptrans: { Default: "", TLS: "tls", TCP: "tcp", UDP: "udp" }[sip_transport],
        prov_t38: { Default: "", On: "true", Off: "false" }[t38],
        refresh: { Automatic: "", No: "false", Yes: "true" }[refresh_connection],
        name: name || "",
        extensions: extension,
        // Vodia PBX 69.5.16+ maps the Yealink RPS API V2 serial number to
        // the legacy wire-level `pin` field. Keep the MCP input unambiguous.
        pin: isYealink ? serial_number : "",
      };
      const plan = await makePlan({
        operationId: "post_rest_domain_domain_macs",
        pathParams: { domain },
        body,
        reason,
        actor,
        callOperation,
        preimageOverride: { available: true, operationId: "get_rest_domain_domain_macs_1", data: current.data },
        precondition: { type: "mac-entry-state", domain, mac: normalizedMac, expectedHash: stateHash(current.data) },
      });
      return success(publicPlan(plan, redactSensitive), {
        expiresAt: plan.expiresAt,
        vendorSource: "live-pbx-catalog",
        normalizedMac,
        yealinkSerialRequired: isYealink,
        selections: { sipTransport: sip_transport, t38, refreshConnection: refresh_connection },
      }, isYealink
        ? "Yealink MAC provisioning planned. Vendor/model were validated and the full serial number was mapped to Vodia's redacted pin field for RPS API V2."
        : "MAC provisioning planned. Vendor and model were validated against the live PBX catalog.");
    } catch (error) { return failure(error, "plan"); }
  });

  server.registerTool("plan_update_sip_trunk", {
    title: "Plan SIP trunk update",
    description: "Plan changes to an existing SIP trunk, including its name, registrar, proxy, transport, authentication, codecs, routing, headers, failover, PCAP, and other supported fields.",
    inputSchema: { domain: z.string().min(1), trunk_id: z.union([z.string().min(1).max(128), z.number().int().nonnegative()]), changes: nonEmptyChanges, reason: z.string().min(3).max(500) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ domain, trunk_id, changes, reason }) => {
    audit("plan_update_sip_trunk", { actor, domain, trunk_id, changes, reason });
    try {
      const plan = await makePlan({ operationId: "post_rest_domain_domain_edit_trunk_trunk_id", pathParams: { domain, trunk_id }, body: changes, reason, actor, callOperation });
      return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt }, "SIP trunk update planned. Authentication fields remain redacted in the preview and audit log.");
    } catch (error) { return failure(error, "plan"); }
  });

  server.registerTool("plan_set_sip_trunk_enabled", {
    title: "Plan SIP trunk enable or disable",
    description: "Plan enabling or disabling an existing tenant SIP trunk.",
    inputSchema: { domain: z.string().min(1), trunk_id: z.union([z.string().min(1).max(128), z.number().int().nonnegative()]), enabled: z.boolean(), reason: z.string().min(3).max(500) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ domain, trunk_id, enabled, reason }) => {
    audit("plan_set_sip_trunk_enabled", { actor, domain, trunk_id, enabled, reason });
    try {
      const plan = await makePlan({ operationId: "post_rest_domain_domain_domain_trunks", pathParams: { domain }, queryParams: { trunk: trunk_id }, body: { dis: enabled ? "false" : "true" }, reason, actor, callOperation });
      return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt }, `SIP trunk ${enabled ? "enable" : "disable"} change planned.`);
    } catch (error) { return failure(error, "plan"); }
  });

  server.registerTool("plan_create_dial_plan", {
    title: "Plan dial-plan creation",
    description: "Plan creation of a new empty tenant dial plan. Configure its ordered rules afterward with plan_update_dial_plan.",
    inputSchema: { domain: z.string().min(1), name: z.string().min(1).max(128), reason: z.string().min(3).max(500) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ domain, name, reason }) => {
    audit("plan_create_dial_plan", { actor, domain, name, reason });
    try {
      const current = await callOperation("get_rest_domain_domain_dialplans", { pathParams: { domain } });
      const rows = Array.isArray(current.data) ? current.data : [];
      if (rows.some((row) => String(row?.name || "").toLowerCase() === name.toLowerCase())) {
        throw new Error(`A dial plan named '${name}' already exists in '${domain}'.`);
      }
      const plan = await makePlan({ operationId: "post_rest_domain_domain_dialplans", pathParams: { domain }, body: { name }, reason, actor, callOperation });
      return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt }, "Dial-plan creation planned. The resulting plan will be empty until rules are configured.");
    } catch (error) { return failure(error, "plan"); }
  });

  server.registerTool("plan_update_dial_plan", {
    title: "Plan dial-plan update",
    description: "Plan an update to the selected tenant dial plan, including its ordered routing rules.",
    inputSchema: { domain: z.string().min(1), dialplan_id: z.union([z.string().min(1).max(128), z.number().int().nonnegative()]), changes: nonEmptyChanges, reason: z.string().min(3).max(500) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ domain, dialplan_id, changes, reason }) => {
    audit("plan_update_dial_plan", { actor, domain, dialplan_id, changes, reason });
    try {
      const plan = await makePlan({ operationId: "post_rest_domain_domain_edit_dialplan", pathParams: { domain }, queryParams: { dialplan: dialplan_id }, body: changes, reason, actor, callOperation });
      return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt }, "Dial-plan update planned. Review rule order, patterns, replacements, and trunk assignments.");
    } catch (error) { return failure(error, "plan"); }
  });

  server.registerTool("plan_delete_dial_plan", {
    title: "Plan dial-plan deletion",
    description: "Plan permanent deletion of an unused tenant dial plan. Destructive writes must be explicitly enabled.",
    inputSchema: { domain: z.string().min(1), dialplan_id: z.union([z.string().min(1).max(128), z.number().int().nonnegative()]), reason: z.string().min(3).max(500) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: true, openWorldHint: false },
  }, async ({ domain, dialplan_id, reason }) => {
    audit("plan_delete_dial_plan", { actor, domain, dialplan_id, reason });
    try {
      const plan = await makePlan({ operationId: "delete_rest_domain_domain_dialplans", pathParams: { domain }, queryParams: { id: dialplan_id }, reason, actor, callOperation });
      return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt }, "Dial-plan deletion planned. Vodia will reject deletion if the dial plan is still in use.");
    } catch (error) { return failure(error, "plan"); }
  });

  server.registerTool("plan_update_tenant_settings", {
    title: "Plan tenant settings update",
    description: "Plan a supported tenant-level configuration update.",
    inputSchema: { domain: z.string().min(1), changes: nonEmptyChanges, reason: z.string().min(3).max(500) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ domain, changes, reason }) => {
    audit("plan_update_tenant_settings", { actor, domain, changes, reason });
    try {
      const plan = await makePlan({ operationId: "post_rest_domain_domain_settings", pathParams: { domain }, body: changes, reason, actor, callOperation });
      return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt }, "Tenant settings update planned.");
    } catch (error) { return failure(error, "plan"); }
  });

  server.registerTool("plan_delete_account", {
    title: "Plan account deletion",
    description: "Plan permanent deletion of one tenant account. Requires the destructive policy switch and DELETE confirmation.",
    inputSchema: { domain: z.string().min(1), account: z.string().min(1).max(128), reason: z.string().min(3).max(500) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: true, openWorldHint: false },
  }, async ({ domain, account, reason }) => {
    audit("plan_delete_account", { actor, domain, account, reason });
    try {
      const plan = await makePlan({ operationId: "delete_rest_domain_domain_addacc_ext", pathParams: { domain, ext: account }, body: {}, reason, actor, callOperation });
      return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt }, "Account deletion planned. This action is permanent.");
    } catch (error) { return failure(error, "plan"); }
  });

  server.registerTool("plan_delete_sip_trunk", {
    title: "Plan SIP trunk deletion",
    description: "Plan permanent deletion of one tenant SIP trunk. Requires the destructive policy switch and DELETE confirmation.",
    inputSchema: { domain: z.string().min(1), trunk_id: z.union([z.string().min(1).max(128), z.number().int().nonnegative()]), reason: z.string().min(3).max(500) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: true, openWorldHint: false },
  }, async ({ domain, trunk_id, reason }) => {
    audit("plan_delete_sip_trunk", { actor, domain, trunk_id, reason });
    try {
      const plan = await makePlan({ operationId: "delete_rest_domain_domain_domain_trunks", pathParams: { domain }, queryParams: { trunk: trunk_id }, body: {}, reason, actor, callOperation });
      return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt }, "SIP trunk deletion planned. This action is permanent.");
    } catch (error) { return failure(error, "plan"); }
  });

  server.registerTool("apply_vodia_change", {
    title: "Apply an approved Vodia PBX change",
    description: "Apply an unexpired change plan after explicit confirmation. The body cannot be altered after planning.",
    inputSchema: { change_id: z.string().uuid(), confirmation: z.string().min(1).max(512) },
    outputSchema,
    annotations: writeAnnotations,
  }, async ({ change_id, confirmation }) => {
    const plan = plans.get(change_id);
    audit("apply_vodia_change", { actor, change_id, operation_id: plan?.operationId, reason: plan?.reason });
    try {
      if (!plan) throw new Error("Unknown or already-used change plan.");
      if (Date.parse(plan.expiresAt) <= Date.now()) { plans.delete(change_id); throw new Error("Change plan expired; create a new plan."); }
      if (plan.actor !== actor) throw new Error("Change plan belongs to a different administrator.");
      if (confirmation !== plan.confirmationRequired) throw new Error(`This plan requires confirmation exactly ${plan.confirmationRequired}.`);
      const operation = operationsById.get(plan.operationId);
      if (plan.precondition?.type === "active-call-exists") {
        const current = await findActiveCall(callOperation, plan.precondition.account, plan.precondition.callId);
        if (!current.call) {
          throw new Error(`Active call '${plan.precondition.callId}' no longer exists. Nothing was written; create a new plan from current call state.`);
        }
      } else if (plan.precondition?.type === "mac-entry-state") {
        const current = await callOperation("get_rest_domain_domain_macs_1", {
          pathParams: { domain: plan.precondition.domain },
          queryParams: { adr: plan.precondition.mac },
        });
        if (stateHash(current.data) !== plan.precondition.expectedHash) {
          throw new Error(`MAC provisioning entry '${plan.precondition.mac}' changed after the plan was created. Nothing was written; create and review a new plan.`);
        }
      } else if (plan.preimage?.available) {
        const current = await preimageFor(operation, plan.pathParams, plan.queryParams, callOperation);
        if (!current.available || createHash("sha256").update(JSON.stringify(current.data)).digest("hex") !== createHash("sha256").update(JSON.stringify(plan.preimage.data)).digest("hex")) {
          throw new Error("PBX state changed after the plan was created. Nothing was written; create and review a new plan.");
        }
      }
      const result = await rawRequest(operation, plan);
      if (plan.autoRestoreSeconds && plan.preimage?.available && plan.preimage.data && typeof plan.preimage.data === "object") {
        const source = Array.isArray(plan.preimage.data) ? plan.preimage.data[0] : plan.preimage.data;
        const restoreBody = Object.fromEntries(Object.keys(plan.body).filter((key) => Object.hasOwn(source || {}, key)).map((key) => [key, source[key]]));
        if (Object.keys(restoreBody).length) {
          const timer = setTimeout(async () => {
            try {
              await rawRequest(operation, { pathParams: plan.pathParams, queryParams: plan.queryParams, body: restoreBody });
              audit("temporary_change_restored", { actor: plan.actor, operation_id: plan.operationId, tenant: plan.tenant, reason: plan.reason });
            } catch (error) {
              audit("temporary_change_restore_failed", { actor: plan.actor, operation_id: plan.operationId, error: error.message || String(error) });
            }
          }, plan.autoRestoreSeconds * 1000);
          timer.unref();
        }
      }
      plans.delete(change_id);
      const verification = plan.precondition?.type === "active-call-exists"
        ? await findActiveCall(callOperation, plan.precondition.account, plan.precondition.callId)
          .then(({ call }) => ({ available: true, operationId: "get_rest_user_account_calls", callStillPresent: Boolean(call), data: call }))
          .catch((error) => ({ available: false, error: error.message || String(error), data: null }))
        : plan.precondition?.type === "mac-entry-state"
          ? await callOperation("get_rest_domain_domain_macs_1", {
            pathParams: { domain: plan.precondition.domain },
            queryParams: { adr: plan.precondition.mac },
          }).then((current) => ({ available: true, operationId: "get_rest_domain_domain_macs_1", data: current.data }))
            .catch((error) => ({ available: false, error: error.message || String(error), data: null }))
        : await preimageFor(operation, plan.pathParams, plan.queryParams, callOperation);
      const data = redactSensitive({ operationId: plan.operationId, status: result.status, tenant: plan.tenant, reason: plan.reason, result: result.data, verification });
      audit("vodia_change_applied", data);
      return success(data, { requestHash: plan.requestHash }, "Approved Vodia change applied and verification read attempted.");
    } catch (error) { return failure(error, "write"); }
  });

  server.registerTool("plan_extension_pcap", {
    title: "Plan extension PCAP change",
    description: "Plan enabling or disabling packet capture for one extension. Applying requires a separate explicit confirmation.",
    inputSchema: { domain: z.string().min(1), extension: z.string().min(1), enabled: z.boolean(), reason: z.string().min(3).max(500) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ domain, extension, enabled, reason }) => {
    audit("plan_extension_pcap", { actor, domain, extension, enabled, reason });
    try {
      const plan = await makePlan({ operationId: "post_rest_domain_domain_user_settings_ext", pathParams: { domain, ext: extension }, body: { pcap: enabled ? "true" : "" }, reason, actor, callOperation, safeWrapper: true });
      return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt }, `PCAP ${enabled ? "enable" : "disable"} change planned for the extension.`);
    } catch (error) { return failure(error, "plan"); }
  });

  server.registerTool("plan_trunk_pcap", {
    title: "Plan trunk PCAP change",
    description: "Plan enabling or disabling packet capture for one SIP trunk. Applying requires a separate explicit confirmation.",
    inputSchema: { domain: z.string().min(1), trunk_id: z.union([z.string().min(1), z.number().int().nonnegative()]), enabled: z.boolean(), reason: z.string().min(3).max(500) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ domain, trunk_id, enabled, reason }) => {
    audit("plan_trunk_pcap", { actor, domain, trunk_id, enabled, reason });
    try {
      const plan = await makePlan({ operationId: "post_rest_domain_domain_edit_trunk_trunk_id", pathParams: { domain, trunk_id }, body: { pcap: enabled ? "true" : "" }, reason, actor, callOperation, safeWrapper: true });
      return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt }, `PCAP ${enabled ? "enable" : "disable"} change planned for the trunk.`);
    } catch (error) { return failure(error, "plan"); }
  });

  server.registerTool("plan_sip_trace_logging", {
    title: "Plan temporary SIP trace logging",
    description: "Plan a short-lived PBX SIP dialog trace. Applying requires confirmation; logging automatically restores afterward.",
    inputSchema: { duration_seconds: z.number().int().min(60).max(3600).default(600), sip_level: z.number().int().min(7).max(9).default(9), media_level: z.number().int().min(0).max(9).default(7), include_register: z.boolean().default(false), include_subscribe_notify: z.boolean().default(false), watch_ip: z.string().optional(), reason: z.string().min(3).max(500) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ duration_seconds, sip_level, media_level, include_register, include_subscribe_notify, watch_ip, reason }) => {
    audit("plan_sip_trace_logging", { actor, duration_seconds, sip_level, media_level, include_register, include_subscribe_notify, watch_ip, reason });
    try {
      const body = { log_duration: String(duration_seconds), log_event_sip: String(sip_level), log_event_media: String(media_level), log_sip_dialog: "true", log_sip_register: String(include_register), log_sip_subnot: String(include_subscribe_notify), ...(watch_ip ? { log_sip_watchlist: watch_ip } : {}) };
      const plan = await makePlan({ operationId: "post_rest_system_config", body, reason, actor, callOperation, safeWrapper: true });
      plan.autoRestoreSeconds = duration_seconds;
      return success(publicPlan(plan, redactSensitive), { expiresAt: plan.expiresAt, autoRestoreSeconds: duration_seconds }, "Temporary SIP logging change planned.");
    } catch (error) { return failure(error, "plan"); }
  });

  server.registerTool("get_call_sip_trace", {
    title: "Get a call SIP trace",
    description: "Validate a call against its tenant, retrieve its size-limited PCAP, and return a redacted chronological SIP dialog.",
    inputSchema: { domain: z.string().min(1), call_id: z.string().min(1).max(256), include_sdp: z.boolean().default(false), include_raw_messages: z.boolean().default(false) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ domain, call_id, include_sdp, include_raw_messages }) => {
    audit("get_call_sip_trace", { actor, domain, call_id, include_sdp, include_raw_messages });
    try {
      const { buffer } = await retrieveCallPcap({ domain, callId: call_id, callOperation });
      const messages = parseSipFromPcap(buffer, { includeSdp: include_sdp });
      if (!messages.length) throw new Error("PCAP was retrieved but contained no recognizable SIP messages.");
      const safeMessages = messages.map((message) => include_raw_messages ? message : { timestamp: message.timestamp, startLine: message.startLine, callId: message.callId, cseq: message.cseq, reason: message.reason, userAgent: message.userAgent });
      return success(redactSensitive({ summary: summarizeSipDialog(messages), messages: safeMessages }), { domain, callId: call_id, pcapBytes: buffer.length, redactionApplied: true }, `Retrieved and parsed ${messages.length} SIP messages.`);
    } catch (error) { return failure(error); }
  });
}

export function registerLearningApprovalTools(server, { audit, success, failure, actor = "human-approver" }) {
  const outputSchema = { data: z.any(), meta: z.record(z.string(), z.any()) };

  server.registerTool("list_learning_proposals", {
    title: "List MCP learning proposals",
    description: "List proposed learned operations for independent human review. This does not contact the PBX.",
    inputSchema: {},
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async () => {
    audit("list_learning_proposals", { actor });
    try {
      const data = listLearnedOperations({ status: "proposed" });
      return success(data, { returned: data.length, learning: learnedRuntimeInfo() }, `Returned ${data.length} pending learning proposals.`);
    } catch (error) { return failure(error); }
  });

  server.registerTool("inspect_learning_proposal", {
    title: "Inspect an MCP learning proposal",
    description: "Inspect one proposal and its redacted template and evidence before approval.",
    inputSchema: { operation_id: z.string().min(1).max(160) },
    outputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  }, async ({ operation_id }) => {
    audit("inspect_learning_proposal", { actor, operation_id });
    try {
      const data = listLearnedOperations().find((item) => item.id === operation_id || item.operationId === operation_id);
      if (!data) throw new Error(`Learned operation '${operation_id}' was not found.`);
      return success(data, { executable: false }, "Returned the learning proposal without executing it.");
    } catch (error) { return failure(error); }
  });

  server.registerTool("approve_learned_operation", {
    title: "Approve an MCP learning proposal",
    description: "Approve one non-destructive proposal from the separate approver endpoint. Approval does not execute the operation or apply a PBX change.",
    inputSchema: { operation_id: z.string().min(1).max(160), confirmation: z.string().min(1).max(256) },
    outputSchema,
    annotations: { readOnlyHint: false, destructiveHint: false, openWorldHint: false },
  }, async ({ operation_id, confirmation }) => {
    audit("approve_learned_operation", { actor, operation_id });
    try {
      const proposal = getLearnedOperation(operation_id);
      const required = `APPROVE LEARNING ${proposal.operationId}`;
      if (confirmation !== required) throw new Error(`Approval requires confirmation exactly ${required}.`);
      const data = approveLearnedOperation(operation_id, actor);
      const catalog = loadApprovedLearnedCatalog().find((item) => item.operationId === data.operationId);
      if (!catalog) throw new Error("Approved operation could not be loaded into the runtime catalog.");
      operationsById.set(catalog.operationId, catalog);
      audit("learned_operation_approved", { actor, operation_id: data.operationId, method: data.method, path: data.path });
      return success(data, { executed: false, confirmationRequiredForUse: data.method === "GET" ? null : `APPLY ${data.operationId} ON <tenant>` }, "Learning proposal approved. No PBX request was sent.");
    } catch (error) { return failure(error, "learning approval"); }
  });
}

export function getAdminRuntimeInfo() {
  const writes = apiCatalog.operations.filter((operation) => (operation.method !== "GET" || operation.risk === "elevated") && operation.callable);
  const binaryReads = apiCatalog.operations.filter((operation) => operation.method === "GET" && operation.risk === "specialized" && /Binary content/i.test(operation.blockedReason || ""));
  const privateBlocked = apiCatalog.operations.filter((operation) => !operation.callable && !binaryReads.includes(operation));
  return {
    apiVersion: apiCatalog.vodiaApiVersion,
    totalOperations: apiCatalog.totalOperations,
    counts: apiCatalog.counts,
    adminProfile: ADMIN_PROFILE,
    standardWritesAllowed: PROFILE_LEVEL[ADMIN_PROFILE] >= PROFILE_LEVEL.operator,
    elevatedWritesAllowed: PROFILE_LEVEL[ADMIN_PROFILE] >= PROFILE_LEVEL.full || ELEVATED_ENABLED,
    destructiveEnabled: DESTRUCTIVE_ENABLED,
    criticalWritesEnabled: CRITICAL_ENABLED,
    allowedWriteOperationCount: writes.filter((operation) => operationPolicy(operation).allowed).length,
    deniedWriteOperationCount: writes.filter((operation) => !operationPolicy(operation).allowed).length,
    directCallableOperationCount: apiCatalog.operations.filter((operation) => operation.callable).length,
    boundedBinaryReadOperationCount: binaryReads.length,
    intentionallyUnavailableOperationCount: privateBlocked.length,
    totalExposedOperationCount: apiCatalog.operations.filter((operation) => operation.callable).length + binaryReads.length,
    explicitWriteAllowlistEnabled: ALLOWED_WRITE_OPERATIONS.size > 0,
    explicitWriteDenylistCount: BLOCKED_WRITE_OPERATIONS.size,
    maxWriteBodyBytes: MAX_WRITE_BODY_BYTES,
    planTtlMs: PLAN_TTL_MS,
    pcapLimitBytes: PCAP_LIMIT_BYTES,
    learning: learnedRuntimeInfo(),
  };
}

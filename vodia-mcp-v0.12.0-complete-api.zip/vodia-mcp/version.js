export const CONNECTOR_VERSION = "0.12.0";

#!/usr/bin/env node

/**
 * Vodia PBX MCP Server — policy-controlled full-admin v0.9
 *
 * Exposes the official Vodia v70 OpenAPI GET surface through:
 *   1. Focused, high-value PBX tools for routine support work.
 *   2. A searchable read capability catalog.
 *   3. A universal GET reader restricted to that generated allowlist.
 *
 * The read endpoint registers no write tools. The separate administrator
 * endpoint adds policy-controlled plan/apply tools backed by the REST catalog.
 */

import { appendFileSync, readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { pathToFileURL } from "node:url";
import { fileURLToPath } from "node:url";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";
import { getAdminRuntimeInfo, registerAdminTools, registerLearningApprovalTools } from "./admin.js";
import { CONNECTOR_VERSION } from "./version.js";
import {
  getAwsChimeConfig,
  getAwsChimeVoiceConnector,
  listAwsChimeVoiceConnectors,
  testAwsChimeConnection,
  getAwsChimeTermination,
  getAwsChimeOrigination,
  listAwsChimeTerminationCredentials,
  getAwsChimeTerminationHealth,
  listAwsChimeAvailableRegions,
  recommendAwsChimeRegion,
  planAwsChimeCreateVoiceConnector,
  searchAwsChimeAvailablePhoneNumbers,
  listAwsChimePhoneNumbers,
  getAwsChimePhoneNumber,
  listAwsChimePhoneNumberOrders,
  getAwsChimePhoneNumberOrder,
  planAwsChimeOrderPhoneNumber,
  planAwsChimeAssignPhoneNumber,
  applyAwsChimeChange,

  planAwsChimeSetTerminationCredentials,
  planAwsChimeUpdateTermination,
  planAwsChimeUpdateOrigination,} from "./aws-chime.js";
import { getAiWorkflowCatalog, prepareAiWorkflow } from "./workflow-helper.js";

const projectRoot = dirname(fileURLToPath(import.meta.url));
export const catalog = JSON.parse(
  readFileSync(resolve(projectRoot, "generated/read-catalog.json"), "utf8")
);

const PBX_URL = (process.env.VODIA_URL || "").replace(/\/+$/, "");
const PBX_USER = process.env.VODIA_USER || "";
const PBX_PASS = process.env.VODIA_PASS || "";
const AUDIT_LOG_PATH = String(process.env.VODIA_AUDIT_LOG || "").trim();
const ALLOWED_DOMAINS = new Set(
  String(process.env.VODIA_ALLOWED_DOMAINS || "")
    .split(",")
    .map((domain) => domain.trim().toLowerCase())
    .filter(Boolean)
);
const REQUEST_TIMEOUT_MS = readPositiveInteger("VODIA_TIMEOUT_MS", 30_000, 1_000, 120_000);
const RESPONSE_LIMIT_BYTES = readPositiveInteger(
  "VODIA_RESPONSE_LIMIT_BYTES",
  2_000_000,
  10_000,
  10_000_000
);

if (/^true$/i.test(process.env.VODIA_INSECURE || "")) {
  process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
  console.error("[vodia-mcp] WARNING: TLS certificate verification is disabled (lab use only).");
}

if (!PBX_URL || !PBX_USER || !PBX_PASS) {
  console.error("[vodia-mcp] VODIA_URL, VODIA_USER and VODIA_PASS are required.");
  process.exit(1);
}

const operationsById = new Map(
  catalog.operations.map((operation) => [operation.operationId, operation])
);

export function resolveCatalogOperationId(path, { method = "GET", requiredQueryParams = [] } = {}) {
  const matches = catalog.operations.filter((operation) =>
    operation.path === path &&
    operation.method === method &&
    operation.callable !== false &&
    requiredQueryParams.every((name) =>
      operation.parameters.some((parameter) => parameter.in === "query" && parameter.name === name)
    )
  );
  if (matches.length !== 1) {
    throw new Error(`Expected exactly one callable ${method} catalog operation for ${path}; found ${matches.length}.`);
  }
  return matches[0].operationId;
}

const SYSTEM_STATS_OPERATION_ID = resolveCatalogOperationId("/rest/system/stats", { requiredQueryParams: ["type"] });
const TENANT_STATS_OPERATION_ID = resolveCatalogOperationId("/rest/domain/{domain}/stats", { requiredQueryParams: ["type"] });
const TRUNK_STATS_OPERATION_ID = resolveCatalogOperationId("/rest/domain/{domain}/trunk-stats", { requiredQueryParams: ["type"] });

const parameterValueSchema = z.union([z.string(), z.number(), z.boolean()]);
const parameterMapSchema = z.record(z.string(), parameterValueSchema);
const toolOutputSchema = {
  data: z.any(),
  meta: z.record(z.string(), z.any()),
};

const SENSITIVE_KEY = /(?:^|_)(?:pass(?:word|phrase)?|secret|token|credential|authorization|auth|session|cookie|pin|private_key|api_key|access_key|client_secret|oauth|jwt|csrf)(?:$|_)/i;
const TENANT_SAFE_SYSTEM_READS = new Set([
  "get_rest_system_status",
  "get_rest_system_stats_5",
  "get_rest_system_license",
  "get_rest_system_swupdate",
  "get_rest_system_domains",
]);

function isSensitiveKey(key) {
  const normalized = String(key)
    .replace(/([a-z0-9])([A-Z])/g, "$1_$2")
    .replace(/[^a-z0-9]+/gi, "_");
  return SENSITIVE_KEY.test(normalized);
}

function readPositiveInteger(name, fallback, minimum, maximum) {
  const raw = Number(process.env[name] || fallback);
  if (!Number.isInteger(raw) || raw < minimum || raw > maximum) {
    console.error(
      `[vodia-mcp] ${name} must be an integer from ${minimum} through ${maximum}.`
    );
    process.exit(1);
  }
  return raw;
}

export function redactSensitive(value, depth = 0, context = {}) {
  if (depth > 30) return "[MAX_DEPTH]";
  if (typeof value === "string") {
    if (/-----BEGIN (?:RSA |EC |OPENSSH |ENCRYPTED )?PRIVATE KEY-----|\b(?:Basic|Bearer|Digest)\s+[A-Za-z0-9+/=_:.-]{8,}/i.test(value)) {
      return "[REDACTED]";
    }
    if (/^(?:[0-9a-f]{2}[:-]){5}[0-9a-f]{2}$/i.test(value.trim())) return "[REDACTED_MAC]";
    const ip = value.trim().match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
    if (ip) {
      const [, a, b] = ip.map(Number);
      if (a === 10 || a === 127 || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 169 && b === 254)) {
        return "[REDACTED_PRIVATE_IP]";
      }
    }
    return value;
  }
  if (Array.isArray(value)) return value.map((item) => redactSensitive(item, depth + 1, context));
  if (!value || typeof value !== "object") return value;

  const output = {};
  for (const [key, item] of Object.entries(value)) {
    const normalized = String(key)
      .replace(/([a-z0-9])([A-Z])/g, "$1_$2")
      .replace(/[^a-z0-9]+/gi, "_")
      .toLowerCase();
    const operationSensitive =
      /^(?:mac|macs|mac_address|mac_addresses|license_key|licensekey)$/.test(normalized) ||
      (context.operationId === "get_rest_system_license" && /^(?:key|serial|license_key)$/.test(normalized));
    output[key] = isSensitiveKey(key) || operationSensitive
      ? "[REDACTED]"
      : redactSensitive(item, depth + 1, context);
  }
  return output;
}

export function audit(tool, details = {}) {
  const cleanDetails = redactSensitive(details);
  const eventMode = /apply|change_applied|restore/i.test(tool) ? "write" : /plan/i.test(tool) ? "plan" : "read";
  const event = {
    timestamp: new Date().toISOString(),
    mode: eventMode,
    tool,
    details: cleanDetails,
  };
  recentActivity.unshift(event);
  recentActivity.splice(100);
  console.error(
    `[vodia-mcp][${new Date().toISOString()}][${eventMode}] ${tool} ${JSON.stringify(cleanDetails)}`
  );
  if (AUDIT_LOG_PATH) {
    try {
      appendFileSync(AUDIT_LOG_PATH, `${JSON.stringify(event)}\n`, {
        encoding: "utf8",
        mode: 0o600,
      });
    } catch (error) {
      console.error(`[vodia-mcp] audit log write failed: ${error.message || error}`);
    }
  }
}

const recentActivity = [];

export function getRecentActivity(limit = 25) {
  return recentActivity.slice(0, Math.max(1, Math.min(Number(limit) || 25, 100)));
}

function success(data, meta, message) {
  const structuredContent = { data, meta };
  return {
    structuredContent,
    content: [
      { type: "text", text: message },
      { type: "text", text: JSON.stringify(structuredContent, null, 2) },
    ],
  };
}

export function failure(error, mode = "read") {
  return {
    content: [{ type: "text", text: `Vodia ${mode} failed: ${error.message || error}` }],
    isError: true,
  };
}

async function readLimitedBody(response) {
  const declaredLength = Number(response.headers.get("content-length") || 0);
  if (declaredLength > RESPONSE_LIMIT_BYTES) {
    throw new Error(
      `Response is ${declaredLength} bytes; limit is ${RESPONSE_LIMIT_BYTES} bytes. Narrow the query.`
    );
  }

  if (!response.body) return "";
  const reader = response.body.getReader();
  const chunks = [];
  let total = 0;

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    total += value.byteLength;
    if (total > RESPONSE_LIMIT_BYTES) {
      await reader.cancel();
      throw new Error(
        `Response exceeded ${RESPONSE_LIMIT_BYTES} bytes. Narrow the query or page size.`
      );
    }
    chunks.push(value);
  }

  const joined = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) {
    joined.set(chunk, offset);
    offset += chunk.byteLength;
  }
  return Buffer.from(joined);
}

function buildRequest(operation, pathParams = {}, queryParams = {}) {
  if (!operation) throw new Error("Unknown Vodia read operation.");
  if (operation.method !== "GET") throw new Error("Only GET operations are available.");
  if (!operation.callable) {
    throw new Error(
      `Operation '${operation.operationId}' is blocked: ${operation.blockedReason}`
    );
  }
  if (
    ALLOWED_DOMAINS.size &&
    operation.path.startsWith("/rest/system/") &&
    !TENANT_SAFE_SYSTEM_READS.has(operation.operationId) &&
    operation.path !== "/rest/system/domains/{domain}"
  ) {
    throw new Error(
      `Operation '${operation.operationId}' is unavailable when tenant restrictions are enabled.`
    );
  }

  const requiredPathParameters = [...operation.path.matchAll(/\{([^}]+)\}/g)].map(
    (match) => match[1]
  );
  const suppliedPathParameters = Object.keys(pathParams);
  const unknownPathParameters = suppliedPathParameters.filter(
    (name) => !requiredPathParameters.includes(name)
  );
  if (unknownPathParameters.length) {
    throw new Error(`Unknown path parameter(s): ${unknownPathParameters.join(", ")}`);
  }

  let path = operation.path;
  for (const name of requiredPathParameters) {
    const value = pathParams[name];
    if (value === undefined || value === null || String(value).trim() === "") {
      throw new Error(`Missing required path parameter '${name}'.`);
    }
    enforceTenantValue(name, value);
    path = path.replace(`{${name}}`, encodeURIComponent(String(value)));
  }

  const allowedQueryParameters = new Set(
    operation.parameters
      .filter((parameter) => parameter.in === "query")
      .map((parameter) => parameter.name)
  );
  const unknownQueryParameters = Object.keys(queryParams).filter(
    (name) => !allowedQueryParameters.has(name)
  );
  if (unknownQueryParameters.length) {
    throw new Error(
      `Unsupported query parameter(s) for ${operation.operationId}: ${unknownQueryParameters.join(", ")}`
    );
  }

  const url = new URL(`${PBX_URL}${path}`);
  for (const [name, value] of Object.entries(queryParams)) {
    if (value !== undefined && value !== null && String(value) !== "") {
      enforceTenantValue(name, value);
      url.searchParams.set(name, String(value));
    }
  }

  return { url, path };
}

function enforceTenantValue(name, value) {
  if (!ALLOWED_DOMAINS.size) return;
  const parameter = String(name).toLowerCase();
  let domain = "";
  if (parameter === "domain") domain = String(value).trim().toLowerCase();
  if (parameter === "account" || parameter.endsWith("_account")) {
    const account = String(value).trim();
    const separator = account.lastIndexOf("@");
    if (separator < 1) {
      throw new Error(`'${name}' must use account@domain form when tenant restrictions are enabled.`);
    }
    domain = account.slice(separator + 1).toLowerCase();
  }
  if (domain && !ALLOWED_DOMAINS.has(domain)) {
    throw new Error(`Tenant '${domain}' is outside VODIA_ALLOWED_DOMAINS.`);
  }
}

export async function callOperationRaw(operationId, { pathParams = {}, queryParams = {} } = {}) {
  const operation = operationsById.get(operationId);
  const { url, path } = buildRequest(operation, pathParams, queryParams);
  const authorization = Buffer.from(`${PBX_USER}:${PBX_PASS}`, "utf8").toString("base64");

  const response = await fetch(url, {
    method: "GET",
    headers: {
      Accept: "application/json, text/plain;q=0.9",
      Authorization: `Basic ${authorization}`,
      "User-Agent": `vodia-mcp-readonly/${CONNECTOR_VERSION}`,
    },
    signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
  });

  const body = await readLimitedBody(response);
  const contentType = response.headers.get("content-type") || "application/octet-stream";
  if (!response.ok) {
    const diagnostic = /^text\//i.test(contentType) || /json/i.test(contentType)
      ? body.toString("utf8").slice(0, 400)
      : `[${contentType}; ${body.length} bytes]`;
    throw new Error(`Vodia API GET ${path} returned HTTP ${response.status}: ${diagnostic}`);
  }

  let data;
  if (/json/i.test(contentType)) {
    const text = body.toString("utf8");
    try {
      data = text ? JSON.parse(text) : {};
    } catch {
      throw new Error(`Vodia returned invalid JSON for ${operationId}.`);
    }
  } else if (/^text\//i.test(contentType)) {
    data = { contentType, data: body.toString("utf8") };
  } else {
    data = { contentType, encoding: "base64", data: body.toString("base64") };
  }

  if (operationId === "get_rest_system_domains" && ALLOWED_DOMAINS.size) {
    data = [...ALLOWED_DOMAINS].map((domain) => ({ domain }));
  }

  return {
    data,
    meta: {
      operationId,
      method: "GET",
      path: operation.path,
      summary: operation.summary,
      vodiaApiVersion: catalog.vodiaApiVersion,
    },
  };
}

export async function callOperation(operationId, args = {}) {
  const result = await callOperationRaw(operationId, args);
  const redactedData = redactSensitive(result.data, 0, { operationId });
  return {
    data: redactedData,
    meta: {
      ...result.meta,
      redactionApplied: JSON.stringify(redactedData) !== JSON.stringify(result.data),
    },
  };
}

export function createVodiaServer({ accessMode = "read", actor = "bearer-user", identity = null, toolResultLimitBytes = RESPONSE_LIMIT_BYTES } = {}) {
const adminMode = accessMode === "admin";
const approvalMode = accessMode === "approver";
const auditIdentity = identity ? {
  actor,
  user_id: identity.user_id,
  user: identity.email || identity.display_name || identity.user_id,
  role: identity.role,
  client_id: identity.client_id,
  client: identity.client,
  scopes: identity.scopes,
  auth_type: identity.auth_type,
} : { actor };
const scopedAudit = (tool, details = {}) => audit(
  tool,
  tool === "vodia_change_applied"
    ? { user: auditIdentity.user || actor, ...details }
    : { ...auditIdentity, ...details }
);
const scopedSuccess = (data, meta, message) => {
  const result = success(data, meta, message);
  const bytes = Buffer.byteLength(JSON.stringify(result.structuredContent), "utf8");
  if (bytes <= toolResultLimitBytes) return result;
  return success(
    {
      truncated: true,
      originalBytes: bytes,
      limitBytes: toolResultLimitBytes,
      guidance: "The result is too large for this MCP client. Narrow the query or use an operation's pagination parameters.",
    },
    { ...meta, truncated: true, originalBytes: bytes, limitBytes: toolResultLimitBytes },
    `Vodia returned ${bytes} bytes, exceeding this client's ${toolResultLimitBytes}-byte tool-result limit. Narrow or paginate the request.`
  );
};
const server = new McpServer(
  { name: approvalMode ? "vodia-pbx-learning-approver" : adminMode ? "vodia-pbx-admin" : "vodia-pbx-readonly", version: CONNECTOR_VERSION },
  {
    instructions: (approvalMode
      ? "This separate endpoint reviews and approves supervised MCP learning proposals. Approval never executes a PBX request. Inspect all evidence and the redacted request template before using the exact approval confirmation. "
      : adminMode
      ? "This is the policy-controlled system-administrator endpoint. Use get_account_live_calls or list_tenant_live_calls before any live-call action. Use find_api_capabilities plus read_vodia_api, read_vodia_binary, or plan_vodia_change for the complete documented API surface. Every action or write must be planned, reviewed, and separately applied with the exact confirmation shown in the plan. "
      : "This connector endpoint is strictly read-only. ") +
      "Use focused status and analytics tools first. " +
      "Use find_read_capabilities before read_vodia_resource for less common Vodia data. " +
      "Never claim that a read changed PBX configuration. Sensitive fields are redacted.",
  }
);

function registerPbXReadTool(name, definition, operationId, mapArguments, transformData = (data) => data) {
  server.registerTool(
    name,
    {
      title: definition.title,
      description: definition.description,
      inputSchema: definition.inputSchema,
      outputSchema: toolOutputSchema,
      annotations: {
        readOnlyHint: true,
        destructiveHint: false,
        openWorldHint: false,
      },
    },
    async (args) => {
      scopedAudit(name, args);
      try {
        const result = await callOperation(operationId, mapArguments(args || {}));
        return scopedSuccess(
          transformData(result.data),
          result.meta,
          `${definition.title} completed using read-only Vodia data.`
        );
      } catch (error) {
        return failure(error);
      }
    }
  );
}

registerPbXReadTool(
  "get_system_status",
  {
    title: "Get PBX system status",
    description: "Check Vodia PBX health, version and current system status.",
    inputSchema: {},
  },
  "get_rest_system_status",
  () => ({})
);

registerPbXReadTool(
  "get_system_license",
  {
    title: "Get PBX license status",
    description: "Read Vodia license status and licensed capacity without exposing license secrets.",
    inputSchema: {},
  },
  "get_rest_system_license",
  () => ({})
);

registerPbXReadTool(
  "get_system_stats",
  {
    title: "Get PBX performance statistics",
    description: "Read system performance, registration, call, or quality statistics.",
    inputSchema: { type: z.string().min(1).optional() },
  },
  SYSTEM_STATS_OPERATION_ID,
  ({ type }) => ({ queryParams: type ? { type } : {} })
);

registerPbXReadTool(
  "get_system_audit_log",
  {
    title: "Get PBX administrator change log",
    description: "Read paginated system administrator changes. Unavailable in tenant-restricted mode.",
    inputSchema: {
      page: z.number().int().min(1).default(1),
      size: z.number().int().min(1).max(500).default(100),
      search: z.string().optional(),
    },
  },
  "get_rest_system_changes",
  ({ page, size, search }) => ({
    queryParams: { page, size, ...(search ? { search } : {}) },
  })
);

registerPbXReadTool(
  "list_domains",
  {
    title: "List Vodia tenants",
    description: "List all tenant domains visible to the configured PBX API account.",
    inputSchema: {},
  },
  "get_rest_system_domains",
  () => ({})
);

registerPbXReadTool(
  "list_extensions",
  {
    title: "List tenant extensions",
    description: "List extension accounts in a Vodia tenant or retrieve one extension by account number.",
    inputSchema: {
      domain: z.string().min(1),
      account: z.string().min(1).optional(),
    },
  },
  "get_rest_domain_domain_extensions_3",
  ({ domain, account }) => ({
    pathParams: { domain },
    queryParams: account ? { account } : {},
  })
);

registerPbXReadTool(
  "list_accounts",
  {
    title: "List tenant accounts",
    description: "List all account types visible in a tenant, including extensions and routing accounts.",
    inputSchema: { domain: z.string().min(1) },
  },
  "get_rest_domain_domain_users",
  ({ domain }) => ({ pathParams: { domain } })
);

function normalizeParkOrbits(data) {
  const rows = Array.isArray(data)
    ? data
    : Array.isArray(data?.orbits)
      ? data.orbits
      : Array.isArray(data?.data)
        ? data.data
        : [];
  return rows.map((row) => {
    const calls = Array.isArray(row?.calls) ? row.calls : [];
    const number = String(row?.name ?? row?.number ?? row?.orbit ?? "").trim();
    return {
      number,
      name: String(row?.display ?? row?.description ?? `Park ${number}`).trim(),
      occupied: calls.length > 0,
      calls,
    };
  });
}

registerPbXReadTool(
  "list_park_orbits",
  {
    title: "List tenant park orbits",
    description: "List configured Vodia park-orbit accounts and show whether each orbit currently contains parked calls.",
    inputSchema: {
      domain: z.string().min(1),
      page: z.number().int().min(1).default(1),
      size: z.number().int().min(1).max(500).default(100),
    },
  },
  "get_rest_domain_domain_orbits_1",
  ({ domain, page, size }) => ({
    pathParams: { domain },
    queryParams: { page, size },
  }),
  normalizeParkOrbits
);

registerPbXReadTool(
  "get_live_park_status",
  {
    title: "Get user-visible park orbit status",
    description: "List the park orbits visible to one Vodia user and include the current parked-call occupancy for each orbit.",
    inputSchema: {
      account: z.string().min(3).describe("User account in extension@tenant-domain form"),
    },
  },
  "get_rest_user_account_orbits",
  ({ account }) => ({ pathParams: { account } }),
  normalizeParkOrbits
);

for (const [name, title, description, operationId] of [
  ["list_queues", "List tenant call queues", "List call queues configured in a Vodia tenant.", "get_rest_domain_domain_acds_1"],
  ["list_ring_groups", "List tenant ring groups", "List ring groups configured in a Vodia tenant.", "get_rest_domain_domain_hunts"],
  ["list_auto_attendants", "List tenant auto attendants", "List auto attendants configured in a Vodia tenant.", "get_rest_domain_domain_attendants"],
  ["list_conferences", "List tenant conferences", "List conference rooms configured in a Vodia tenant.", "get_rest_domain_domain_conferences"],
  ["list_service_flags", "List tenant service flags", "List service flags and their current state.", "get_rest_domain_domain_srvflags"],
  ["get_live_extension_status", "Get live extension status", "Get live status for all extensions in a Vodia tenant.", "get_rest_domain_domain_status_extensions"],
  ["get_live_ring_group_status", "Get live ring group status", "Get live ring-group state for a Vodia tenant.", "get_rest_domain_domain_status_hunts"],
  ["get_live_conference_status", "Get live conference status", "Get live conference-room state for a Vodia tenant.", "get_rest_domain_domain_status_conferences"],
]) {
  registerPbXReadTool(
    name,
    { title, description, inputSchema: { domain: z.string().min(1) } },
    operationId,
    ({ domain }) => ({ pathParams: { domain } })
  );
}

registerPbXReadTool(
  "list_registrations",
  {
    title: "List SIP and push registrations",
    description: "Show registered phones, apps and push registrations for a Vodia tenant.",
    inputSchema: { domain: z.string().min(1) },
  },
  "get_rest_domain_domain_registrations",
  ({ domain }) => ({ pathParams: { domain } })
);

registerPbXReadTool(
  "list_trunks",
  {
    title: "List tenant trunks",
    description: "List SIP trunks configured for a Vodia tenant.",
    inputSchema: { domain: z.string().min(1) },
  },
  "get_rest_domain_domain_domain_trunks",
  ({ domain }) => ({ pathParams: { domain } })
);

registerPbXReadTool(
  "list_dialplans",
  {
    title: "List tenant dial plans",
    description: "List dial plans configured for a Vodia tenant.",
    inputSchema: { domain: z.string().min(1) },
  },
  "get_rest_domain_domain_dialplans",
  ({ domain }) => ({ pathParams: { domain } })
);

registerPbXReadTool(
  "get_tenant_cdrs",
  {
    title: "Get tenant CDRs",
    description: "Get a paginated set of tenant call detail records for troubleshooting or charting.",
    inputSchema: {
      domain: z.string().min(1),
      page: z.number().int().min(1).default(1),
      size: z.number().int().min(1).max(500).default(100),
    },
  },
  "get_rest_domain_domain_cdrs_1",
  ({ domain, page, size }) => ({
    pathParams: { domain },
    queryParams: { page, size },
  })
);

registerPbXReadTool(
  "get_specific_cdr",
  {
    title: "Get one tenant CDR",
    description: "Read one call detail record by call ID for tenant-scoped troubleshooting.",
    inputSchema: { domain: z.string().min(1), call_id: z.string().min(1).max(256) },
  },
  "get_rest_domain_domain_cdr",
  ({ domain, call_id }) => ({ pathParams: { domain }, queryParams: { id: call_id } })
);

registerPbXReadTool(
  "get_tenant_log",
  {
    title: "Get tenant PBX log entries",
    description: "Read domain-scoped PBX log entries for call routing, registration, and integration troubleshooting.",
    inputSchema: { domain: z.string().min(1) },
  },
  "get_rest_domain_domain_log",
  ({ domain }) => ({ pathParams: { domain } })
);

registerPbXReadTool(
  "get_extension_syslog",
  {
    title: "Get extension syslog",
    description: "Read PBX syslog messages associated with one extension account.",
    inputSchema: { account: z.string().min(3).describe("Extension in extension@tenant-domain form") },
  },
  "get_rest_user_account_syslog",
  ({ account }) => ({ pathParams: { account } })
);

registerPbXReadTool(
  "get_extension_settings",
  {
    title: "Get extension account settings",
    description: "Read the complete redacted account settings for one extension in a tenant.",
    inputSchema: { domain: z.string().min(1), extension: z.string().min(1) },
  },
  "get_rest_domain_domain_user_settings_ext",
  ({ domain, extension }) => ({ pathParams: { domain, ext: extension } })
);

registerPbXReadTool(
  "get_tenant_audit_log",
  {
    title: "Get tenant administrator change log",
    description: "Read paginated administrator changes for one allowed tenant.",
    inputSchema: {
      domain: z.string().min(1),
      page: z.number().int().min(1).default(1),
      size: z.number().int().min(1).max(500).default(100),
    },
  },
  "get_rest_domain_domain_changes",
  ({ domain, page, size }) => ({
    pathParams: { domain },
    queryParams: { page, size },
  })
);

registerPbXReadTool(
  "get_extension_call_history",
  {
    title: "Get extension call history",
    description: "Read call history for an extension account.",
    inputSchema: {
      account: z.string().min(3).describe("Extension in extension@tenant-domain form"),
    },
  },
  "get_rest_user_account_history",
  ({ account }) => ({ pathParams: { account } })
);

registerPbXReadTool(
  "get_account_live_calls",
  {
    title: "Get active calls for one account",
    description: "Return individual active call legs, call IDs, parties, states and durations for one Vodia account.",
    inputSchema: {
      account: z.string().min(3).describe("Account in extension@tenant-domain form"),
    },
  },
  "get_rest_user_account_calls",
  ({ account }) => ({ pathParams: { account } })
);

function partyAccount(value) {
  const text = String(value ?? "").trim();
  const at = text.match(/(?:^|[<\s"'])([A-Za-z0-9*#_.-]+)@[^>\s]+/);
  if (at) return at[1];
  const simple = text.match(/^([A-Za-z0-9*#_.-]+)$/);
  return simple ? simple[1] : null;
}

function deriveLiveCallDirection(call, tenantExtensions) {
  const caller = partyAccount(call?.from ?? call?.caller ?? call?.calling);
  const callee = partyAccount(call?.to ?? call?.callee ?? call?.called ?? call?.remote_party ?? call?.remoteParty);
  const callerIsLocal = caller ? tenantExtensions.has(caller) : false;
  const calleeIsLocal = callee ? tenantExtensions.has(callee) : false;
  if (callerIsLocal && !calleeIsLocal) return "outbound";
  if (!callerIsLocal && calleeIsLocal) return "inbound";
  if (callerIsLocal && calleeIsLocal) return "internal";
  return call?.direction ?? call?.dir ?? null;
}

function deriveLiveCallDurationSeconds(call) {
  const connect = Number(call?.connect);
  const now = Number(call?.now);
  if (Number.isFinite(connect) && connect > 0 && Number.isFinite(now) && now >= connect) return Math.floor(now - connect);
  const existing = call?.duration ?? call?.duration_seconds ?? call?.durationSeconds;
  return existing ?? null;
}

server.registerTool(
  "list_tenant_live_calls",
  {
    title: "List active calls across a tenant",
    description: "Enumerate tenant extensions, read each account's active call legs, and group matching legs by stable call ID.",
    inputSchema: {
      domain: z.string().min(1),
      max_accounts: z.number().int().min(1).max(1000).default(500),
      concurrency: z.number().int().min(1).max(20).default(8),
    },
    outputSchema: toolOutputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  },
  async ({ domain, max_accounts, concurrency }) => {
    scopedAudit("list_tenant_live_calls", { domain, max_accounts, concurrency });
    try {
      const extensionResult = await callOperation("get_rest_domain_domain_extensions_3", {
        pathParams: { domain },
      });
      const records = Array.isArray(extensionResult.data) ? extensionResult.data : [];
      const extensions = records
        .map((record) => {
          const alias = Array.isArray(record?.alias) ? record.alias[0] : record?.alias;
          return String(record?.name ?? record?.account ?? record?.extension ?? record?.ext ?? alias ?? "").trim();
        })
        .filter(Boolean)
        .slice(0, max_accounts);
      const tenantExtensions = new Set(extensions);
      const legs = [];
      const errors = [];
      for (let offset = 0; offset < extensions.length; offset += concurrency) {
        const batch = extensions.slice(offset, offset + concurrency);
        const results = await Promise.all(batch.map(async (extension) => {
          const account = `${extension}@${domain}`;
          try {
            const result = await callOperation("get_rest_user_account_calls", { pathParams: { account } });
            const calls = Array.isArray(result.data) ? result.data : Array.isArray(result.data?.calls) ? result.data.calls : [];
            return { account, calls };
          } catch (error) {
            return { account, error: error.message || String(error) };
          }
        }));
        for (const result of results) {
          if (result.error) {
            errors.push({ account: result.account, error: result.error });
            continue;
          }
          for (const call of result.calls) {
            legs.push({
              account: result.account,
              callId: String(call?.id ?? call?.call_id ?? call?.callId ?? ""),
              legId: String(call?.leg_id ?? call?.legId ?? call?.id ?? ""),
              state: call?.state ?? call?.status ?? null,
              held: Boolean(call?.held ?? /hold/i.test(String(call?.state ?? call?.status ?? ""))),
              caller: call?.from ?? call?.caller ?? call?.calling ?? null,
              callee: call?.to ?? call?.callee ?? call?.called ?? call?.remote_party ?? call?.remoteParty ?? null,
              direction: deriveLiveCallDirection(call, tenantExtensions),
              durationSeconds: deriveLiveCallDurationSeconds(call),
              raw: call,
            });
          }
        }
      }
      const grouped = new Map();
      for (const leg of legs) {
        const key = leg.callId || `leg:${leg.account}:${leg.legId}`;
        if (!grouped.has(key)) grouped.set(key, { callId: leg.callId || null, legs: [] });
        grouped.get(key).legs.push(leg);
      }
      return scopedSuccess(
        { calls: [...grouped.values()], legs, errors },
        { domain, accountsChecked: extensions.length, activeCallCount: grouped.size, activeLegCount: legs.length, failedAccounts: errors.length },
        `Checked ${extensions.length} accounts and found ${grouped.size} active calls across ${legs.length} legs.`
      );
    } catch (error) {
      return failure(error);
    }
  }
);

registerPbXReadTool(
  "get_extension_registration_history",
  {
    title: "Get extension registration history",
    description: "Read SIP registration history for an extension account.",
    inputSchema: {
      account: z.string().min(3).describe("Extension in extension@tenant-domain form"),
    },
  },
  "get_rest_user_account_reghist",
  ({ account }) => ({ pathParams: { account } })
);

registerPbXReadTool(
  "get_voicemail_metadata",
  {
    title: "Get voicemail metadata",
    description: "Read paginated voicemail metadata only; voicemail audio remains blocked.",
    inputSchema: {
      account: z.string().min(3).describe("Extension in extension@tenant-domain form"),
      page: z.number().int().min(1).default(1),
      size: z.number().int().min(1).max(100).default(25),
      unread_only: z.boolean().default(false),
    },
  },
  "get_rest_user_account_messages_2",
  ({ account, page, size, unread_only }) => ({
    pathParams: { account },
    queryParams: { page, size, api: "2", ...(unread_only ? { filter: "unread" } : {}) },
  })
);

registerPbXReadTool(
  "get_tenant_stats",
  {
    title: "Get tenant call statistics",
    description: "Get tenant call or quality statistics, including MOS data when supported by the PBX.",
    inputSchema: {
      domain: z.string().min(1),
      type: z.string().min(1).optional(),
    },
  },
  TENANT_STATS_OPERATION_ID,
  ({ domain, type }) => ({
    pathParams: { domain },
    queryParams: type ? { type } : {},
  })
);

registerPbXReadTool(
  "get_trunk_stats",
  {
    title: "Get trunk statistics",
    description: "Get call or quality statistics for one or all tenant trunks.",
    inputSchema: {
      domain: z.string().min(1),
      trunk: z.string().min(1).optional(),
      type: z.string().min(1).optional(),
    },
  },
  TRUNK_STATS_OPERATION_ID,
  ({ domain, trunk, type }) => ({
    pathParams: { domain },
    queryParams: {
      ...(trunk ? { trunk } : {}),
      ...(type ? { type } : {}),
    },
  })
);

registerPbXReadTool(
  "get_live_queue_status",
  {
    title: "Get live call queue status",
    description: "Get current Vodia call queue state for a tenant.",
    inputSchema: { domain: z.string().min(1) },
  },
  "get_rest_domain_domain_status_acds",
  ({ domain }) => ({ pathParams: { domain } })
);

registerPbXReadTool(
  "get_queue_stats",
  {
    title: "Get call queue statistics",
    description: "Get statistics for a call queue and timeframe; useful for queue charts.",
    inputSchema: {
      account: z.string().min(1).describe("Queue account, usually queue@tenant-domain"),
      date: z.string().min(1).optional(),
      days: z.number().int().min(1).max(366).optional(),
    },
  },
  "get_rest_acd_account_stat",
  ({ account, date, days }) => ({
    pathParams: { account },
    queryParams: {
      ...(date ? { date } : {}),
      ...(days ? { days } : {}),
    },
  })
);

registerPbXReadTool(
  "get_queue_cdrs",
  {
    title: "Get call queue CDRs",
    description: "Get paginated call records for a Vodia call queue for analysis and charting.",
    inputSchema: {
      account: z.string().min(1).describe("Queue account, usually queue@tenant-domain"),
      page: z.number().int().min(1).default(1),
      size: z.number().int().min(1).max(500).default(100),
    },
  },
  "get_rest_acd_account_cdr_1",
  ({ account, page, size }) => ({
    pathParams: { account },
    queryParams: { page, size },
  })
);

server.registerTool(
  "find_read_capabilities",
  {
    title: "Find Vodia read capabilities",
    description:
      "Search the official Vodia GET capability catalog before using the universal reader.",
    inputSchema: {
      query: z.string().optional(),
      tag: z.string().optional(),
      include_blocked: z.boolean().default(false),
      limit: z.number().int().min(1).max(100).default(25),
    },
    outputSchema: toolOutputSchema,
    annotations: {
      readOnlyHint: true,
      destructiveHint: false,
      openWorldHint: false,
    },
  },
  async ({ query, tag, include_blocked, limit }) => {
    scopedAudit("find_read_capabilities", { query, tag, include_blocked, limit });
    const needles = String(query || "")
      .trim()
      .toLowerCase()
      .split(/\s+/)
      .filter(Boolean);
    const tagNeedle = String(tag || "").trim().toLowerCase();
    const matches = catalog.operations
      .filter((operation) => include_blocked || operation.callable)
      .filter((operation) => {
        if (!needles.length) return true;
        const searchable = [
          operation.operationId,
          operation.path,
          operation.summary,
          ...(operation.tags || []),
        ]
          .join(" ")
          .toLowerCase();
        return needles.every((needle) => searchable.includes(needle));
      })
      .filter((operation) => {
        if (!tagNeedle) return true;
        return (operation.tags || []).some((item) => item.toLowerCase().includes(tagNeedle));
      })
      .slice(0, limit)
      .map((operation) => ({
        operationId: operation.operationId,
        path: operation.path,
        summary: operation.summary,
        tags: operation.tags,
        parameters: operation.parameters,
        callable: operation.callable,
        blockedReason: operation.blockedReason,
      }));

    return scopedSuccess(
      matches,
      {
        totalGetOperations: catalog.totalGetOperations,
        callableOperations: catalog.callableOperations,
        returned: matches.length,
        vodiaApiVersion: catalog.vodiaApiVersion,
      },
      `Found ${matches.length} matching Vodia read capabilities.`
    );
  }
);

server.registerTool(
  "read_vodia_resource",
  {
    title: "Read any allowlisted Vodia resource",
    description:
      "Call an official Vodia GET operation by operation ID. First use find_read_capabilities to obtain the operation ID and valid parameters.",
    inputSchema: {
      operation_id: z.string().min(1),
      path_params: parameterMapSchema.optional(),
      query_params: parameterMapSchema.optional(),
    },
    outputSchema: toolOutputSchema,
    annotations: {
      readOnlyHint: true,
      destructiveHint: false,
      openWorldHint: false,
    },
  },
  async ({ operation_id, path_params, query_params }) => {
    scopedAudit("read_vodia_resource", { operation_id, path_params, query_params });
    try {
      const result = await callOperation(operation_id, {
        pathParams: path_params || {},
        queryParams: query_params || {},
      });
      return scopedSuccess(
        result.data,
        result.meta,
        `Read '${operation_id}' from Vodia without changing PBX state.`
      );
    } catch (error) {
      return failure(error);
    }
  }
);

server.registerTool(
  "aws_chime_test_connection",
  {
    title: "Test Amazon Chime SDK Voice connection",
    description:
      "Verify the AWS identity available to this MCP host and confirm read access to Amazon Chime SDK Voice. Uses the AWS SDK default credential provider chain; on EC2 this can use the instance IAM role without stored access keys.",
    inputSchema: {
      region: z.string().optional().describe("AWS region such as us-east-1 or ap-northeast-1. Defaults to AWS_CHIME_REGION/AWS_REGION."),
    },
    outputSchema: toolOutputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: true },
  },
  async ({ region } = {}) => {
    scopedAudit("aws_chime_test_connection", { region });
    try {
      const data = await testAwsChimeConnection({ region });
      return scopedSuccess(
        data,
        { provider: "AWS", service: "ChimeSDKVoice", operation: "GetCallerIdentity+ListVoiceConnectors" },
        `AWS authentication and Amazon Chime SDK Voice read access succeeded in ${data.region}.`
      );
    } catch (error) {
      return failure(error, "AWS read");
    }
  }
);

server.registerTool(
  "aws_chime_list_voice_connectors",
  {
    title: "List Amazon Chime Voice Connectors",
    description: "List Amazon Chime SDK Voice Connectors in an AWS region. Read-only.",
    inputSchema: {
      region: z.string().optional(),
      max_results: z.number().int().min(1).max(99).default(20),
      next_token: z.string().optional(),
    },
    outputSchema: toolOutputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: true },
  },
  async ({ region, max_results, next_token }) => {
    scopedAudit("aws_chime_list_voice_connectors", { region, max_results });
    try {
      const data = await listAwsChimeVoiceConnectors({ region, maxResults: max_results, nextToken: next_token });
      return scopedSuccess(
        data,
        { provider: "AWS", service: "ChimeSDKVoice", operation: "ListVoiceConnectors" },
        `Returned ${data.voiceConnectors.length} Amazon Chime Voice Connector(s) from ${data.region}.`
      );
    } catch (error) {
      return failure(error, "AWS read");
    }
  }
);

server.registerTool(
  "aws_chime_get_voice_connector",
  {
    title: "Get Amazon Chime Voice Connector",
    description: "Read one Amazon Chime SDK Voice Connector by ID. Read-only.",
    inputSchema: {
      voice_connector_id: z.string().min(1),
      region: z.string().optional(),
    },
    outputSchema: toolOutputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: true },
  },
  async ({ voice_connector_id, region }) => {
    scopedAudit("aws_chime_get_voice_connector", { voice_connector_id, region });
    try {
      const data = await getAwsChimeVoiceConnector({ voiceConnectorId: voice_connector_id, region });
      return scopedSuccess(
        data,
        { provider: "AWS", service: "ChimeSDKVoice", operation: "GetVoiceConnector" },
        `Returned Amazon Chime Voice Connector '${voice_connector_id}'.`
      );
    } catch (error) {
      return failure(error, "AWS read");
    }
  }
);

server.registerTool(
  "aws_chime_get_termination",
  {
    title: "Get Amazon Chime Voice Connector termination",
    description: "Read outbound/termination settings including calling regions, allowed CIDRs, CPS limit and default phone number.",
    inputSchema: { voice_connector_id: z.string().min(1), region: z.string().optional() },
    outputSchema: toolOutputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: true },
  },
  async ({ voice_connector_id, region }) => {
    scopedAudit("aws_chime_get_termination", { voice_connector_id, region });
    try {
      const data = await getAwsChimeTermination({ voiceConnectorId: voice_connector_id, region });
      return scopedSuccess(data, { provider: "AWS", service: "ChimeSDKVoice", operation: "GetVoiceConnectorTermination" },
        `Returned termination settings for '${voice_connector_id}'.`);
    } catch (error) { return failure(error, "AWS read"); }
  }
);

server.registerTool(
  "aws_chime_get_origination",
  {
    title: "Get Amazon Chime Voice Connector origination",
    description: "Read inbound/origination routes for one Amazon Chime SDK Voice Connector.",
    inputSchema: { voice_connector_id: z.string().min(1), region: z.string().optional() },
    outputSchema: toolOutputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: true },
  },
  async ({ voice_connector_id, region }) => {
    scopedAudit("aws_chime_get_origination", { voice_connector_id, region });
    try {
      const data = await getAwsChimeOrigination({ voiceConnectorId: voice_connector_id, region });
      return scopedSuccess(data, { provider: "AWS", service: "ChimeSDKVoice", operation: "GetVoiceConnectorOrigination" },
        `Returned origination settings for '${voice_connector_id}'.`);
    } catch (error) { return failure(error, "AWS read"); }
  }
);

server.registerTool(
  "aws_chime_list_termination_credentials",
  {
    title: "List Amazon Chime termination credential usernames",
    description: "List termination credential usernames. AWS does not return stored SIP passwords.",
    inputSchema: { voice_connector_id: z.string().min(1), region: z.string().optional() },
    outputSchema: toolOutputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: true },
  },
  async ({ voice_connector_id, region }) => {
    scopedAudit("aws_chime_list_termination_credentials", { voice_connector_id, region });
    try {
      const data = await listAwsChimeTerminationCredentials({ voiceConnectorId: voice_connector_id, region });
      return scopedSuccess(data, { provider: "AWS", service: "ChimeSDKVoice", operation: "ListVoiceConnectorTerminationCredentials" },
        `Returned termination credential usernames for '${voice_connector_id}'.`);
    } catch (error) { return failure(error, "AWS read"); }
  }
);

server.registerTool(
  "aws_chime_get_termination_health",
  {
    title: "Get Amazon Chime termination health",
    description: "Read termination health information for a Voice Connector.",
    inputSchema: { voice_connector_id: z.string().min(1), region: z.string().optional() },
    outputSchema: toolOutputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: true },
  },
  async ({ voice_connector_id, region }) => {
    scopedAudit("aws_chime_get_termination_health", { voice_connector_id, region });
    try {
      const data = await getAwsChimeTerminationHealth({ voiceConnectorId: voice_connector_id, region });
      return scopedSuccess(data, { provider: "AWS", service: "ChimeSDKVoice", operation: "GetVoiceConnectorTerminationHealth" },
        `Returned termination health for '${voice_connector_id}'.`);
    } catch (error) { return failure(error, "AWS read"); }
  }
);

server.registerTool(
  "aws_chime_list_available_regions",
  {
    title: "List available Amazon Chime Voice Connector regions",
    description: "Ask AWS for Voice Connector regions available to the account.",
    inputSchema: { region: z.string().optional() },
    outputSchema: toolOutputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: true },
  },
  async ({ region } = {}) => {
    scopedAudit("aws_chime_list_available_regions", { region });
    try {
      const data = await listAwsChimeAvailableRegions({ region });
      return scopedSuccess(data, { provider: "AWS", service: "ChimeSDKVoice", operation: "ListAvailableVoiceConnectorRegions" },
        "Returned available Amazon Chime Voice Connector regions.");
    } catch (error) { return failure(error, "AWS read"); }
  }
);

server.registerTool(
  "aws_chime_recommend_region",
  {
    title: "Recommend Amazon Chime Voice Connector region",
    description: "Recommend a Voice Connector region from a deployment country and validate it against AWS live availability.",
    inputSchema: { country: z.string().min(2), region: z.string().optional() },
    outputSchema: toolOutputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: true },
  },
  async ({ country, region }) => {
    scopedAudit("aws_chime_recommend_region", { country, region });
    try {
      const data = await recommendAwsChimeRegion({ country, region });
      return scopedSuccess(data, { provider: "AWS", service: "ChimeSDKVoice", operation: "ListAvailableVoiceConnectorRegions" },
        `Recommended ${data.recommendedRegion} for ${data.countryCode}.`);
    } catch (error) { return failure(error, "AWS read"); }
  }
);


server.registerTool(
  "aws_chime_search_available_phone_numbers",
  {
    title: "Search available Amazon Chime phone numbers",
    description: "Search the live Amazon Chime SDK Voice number pool. Read-only.",
    inputSchema: {
      area_code: z.string().optional(),
      city: z.string().optional(),
      state: z.string().optional(),
      country: z.string().default("US"),
      phone_number_type: z.enum(["Local", "TollFree"]).default("Local"),
      max_results: z.number().int().min(1).max(500).default(20),
      region: z.string().optional(),
    },
    outputSchema: toolOutputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: true },
  },
  async ({ area_code, city, state, country, phone_number_type, max_results, region }) => {
    scopedAudit("aws_chime_search_available_phone_numbers", { area_code, city, state, country, phone_number_type, max_results, region });
    try {
      const data = await searchAwsChimeAvailablePhoneNumbers({ areaCode: area_code, city, state, country, phoneNumberType: phone_number_type, maxResults: max_results, region });
      return scopedSuccess(data, { provider: "AWS", service: "ChimeSDKVoice", operation: "SearchAvailablePhoneNumbers" },
        `Returned ${data.phoneNumbers.length} available Amazon Chime phone numbers.`);
    } catch (error) { return failure(error, "AWS read"); }
  }
);

server.registerTool(
  "aws_chime_list_phone_numbers",
  {
    title: "List Amazon Chime phone number inventory",
    description: "List phone numbers already in the AWS account inventory.",
    inputSchema: { region: z.string().optional(), max_results: z.number().int().min(1).max(99).default(20), next_token: z.string().optional() },
    outputSchema: toolOutputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: true },
  },
  async ({ region, max_results, next_token }) => {
    scopedAudit("aws_chime_list_phone_numbers", { region, max_results });
    try {
      const data = await listAwsChimePhoneNumbers({ region, maxResults: max_results, nextToken: next_token });
      return scopedSuccess(data, { provider: "AWS", service: "ChimeSDKVoice", operation: "ListPhoneNumbers" },
        `Returned ${data.phoneNumbers.length} Amazon Chime phone numbers.`);
    } catch (error) { return failure(error, "AWS read"); }
  }
);

server.registerTool(
  "aws_chime_get_phone_number",
  {
    title: "Get Amazon Chime phone number",
    description: "Read details for one Amazon Chime phone number by E.164 number or phone-number ID.",
    inputSchema: { phone_number: z.string().min(1), region: z.string().optional() },
    outputSchema: toolOutputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: true },
  },
  async ({ phone_number, region }) => {
    scopedAudit("aws_chime_get_phone_number", { phone_number, region });
    try {
      const data = await getAwsChimePhoneNumber({ phoneNumber: phone_number, region });
      return scopedSuccess(data, { provider: "AWS", service: "ChimeSDKVoice", operation: "GetPhoneNumber" },
        `Returned Amazon Chime phone number '${phone_number}'.`);
    } catch (error) { return failure(error, "AWS read"); }
  }
);

server.registerTool(
  "aws_chime_list_phone_number_orders",
  {
    title: "List Amazon Chime phone number orders",
    description: "List phone-number orders and statuses.",
    inputSchema: { region: z.string().optional(), max_results: z.number().int().min(1).max(99).default(20), next_token: z.string().optional() },
    outputSchema: toolOutputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: true },
  },
  async ({ region, max_results, next_token }) => {
    scopedAudit("aws_chime_list_phone_number_orders", { region, max_results });
    try {
      const data = await listAwsChimePhoneNumberOrders({ region, maxResults: max_results, nextToken: next_token });
      return scopedSuccess(data, { provider: "AWS", service: "ChimeSDKVoice", operation: "ListPhoneNumberOrders" },
        `Returned ${data.orders.length} Amazon Chime phone-number orders.`);
    } catch (error) { return failure(error, "AWS read"); }
  }
);

server.registerTool(
  "aws_chime_get_phone_number_order",
  {
    title: "Get Amazon Chime phone number order",
    description: "Read one phone-number order by order ID.",
    inputSchema: { order_id: z.string().min(1), region: z.string().optional() },
    outputSchema: toolOutputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: true },
  },
  async ({ order_id, region }) => {
    scopedAudit("aws_chime_get_phone_number_order", { order_id, region });
    try {
      const data = await getAwsChimePhoneNumberOrder({ orderId: order_id, region });
      return scopedSuccess(data, { provider: "AWS", service: "ChimeSDKVoice", operation: "GetPhoneNumberOrder" },
        `Returned Amazon Chime phone-number order '${order_id}'.`);
    } catch (error) { return failure(error, "AWS read"); }
  }
);

if (adminMode) {
  server.registerTool(
    "aws_chime_plan_create_voice_connector",
    {
      title: "Plan Amazon Chime Voice Connector creation",
      description: "Create an expiring guarded plan. This does not change AWS.",
      inputSchema: {
        name: z.string().min(1).max(256),
        deployment_country: z.string().min(2),
        region: z.string().optional(),
        require_encryption: z.boolean().default(true),
        network_type: z.enum(["IPV4_ONLY", "DUAL_STACK"]).default("IPV4_ONLY"),
      },
      outputSchema: toolOutputSchema,
      annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: true },
    },
    async ({ name, deployment_country, region, require_encryption, network_type }) => {
      scopedAudit("aws_chime_plan_create_voice_connector", { name, deployment_country, region, require_encryption, network_type });
      try {
        const data = await planAwsChimeCreateVoiceConnector({
          actor, name, deploymentCountry: deployment_country, region,
          requireEncryption: require_encryption, networkType: network_type,
        });
        return scopedSuccess(data, { provider: "AWS", service: "ChimeSDKVoice", operation: "PLAN CreateVoiceConnector" },
          `Planned Amazon Chime Voice Connector '${name}'. Review and apply only with the exact confirmation.`);
      } catch (error) { return failure(error, "AWS plan"); }
    }
  );


  server.registerTool(
    "aws_chime_plan_order_phone_number",
    {
      title: "Plan Amazon Chime phone number order",
      description: "Create an expiring guarded plan to order one available phone number. Does not change AWS.",
      inputSchema: { phone_number: z.string().min(1), region: z.string().optional() },
      outputSchema: toolOutputSchema,
      annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: true },
    },
    async ({ phone_number, region }) => {
      scopedAudit("aws_chime_plan_order_phone_number", { phone_number, region });
      try {
        const data = await planAwsChimeOrderPhoneNumber({ actor, phoneNumber: phone_number, region });
        return scopedSuccess(data, { provider: "AWS", service: "ChimeSDKVoice", operation: "PLAN CreatePhoneNumberOrder" },
          `Planned order of '${phone_number}'.`);
      } catch (error) { return failure(error, "AWS plan"); }
    }
  );

  server.registerTool(
    "aws_chime_plan_assign_phone_number",
    {
      title: "Plan Amazon Chime phone number assignment",
      description: "Create an expiring guarded plan to assign an owned phone number to a Voice Connector. ForceAssociate is always false.",
      inputSchema: { phone_number: z.string().min(1), voice_connector_id: z.string().min(1), region: z.string().optional() },
      outputSchema: toolOutputSchema,
      annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: true },
    },
    async ({ phone_number, voice_connector_id, region }) => {
      scopedAudit("aws_chime_plan_assign_phone_number", { phone_number, voice_connector_id, region });
      try {
        const data = await planAwsChimeAssignPhoneNumber({ actor, phoneNumber: phone_number, voiceConnectorId: voice_connector_id, region });
        return scopedSuccess(data, { provider: "AWS", service: "ChimeSDKVoice", operation: "PLAN AssociatePhoneNumbersWithVoiceConnector" },
          `Planned assignment of '${phone_number}' to Voice Connector '${voice_connector_id}'.`);
      } catch (error) { return failure(error, "AWS plan"); }
    }
  );


  server.registerTool(
    "aws_chime_plan_set_termination_credentials",
    {
      title: "Plan Amazon Chime termination credentials",
      description: "Create an expiring guarded plan to set or replace SIP termination credentials on one Voice Connector. The password is never returned in clear text and is redacted from audit output.",
      inputSchema: {
        voice_connector_id: z.string().min(1),
        username: z.string().min(1).max(256),
        password: z.string().min(8).max(256),
        region: z.string().optional(),
      },
      outputSchema: toolOutputSchema,
      annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: true },
    },
    async ({ voice_connector_id, username, password, region }) => {
      scopedAudit("aws_chime_plan_set_termination_credentials", {
        voice_connector_id, username, password: "[REDACTED]", region
      });
      try {
        const data = await planAwsChimeSetTerminationCredentials({
          actor, voiceConnectorId: voice_connector_id, username, password, region
        });
        return scopedSuccess(
          data,
          { provider: "AWS", service: "ChimeSDKVoice", operation: "PLAN PutVoiceConnectorTerminationCredentials" },
          `Planned Amazon Chime termination credential update for '${username}' on '${voice_connector_id}'.`
        );
      } catch (error) { return failure(error, "AWS plan"); }
    }
  );

  server.registerTool(
    "aws_chime_plan_update_termination",
    {
      title: "Plan Amazon Chime termination update",
      description: "Create an expiring guarded plan to update Voice Connector termination settings such as calling regions, allowed CIDRs, CPS limit, default phone number, or disabled state.",
      inputSchema: {
        voice_connector_id: z.string().min(1),
        calling_regions: z.array(z.string().min(1)).optional(),
        cidr_allowed_list: z.array(z.string().min(1)).optional(),
        cps_limit: z.number().int().min(1).max(100).optional(),
        default_phone_number: z.string().optional(),
        disabled: z.boolean().optional(),
        region: z.string().optional(),
      },
      outputSchema: toolOutputSchema,
      annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: true },
    },
    async ({ voice_connector_id, calling_regions, cidr_allowed_list, cps_limit, default_phone_number, disabled, region }) => {
      scopedAudit("aws_chime_plan_update_termination", {
        voice_connector_id, calling_regions, cidr_allowed_list, cps_limit,
        default_phone_number, disabled, region
      });
      try {
        const data = await planAwsChimeUpdateTermination({
          actor, voiceConnectorId: voice_connector_id, callingRegions: calling_regions,
          cidrAllowedList: cidr_allowed_list, cpsLimit: cps_limit,
          defaultPhoneNumber: default_phone_number, disabled, region
        });
        return scopedSuccess(
          data,
          { provider: "AWS", service: "ChimeSDKVoice", operation: "PLAN PutVoiceConnectorTermination" },
          `Planned Amazon Chime termination update for '${voice_connector_id}'.`
        );
      } catch (error) { return failure(error, "AWS plan"); }
    }
  );

  server.registerTool(
    "aws_chime_plan_update_origination",
    {
      title: "Plan Amazon Chime origination update",
      description: "Create an expiring guarded plan to update Voice Connector origination routes toward the PBX.",
      inputSchema: {
        voice_connector_id: z.string().min(1),
        disabled: z.boolean().optional(),
        routes: z.array(z.object({
          host: z.string().min(1),
          port: z.number().int().min(1).max(65535).default(5060),
          priority: z.number().int().min(1).max(100).default(1),
          protocol: z.enum(["TCP","UDP"]).default("TCP"),
          weight: z.number().int().min(1).max(100).default(1),
        })).optional(),
        region: z.string().optional(),
      },
      outputSchema: toolOutputSchema,
      annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: true },
    },
    async ({ voice_connector_id, disabled, routes, region }) => {
      scopedAudit("aws_chime_plan_update_origination", {
        voice_connector_id, disabled, routes, region
      });
      try {
        const data = await planAwsChimeUpdateOrigination({
          actor, voiceConnectorId: voice_connector_id, disabled, routes, region
        });
        return scopedSuccess(
          data,
          { provider: "AWS", service: "ChimeSDKVoice", operation: "PLAN PutVoiceConnectorOrigination" },
          `Planned Amazon Chime origination update for '${voice_connector_id}'.`
        );
      } catch (error) { return failure(error, "AWS plan"); }
    }
  );

  server.registerTool(
    "aws_chime_apply_change",
    {
      title: "Apply planned Amazon Chime change",
      description: "Apply one unchanged, unexpired AWS Chime plan. Phase 2 supports guarded Voice Connector creation.",
      inputSchema: { change_id: z.string().min(1), confirmation: z.string().min(1) },
      outputSchema: toolOutputSchema,
      annotations: { readOnlyHint: false, destructiveHint: false, openWorldHint: true },
    },
    async ({ change_id, confirmation }) => {
      scopedAudit("aws_chime_apply_change", { change_id });
      try {
        const data = await applyAwsChimeChange({ actor, changeId: change_id, confirmation });
        scopedAudit("aws_chime_change_applied", {
          change_id, operation: data.operation, region: data.region,
          voice_connector_id: data.voiceConnector?.voiceConnectorId || null,
          name: data.voiceConnector?.name || null,
        });
        return scopedSuccess(data, { provider: "AWS", service: "ChimeSDKVoice", operation: data.operation },
          `Applied AWS Chime change '${change_id}'.`);
      } catch (error) { return failure(error, "AWS write"); }
    }
  );
}


server.registerTool(
  "pbx_ai_get_workflow_catalog",
  {
    title: "Get AI PBX workflow catalog",
    description: "Describe the high-level PBX operational workflows, safe defaults, approval model, and tool families that the MCP knows. Use this to turn natural-language administrator requests into consistent PBX workflows.",
    inputSchema: {},
    outputSchema: toolOutputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
  },
  async () => {
    scopedAudit("pbx_ai_get_workflow_catalog", {});
    try {
      const data = getAiWorkflowCatalog();
      return scopedSuccess(
        data,
        { operation: "AI_WORKFLOW_CATALOG" },
        "Returned the Vodia MCP AI workflow catalog."
      );
    } catch (error) {
      return failure(error, "workflow catalog");
    }
  }
);

server.registerTool(
  "pbx_ai_prepare_workflow",
  {
    title: "Prepare AI PBX workflow",
    description: "Turn a natural-language PBX administrator request into a structured, read-first workflow with recommended defaults, missing inputs, user choices, approval boundaries, verification goals, and relevant MCP tool families. For Amazon Chime, this also performs live AWS discovery when enough context is supplied. This tool never changes the PBX or AWS.",
    inputSchema: {
      request: z.string().min(1).max(2000),
      tenant: z.string().optional(),
      country: z.string().optional(),
      area_code: z.string().optional(),
      provider: z.string().optional(),
      region: z.string().optional(),
    },
    outputSchema: toolOutputSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: true },
  },
  async ({ request, tenant, country, area_code, provider, region }) => {
    scopedAudit("pbx_ai_prepare_workflow", {
      request,
      tenant,
      country,
      area_code,
      provider,
      region,
    });
    try {
      const data = await prepareAiWorkflow({
        request,
        tenant,
        country,
        areaCode: area_code,
        provider,
        region,
      });
      return scopedSuccess(
        data,
        { operation: "AI_PREPARE_WORKFLOW" },
        `Prepared ${data.workflow.id} workflow. No changes were made.`
      );
    } catch (error) {
      return failure(error, "workflow preparation");
    }
  }
);

server.registerTool(
  "get_connector_info",
  {
    title: "Get Vodia connector information",
    description: "Show connector version, API catalog coverage and enforced safety limits.",
    inputSchema: {},
    outputSchema: toolOutputSchema,
    annotations: {
      readOnlyHint: true,
      destructiveHint: false,
      openWorldHint: false,
    },
  },
  async () => {
    scopedAudit("get_connector_info");
    return scopedSuccess(
      {
        connectorVersion: CONNECTOR_VERSION,
        mode: approvalMode ? "learning-approval-only" : adminMode ? "policy-controlled-full-admin" : "strict-read-only",
        vodiaApiVersion: catalog.vodiaApiVersion,
        totalGetOperations: catalog.totalGetOperations,
        callableOperations: catalog.callableOperations,
        blockedOperations: catalog.blockedOperations,
        responseLimitBytes: RESPONSE_LIMIT_BYTES,
        redactionApplied: true,
        tenantRestrictionsEnabled: ALLOWED_DOMAINS.size > 0,
        allowedDomains: [...ALLOWED_DOMAINS],
        persistentAuditLogEnabled: Boolean(AUDIT_LOG_PATH),
        awsChime: getAwsChimeConfig(),
        ...(adminMode || approvalMode ? { admin: getAdminRuntimeInfo() } : {}),
      },
      { source: catalog.source },
      "Returned Vodia connector coverage and safety information."
    );
  }
);

if (adminMode) {
  registerAdminTools(server, { audit: scopedAudit, success: scopedSuccess, failure, redactSensitive, callOperation: callOperationRaw, actor });
  registerLearningApprovalTools(server, { audit: scopedAudit, success: scopedSuccess, failure, actor });
}
if (approvalMode) {
  registerLearningApprovalTools(server, { audit: scopedAudit, success: scopedSuccess, failure, actor });
}

return server;
}

export function getRuntimeInfo(accessMode = "read") {
  return {
    connectorVersion: CONNECTOR_VERSION,
    mode: accessMode === "approver" ? "learning-approval-only" : accessMode === "admin" ? "policy-controlled-full-admin" : "strict-read-only",
    pbxUrl: PBX_URL,
    apiUser: PBX_USER,
    vodiaApiVersion: catalog.vodiaApiVersion,
    totalGetOperations: catalog.totalGetOperations,
    callableOperations: catalog.callableOperations,
    blockedOperations: catalog.blockedOperations,
    responseLimitBytes: RESPONSE_LIMIT_BYTES,
    tenantRestrictionsEnabled: ALLOWED_DOMAINS.size > 0,
    allowedDomains: [...ALLOWED_DOMAINS],
    persistentAuditLogEnabled: Boolean(AUDIT_LOG_PATH),
    ...(accessMode === "admin" || accessMode === "approver" ? { admin: getAdminRuntimeInfo() } : {}),
  };
}

async function startStdio() {
  const server = createVodiaServer();
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error(
    `[vodia-mcp] connected read-only endpoint. PBX=${PBX_URL} ` +
      `VodiaAPI=${catalog.vodiaApiVersion} GET=${catalog.callableOperations}/${catalog.totalGetOperations}`
  );
}

const invokedPath = process.argv[1] ? pathToFileURL(resolve(process.argv[1])).href : "";
if (invokedPath === import.meta.url) {
  await startStdio();
}
